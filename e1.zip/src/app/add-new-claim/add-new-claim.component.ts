import {
  Component, OnInit, ViewChild, AfterViewInit, ViewEncapsulation,
  ViewChildren, QueryList, Output, EventEmitter, OnDestroy,ElementRef 
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TypeOfEventsComponent } from './type-of-events/type-of-events.component';
import { PersonalDetailsComponent } from './personal-details/personal-details.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { AttachmentsComponent } from './attachments/attachments.component';
import { ReviewDetailsComponent } from './review-details/review-details.component';
import { FormBuilder, FormGroup, FormControl, FormArray, NgForm, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material';
import { InsuranceReferSecComponent } from './personal-details/insurance-refer-sec/insurance-refer-sec.component';
import { EclaimsModel } from './models/EclaimsModel';
import { SubmitClaimPopulateDeatils } from './populate-new-claim-submit-details';
import { HttpCommonService } from '../shared/services/http-common.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { ClaimAttachmentModel } from './models/ClaimAttachmentModel';
import { NewClaimSharedService } from './add-new-claim.service';
import { ActivatedRoute } from '@angular/router';

import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { DataService } from '../shared/services/data.service';
import * as utils from 'lodash';
import { ScreenRenderReqModel } from './models/ScreenRenderReqModel';

import { AlertDialogComponent } from '../shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from '../shared/services/dialog.service';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { DeviceDetectorService } from 'ngx-device-detector';
//import { ErrorPageComponent } from '../error-page/error-page.component';
import { ErrorDialogComponent } from '../shared/dialog/error-dialog/error-dialog.component';

@Component({
  selector: 'add-new-claim',
  templateUrl: './add-new-claim.component.html',
  styleUrls: ['./add-new-claim.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [{
    provide: STEPPER_GLOBAL_OPTIONS, useValue: { showError: true }
  }]
})
export class AddNewClaimComponent implements OnInit, AfterViewInit, OnDestroy {
  typeOfEventForm: FormGroup;
  attachmentForm: FormGroup;
  personalForm: FormGroup;
  eventForm: FormGroup;
  reviewForm: FormGroup;
  previouslySelectedstep = [];
  eclaimsObj: EclaimsModel = new EclaimsModel();
  populateDetailsObj: SubmitClaimPopulateDeatils =
    new SubmitClaimPopulateDeatils(this.translate, this._formBuilder, this.httpService, this.newClaimService,
      this.dataService);
  isStepInteracted = false;
  reviewSecError = false;
  eventDetailsSecError = false;
  personalDetailsSecError = false;
  typeOfEventSecError = false;
  attachmentSecError = false;
  addtionalCommentsShow = false;

  disableConfirmation = true;
  claimTabIndex = this.disableConfirmation ? 0 : 1;

  @ViewChild(TypeOfEventsComponent, { static: false }) typeOfEventRefComp: TypeOfEventsComponent;
  @ViewChild(PersonalDetailsComponent, { static: false }) personalDetailsRefComp: PersonalDetailsComponent;
  @ViewChild(InsuranceReferSecComponent, { static: false }) insuranceRefComp: InsuranceReferSecComponent;
  @ViewChild(EventDetailsComponent, { static: false }) eventDetailsComp: EventDetailsComponent;

  @ViewChild(AttachmentsComponent, { static: false }) attachmentsComp: AttachmentsComponent;
  @ViewChild('stepper', { static: false }) stepper: MatStepper;

  // @ViewChildren(EventDetailsComponent) myValue: QueryList<EventDetailsComponent>

  @ViewChild(ReviewDetailsComponent, { static: false }) reviewDetailsComp: ReviewDetailsComponent;

  claimAttachmentModel: Array<ClaimAttachmentModel> = new Array();
  typeOfEventLobOldValue = "";
  primaryClaimEventOldValue = "";
  eventRelatedOldValue = '';
  insuranceReferOldValue = '';
  capcityOldValue = '';
  policeConductedInvestigationOldVal = '';
  employerPreAccidentRepOldVal = '';
  sportsClubPlayerOldValue = '';

  dedicatedOperationKey = [];

  // Event fired after view is initialized
  headers = new HttpHeaders();
  screenRequestObj: ScreenRenderReqModel = new ScreenRenderReqModel();
  jsonObj = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.jsonObj.sourceOrigin;
  loggedinuserName: string = this.jsonObj.userName;
  screenName1: string = 'ComponentsBySourceOfOrigin';
  partner: string = 'metlife';
  renderClaimSections: any = null;

  private claimNo: string = '126888';

  step = 0;
  formDetails: any;
  countryList: any;
  eventTypeList: any;

  showNewClaim: boolean;
  saveClaimsResponse: any;
  redirectFromReportClaim = false;
  generatedClaimNo:any=null;
  formDetailsOrigin = [
    {
      "form": "typeOfEventForm",
      "initFunc": "formInit",
      "formRef": "typeOfEventRefComp",
      "submit": "formSubmit",
      "error": "typeOfEventSecError",
      "nameInResponse": "TypeOfEvent",
      "calledOnce": false
    },
    {
      "form": "personalForm",
      "initFunc": "formInit",
      "formRef": "personalDetailsRefComp",
      "submit": "formSubmit",
      "error": "personalDetailsSecError",
      "nameInResponse": "PersonalDetails",
      "calledOnce": false
    },
    {
      "form": "eventDetailForm",
      "initFunc": "formInit",
      "formRef": "eventDetailsComp",
      "submit": "formSubmit",
      "error": "eventDetailsSecError",
      "nameInResponse": "EventDetails",
      "calledOnce": false
    },
    {
      "form": "attachmentForm",
      "initFunc": "formInit",
      "formRef": "attachmentsComp",
      "submit": "formSubmit",
      "error": "attachmentSecError",
      "nameInResponse": "Attachments",
      "calledOnce": false
    },
    {
      "form": "reviewForm",
      "initFunc": "formInit",
      "formRef": "reviewDetailsComp",
      "submit": "formSubmit",
      "error": "reviewSecError",
      "nameInResponse": "Review",
      "calledOnce": false
    }
  ];

  constructor(private translate: TranslateService, private _formBuilder: FormBuilder,
    private httpService: HttpCommonService, private router: Router, 
    public dataService: DataService,
    public newClaimService: NewClaimSharedService, private route: ActivatedRoute,
     public dialogService: DialogService,
     public myElement: ElementRef,
     public deviceDetector:DeviceDetectorService
  ) { 
    this.dataService.setOption('uploadNewClaimList', {});
  }


  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    //this.dialogService.openDialog(ErrorDialogComponent, { 'heading': 'Error'});
    this.eventTypes();
    this.typeOfEventForm = this._formBuilder.group({
    });
    this.attachmentForm = this._formBuilder.group({
    });

    this.personalForm = this._formBuilder.group({
    });
    this.eventForm = this._formBuilder.group({

    });
    this.reviewForm = this._formBuilder.group({

    });
    //if (!this.newClaimService.getParamValue('countryList')) {
    //console.log("this.route.snapshot.data.countryList",this.route.snapshot.data)  
    this.newClaimService.setParamValue('countryList', this.route.snapshot.data.countryList);
    this.newClaimService.setCountryList(this.route.snapshot.data.countryList);
    //set component display
    this.newClaimService.triggerShowClaimCompApi().subscribe(data => {
      //console.log('subject Data :', data);
      this.showNewClaim = !data;
      this.stepper.selectedIndex = 0;
      this.redirectFromReportClaim = true;
      this.stepperReset()
         
    });

    this.showNewClaim = true;
    this.redirectFromReportClaim = false;
    this.generatedClaimNo =null;
  }

stepperReset(){
  this.personalDetailsSecError = false;
  this.eventDetailsSecError = false;
  this.attachmentSecError = false;
  this.reviewSecError = false;
  if(this.stepper && this.stepper.reset){
    this.stepper.reset();
  }
  
}

  validateTypeOfEvent(id) {
    this.typeOfEventRefComp.submitEventType();
    if (this.typeOfEventRefComp.typeOfEventForm.valid) {
      this.nextStep(id);
      
    }
    ////console.log("this.typeOfEventRefComp.typeOfEventForm",this.typeOfEventRefComp.typeOfEventForm);
  }

  validatePersonalDetails(id) {
    this.personalDetailsRefComp.formSubmit();
    this.nextStep(id);
  }

  validateEventDetails(id) {
    this.eventDetailsComp.setEventDetails();
    this.eventDetailsComp.formSubmit();
    this.nextStep(id);
  }

  validateAttachmentSection(id) {
    this.attachmentsComp.formSubmit();
    this.nextStep(id);
  }


  setStep(index: number) {
    this.step = index;
  }

  nextStep(id) {
   // console.log("next step", this.typeOfEventRefComp.typeOfEventForm.value);
    this.stepper.selected.completed = true;
    this.stepper.selectedIndex = this.stepper.selectedIndex + 1;
   if(this.isMobile){
    this.setFocus(id);
   }else{
    window.scroll(0,0);
   }
    
  }

  prevStep() {
    this.step--;
  }
  targetInput : any = null;
  setFocus(id) {
   let targetElem = document.getElementById(id);
  // targetElem.scrollIntoView();
   //targetElem.focus();
    setTimeout(function waitTargetElem() {
     if (targetElem) {
      targetElem.scrollIntoView();
     } else {
       setTimeout(waitTargetElem, 100);
     }
   }, 100);
 }
  personalFormCompleted(event) {
    this.gotoStep(3);
  }

  callSubCompFormSubmit() {

    let newClaimSubCompSubmit = true;
    let submitFormValid = true;
    for (let i = 0; i < this.formDetails.length; i++) {

      if (this[this.formDetails[i].formRef] && this[this.formDetails[i].formRef][this.formDetails[i].submit]) {
        let newClaimSubCompSubmit = this[this.formDetails[i].formRef][this.formDetails[i].submit]();
        // console.log(newClaimSubCompSubmit, this[this.formDetails[i].formRef])

        this[this.formDetails[i].error] = !newClaimSubCompSubmit;

        /*  if (!newClaimSubCompSubmit) {
            return false;
          }
  */
        if (!newClaimSubCompSubmit) {
          submitFormValid = false;
        }

      } else {
        submitFormValid = false;
        this[this.formDetails[i].error] = true;
      }

    }
    return submitFormValid;
  }

  comparePrimaryClaimArr(olArr, newArr) {
    for (let i = 0; i < newArr.length; i++) {
      if (olArr.indexOf(newArr[i]) == -1) {
        return true;
      }
    }

    return false;
  }
  onStepChange(event) {
    let formDetailClone = this.formDetails[event.selectedIndex];
    let claimData = this.newClaimService.getClaimData();
    let primaryClaimType = this.newClaimService.getPrimaryClaimType();
    if (event.selectedIndex == 0) {

      this.typeOfEventLobOldValue = this.typeOfEventRefComp.typeOfEventForm.value.newclaim;
      this.primaryClaimEventOldValue = primaryClaimType;
    }
   
    if (event.previouslySelectedIndex == 0) {
      if ((this.typeOfEventLobOldValue != this.typeOfEventRefComp.typeOfEventForm.value.newclaim)
        || this.comparePrimaryClaimArr(this.primaryClaimEventOldValue, this.typeOfEventRefComp.typeOfEventForm.value.claimTypeCode)) {
        
        //  this.stepperReset();
          for (let i = 0; i < this.formDetails.length; i++) {
          this.formDetails[i].calledOnce = false;
        }

      }
    }


    if (this.formDetails) {
      let i = event.selectedIndex;
      if ((!this.formDetails[i].calledOnce) && this[this.formDetails[i].formRef] && this[this.formDetails[i].formRef][this.formDetails[i].initFunc]) {

        try {
          this[this.formDetails[i].formRef][this.formDetails[i].initFunc]();
          this.formDetails[i].calledOnce = true;
        }
        catch (e) {
          console.log(e);
        }

      }

    }


    this.getSectionOldValue(event.selectedIndex);
    if (event.previouslySelectedIndex == 2 || event.previouslySelectedIndex == 1) {
      if ((this.eventDetailsComp && this.eventDetailsComp.eventDetailForm.value && this.eventDetailsComp.eventDetailForm.value.eventInformationSection &&
        this.eventDetailsComp.eventDetailForm.value.eventInformationSection.eventRelatedTo != undefined && this.eventRelatedOldValue != this.eventDetailsComp.eventDetailForm.value.eventInformationSection.eventRelatedTo) ||
        (this.personalDetailsRefComp.insuranceRefComp && this.personalDetailsRefComp.insuranceRefComp.insureForm.value.insuranceEventRefersTo !== null && this.insuranceReferOldValue !== this.personalDetailsRefComp.insuranceRefComp.insureForm.value.insuranceEventRefersTo) ||
        (this.personalDetailsRefComp.personalForm.value.entitledForBenefitsSection && this.personalDetailsRefComp.personalForm.value.entitledForBenefitsSection.capacity != undefined && this.capcityOldValue !==
          this.personalDetailsRefComp.personalForm.value.entitledForBenefitsSection.capacity) || this.questionarieStatus()) {
        if (this[formDetailClone.formRef][formDetailClone.initFunc] && formDetailClone.formRef == "attachmentsComp") {
          //  event.selectedIndex == 3
          // && event.previouslySelectedIndex == 0
          this[formDetailClone.formRef][formDetailClone.initFunc]();
        }

      }
    }
    if (event.selectedIndex == 4) {
      // || event.selectedIndex == 3
      if (this[formDetailClone.formRef][formDetailClone.initFunc]) {
        // && event.previouslySelectedIndex == 0
        this[formDetailClone.formRef][formDetailClone.initFunc]();
      }
    }

    //    //console.log(this[formDetailClone.formRef][formDetailClone.initFunc])
    ////console.log(event.selected);

    if (!this.previouslySelectedstep.indexOf(event.previouslySelectedIndex)) {
      this.previouslySelectedstep.push(event.previouslySelectedIndex);
      ////console.log(event)
    }
    // if (event.selectedIndex === 2)
    //   this.eventDetailsComp.eventDetailsRender();

    /*console.log(this[this.formDetails[event.previouslySelectedIndex].formRef]
    [this.formDetails[event.previouslySelectedIndex].form], "this[this.formDetails[event.previouslySelectedIndex].formRef");*/
    /*this[this.formDetails[event.previouslySelectedIndex].error] = false;
    if (this[this.formDetails[event.previouslySelectedIndex].formRef]
    [this.formDetails[event.previouslySelectedIndex].form]) {
      this[this.formDetails[event.previouslySelectedIndex].error] = true;
    }
*/

    for (let i = 0; i < this.formDetails.length; i++) {

      if ((event.previouslySelectedIndex === i) && this[this.formDetails[i].formRef] &&
        this[this.formDetails[i].formRef][this.formDetails[i].submit]) {
        let newClaimSubCompSubmit = this[this.formDetails[i].formRef][this.formDetails[i].submit]();
        // console.log(newClaimSubCompSubmit, this[this.formDetails[i].formRef])
        this[this.formDetails[i].error] = !newClaimSubCompSubmit;

      }

    }

    if (event.previouslySelectedIndex == 0) {
      if ((this.typeOfEventLobOldValue != this.typeOfEventRefComp.typeOfEventForm.value.newclaim)
        || this.comparePrimaryClaimArr(this.primaryClaimEventOldValue, this.typeOfEventRefComp.typeOfEventForm.value.claimTypeCode)) {
        if (this.redirectFromReportClaim) {
          // this.personalDetailsSecError = false;
          // this.eventDetailsSecError = false;
          // this.attachmentSecError = false;
          // this.reviewSecError = false;
          
          // this.stepper.reset();
         
          //let isSubmitValid = this.callSubCompFormSubmit();
        }
      }
    }

  }


  questionarieStatus() {
    if (this.eventDetailsComp) {
      if (this.eventDetailsComp.eventDetailForm &&
        this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection && this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.policeConductedInvestigation !== null && this.policeConductedInvestigationOldVal !== this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.policeConductedInvestigation) {
        // && this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.policeConductedInvestigation == 'yes'
        return true;
      }

      if (this.eventDetailsComp.eventDetailForm &&
        this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection &&
        this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.employerPreparedAccidentReport !== null && this.employerPreAccidentRepOldVal !== this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.employerPreparedAccidentReport) {
        // && this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.employerPreparedAccidentReport == 'yes'
        return true;
      }
      if (this.eventDetailsComp.eventDetailForm &&
        this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection &&
        this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.sportsClubPlayerDropDown !== null && this.sportsClubPlayerOldValue !== this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.sportsClubPlayerDropDown) {
        // && this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.sportsClubPlayerDropDown == 'yes'
        return true;
      }
    }
  }

  getSectionOldValue(selectedIndex) {
    if (selectedIndex == 2) {
      if (this.eventDetailsComp) {
        this.eventRelatedOldValue = (this.eventDetailsComp.eventDetailForm && this.eventDetailsComp.eventDetailForm.value &&
          this.eventDetailsComp.eventDetailForm.value.eventInformationSection) ?
          this.eventDetailsComp.eventDetailForm.value.eventInformationSection.eventRelatedTo : '';
        this.policeConductedInvestigationOldVal = (this.eventDetailsComp.eventDetailForm && this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection
          && this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.policeConductedInvestigation != undefined) ?
          this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.policeConductedInvestigation : '';
        this.employerPreAccidentRepOldVal = (this.eventDetailsComp.eventDetailForm && this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection
          && this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.employerPreparedAccidentReport != undefined) ?
          this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.employerPreparedAccidentReport : '';
        this.sportsClubPlayerOldValue = (this.eventDetailsComp.eventDetailForm && this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection &&
          this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.sportsClubPlayerDropDown != undefined) ?
          this.eventDetailsComp.eventDetailForm.value.additionalFieldDetailsSection.sportsClubPlayerDropDown : '';
      }
    }
    if (selectedIndex === 1) {
      this.insuranceReferOldValue = (this.personalDetailsRefComp.insuranceRefComp &&
        this.personalDetailsRefComp.insuranceRefComp.insureForm) ?
        this.personalDetailsRefComp.insuranceRefComp.insureForm.value.insuranceEventRefersTo : '';
      this.capcityOldValue = (this.personalDetailsRefComp &&
        this.personalDetailsRefComp.personalForm.value.entitledForBenefitsSection) ?
        this.personalDetailsRefComp.personalForm.value.entitledForBenefitsSection.capacity : '';
    }
  }


  eventTypes() {

    this.componentSoucreOrigin();
    this.httpService[environment.typeOfEventServiceConfig.method](
      (environment.host + environment.typeOfEventServiceConfig.screenInfoUrl)
      , this.screenRequestObj, this.headers).
      subscribe((response) => {
        //console.log("=========== >", response)

        let eventTypeClaim = response.lobsRendered ? response.lobsRendered.split("|") : [];
        this.newClaimService.setParamValue('lobsRendered', eventTypeClaim);
        this.newClaimService.setParamValue('renderClaimSections', response);
        this.renderClaimSections = response;
        //this[this.formDetails[0].formRef][this.formDetails[0].initFunc]();
        /*setTimeout(() => {
          this.stepper.selectedIndex = 0;
        }, 0);*/
        this.formDetails = JSON.parse(JSON.stringify(this.formDetailsOrigin));


        for (let i = this.formDetails.length - 1; i >= 0; i--) {
          if (response.breadCrumbsRendered.indexOf(this.formDetails[i].nameInResponse) == -1) {
            this.formDetails.splice(i, 1)
          }
        }

        /* for (let i = 0; i < this.formDetails.length; i++) {
           if (response.breadCrumbsRendered.indexOf(this.formDetails[i].nameInResponse) == -1) {
             this.formDetails.splice(i, 1)
           }
         }*/
      })
  }
  componentSoucreOrigin() {
    this.screenRequestObj.sourceOfOrigin = this.sourceOfOrigin;
    this.screenRequestObj.partner = this.partner;
    this.screenRequestObj.screenName = this.screenName1;
  }

  ngAfterViewInit() {
    //this.stepper.selectedIndex = 1; 

    // To avoid "ExpressionChangedAfterItHasBeenCheckedError" error, 
    // set the index in setTimeout 
    /*setTimeout(() => {
      this.stepper.selectedIndex = 0;
    }, 0);*/
    //this.eventTypes();
    // this.typeOfEventRefComp.eventTypes();
    //this.showNewClaim = true;
  }

  gotoStep(step) {
    this.stepper.selectedIndex = step;
  }

  /*typofEventsClick(obj) {
    if (obj.srcElement.outerText === "Type of Event")
      this.typeOfEventRefComp.eventTypes(obj);

  }*/
callAttachmentsFunc(generatedClaimNo){
  if (generatedClaimNo) {
    let attachmentReference: any = null;
    if (this.renderClaimSections.tab2AttachmentsSection.renderFlag) {

      attachmentReference = this.personalDetailsRefComp.attachmentsComp;
    } else {
      attachmentReference = this.attachmentsComp;
    }
    this.attachmentFiles(this.typeOfEventRefComp, attachmentReference, generatedClaimNo);
  }
}
  onSubmit() {

    // console.log(this.newClaimService.getCountryList());*

    let isSubmitValid = this.callSubCompFormSubmit();
    if (isSubmitValid) {
      const baseUrl = environment.host + environment.generateClaimServiceConfig.url;
      var hiddenhcCount_val = document.getElementById("hiddenhcCount");
      //const val = hiddenhcCount_val.getAttribute("hcCount");
    if(!this.generatedClaimNo || this.generatedClaimNo ==''){
      this.httpService[environment.generateClaimServiceConfig.method](baseUrl).
      subscribe((generatedClaimNo) => {
        ////console.log("======generatedClaimNo===== >", generatedClaimNo);
        this.generatedClaimNo = generatedClaimNo;
        this.callAttachmentsFunc(generatedClaimNo);

      },(err) => {console.log(err)
        this.dialogService.openDialog(ErrorDialogComponent, { 'heading': 'Error'});    
//        this.router.navigate(['/errorPage']);
      })
    }else if(this.generatedClaimNo && this.generatedClaimNo!=''){
      this.callAttachmentsFunc(this.generatedClaimNo);
    }
    
    } else {
      this.dialogService.openDialog(AlertDialogComponent, { 'heading': '', 'body': this.translate.instant('mandatoryErrorMsg'), 'primaryButton': 'OK' });
    }

  }

  attachmentFiles(typeOfEventRefComp, attachmentsComp, generatedClaimNo) {
    var headers = new HttpHeaders();
    let filesObject = new Map();
    let attachmentsFormData = new FormData();
    const typeofEventControl = typeOfEventRefComp.typeOfEventForm.controls;
    const lob = typeofEventControl.newclaim.value;
    const fileObjs = attachmentsComp.fileUploadModel;
    //const baseUrl = environment.host + environment.attachmentServiceConfig.url + generatedClaimNo + '/' + lob + '/files';
    const baseUrl = environment.host + environment.attachmentServiceConfig.url;
    //console.log("==attachmentFilesbaseUrl  ===== >", baseUrl);

    for (var index in fileObjs)
      filesObject.set(fileObjs[index].name, fileObjs[index].data)

    filesObject.forEach((value: File, key: string) => {
      attachmentsFormData.append('files', value, key)
    });

    let claimDetails={
      "claimNo" :generatedClaimNo,
      "lob": lob

    }
    attachmentsFormData.append('claimDetails', JSON.stringify(claimDetails));
    this.httpService[environment.attachmentServiceConfig.method](baseUrl, attachmentsFormData, headers).
      subscribe((attachmentResponse) => {

        //console.log("======attachmentResponse===== >", attachmentResponse);

        this.saveClaim(attachmentResponse, generatedClaimNo, attachmentsComp);
      },(err) => {console.log(err)
        this.dialogService.openDialog(ErrorDialogComponent, { 'heading': 'Error'});
      
//        this.router.navigate(['/errorPage']);
      })

  }

  saveClaim(attachmentResponse: any, claimNo: string, attachmentsComp?: any) {

    var headers = new HttpHeaders();
    ///let screenRequestObj = new ScreenRenderReqModel();
    const baseUrl = environment.host + environment.saveServiceConfig.url;
    this.claimAttachmentModel = [];
    let confimationCodes = this.newClaimService.getnewClaimConfirmationCodes();
    this.eclaimsObj = this.populateDetailsObj.populateSubmitClaimForm(this.typeOfEventRefComp,
      this.personalDetailsRefComp, this.eventDetailsComp,
      attachmentResponse, confimationCodes);
    this.newClaimService.setCNPFieldValue(this.eclaimsObj.personProposesClaimInfoVO.cnpFieldIndv);
    let documentTypesArray = attachmentsComp.documentTypes;
    let selectedFilesList = attachmentsComp.fileUploadModel;

    // for (let index = 0; index < selectedFilesList.length; index++) {
    //   const attachmentObj: ClaimAttachmentModel = new ClaimAttachmentModel();

    //   attachmentObj.fileName = selectedFilesList[index].name;
    //   attachmentObj.id = selectedFilesList[index].state;
    //   this.claimAttachmentModel.push(attachmentObj);
    //   //this.documentList.push(array[index].id);
    // }
    for (let indx = 0; indx < documentTypesArray.length; indx++) {

      // let value = this.claimAttachmentModel.find(x => x.id === documentTypesArray[indx].id);
      // if (!value) {
      const attachmentObj: ClaimAttachmentModel = new ClaimAttachmentModel();
      let str = documentTypesArray[indx].id;
      //     if (str.indexOf('_existing') > -1){
      attachmentObj.id = str.indexOf('_existing') > -1 ? str.substring(0, str.indexOf('_')) : str;
      attachmentObj.pdfDocumentType = str.indexOf('_existing') > -1 ? str.substring(0, str.indexOf('_')) : str;
      this.claimAttachmentModel.push(attachmentObj);

      // }

      // }

    }
    this.eclaimsObj.claimNumber = claimNo;
    
    
    this.eclaimsObj.userName=this.loggedinuserName;
    this.eclaimsObj.uploadedDocumentSecondaryList = this.claimAttachmentModel;

    //console.log("=========== >", this.eclaimsObj) 

    this.httpService[environment.saveServiceConfig.method](baseUrl, this.eclaimsObj, headers).
      subscribe((saveClaimsResponse) => {
        //this.dataService.setOption('uploadNewClaimList', {});
        this.generatedClaimNo = null;
        this.gotoDownloadConfirmation(saveClaimsResponse);
      },(err) => {console.log(err)
        this.dialogService.openDialog(ErrorDialogComponent, { 'heading': 'Error'});
     //  let errorMsg = this.translate.instant('eClaims.newClaim.claimSubmissionError')
     //   alert(errorMsg);
       // let confirmDownload = confirm(this.translate.instant('eClaims.existingClaim.confirmation.CacheWarning'));
    
    //    this.router.navigate(['/errorPage']);
      })

  }
  
  gotoTop(id) {

    this.myElement.nativeElement.ownerDocument.getElementById(id).scrollIntoView({behavior: 'smooth'});
  }
  
  
  
  
  gotoDownloadConfirmation(saveClaimsResponse) {
    this.showNewClaim = false;
    window.scroll(0,0);
    //this.newClaimService.setNewClaimResponse(saveClaimsResponse);
    this.newClaimService.updateSaveClaimResponseComponents(saveClaimsResponse);
    //this.router.navigate(['/submitNewClaimConfirmation'], saveClaimsResponse,);
  }

  changeSelection() {
    if (this.previouslySelectedstep.indexOf(0) && this.stepper && this.stepper['_selectedIndex'] !== 0) {
      return true;
    }
    return false;
  }

  changeSelection1() {
    if (this.previouslySelectedstep.indexOf(1) && this.stepper && this.stepper['_selectedIndex'] !== 1) {
      return true;
    }
    return false;
  }

  changeSelection2() {
    if (this.previouslySelectedstep.indexOf(2) && this.stepper && this.stepper['_selectedIndex'] !== 2) {
      return true;
    }
    return false;
  }
  changeSelection3() {
    if (this.previouslySelectedstep.indexOf(3) && this.stepper && this.stepper['_selectedIndex'] !== 3) {
      return true;
    }
    return false;
  }



  exitFromClaim() {
    this.router.navigate(['/landing']);
  }

  navigateToNewClaimSubmission() {
    this.router.navigate(['/submitNewClaimConfirmation']);
  }

  gotoSetClaimCompFlag(val) {
    this.showNewClaim = !val;
  }

  // onTabChanged(event) {
  //   this.claimTabIndex = event.index;
  //   if (event.index == 0) {
  //     this.disableConfirmation = true;
  //   }
  // }

  // getConfirmationFlag($event) {
  //   // //console.log($event);
  //   this.disableConfirmation = $event;
  //   this.claimTabIndex = this.disableConfirmation ? 0 : 1;
  // }
  ngOnDestroy() {

  }
}
