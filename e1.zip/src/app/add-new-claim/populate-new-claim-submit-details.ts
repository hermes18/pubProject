import { ClaimTypeModel } from './models/ClaimTypeModel';
import { EclaimsModel } from './models/EclaimsModel';
import { PersonProposesClaimInfoModel } from './models/PersonProposesClaimInfoModel';
import { PolicyNumberModel } from './models/PolicyNumberModel';
import { PersonInsuranceInfoModel } from './models/PersonInsuranceInfoModel';
import { ClaimCommunicationAddressModel } from './models/ClaimCommunicationAddressModel';
import { DisbursementBenefitModel } from './models/DisbursementBenefitModel';
import { EventInformationModel } from './models/EventInformationModel';
import { HealthCareCenterInfoModel } from './models/HealthCareCenterInfoModel';
import { HealthCareFamilyDocModel } from './models/healthCareFamilyDocModel';
import { ClaimAttachmentModel } from './models/ClaimAttachmentModel';
import { TranslateService } from '@ngx-translate/core';
import { HttpCommonService } from '../shared/services/http-common.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AdditionalFieldDetailsModel } from './models/AdditionalFieldDetailsModel';
import { HCAddressInfoModel } from './models/HCAddressInfoModel';
import { HCFamilyDocModel } from './models/HCFamilyDocModel';
import { AdditionalFieldAddressInfoModel } from './models/AdditionalFieldAddressInfoModel';
import { NewClaimSharedService } from './add-new-claim.service';
import { ScreenRenderReqModel } from './models/ScreenRenderReqModel';
import { DataService } from '../shared/services/data.service';

export class SubmitClaimPopulateDeatils {

    eclaimsObj: EclaimsModel = new EclaimsModel();
    resideneAddressSection: Array<ClaimCommunicationAddressModel> = new Array();
    healthCareFamilyDocModel: Array<HealthCareFamilyDocModel> = new Array();
    claimAttachmentModel: Array<ClaimAttachmentModel> = new Array();
    healthCareAddressInfoModel: Array<HCAddressInfoModel> = new Array();
    healthcareFamilyDocInfoModelList: Array<HCFamilyDocModel> = new Array();
    documentList: Array<any> = new Array();
    claimTypeList: Array<ClaimTypeModel> = new Array();
    policyList: Array<PolicyNumberModel> = new Array();
    confirmationTextList: Array<string> = new Array();
    additionalFieldAddrinfoModelList: Array<AdditionalFieldAddressInfoModel> = new Array();
    screenRequestObj: ScreenRenderReqModel = new ScreenRenderReqModel();
    constructor(private translate: TranslateService, private _formBuilder: FormBuilder,
        private httpService: HttpCommonService, public newClaimService: NewClaimSharedService,
        public dataService: DataService,) { }
    jsonObj = JSON.parse(sessionStorage.userData);
    sourceOfOrigin: string = this.jsonObj.sourceOrigin;
    defaultLanguage: string = this.jsonObj.defaultLanguage;
    langauageSelected = sessionStorage.getItem('defaultLanguage');
    lob: string = null;
    countryList = new Array();

    populateSubmitClaimForm(typeOfEventRefComp, personalDetailsRefComp,
        eventDetailsComp, attachmentResponse, confimationCodes) {

        this.newClaimService.getCountryList().subscribe((data) => {
            this.countryList = (data ? data : []);
        });

        this.clearobjvalues();
        if (typeOfEventRefComp && typeOfEventRefComp.typeOfEventForm) {

            //console.log("=====typeOfEventForm====== ", typeOfEventRefComp.typeOfEventForm);
            const typeofEventControl = typeOfEventRefComp.typeOfEventForm.controls;
            const newClaimCodeArray = typeofEventControl.claimTypeCode.value;
            const policy_Nos = typeofEventControl.policyNumber.value.length;
            const eventInformationSection = eventDetailsComp ? eventDetailsComp.eventDetailForm.controls.eventInformationSection.value : null;

            this.eclaimsObj.claimsType = typeofEventControl.newclaim.value;
            this.eclaimsObj.lineOfBusiness = typeofEventControl.newclaim.value;
            this.lob = typeofEventControl.newclaim.value;
            this.eclaimsObj.employerDetails = typeofEventControl.employerDetails.value;

            this.setScreenRequestObj(typeOfEventRefComp, newClaimCodeArray, eventInformationSection);

            if (typeOfEventRefComp.labelPropertyFeild === "Individual") {
                this.eclaimsObj.employerTextKey = "emplyerDetTextIndv";  //this.translate.instant('emplyerDetTextIndv');
            }
            else if (typeOfEventRefComp.labelPropertyFeild === "Telemarketing") {
                this.eclaimsObj.employerTextKey = "emplyerDetTextTmk";
            }
            else if (typeOfEventRefComp.labelPropertyFeild === "Group") {
                this.eclaimsObj.employerTextKey = "emplyerDetTextGrp";
            }
            else if (typeOfEventRefComp.labelPropertyFeild === "CreditLife") {
                this.eclaimsObj.employerTextKey = "emplyerDetTextCreditLife";
            }
            else if (typeOfEventRefComp.labelPropertyFeild === "Financial") {
                this.eclaimsObj.employerTextKey = "emplyerDetTextFin";
            }

            for (let index = 0; index < policy_Nos; index++) {
                var policyvalue = typeofEventControl.policyNumber.value[index];
                this.policyList.push({ policyNumber: policyvalue });
            }
            for (let index = 0; index < newClaimCodeArray.length; index++) {
                const claimtypeModObj: ClaimTypeModel = new ClaimTypeModel();
                var claimCodeValue = typeofEventControl.claimTypeCode.value[index];

                claimtypeModObj.claimConfirmationCode = claimCodeValue;
                claimtypeModObj.claimTypeValue = claimCodeValue;
                claimtypeModObj.claimTypeLabelValue = this.translate.instant(claimCodeValue);
                this.claimTypeList.push(claimtypeModObj)
            }
        }
        let aray = confimationCodes.split("|");
        for (let index = 0; index < aray.length; index++) {

            this.confirmationTextList.push(aray[index]);
        }
        this.eclaimsObj.submittedBy = this.jsonObj.submittedBy;
        this.eclaimsObj.policyList = this.policyList;
        this.eclaimsObj.claimTypeList = this.claimTypeList;
        this.eclaimsObj.sourceOfOrigin = this.sourceOfOrigin;
        this.eclaimsObj.brokerOrAgentName = this.jsonObj.submittedBy;
        this.eclaimsObj.confirmationTextList = this.confirmationTextList;
        this.eclaimsObj.eventDetailsAdditionalComments = null;
        this.eclaimsObj.userName = null;
        this.eclaimsObj.screenRequest = this.screenRequestObj;

        if (personalDetailsRefComp && personalDetailsRefComp.personalForm) {
let personalDetailsRederSec = this.newClaimService.getParamValue('renderSecFlagList');
       
//need to check whether old data is sending if section is not visible
//if(personalDetailsRefComp.personalSectionsRule.insuranceRefersToSection.renderFlag){
    this.populatePersonalDetailsForm(personalDetailsRefComp);
//}
//if(personalDetailsRefComp.personalSectionsRule.entitledForBenefitsSection.renderFlag){
    this.populateBenefitiaryDetailsForm(personalDetailsRefComp);
//}

this.populateResideneAddressSectionDetailsForm(personalDetailsRefComp);
//if(personalDetailsRefComp.personalSectionsRule.formOfDisbursementSection.renderFlag){
    this.populateFormOfDisbursementSectionForm(personalDetailsRefComp);
//}

            
        // if(personalDetailsRederSec.formOfDisbursementSection.renderFlag){

         //}
            
        }
        if (eventDetailsComp && eventDetailsComp.eventDetailForm) {

            this.populateAdditionalDetails(eventDetailsComp);
            this.populateEventInfoSec(eventDetailsComp);
            this.populatehealthCareEvent(eventDetailsComp);
            this.populatehealthCareFamilyDocEvent(eventDetailsComp);
            this.populateAdditionalComments(eventDetailsComp);

        }

        this.populateAttachmentsDetails(attachmentResponse);
        return this.eclaimsObj;

    }
    setScreenRequestObj(typeOfEventRefComp, newClaimCodeArray, eventInformationSection) {
        const typeofEventControl = typeOfEventRefComp.typeOfEventForm.controls;
        let primaryClaimType = this.newClaimService.getPrimaryClaimType();
        // let claimData = this.newClaimService.getClaimData();
        let eventDetail = this.newClaimService.getEventDetail();
        let personalDetail = this.newClaimService.getPersonalDetails();
        // let renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');
        let personalEventType = (personalDetail && personalDetail.value.insuranceRefersToSection) ? personalDetail.value.insuranceRefersToSection.insuranceEventRefersTo : '';
        if (personalEventType && personalEventType.toLowerCase() == 'insured') {
            personalEventType = 'PrimaryPolicyHolderEvent';
        }
        let eventRelated = eventDetail ? eventDetail.value.eventInformationSection.eventRelatedTo ?
            eventDetail.value.eventInformationSection.eventRelatedTo : 'NoEventRelated' : 'NoEventRelated';

        this.screenRequestObj.partner = 'metlife';
        this.screenRequestObj.sourceOfOrigin = this.sourceOfOrigin;
        this.screenRequestObj.lob = typeofEventControl.newclaim.value;
        this.screenRequestObj.product = typeofEventControl.newclaim.value;
        this.screenRequestObj.submittedBy = this.jsonObj.submittedBy;
        //this.screenRequestObj.primaryClaimEvent = typeOfEventRefComp.eventTypeClaimBusiness ? typeOfEventRefComp.eventTypeClaimBusiness.join('|'): null;
        this.screenRequestObj.primaryClaimEvent = newClaimCodeArray ? newClaimCodeArray.join('|') : null;
        this.screenRequestObj.selectedClaim = newClaimCodeArray ? newClaimCodeArray.join('|') : null;
        this.screenRequestObj.screenName = "EventDetailEventInformationSectionRender";
        this.screenRequestObj.eventType = personalEventType ? personalEventType : 'NoEvent';
        this.screenRequestObj.eventRelatedTo = eventRelated;
        this.screenRequestObj.claimType = primaryClaimType;
        this.screenRequestObj.relatedEventType = eventRelated;
    }

    populatePersonalDetailsForm(personalDetailsRefComp) {
        const personInsuranceInfomodelObj: PersonInsuranceInfoModel = new PersonInsuranceInfoModel();
        if (personalDetailsRefComp.personalForm.controls.insuranceRefersToSection) {
            const personFormControls = personalDetailsRefComp.personalForm.value;
            const insuranceRefersToSection = personalDetailsRefComp.personalForm.controls.insuranceRefersToSection.value;
            //console.log("=====insuranceRefersToSection====== ", insuranceRefersToSection);

            if (insuranceRefersToSection.insuranceEventRefersTo === 'Owner') {
                personInsuranceInfomodelObj.eventSelected = "PrimaryOwnerEvent";
            } else if (insuranceRefersToSection.insuranceEventRefersTo === 'Insured') {
                personInsuranceInfomodelObj.eventSelected = "PrimaryPolicyHolderEvent";
            } else {
                personInsuranceInfomodelObj.eventSelected = insuranceRefersToSection.insuranceEventRefersTo;
            }
            personInsuranceInfomodelObj.sectionRender = personalDetailsRefComp.personalSectionsRule.insuranceRefersToSection.renderFlag;
            personInsuranceInfomodelObj.insuranceEventRefersto = insuranceRefersToSection.insuranceEventRefersTo;
            personInsuranceInfomodelObj.name = insuranceRefersToSection.nameField;
            personInsuranceInfomodelObj.surName = insuranceRefersToSection.surnameField;
            personInsuranceInfomodelObj.peselNumber = insuranceRefersToSection.cnpfield;
            personInsuranceInfomodelObj.cnpField = insuranceRefersToSection.cnpfield;
            personInsuranceInfomodelObj.profession = insuranceRefersToSection.currentProfessionField;
            personInsuranceInfomodelObj.qualifiedProfession = insuranceRefersToSection.qualifiedProfessionField;

            if (personFormControls.emailAddressOfTheAgentFilingClaim)
                personInsuranceInfomodelObj.emailAddressOfTheAgentFilingClaim = personFormControls.emailAddressOfTheAgentFilingClaim;
            if (personFormControls.eventDetailsAdditionalComments)
                personInsuranceInfomodelObj.commentsByAgent = personFormControls.eventDetailsAdditionalComments;

            if (insuranceRefersToSection.nationalityField === "other") {
                personInsuranceInfomodelObj.countryName = this.countrynameByCode(insuranceRefersToSection.otherNationalityField);
                personInsuranceInfomodelObj.otherCountryName = this.countrynameByCode(insuranceRefersToSection.otherNationalityField);
                personInsuranceInfomodelObj.insuranceRefersCountryName = this.countrynameByCode(insuranceRefersToSection.otherNationalityField);
            } else {
                personInsuranceInfomodelObj.countryName = this.countrynameByCode(insuranceRefersToSection.nationalityField);
                personInsuranceInfomodelObj.otherCountryName = this.countrynameByCode(insuranceRefersToSection.otherNationalityField);
                personInsuranceInfomodelObj.insuranceRefersCountryName = this.countrynameByCode(insuranceRefersToSection.nationalityField);

            }

            if (insuranceRefersToSection.dobField)
                personInsuranceInfomodelObj.dateOfBirth = this.toDateString(insuranceRefersToSection.dobField);
            personInsuranceInfomodelObj.maidenName = insuranceRefersToSection.maidenNameField;

            //this.translate.instant('sexMaleLabel');
            if (insuranceRefersToSection.sexField === "M") {
                personInsuranceInfomodelObj.insuranceRefersSex = this.translate.instant('sexMaleLabel');
            } else if (insuranceRefersToSection.sexField === "F") {
                personInsuranceInfomodelObj.insuranceRefersSex = this.translate.instant('sexFemaleLabel');
            }
            personInsuranceInfomodelObj.seriesAndNumber = insuranceRefersToSection.passportNumField;

        }
        this.eclaimsObj.personInsuranceInfoVO = personInsuranceInfomodelObj;
    }

    populateBenefitiaryDetailsForm(personalDetailsRefComp) {
        const personProposesClaimInfoModelObj: PersonProposesClaimInfoModel = new PersonProposesClaimInfoModel();
        if (personalDetailsRefComp.personalForm.controls.entitledForBenefitsSection) {
            const entitledForBenefitsSection = personalDetailsRefComp.personalForm.controls.entitledForBenefitsSection.value;
            //console.log("=====entitledForBenefitsSection====== ", entitledForBenefitsSection);
            personProposesClaimInfoModelObj.sectionRender = personalDetailsRefComp.personalSectionsRule.entitledForBenefitsSection.renderFlag;
            if (entitledForBenefitsSection.benefitiaryGrp === "individual")
                personProposesClaimInfoModelObj.individual = true;
            else if (entitledForBenefitsSection.benefitiaryGrp === "institution")
                personProposesClaimInfoModelObj.institutionDifferentThanTrader = true;
            else if (entitledForBenefitsSection.benefitiaryGrp === "trader")
                personProposesClaimInfoModelObj.trader = true;

            if (entitledForBenefitsSection.capacity === "insured")
                personProposesClaimInfoModelObj.insured = true;
            else if (entitledForBenefitsSection.capacity === "benefitiary")
                personProposesClaimInfoModelObj.benefitiary = true;
            else if (entitledForBenefitsSection.capacity === "statutoryRepBen")
                personProposesClaimInfoModelObj.statutoryRepBen = true;
            else if (entitledForBenefitsSection.capacity === "plenipotentiaryBenf")
                personProposesClaimInfoModelObj.plenipotentiaryBenf = true;
            else if (entitledForBenefitsSection.capacity === "owner")
                personProposesClaimInfoModelObj.owner = true;
            else if(entitledForBenefitsSection.capacity === "otherPerson" )
                personProposesClaimInfoModelObj.otherPerson = true;

            //  personProposesClaimInfoModelObj.amlAcceptance = entitledForBenefitsSection.capacity;  // ToDO ' amlAcceptance 'check in which condition
            if (entitledForBenefitsSection.taxResidencyCountryIndv !== "other") {
                personProposesClaimInfoModelObj.taxResidencyCountryIndv = entitledForBenefitsSection.taxResidencyCountryIndv;
                personProposesClaimInfoModelObj.taxResidencyCountryIndv_cntryName = this.countrynameByCode(entitledForBenefitsSection.taxResidencyCountryIndv);
            } else {
                personProposesClaimInfoModelObj.taxResidencyCountryIndv = "OTH";
                personProposesClaimInfoModelObj.taxResidencyCountryIndv_cntryName = this.countrynameByCode(entitledForBenefitsSection.fillInCountryTax);
                personProposesClaimInfoModelObj.fillInCountryTax = this.countrynameByCode(entitledForBenefitsSection.fillInCountryTax);
            }

            if (entitledForBenefitsSection.nationalityTrader !== "other") {
                personProposesClaimInfoModelObj.countryOfRegistration_trader = entitledForBenefitsSection.nationalityTrader;
                personProposesClaimInfoModelObj.countryOfRegistration_trader_cntryName = this.countrynameByCode(entitledForBenefitsSection.nationalityTrader);
            } else {
                personProposesClaimInfoModelObj.countryOfRegistration_trader = "OTH";
                personProposesClaimInfoModelObj.countryOfRegistration_trader_cntryName = this.countrynameByCode(entitledForBenefitsSection.fillInTheNationalityTrader);
                personProposesClaimInfoModelObj.fillCountryOfRegistration_trader = this.countrynameByCode(entitledForBenefitsSection.fillInTheNationalityTrader);
            }
            if (personalDetailsRefComp.benefitRenderSecRules.countryOfBirthIndv.renderFlag) {
                if (entitledForBenefitsSection.countryOfBirthIndv !== "other") {
                    personProposesClaimInfoModelObj.countryOfBirthIndv = entitledForBenefitsSection.countryOfBirthIndv;
                    personProposesClaimInfoModelObj.countryOfBirthIndv_cntryName = this.countrynameByCode(entitledForBenefitsSection.countryOfBirthIndv);
                } else {
                    personProposesClaimInfoModelObj.fillInCountryBirth = entitledForBenefitsSection.fillInCountryBirth;
                    personProposesClaimInfoModelObj.countryOfBirthIndv = "OTH";
                    personProposesClaimInfoModelObj.countryOfBirthIndv_cntryName = this.countrynameByCode(entitledForBenefitsSection.fillInCountryBirth);

                }
            }
            if (entitledForBenefitsSection.dateOfBirthIndv)
                personProposesClaimInfoModelObj.dateOfBirthIndv = this.toDateString(entitledForBenefitsSection.dateOfBirthIndv);

            personProposesClaimInfoModelObj.institutionName = entitledForBenefitsSection.institutionNameInst;
            personProposesClaimInfoModelObj.institutionNameTrader = entitledForBenefitsSection.institutionNameTrader;
            if (entitledForBenefitsSection.documentValidupto)
                personProposesClaimInfoModelObj.idDocumentsValidUptoIndv1 = entitledForBenefitsSection.documentValidupto;
            personProposesClaimInfoModelObj.kRSInst = entitledForBenefitsSection.kRSInst;
            personProposesClaimInfoModelObj.kRSTrader = entitledForBenefitsSection.kRSTrader;
            personProposesClaimInfoModelObj.nIPInst = entitledForBenefitsSection.nIPInst;
            personProposesClaimInfoModelObj.regionInst = entitledForBenefitsSection.regionInst;
            personProposesClaimInfoModelObj.nameIndv = entitledForBenefitsSection.nameIndv;
            personProposesClaimInfoModelObj.nameInst = entitledForBenefitsSection.nameInst;
            personProposesClaimInfoModelObj.nameTrader = entitledForBenefitsSection.nameTrader;

            personProposesClaimInfoModelObj.nationalityIndv1 = this.countrynameByCode(entitledForBenefitsSection.nationality);
            personProposesClaimInfoModelObj.peselNumberIndv = entitledForBenefitsSection.peselNumberIndv;
            personProposesClaimInfoModelObj.maidenName = entitledForBenefitsSection.maidenName;
            personProposesClaimInfoModelObj.cnpFieldIndv = entitledForBenefitsSection.cnpfieldIndv;
            personProposesClaimInfoModelObj.regionTrader = entitledForBenefitsSection.regionTrader;
            personProposesClaimInfoModelObj.nIPTrader = entitledForBenefitsSection.nIPTrader;
            personProposesClaimInfoModelObj.seriesAndNumberIndv = entitledForBenefitsSection.seriesAndNumberIndv;

            if (entitledForBenefitsSection.sexIndv === "M") {
                personProposesClaimInfoModelObj.sexIndv = this.translate.instant('sexMaleLabel');
                personProposesClaimInfoModelObj.sexIndv_label = this.translate.instant('sexMaleLabel');
            } else if (entitledForBenefitsSection.sexIndv === "F") {
                personProposesClaimInfoModelObj.sexIndv = this.translate.instant('sexFemaleLabel');
                personProposesClaimInfoModelObj.sexIndv_label = this.translate.instant('sexFemaleLabel');
            }
            if (entitledForBenefitsSection.sexInst === "M") {
                personProposesClaimInfoModelObj.sexInst = this.translate.instant('sexMaleLabel');
                personProposesClaimInfoModelObj.sexInst_label = this.translate.instant('sexMaleLabel');
            } else if (entitledForBenefitsSection.sexInst === "F") {
                personProposesClaimInfoModelObj.sexInst = this.translate.instant('sexFemaleLabel');
                personProposesClaimInfoModelObj.sexInst_label = this.translate.instant('sexFemaleLabel');
            }
            if (entitledForBenefitsSection.sexTrader === "M") {
                personProposesClaimInfoModelObj.sexTrader = this.translate.instant('sexMaleLabel');
            } else if (entitledForBenefitsSection.sexTrader === "F") {
                personProposesClaimInfoModelObj.sexTrader = this.translate.instant('sexFemaleLabel');
            } personProposesClaimInfoModelObj.surNameIndv = entitledForBenefitsSection.surNameIndv;
            personProposesClaimInfoModelObj.surNameInst = entitledForBenefitsSection.surNameInst;
            personProposesClaimInfoModelObj.surNameTrader = entitledForBenefitsSection.surNameTrader;

            if (personalDetailsRefComp.benefitRenderSecRules.nationalityInst.renderFlag) {

                if (entitledForBenefitsSection.nationalityInst !== "other") {
                    personProposesClaimInfoModelObj.countryOfRegistration_inst = entitledForBenefitsSection.nationalityInst;
                    personProposesClaimInfoModelObj.countryOfRegistration_inst_cntryName = this.countrynameByCode(entitledForBenefitsSection.nationalityInst);
                } else {
                    personProposesClaimInfoModelObj.countryOfRegistration_inst = "OTH";
                    personProposesClaimInfoModelObj.countryOfRegistration_inst_cntryName = this.countrynameByCode(entitledForBenefitsSection.fillInTheNationalityInst);
                    personProposesClaimInfoModelObj.fillCountryOfRegistration_inst = this.countrynameByCode(entitledForBenefitsSection.fillInTheNationalityInst);
                }
            }

            // if (this.defaultLanguage === 'ro') {
            personProposesClaimInfoModelObj.peselNumberIndv = entitledForBenefitsSection.cnpfieldIndv;
            // }
            if (personalDetailsRefComp.benefitRenderSecRules.nationality_bu_Inst.renderFlag)
                this.countriesUnitOfOperates(entitledForBenefitsSection.nationality_bu_Inst, personProposesClaimInfoModelObj);

            let traderNationalityArray = entitledForBenefitsSection.nationality_bu_Trader;
            // if(personalDetailsRefComp.benefitRenderSecRules.nationality_bu_Trader.renderFlag){

            for (let index = 0; index < traderNationalityArray.length; index++) {

                personProposesClaimInfoModelObj[('fillCountryOfOperation' + (index + 1) + '_trader')] = this.countrynameByCode(traderNationalityArray[index].fillInTheNationalityTraderReg);
                if (this.countrynameByCode(traderNationalityArray[index].nationality) !== "other") {
                    personProposesClaimInfoModelObj[('countryOfOperation' + (index + 1) + '_trader')] = traderNationalityArray[index].nationality;
                    personProposesClaimInfoModelObj[('countryOfOperation' + (index + 1) + '_trader_cntryName')] = this.countrynameByCode(traderNationalityArray[index].nationality);
                } else {
                    personProposesClaimInfoModelObj[('countryOfOperation' + (index + 1) + '_trader')] = "OTH";
                    personProposesClaimInfoModelObj[('countryOfOperation' + (index + 1) + '_trader_cntryName')] = this.countrynameByCode(traderNationalityArray[index].fillInTheNationalityTraderReg);

                }
            }
            // }

            //-- need to refactor the code
            let nationalityIndvArry = entitledForBenefitsSection.nationalityIndv;
            for (let index = 0; index < nationalityIndvArry.length; index++) {

                if (nationalityIndvArry[index].documentValidupto)
                    personProposesClaimInfoModelObj[('idDocumentsValidUptoIndv' + (index + 1))] = this.toDateString(nationalityIndvArry[index].documentValidupto);

                if (nationalityIndvArry[index].citizenship !== "other") {
                    personProposesClaimInfoModelObj[('nationalityIndv' + (index + 1))] = nationalityIndvArry[index].citizenship;
                    personProposesClaimInfoModelObj[('nationalityIndv' + (index + 1) + '_cntryName')] = this.countrynameByCode(nationalityIndvArry[index].citizenship);
                } else {
                    personProposesClaimInfoModelObj[('nationalityIndv' + (index + 1))] = "OTH";
                    personProposesClaimInfoModelObj[('nationalityIndv' + (index + 1) + '_cntryName')] = this.countrynameByCode(nationalityIndvArry[index].fillInTheNationalityIndv);
                }
            }
        }

        this.eclaimsObj.personProposesClaimInfoVO = personProposesClaimInfoModelObj;

    }

    countriesUnitOfOperates(nationality_bu_Inst, personProposesClaimInfoModelObj) {

        for (let index = 0; index < nationality_bu_Inst.length; index++) {

            personProposesClaimInfoModelObj[('fillCountryOfOperation' + (index + 1) + '_inst')] = this.countrynameByCode(nationality_bu_Inst[index].fillInTheNationalityReg);

            if (nationality_bu_Inst[index].nationality !== "other") {
                personProposesClaimInfoModelObj[('countryOfOperation' + (index + 1) + '_inst')] = nationality_bu_Inst[index].nationality;
                personProposesClaimInfoModelObj[('countryOfOperation' + (index + 1) + '_inst_cntryName')] = this.countrynameByCode(nationality_bu_Inst[index].nationality);
            } else {
                personProposesClaimInfoModelObj[('countryOfOperation' + (index + 1) + '_inst')] = "OTH";
                personProposesClaimInfoModelObj[('countryOfOperation' + (index + 1) + '_inst_cntryName')] = this.countrynameByCode(nationality_bu_Inst[index].fillInTheNationalityReg);
            }

        }


        return personProposesClaimInfoModelObj;
    }

    countrynameByCode(countryCode) {

        if (countryCode) {

            const obj = this.countryList.find(x => x.countryCode === countryCode.toUpperCase());
            if (obj) {
                return obj.countryName;
            } else {
                let langauage = sessionStorage.getItem('defaultLanguage');
                if (countryCode.toUpperCase() === "EU" && langauage === "pl_en") {
                    return "European Union";
                } else if (countryCode.toUpperCase() === "EU" && langauage === "pl_pl") {
                    return "Unia Europejska";
                } else {
                    return countryCode;
                }


            }
        }
    }

    populateResideneAddressSectionDetailsForm(personalDetailsRefComp) {

        if (personalDetailsRefComp.personalSectionsRule.resideneAddressSection.renderFlag) {
            const addressComp = personalDetailsRefComp.personalForm.controls.resideneAddressSection.value;
            this.populateResidenceAddress(addressComp);

        }
        if (personalDetailsRefComp.personalSectionsRule.correspondenceAddressSection.renderFlag) {

            const addressComp = personalDetailsRefComp.personalForm.controls.correspondenceAddressSection.value;
            this.populateCommunicationAddress(addressComp);
        }

        this.eclaimsObj.claimAddressInfo = this.resideneAddressSection;

    }
    populateCommunicationAddress(addressComp) {

        const claimComModelObj: ClaimCommunicationAddressModel = new ClaimCommunicationAddressModel();
        //  claimComModelObj.sectionRender =personalDetailsRefComp.personalSectionsRule.entitledForBenefitsSection.renderFlag;
        //console.log("=====residenceAddrComp====== ", residenceAddrComp);
        claimComModelObj.addressType = "Communication";

        if (addressComp.country !== "other") {
            claimComModelObj.countryCode = addressComp.country;
            claimComModelObj.country = this.countrynameByCode(addressComp.country);
            claimComModelObj.stateCountry = this.countrynameByCode(addressComp.country);
            claimComModelObj.stateCountry_cntrynme = this.countrynameByCode(addressComp.country);
        } else {
            claimComModelObj.countryCode = "OTH";
            claimComModelObj.country = this.countrynameByCode(addressComp.otherCountry);
            claimComModelObj.stateCountry = this.countrynameByCode(addressComp.otherCountry);
            claimComModelObj.stateCountry_cntrynme = this.countrynameByCode(addressComp.otherCountry);

        }

        claimComModelObj.county = this.countrynameByCode(addressComp.county);

        claimComModelObj.otherCountry = this.countrynameByCode(addressComp.otherCountry);

        claimComModelObj.email = addressComp.email;
        claimComModelObj.flatNumber = addressComp.flatNumber;
        claimComModelObj.houseNo = addressComp.houseNumber;
        if (addressComp.country.toUpperCase() === "PL" || addressComp.country.toUpperCase() === "RO")
            claimComModelObj.isdCode = addressComp.isdCode;

        claimComModelObj.sector = addressComp.sector;
        claimComModelObj.appartment = addressComp.appartment;
        claimComModelObj.entrance = addressComp.entrance;
        claimComModelObj.block = addressComp.block;
        claimComModelObj.zipCode = addressComp.zipCode;
        claimComModelObj.mobileNumber = addressComp.mobileNumber;
        claimComModelObj.postalCode = addressComp.postalCode;
        //   if (addressComp.country !== 'PL')
        claimComModelObj.postBox = addressComp.postBox;
        claimComModelObj.modeOfCommunication = addressComp.preferredModeOfCommunication;
        claimComModelObj.streetName = addressComp.streetName;
        claimComModelObj.streetNumber = addressComp.houseNumber;
        claimComModelObj.town = addressComp.town;
        claimComModelObj.city = addressComp.city;
        if (addressComp.addressAcceptanceCheck)
            claimComModelObj.mailingAddressConfirmation = addressComp.addressAcceptanceCheck;

        this.resideneAddressSection.push(claimComModelObj);

    }
    populateResidenceAddress(residenceAddrComp) {
        const claimComModelObj: ClaimCommunicationAddressModel = new ClaimCommunicationAddressModel();
        //console.log("=====residenceAddrComp====== ", residenceAddrComp);
        claimComModelObj.addressType = "Residence";

        claimComModelObj.otherCountry = this.countrynameByCode(residenceAddrComp.otherCountry);
        claimComModelObj.county = this.countrynameByCode(residenceAddrComp.county);
        //claimComModelObj.stateCountry = residenceAddrComp.country;

        if (residenceAddrComp.country !== "other") {
            claimComModelObj.countryCode = residenceAddrComp.country;
            claimComModelObj.stateCountry = this.countrynameByCode(residenceAddrComp.country);
            claimComModelObj.country = this.countrynameByCode(residenceAddrComp.country);
            // claimComModelObj.otherCountry = this.countrynameByCode(residenceAddrComp.otherCountry);

        } else {
            claimComModelObj.countryCode = "OTH";
            claimComModelObj.stateCountry = this.countrynameByCode(residenceAddrComp.otherCountry);
            claimComModelObj.country = this.countrynameByCode(residenceAddrComp.otherCountry);
            // claimComModelObj.otherCountry = this.countrynameByCode(residenceAddrComp.otherCountry);
        }

        claimComModelObj.email = residenceAddrComp.email;
        claimComModelObj.flatNumber = residenceAddrComp.flatNumber;
        claimComModelObj.houseNo = residenceAddrComp.houseNumber;
        claimComModelObj.isdCode = residenceAddrComp.isdCode;
        claimComModelObj.sector = residenceAddrComp.sector;
        claimComModelObj.appartment = residenceAddrComp.appartment;
        claimComModelObj.entrance = residenceAddrComp.entrance;
        claimComModelObj.block = residenceAddrComp.block;
        claimComModelObj.zipCode = residenceAddrComp.zipCode;
        claimComModelObj.mobileNumber = residenceAddrComp.mobileNumber;
        claimComModelObj.postalCode = residenceAddrComp.postalCode;
        claimComModelObj.postBox = residenceAddrComp.postBox;
        claimComModelObj.modeOfCommunication = residenceAddrComp.preferredModeOfCommunication;
        claimComModelObj.streetName = residenceAddrComp.streetName;
        claimComModelObj.streetNumber = residenceAddrComp.streetName;
        claimComModelObj.town = residenceAddrComp.town;
        claimComModelObj.city = residenceAddrComp.city;

        this.resideneAddressSection.push(claimComModelObj);

    }


    populateFormOfDisbursementSectionForm(personalDetailsRefComp) {
        let personalDetailsRederSec = this.newClaimService.getParamValue('renderSecFlagList');
        const disbursementBenefitModel: DisbursementBenefitModel = new DisbursementBenefitModel();
        if (personalDetailsRederSec.formOfDisbursementSection.renderFlag && personalDetailsRefComp.personalForm.controls.formOfDisbursementSection) {
            const formOfDisbursementSection = personalDetailsRefComp.personalForm.controls.formOfDisbursementSection.value;
            disbursementBenefitModel.sectionRender = personalDetailsRefComp.personalSectionsRule.formOfDisbursementSection.renderFlag;
            //  if (personalDetailsRefComp.personalSectionsRule.formOfDisbursementSection.renderFlag) {

            //console.log("=====formOfDisbursementSection====== ", formOfDisbursementSection);
            disbursementBenefitModel.amount = formOfDisbursementSection.amount;
            disbursementBenefitModel.currencyGrp = formOfDisbursementSection.currency;
            disbursementBenefitModel.bankAccountNumberFormat = formOfDisbursementSection.bankaccountnumber;
            disbursementBenefitModel.bankAccountNumber = formOfDisbursementSection.bankaccountnumber ? (formOfDisbursementSection.bankaccountnumber).replace(/[\s]/g, '') : '';
            
            disbursementBenefitModel.bankCodeSwift = formOfDisbursementSection.codeswift;
            disbursementBenefitModel.nameOfTheBank = formOfDisbursementSection.bankname;
            if (formOfDisbursementSection.bankname)
                disbursementBenefitModel.banknameFinInst = formOfDisbursementSection.bankname;
            disbursementBenefitModel.bankAddress = formOfDisbursementSection.bankaddress;
            if (formOfDisbursementSection.banknamefinancialinst)
                disbursementBenefitModel.banknameFinInst = formOfDisbursementSection.banknamefinancialinst;
            //  disbursementBenefitModel.countryOfBank = this.countrynameByCode(formOfDisbursementSection.countryofbank);
            if (formOfDisbursementSection.interestedinreinvestment === "reinvestment") {
                disbursementBenefitModel.reinvestment = true;
            }
            if (formOfDisbursementSection.viafinancialinst) {
                disbursementBenefitModel.financialInstitution = true;
            }

            if (formOfDisbursementSection.viabanktransfer) {
                disbursementBenefitModel.reinvestmentBank = true;
                disbursementBenefitModel.disbursementBankCountryName = this.countrynameByCode(formOfDisbursementSection.countryofbank);
                disbursementBenefitModel.disbursementBankCountryCode = formOfDisbursementSection.countryofbank;
                disbursementBenefitModel.countyName = this.countrynameByCode(formOfDisbursementSection.county);

                if (formOfDisbursementSection.country !== "other") {
                    disbursementBenefitModel.disbursementBankAddressCountryCode = formOfDisbursementSection.country; 
                    disbursementBenefitModel.disbursementBankAddressCountryName = this.countrynameByCode(formOfDisbursementSection.country);
                } else {
                    disbursementBenefitModel.disbursementBankAddressCountryCode = "OTH"; 
                    disbursementBenefitModel.disbursementBankAddressCountryName = this.countrynameByCode(formOfDisbursementSection.otherNationalityField);
                }
            }
            if (formOfDisbursementSection.viapost) {
                disbursementBenefitModel.reinvestmentPostal = true;

                if (formOfDisbursementSection.post_country !== "other") {
                    disbursementBenefitModel.postal_countryCode = formOfDisbursementSection.post_country;
                    disbursementBenefitModel.postal_countryName = this.countrynameByCode(formOfDisbursementSection.post_country);
                    disbursementBenefitModel.disbursementPostalCountryName = this.countrynameByCode(formOfDisbursementSection.post_country);
                } else {
                    disbursementBenefitModel.postal_countryName = "OTH";
                    disbursementBenefitModel.postal_otherCountryName = this.countrynameByCode(formOfDisbursementSection.postal_otherNationalityField)
                    disbursementBenefitModel.disbursementPostalCountryName = this.countrynameByCode(formOfDisbursementSection.postal_otherNationalityField);
                }
            }
            disbursementBenefitModel.bank_inst_name = formOfDisbursementSection.businessunit;
            disbursementBenefitModel.reinvestment = formOfDisbursementSection.interestedinreinvestment;

            if (this.lob === "Group" && disbursementBenefitModel.reinvestment) {
                disbursementBenefitModel.reinvestmetnGrp = true;
            }

            if (disbursementBenefitModel.reinvestmetnGrp) {

                disbursementBenefitModel.amountGrp = formOfDisbursementSection.amount;
                disbursementBenefitModel.currencyGrp = formOfDisbursementSection.currency;
                disbursementBenefitModel.polNumGrp = formOfDisbursementSection.policynumber;
            }

            disbursementBenefitModel.name = formOfDisbursementSection.name;
            disbursementBenefitModel.policyNumber = formOfDisbursementSection.policynumber;
            //  disbursementBenefitModel.postalCode = formOfDisbursementSection.post_copyfromcommn;
            disbursementBenefitModel.postal_inst_name = formOfDisbursementSection.post_copyfromlegal;
            //disbursementBenefitModel.post_businessunit = formOfDisbursementSection.post_businessunit; //post_businessunit  
            disbursementBenefitModel.postal_flatNumber = formOfDisbursementSection.post_flatnumber;;
            disbursementBenefitModel.postal_name = formOfDisbursementSection.post_name;
            disbursementBenefitModel.postal_postalCode = formOfDisbursementSection.post_postalcode;

            disbursementBenefitModel.postal_postBox = formOfDisbursementSection.post_postbox;
            disbursementBenefitModel.postal_streetName = formOfDisbursementSection.post_streetname;
            disbursementBenefitModel.postal_streetNumber = formOfDisbursementSection.post_streetnumber;
            disbursementBenefitModel.postalSurname = formOfDisbursementSection.post_surname;
            disbursementBenefitModel.postal_town = formOfDisbursementSection.post_town;
            disbursementBenefitModel.surName = formOfDisbursementSection.surname;

            disbursementBenefitModel.viapost = formOfDisbursementSection.viapost;
            disbursementBenefitModel.streetName = formOfDisbursementSection.streetname;
            disbursementBenefitModel.streetNumber = formOfDisbursementSection.streetnumber;
            disbursementBenefitModel.flatNumber = formOfDisbursementSection.flatnumber;
            disbursementBenefitModel.postalCode = formOfDisbursementSection.postalcode;
            disbursementBenefitModel.entrance = formOfDisbursementSection.entrance;
            disbursementBenefitModel.appartment = formOfDisbursementSection.appartment;
            disbursementBenefitModel.sector = formOfDisbursementSection.sector;
            disbursementBenefitModel.town = formOfDisbursementSection.town;
            disbursementBenefitModel.bank_postBox = formOfDisbursementSection.postbox;
            disbursementBenefitModel.zipCode = formOfDisbursementSection.zipCode;
            disbursementBenefitModel.city = formOfDisbursementSection.city;
            disbursementBenefitModel.block = formOfDisbursementSection.block;
            //   }
            // if (formOfDisbursementSection.otherNationalityField)
            //     disbursementBenefitModel.countyName = formOfDisbursementSection.otherNationalityField;


        }


        this.eclaimsObj.disbursementBenefitVO = disbursementBenefitModel;
    }
    populateAdditionalDetails(eventDetailsComp) {
        //console.log("=====eventDetailsComp====== ", eventDetailsComp.eventDetailForm.controls.additionalFieldDetailsSection);
        const additionalDetailsModel: AdditionalFieldDetailsModel = new AdditionalFieldDetailsModel();
        if (eventDetailsComp.eventDetailForm.controls.additionalFieldDetailsSection) {

            const additionalFieldDetailsSection = eventDetailsComp.eventDetailForm.controls.additionalFieldDetailsSection.value;
            // additionalDetailsModel.sectionRender = eventDetailsComp.additionalFieldDetailsSectionValue;
            additionalDetailsModel.sectionRender = eventDetailsComp.eventFormValue
           //  if (eventDetailsComp.eventFormValue) {

            additionalDetailsModel.article = additionalFieldDetailsSection.article;
            if (additionalFieldDetailsSection.employmentPeriodFromDate)
                additionalDetailsModel.employmentPeriodFrom = this.toDateString(additionalFieldDetailsSection.employmentPeriodFromDate);
            if (additionalFieldDetailsSection.employmentPeriodToDate)
                additionalDetailsModel.employmentPeriodTo = this.toDateString(additionalFieldDetailsSection.employmentPeriodToDate);

            // if (additionalFieldDetailsSection.employmentPeriod)
            //     additionalDetailsModel.employmentPeriodFrom = this.toDateString(additionalFieldDetailsSection.employmentPeriod);
            // if (additionalFieldDetailsSection.employmentPeriod)
            //     additionalDetailsModel.employmentPeriodTo = this.toDateString(additionalFieldDetailsSection.employmentPeriod);

            additionalDetailsModel.caseNumber = additionalFieldDetailsSection.caseNumber;
            if (additionalFieldDetailsSection.dateCompletionOfMedicalTreatment) {
                additionalDetailsModel.medicalTreatmentFromDate = this.toDateString(additionalFieldDetailsSection.dateCompletionOfMedicalTreatment);
            }
            //eventDetailsComp.eventDetailForm.controls.additionalFieldDetailsSection.controls.medicalTreatmentStillUndergoing.value;
            if (additionalFieldDetailsSection.medicalTreatmentStillUndergoing)
                additionalDetailsModel.medicalTreatmentStillUndergoing = true;

            if (additionalFieldDetailsSection.medicalTreatmentNotApplicable)
                additionalDetailsModel.medicalTreatmentNotApplicable = true;

            if (additionalFieldDetailsSection.notApplicableCheckBox)
                additionalDetailsModel.recognitionOfDiseaseNotApplicable = true;

            if (additionalFieldDetailsSection.sickLeavePeriodNACheckBox)
                additionalDetailsModel.sickLeaveNotApplicable = true;

            if (additionalFieldDetailsSection.dateOfRecognitionDisease)
                additionalDetailsModel.recognitionOfDisease = this.toDateString(additionalFieldDetailsSection.dateOfRecognitionDisease);
            if (additionalFieldDetailsSection.dateOffirstSymptomsDisease)
                additionalDetailsModel.firstSymptomsOfDisease = this.toDateString(additionalFieldDetailsSection.dateOffirstSymptomsDisease);
            if (additionalFieldDetailsSection.dateWhenPhysicalInjuriesOccurred)
                additionalDetailsModel.physicalInjuriesOccured = this.toDateString(additionalFieldDetailsSection.dateWhenPhysicalInjuriesOccurred);
            additionalDetailsModel.employerAccidentReport = additionalFieldDetailsSection.employerPreparedAccidentReport;

            additionalDetailsModel.eventAfterAlchoholConsumtion = additionalFieldDetailsSection.eventAfterConsumptionAlcohol;
            additionalDetailsModel.forwhatperiod = additionalFieldDetailsSection.forwhatperiod;
            additionalDetailsModel.investigationEntities = additionalFieldDetailsSection.nameInvestigationEntities;
            additionalDetailsModel.recognitionOfDiseaseNotApplicable = additionalFieldDetailsSection.notApplicableCheckBox;
            additionalDetailsModel.investigationConductedDropDown = additionalFieldDetailsSection.policeConductedInvestigation;

            if (additionalFieldDetailsSection.sickLeavePeriodFromDate)
                additionalDetailsModel.sickLeaveFromDate = this.toDateString(additionalFieldDetailsSection.sickLeavePeriodFromDate);
            if (additionalFieldDetailsSection.sickLeavePeriodToDate)
                additionalDetailsModel.sickLeaveToDate = this.toDateString(additionalFieldDetailsSection.sickLeavePeriodToDate);
            additionalDetailsModel.sportsClubPlayerDropDown = additionalFieldDetailsSection.sportsClubPlayerDropDown;
            additionalDetailsModel.sportsClubPoliceTown = additionalFieldDetailsSection.sportsClubPoliceTown;
            additionalDetailsModel.temporaryDisabilityFromDate = this.toDateString(additionalFieldDetailsSection.temporaryDisabilityPeriod);
            additionalDetailsModel.temporaryDisabilityToDate = this.toDateString(additionalFieldDetailsSection.temporaryDisabilityPeriod);
            // }
            let copFlag = false
            let hcSpClbFlag = false;
            if (additionalFieldDetailsSection.policeConductedInvestigation === "yes")
                copFlag = true
            this.populatepoliceInvestigateAddressType(additionalFieldDetailsSection, additionalDetailsModel, copFlag);
            if (additionalFieldDetailsSection.sportsClubPlayerDropDown === "yes")
                hcSpClbFlag = true
            this.populateSportsClubAddressInfo(additionalFieldDetailsSection, additionalDetailsModel, hcSpClbFlag);

      //  }
        this.eclaimsObj.additionalFieldDetailsVO = additionalDetailsModel;
    }
    }
    populateSportsClubAddressInfo(additionalFieldDetailsSection: any, additionalDetailsModel: AdditionalFieldDetailsModel, hcSpClbFlag) {
        const sportsclubAdditionalFieldAddrObj: AdditionalFieldAddressInfoModel = new AdditionalFieldAddressInfoModel();
        sportsclubAdditionalFieldAddrObj.addressTpe = 'sportsclub';

        if (hcSpClbFlag) {
            sportsclubAdditionalFieldAddrObj.name = additionalFieldDetailsSection.sportsClubName;
            if (additionalFieldDetailsSection.sportsClubCountyName) {
                sportsclubAdditionalFieldAddrObj.countyName = additionalFieldDetailsSection.sportsClubCountyName;
            }
            if (additionalFieldDetailsSection.sportsClubCountry !== "other") {

                sportsclubAdditionalFieldAddrObj.countryCode = additionalFieldDetailsSection.sportsClubCountry;
                sportsclubAdditionalFieldAddrObj.country = this.countrynameByCode(additionalFieldDetailsSection.sportsClubCountry);
                sportsclubAdditionalFieldAddrObj.country_Name = this.countrynameByCode(additionalFieldDetailsSection.sportsClubCountry);
            } else {
                sportsclubAdditionalFieldAddrObj.countryCode = "OTH";
                sportsclubAdditionalFieldAddrObj.country = this.countrynameByCode(additionalFieldDetailsSection.otherSportsClubCountry);
                sportsclubAdditionalFieldAddrObj.country_Name = this.countrynameByCode(additionalFieldDetailsSection.otherSportsClubCountry);
                sportsclubAdditionalFieldAddrObj.otherCountry = this.countrynameByCode(additionalFieldDetailsSection.otherSportsClubCountry);
            }

            // sportsclubAdditionalFieldAddrObj.country_Name = additionalFieldDetailsSection.sportsClubCountyName;
            if (additionalFieldDetailsSection.sportsClubZipCode){
                sportsclubAdditionalFieldAddrObj.postalCode = additionalFieldDetailsSection.sportsClubZipCode;
            }
                
            else{
                sportsclubAdditionalFieldAddrObj.postalCode = additionalFieldDetailsSection.sportsClubPostalCode;
                sportsclubAdditionalFieldAddrObj.city = additionalFieldDetailsSection.sportsClubCity;
                sportsclubAdditionalFieldAddrObj.streetName = additionalFieldDetailsSection.sportsClubStreetName;
                sportsclubAdditionalFieldAddrObj.houseNumber = additionalFieldDetailsSection.sportsClubHouseNumber;
                sportsclubAdditionalFieldAddrObj.flatNo = additionalFieldDetailsSection.sportsClubFlatNo;
                sportsclubAdditionalFieldAddrObj.block = additionalFieldDetailsSection.sportsClubBlock;
                sportsclubAdditionalFieldAddrObj.entrance = additionalFieldDetailsSection.sportsClubEntrance;
                sportsclubAdditionalFieldAddrObj.appartment = additionalFieldDetailsSection.sportsClubAppartment;
                sportsclubAdditionalFieldAddrObj.sector = additionalFieldDetailsSection.sportsClubSector;
                sportsclubAdditionalFieldAddrObj.town = additionalFieldDetailsSection.sportsClubPoliceTown;
                sportsclubAdditionalFieldAddrObj.postBox = additionalFieldDetailsSection.sportsClubPostBox;
            }
                
        }

        this.additionalFieldAddrinfoModelList.push(sportsclubAdditionalFieldAddrObj);
        additionalDetailsModel.addressInfo = this.additionalFieldAddrinfoModelList;
        this.eclaimsObj.additionalFieldDetailsVO = additionalDetailsModel;

    }

    populatepoliceInvestigateAddressType(additionalFieldDetailsSection: any,
        additionalDetailsModel: AdditionalFieldDetailsModel, copFlag) {

        const policeInvestegateAddrObj: AdditionalFieldAddressInfoModel = new AdditionalFieldAddressInfoModel();
        policeInvestegateAddrObj.addressTpe = 'Policeinvestigate';
        if (copFlag) {
            if (additionalFieldDetailsSection.county) {
                policeInvestegateAddrObj.countyName = additionalFieldDetailsSection.county;
            }
            if (additionalFieldDetailsSection.country !== "other") {
                policeInvestegateAddrObj.countryCode = additionalFieldDetailsSection.country;
                policeInvestegateAddrObj.country = this.countrynameByCode(additionalFieldDetailsSection.country);
            } else {
                policeInvestegateAddrObj.countryCode = "OTH";
                policeInvestegateAddrObj.country = this.countrynameByCode(additionalFieldDetailsSection.otherCountry);
            }

            //policeInvestegateAddrObj.country = additionalFieldDetailsSection.country;
            //policeInvestegateAddrObj.postalCode = additionalFieldDetailsSection.zipCode;
            if (additionalFieldDetailsSection.zipCode)
                policeInvestegateAddrObj.postalCode = additionalFieldDetailsSection.zipCode;
            else
                policeInvestegateAddrObj.postalCode = additionalFieldDetailsSection.postalCode;
            policeInvestegateAddrObj.city = additionalFieldDetailsSection.city;
            policeInvestegateAddrObj.streetName = additionalFieldDetailsSection.streetName;
            policeInvestegateAddrObj.houseNumber = additionalFieldDetailsSection.houseNumber;
            policeInvestegateAddrObj.flatNo = additionalFieldDetailsSection.flatNo;
            policeInvestegateAddrObj.block = additionalFieldDetailsSection.block;
            policeInvestegateAddrObj.entrance = additionalFieldDetailsSection.entrance;
            policeInvestegateAddrObj.appartment = additionalFieldDetailsSection.appartment;
            policeInvestegateAddrObj.sector = additionalFieldDetailsSection.sector;
            policeInvestegateAddrObj.town = additionalFieldDetailsSection.town;
            policeInvestegateAddrObj.postBox = additionalFieldDetailsSection.postBox;
            // policeInvestegateAddrObj.caseNumber= additionalFieldDetailsSection.caseNumber;
        }

        this.additionalFieldAddrinfoModelList.push(policeInvestegateAddrObj)
        additionalDetailsModel.addressInfo = this.additionalFieldAddrinfoModelList;
        this.eclaimsObj.additionalFieldDetailsVO = additionalDetailsModel;

    }

    populateEventInfoSec(eventDetailsComp) {

        const eventInformationModel: EventInformationModel = new EventInformationModel();
        const eventInformationSection = eventDetailsComp.eventDetailForm.controls.eventInformationSection.value;
        eventInformationModel.sectionRender = eventDetailsComp.eventInformationSectionValue;
       //if(eventInformationModel.sectionRender){
        if (eventDetailsComp.eventDetailForm.controls.eventInformationSection) {
            //console.log("=====eventInformationSection====== ", eventInformationSection);
            if (eventInformationSection.dateOfEvent)
                eventInformationModel.dateOfEvent = this.toDateString(eventInformationSection.dateOfEvent);
            eventInformationModel.descriptionOfInjuries = eventInformationSection.descriptionOfEvent;
            eventInformationModel.eventRelatedTo = eventInformationSection.eventRelatedTo;
            eventInformationModel.placeOfEvent = eventInformationSection.placeOfEvent;
            eventInformationModel.cause = eventInformationSection.causeOfEvent;

        }

        this.eclaimsObj.eventInformationVO = eventInformationModel;
       //}
        
    }
    populatehealthCareEvent(eventDetailsComp) {
        let flag = true;
        const array = eventDetailsComp.eventDetailForm.controls.informationHealthCareEventSection.controls.length;
        //console.log("======array length===== ", array);
        let healthCareInfoModel: HealthCareCenterInfoModel = new HealthCareCenterInfoModel();
        healthCareInfoModel.sectionRender = eventDetailsComp.informationHealthCareEventSectionValue;
       //if(healthCareInfoModel.sectionRender){
        for (let index = 0; index < array; index++) {
            const hcAddressInfoModObj: HCAddressInfoModel = new HCAddressInfoModel();
            const infoHealthCareObj = eventDetailsComp.eventDetailForm.controls.informationHealthCareEventSection.controls[index].value;
            //console.log("=====infoHealthCareObj====== ", infoHealthCareObj);

            if (index == 0) {
                healthCareInfoModel = this.populatePrimaryHCSec(healthCareInfoModel, infoHealthCareObj);
                hcAddressInfoModObj.hcAddressType = 'primary';
            }
            else if (index == 1) {
                hcAddressInfoModObj.hcAddressType = 'secondary';
                healthCareInfoModel = this.populateSecondaryHC1Sec(healthCareInfoModel, infoHealthCareObj);
            }
            else if (index == 2) {
                hcAddressInfoModObj.hcAddressType = 'secondaryhc2';
                healthCareInfoModel = this.populateSecondaryHC2Sec(healthCareInfoModel, infoHealthCareObj);
            }
            else if (index == 3) {
                hcAddressInfoModObj.hcAddressType = 'secondaryhc3';
                healthCareInfoModel = this.populateSecondaryHC3Sec(healthCareInfoModel, infoHealthCareObj);
            }

            hcAddressInfoModObj.hcBlock = infoHealthCareObj.healthCareCenterBlock;
            hcAddressInfoModObj.hcCity = infoHealthCareObj.healthCareCenterCity;

            hcAddressInfoModObj.hcCounty = this.countrynameByCode(infoHealthCareObj.healthCareCenterCounty);

            if (infoHealthCareObj.healthCareCenterCountry === "other") {
                hcAddressInfoModObj.hcCountryCode = "OTH";
                hcAddressInfoModObj.hcCountry = this.countrynameByCode(infoHealthCareObj.healthCareOtherCountry);
                hcAddressInfoModObj.hcCountryName = this.countrynameByCode(infoHealthCareObj.healthCareOtherCountry);
            } else {
                hcAddressInfoModObj.hcCountryCode = infoHealthCareObj.healthCareCenterCountry;
                hcAddressInfoModObj.hcCountry = this.countrynameByCode(infoHealthCareObj.healthCareCenterCountry);
                hcAddressInfoModObj.hcCountryName = this.countrynameByCode(infoHealthCareObj.healthCareCenterCountry);
            }

            hcAddressInfoModObj.hcEntrance = infoHealthCareObj.healthCareCenterEntrance;
            hcAddressInfoModObj.hcFlatNumber = infoHealthCareObj.healthCareCenterFlatNo;
            hcAddressInfoModObj.hcHouseNumber = infoHealthCareObj.healthCareCenterHouseNumber;
            hcAddressInfoModObj.hcName = infoHealthCareObj.healthCareCenterName;
            if (infoHealthCareObj.healthCareCenterPeriodFrom)
                hcAddressInfoModObj.hcPeriodFrom = this.toDateString(infoHealthCareObj.healthCareCenterPeriodFrom);
            if (infoHealthCareObj.healthCareCenterPeriodTo)
                hcAddressInfoModObj.hcPeriodTo = this.toDateString(infoHealthCareObj.healthCareCenterPeriodTo);
            hcAddressInfoModObj.hcPostBox = infoHealthCareObj.healthCareCenterPostBox;
            hcAddressInfoModObj.hcSector = infoHealthCareObj.healthCareCenterSector;
            hcAddressInfoModObj.hcStreetName = infoHealthCareObj.healthCareCenterStreetName;
            hcAddressInfoModObj.hcTown = infoHealthCareObj.healthCareCenterTown;
            hcAddressInfoModObj.hcOtherTown = infoHealthCareObj.healthCareCenterTown;
            // hcAddressInfoModObj.hcZipCode = infoHealthCareObj.healthCareCenterZipCode;
            // hcAddressInfoModObj.hcPostalCode = infoHealthCareObj.healthCareCenterPostalCode;
            if (infoHealthCareObj.healthCareCenterZipCode)
                hcAddressInfoModObj.hcPostalCode = infoHealthCareObj.healthCareCenterZipCode;
            else
                hcAddressInfoModObj.hcPostalCode = infoHealthCareObj.healthCareCenterPostalCode;
            hcAddressInfoModObj.hcAppartment = infoHealthCareObj.healthCareCenterAppartment;
            hcAddressInfoModObj.hcSector = infoHealthCareObj.healthCareCenterSector;

            this.healthCareAddressInfoModel.push(hcAddressInfoModObj);

        }
        healthCareInfoModel.hcAddressInfo = this.healthCareAddressInfoModel;
        this.eclaimsObj.healthCareCenterInfoVO = healthCareInfoModel;
    //}
    }
    populateSecondaryHC3Sec(healthCareInfoModel: HealthCareCenterInfoModel, infoHealthCareObj: any): HealthCareCenterInfoModel {
        if (infoHealthCareObj.healthCareCenterPeriodFrom)
            healthCareInfoModel.secondaryHC3PeriodFrom = this.toDateString(infoHealthCareObj.healthCareCenterPeriodFrom);
        healthCareInfoModel.secondaryHC3Name = infoHealthCareObj.healthCareCenterName;
        healthCareInfoModel.secondaryHC3StreetName = infoHealthCareObj.healthCareCenterStreetName;
        healthCareInfoModel.secondaryHC3HouseNumber = infoHealthCareObj.healthCareCenterHouseNumber;
        healthCareInfoModel.secondaryHC3FlatNumber = infoHealthCareObj.healthCareCenterFlatNo;
        healthCareInfoModel.secondaryHC3Country = infoHealthCareObj.healthCareCenterCountry;
        healthCareInfoModel.secondaryHC3Country_Name = infoHealthCareObj.healthCareCenterCountry;
        healthCareInfoModel.secondaryHC3OtherCountry = infoHealthCareObj.healthCareOtherCountry;
        healthCareInfoModel.secondaryHC3Town = infoHealthCareObj.healthCareCenterTown;
        healthCareInfoModel.secondaryHC3OtherTown = infoHealthCareObj.healthCareCenterTown;
        healthCareInfoModel.secondaryHC3PostalCode = infoHealthCareObj.healthCareCenterPostalCode;
        healthCareInfoModel.secondaryHC3PostBox = infoHealthCareObj.healthCareCenterPostBox;
        return healthCareInfoModel;
    }
    populateSecondaryHC2Sec(healthCareInfoModel: HealthCareCenterInfoModel, infoHealthCareObj: any): HealthCareCenterInfoModel {
        if (infoHealthCareObj.healthCareCenterPeriodFrom)
            healthCareInfoModel.secondaryHC2PeriodFrom = this.toDateString(infoHealthCareObj.healthCareCenterPeriodFrom);
        healthCareInfoModel.secondaryHC2Name = infoHealthCareObj.healthCareCenterName;
        healthCareInfoModel.secondaryHC2StreetName = infoHealthCareObj.healthCareCenterStreetName;
        healthCareInfoModel.secondaryHC2HouseNumber = infoHealthCareObj.healthCareCenterHouseNumber;
        healthCareInfoModel.secondaryHC2FlatNumber = infoHealthCareObj.healthCareCenterFlatNo;
        healthCareInfoModel.secondaryHC2Country = infoHealthCareObj.healthCareCenterCountry;
        healthCareInfoModel.secondaryHC2Country_Name = infoHealthCareObj.healthCareCenterCountry;
        healthCareInfoModel.secondaryHC2OtherCountry = infoHealthCareObj.healthCareOtherCountry;
        healthCareInfoModel.secondaryHC2Town = infoHealthCareObj.healthCareCenterTown;
        healthCareInfoModel.secondaryHC2OtherTown = infoHealthCareObj.healthCareCenterTown;
        healthCareInfoModel.secondaryHC2PostalCode = infoHealthCareObj.healthCareCenterPostalCode;
        healthCareInfoModel.secondaryHC2PostBox = infoHealthCareObj.healthCareCenterPostBox;
        return healthCareInfoModel;
    }
    populateSecondaryHC1Sec(healthCareInfoModel: HealthCareCenterInfoModel, infoHealthCareObj: any): HealthCareCenterInfoModel {

        if (infoHealthCareObj.healthCareCenterPeriodFrom)
            healthCareInfoModel.secondaryHC1PeriodFrom = this.toDateString(infoHealthCareObj.healthCareCenterPeriodFrom);
        healthCareInfoModel.secondaryHC1Name = infoHealthCareObj.healthCareCenterName;
        healthCareInfoModel.secondaryHC1StreetName = infoHealthCareObj.healthCareCenterStreetName;
        healthCareInfoModel.secondaryHC1HouseNumber = infoHealthCareObj.healthCareCenterHouseNumber;
        healthCareInfoModel.secondaryHC1FlatNumber = infoHealthCareObj.healthCareCenterFlatNo;
        healthCareInfoModel.secondaryHC1Country = infoHealthCareObj.healthCareCenterCountry;
        healthCareInfoModel.secondaryHC1Country_Name = infoHealthCareObj.healthCareCenterCountry;
        healthCareInfoModel.secondaryHC1OtherCountry = infoHealthCareObj.healthCareOtherCountry;
        healthCareInfoModel.secondaryHC1Town = infoHealthCareObj.healthCareCenterTown;
        healthCareInfoModel.secondaryHC1OtherTown = infoHealthCareObj.healthCareCenterTown;
        healthCareInfoModel.secondaryHC1PostalCode = infoHealthCareObj.healthCareCenterPostalCode;
        healthCareInfoModel.secondaryHC1PostBox = infoHealthCareObj.healthCareCenterPostBox;

        return healthCareInfoModel;
    }
    populatePrimaryHCSec(healthCareInfoModel, infoHealthCareObj) {

        healthCareInfoModel.primaryHCName = infoHealthCareObj.healthCareCenterName;
        if (infoHealthCareObj.healthCareCenterPeriodFrom)
            healthCareInfoModel.primaryHCPeriodFrom = this.toDateString(infoHealthCareObj.healthCareCenterPeriodFrom);
        healthCareInfoModel.primaryHCStreetName = infoHealthCareObj.healthCareCenterStreetName;
        healthCareInfoModel.primaryHCHouseNumber = infoHealthCareObj.healthCareCenterHouseNumber;
        healthCareInfoModel.primaryHCFlatNumber = infoHealthCareObj.healthCareCenterFlatNo;
        healthCareInfoModel.primaryHCCountry = infoHealthCareObj.healthCareCenterCountry;
        healthCareInfoModel.primaryHCCountry_Name = infoHealthCareObj.healthCareCenterCountry;
        healthCareInfoModel.primaryHCOtherCountry = infoHealthCareObj.healthCareOtherCountry;
        healthCareInfoModel.primaryHCTown = infoHealthCareObj.healthCareCenterTown;
        healthCareInfoModel.primaryHCOtherTown = infoHealthCareObj.healthCareCenterTown;
        healthCareInfoModel.primaryHCPostalCode = infoHealthCareObj.healthCareCenterPostalCode;
        healthCareInfoModel.primaryHCPostBox = infoHealthCareObj.healthCareCenterPostBox;

        return healthCareInfoModel;
    }


    populatehealthCareFamilyDocEvent(eventDetailsComp) {

        const array = eventDetailsComp.eventDetailForm.controls.informationHealthCareFamilyDocSection.controls.length;
        //console.log("======array length===== ", array);
        let hcFamilyDocInfoModel: HealthCareFamilyDocModel = new HealthCareFamilyDocModel();
        hcFamilyDocInfoModel.sectionRender = eventDetailsComp.informationHealthCareFamilyDocSectionValue;
      // if(hcFamilyDocInfoModel.sectionRender){
        for (let index = 0; index < array; index++) {
            const healthcareFamilyDocInfoModel: HCFamilyDocModel = new HCFamilyDocModel();
            const infoHealthCareFamilyDocObj = eventDetailsComp.eventDetailForm.controls.informationHealthCareFamilyDocSection.controls[index].value;
            //console.log("=====infoHealthCareFamilyDocObj====== ", infoHealthCareFamilyDocObj);
            if (index == 0) {
                healthcareFamilyDocInfoModel.familyDocType = 'primarydoc';
                hcFamilyDocInfoModel = this.populatePrimaryFamilyDocSec(hcFamilyDocInfoModel, infoHealthCareFamilyDocObj);
            }
            else if (index == 1) {
                healthcareFamilyDocInfoModel.familyDocType = 'secondarydoc1';
                hcFamilyDocInfoModel = this.populateSecondaryFamilyDoc1Sec(hcFamilyDocInfoModel, infoHealthCareFamilyDocObj);
            }
            else if (index == 2) {
                healthcareFamilyDocInfoModel.familyDocType = 'secondarydoc2';
                hcFamilyDocInfoModel = this.populatePrimaryFamilyDoc2Sec(hcFamilyDocInfoModel, infoHealthCareFamilyDocObj);
            }

            if (infoHealthCareFamilyDocObj.familyDoctorCountry !== "other") {
                healthcareFamilyDocInfoModel.familyDocCountryCode = infoHealthCareFamilyDocObj.familyDoctorCountry;
                healthcareFamilyDocInfoModel.familyDocCountry = this.countrynameByCode(infoHealthCareFamilyDocObj.familyDoctorCountry);
                healthcareFamilyDocInfoModel.familyDocCountry_Name = this.countrynameByCode(infoHealthCareFamilyDocObj.familyDoctorCountry);
            } else {
                healthcareFamilyDocInfoModel.familyDocCountryCode = "OTH";
                healthcareFamilyDocInfoModel.familyDocCountry = this.countrynameByCode(infoHealthCareFamilyDocObj.familyDoctorOtherCountry);
                healthcareFamilyDocInfoModel.familyDocCountry_Name = this.countrynameByCode(infoHealthCareFamilyDocObj.familyDoctorOtherCountry);
            }

            healthcareFamilyDocInfoModel.familyDocFlatNumber = infoHealthCareFamilyDocObj.familyDoctorFlatNumber;
            healthcareFamilyDocInfoModel.familyDocHouseNumber = infoHealthCareFamilyDocObj.familyDoctorHouseNumber;
            healthcareFamilyDocInfoModel.familyDocName = infoHealthCareFamilyDocObj.familyDoctorName;
            healthcareFamilyDocInfoModel.familyDocPhoneNumber = infoHealthCareFamilyDocObj.familyDoctorPhoneNumber;
            healthcareFamilyDocInfoModel.familyDocPostBox = infoHealthCareFamilyDocObj.familyDoctorPostBox;
            healthcareFamilyDocInfoModel.familyDocPostalCode = infoHealthCareFamilyDocObj.familyDoctorPostalCode;
            healthcareFamilyDocInfoModel.familyDocStreetName = infoHealthCareFamilyDocObj.familyDoctorStreetName;
            healthcareFamilyDocInfoModel.familyDocTown = infoHealthCareFamilyDocObj.familyDoctorTown;

            this.healthcareFamilyDocInfoModelList.push(healthcareFamilyDocInfoModel);
        }
        hcFamilyDocInfoModel.familyDocInfo = this.healthcareFamilyDocInfoModelList;
        this.eclaimsObj.healthCareFamilyDocVO = hcFamilyDocInfoModel;
    //}
    }
    populatePrimaryFamilyDoc2Sec(hcFamilyDocInfoModel: HealthCareFamilyDocModel, infoHealthCareFamilyDocObj: any): HealthCareFamilyDocModel {
        hcFamilyDocInfoModel.secondaryFamilyDoc2Name = infoHealthCareFamilyDocObj.familyDoctorName;
        hcFamilyDocInfoModel.secondaryFamilyDoc2StreetName = infoHealthCareFamilyDocObj.familyDoctorStreetName;
        hcFamilyDocInfoModel.secondaryFamilyDoc2HouseNumber = infoHealthCareFamilyDocObj.familyDoctorHouseNumber;
        hcFamilyDocInfoModel.secondaryFamilyDoc2FlatNumber = infoHealthCareFamilyDocObj.familyDoctorFlatNumber;
        hcFamilyDocInfoModel.secondaryFamilyDoc2Country = infoHealthCareFamilyDocObj.familyDoctorCountry;
        hcFamilyDocInfoModel.secondaryFamilyDoc2Country_Name = infoHealthCareFamilyDocObj.familyDoctorCountry;
        hcFamilyDocInfoModel.secondaryFamilyDoc2OtherCountry = infoHealthCareFamilyDocObj.familyDoctorOtherCountry;
        hcFamilyDocInfoModel.secondaryFamilyDoc2Town = infoHealthCareFamilyDocObj.familyDoctorTown;
        hcFamilyDocInfoModel.secondaryFamilyDoc2OtherTown = infoHealthCareFamilyDocObj.familyDoctorTown;
        hcFamilyDocInfoModel.secondaryFamilyDoc2PostalCode = infoHealthCareFamilyDocObj.familyDoctorPostalCode;
        hcFamilyDocInfoModel.secondaryFamilyDoc2PostBox = infoHealthCareFamilyDocObj.familyDoctorPostBox;
        hcFamilyDocInfoModel.secondaryFamilyDoc2PhoneNumber = infoHealthCareFamilyDocObj.familyDoctorPhoneNumber;
        hcFamilyDocInfoModel.secondaryFamilyDoc2CountryCode = infoHealthCareFamilyDocObj.familyDoctorCountry;

        return hcFamilyDocInfoModel;
    }
    populateSecondaryFamilyDoc1Sec(hcFamilyDocInfoModel: HealthCareFamilyDocModel, infoHealthCareFamilyDocObj: any): HealthCareFamilyDocModel {
        hcFamilyDocInfoModel.secondaryFamilyDoc1Name = infoHealthCareFamilyDocObj.familyDoctorName;
        hcFamilyDocInfoModel.secondaryFamilyDoc1StreetName = infoHealthCareFamilyDocObj.familyDoctorStreetName;
        hcFamilyDocInfoModel.secondaryFamilyDoc1HouseNumber = infoHealthCareFamilyDocObj.familyDoctorHouseNumber;
        hcFamilyDocInfoModel.secondaryFamilyDoc1FlatNumber = infoHealthCareFamilyDocObj.familyDoctorFlatNumber;
        hcFamilyDocInfoModel.secondaryFamilyDoc1Country = infoHealthCareFamilyDocObj.familyDoctorCountry;
        hcFamilyDocInfoModel.secondaryFamilyDoc1Country_Name = infoHealthCareFamilyDocObj.familyDoctorCountry;
        hcFamilyDocInfoModel.secondaryFamilyDoc1OtherCountry = infoHealthCareFamilyDocObj.familyDoctorOtherCountry;
        hcFamilyDocInfoModel.secondaryFamilyDoc1Town = infoHealthCareFamilyDocObj.familyDoctorTown;
        hcFamilyDocInfoModel.secondaryFamilyDoc1OtherTown = infoHealthCareFamilyDocObj.familyDoctorTown;
        hcFamilyDocInfoModel.secondaryFamilyDoc1PostalCode = infoHealthCareFamilyDocObj.familyDoctorPostalCode;
        hcFamilyDocInfoModel.secondaryFamilyDoc1PostBox = infoHealthCareFamilyDocObj.familyDoctorPostBox;
        hcFamilyDocInfoModel.secondaryFamilyDoc1PhoneNumber = infoHealthCareFamilyDocObj.familyDoctorPhoneNumber;
        hcFamilyDocInfoModel.secondaryFamilyDoc1CountryCode = infoHealthCareFamilyDocObj.familyDoctorCountry;

        return hcFamilyDocInfoModel;
    }
    populatePrimaryFamilyDocSec(hcFamilyDocInfoModel: HealthCareFamilyDocModel, infoHealthCareFamilyDocObj: any) {

        hcFamilyDocInfoModel.primaryFamilyDocName = infoHealthCareFamilyDocObj.familyDoctorName;
        hcFamilyDocInfoModel.primaryFamilyDocStreetName = infoHealthCareFamilyDocObj.familyDoctorStreetName;
        hcFamilyDocInfoModel.primaryFamilyDocHouseNumber = infoHealthCareFamilyDocObj.familyDoctorHouseNumber;
        hcFamilyDocInfoModel.primaryFamilyDocFlatNumber = infoHealthCareFamilyDocObj.familyDoctorFlatNumber;
        hcFamilyDocInfoModel.primaryFamilyDocCountry = infoHealthCareFamilyDocObj.familyDoctorCountry;
        hcFamilyDocInfoModel.primaryFamilyDocCountry_Name = infoHealthCareFamilyDocObj.familyDoctorCountry;
        hcFamilyDocInfoModel.primaryFamilyDocOtherCountry = infoHealthCareFamilyDocObj.familyDoctorOtherCountry;
        hcFamilyDocInfoModel.primaryFamilyDocTown = infoHealthCareFamilyDocObj.familyDoctorTown;
        hcFamilyDocInfoModel.primaryFamilyDocOtherTown = infoHealthCareFamilyDocObj.familyDoctorTown;
        hcFamilyDocInfoModel.primaryFamilyDocPostalCode = infoHealthCareFamilyDocObj.familyDoctorPostalCode;
        hcFamilyDocInfoModel.primaryFamilyDocPostBox = infoHealthCareFamilyDocObj.familyDoctorPostBox;
        hcFamilyDocInfoModel.primaryFamilyDocPhoneNumber = infoHealthCareFamilyDocObj.familyDoctorPhoneNumber;
        hcFamilyDocInfoModel.primaryFamilyDocCountryCode = infoHealthCareFamilyDocObj.familyDoctorCountry;

        return hcFamilyDocInfoModel;
    }
    populateAdditionalComments(eventDetailsComp) {
        try {
            if (eventDetailsComp.eventDetailForm.controls['eventDetailsAdditionalComments']) {
                this.eclaimsObj.eventDetailsAdditionalComments = eventDetailsComp.eventDetailForm.controls['eventDetailsAdditionalComments'].value;
            }

        } catch (err) {
            console.log("err", err);
        }

    }

    populateAttachmentsDetails(attachmentResponse) {
        let claimNo = '';
        const array = attachmentResponse.length;
        for (let index = 0; index < array; index++) {

            const attachmentObj: ClaimAttachmentModel = new ClaimAttachmentModel();
            attachmentObj.fileValue = attachmentResponse[index].fileValue;
            attachmentObj.orderId = attachmentResponse[index].orderId;
            attachmentObj.status = attachmentResponse[index].status;
            attachmentObj.claimNumber = attachmentResponse[index].claimNumber;
            claimNo = attachmentResponse[index].claimNumber;
            attachmentObj.document = '';
            if (attachmentResponse[index].fileName)
                attachmentObj.fileName = attachmentResponse[index].fileName;
            else
                attachmentObj.fileName = attachmentResponse[index].documentExt;

            attachmentObj.documentExt = attachmentResponse[index].documentExt;
            attachmentObj.documentType = attachmentResponse[index].documentType;
            attachmentObj.pdfDocumentType = attachmentResponse[index].pdfDocumentType;
            this.claimAttachmentModel.push(attachmentObj);
        }
        this.eclaimsObj.claimNumber = claimNo;
        this.eclaimsObj.uploadedDocumentList = this.claimAttachmentModel;
        return this.eclaimsObj;
    }

    toDateString(dateObj) {
        if (dateObj) {
            var date = new Date(dateObj);
            return ("0" + date.getDate()).slice(-2) + "/" + ("0" + (date.getMonth() + 1)).slice(-2) + "/" + + date.getFullYear();
        } else {
            return null;
        }
    }
    clearobjvalues() {
        this.eclaimsObj = new EclaimsModel();
        this.resideneAddressSection = new Array();
        this.healthCareFamilyDocModel = new Array();
        this.claimAttachmentModel = new Array();
        this.healthCareAddressInfoModel = new Array();
        this.healthcareFamilyDocInfoModelList = new Array();
        this.documentList = new Array();
        this.claimTypeList = new Array();
        this.policyList = new Array();
        this.additionalFieldAddrinfoModelList = new Array();
        this.screenRequestObj = new ScreenRenderReqModel();

    }


}
