import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { TypeOfEventsComponent } from './type-of-events.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {SharedModule} from 'src/app/shared/shared.module';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { environment } from 'src/environments/environment';

import { of } from 'rxjs';


describe('TypeOfEventsComponent', () => {
  let component: TypeOfEventsComponent;
  let fixture: ComponentFixture<TypeOfEventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ TypeOfEventsComponent ],
      providers :[ HttpClient ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    if(!(sessionStorage.getItem('userData'))){
      let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    sessionStorage.setItem('defaultLanguage','pl_pl');
    sessionStorage.setItem('tenantId','pl');
    fixture = TestBed.createComponent(TypeOfEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('getDisclaimerSection should cal typeOfEventSecondary', () => {
    let cService = TestBed.get(HttpCommonService);
    let claim_event_secondary = {"partner":"metlife","product":"Individual","primaryClaimEvent":"E160","secondaryClaimEvent":"E160","ruleFileName":"Eclaims_SecondaryClaimEvent.xls_CLAIM_EVENT_SECONDARY","sheetName":null,"disclaimerCode":"I","submittedBy":"Customer","confirmationCode":"conf3|conf1|conf10|conf13|confi|conf19","ksession":null};
    spyOn(cService, 'postData').and.returnValue(of(claim_event_secondary));
    spyOn(component, 'typeOfEventSecondary').and.callThrough();
   
    component.getDisclaimerSection('');
   // component.typeOfEventSecondary();
  //  component.disableCheckbox(0);

  expect(component.typeOfEventSecondary).toHaveBeenCalled(); 
  
  //expect(component.getValueDisclaimerSection).toHaveBeenCalled(); 
  
  
});

    it('eventTypes should cal', () => {

      let cService = TestBed.get(HttpCommonService);
      let response ={"ruleFileName":"Eclaims_EventTypeComponentRender.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","claimTypeSection":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"policyDetailsSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"policyNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"9","fieldminlength":"0","allowedDataType":"numeric"},"employerDetails":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"ksession":null};
      spyOn(cService, 'postData').and.returnValue(of(response));
      component.screenRequestObj = {"partner":"metlife","sourceOfOrigin":null,"lob":"Financial","product":"Financial","submittedBy":null,"primaryClaimEvent":null,"selectedClaim":null,"screenName":"TypeOfEvent","eventType":null,"eventRelatedTo":null,"claimType":null,"relatedEventType":null}

      spyOn(component, 'componentSoucreOrigin').and.callThrough();
      component.eventTypes();
      expect(component.componentSoucreOrigin).toHaveBeenCalled(); 
      });

      



      it('clearradioButtons should cal', () => {
        spyOn(component, 'clearradioButtons').and.callThrough();
        component.clearradioButtons();
        //expect(component.clearradioButtons).toHaveBeenCalled(); 
        //  component.clearradioButtons();
     
        });
      
        it('addCheckboxes should add checckbox', () => {
          spyOn(component, 'addCheckboxes').and.callThrough();
          component.addCheckboxes();
          //expect(component.clearradioButtons).toHaveBeenCalled(); 
          //  component.clearradioButtons();
       
          });

          it('onEventType should cal getTypeOfEvent', () => {
            let cService = TestBed.get(HttpCommonService);
            let response ={"ruleFileName":"Eclaims_EventTypeComponentRender.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","claimTypeSection":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"policyDetailsSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"policyNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"9","fieldminlength":"0","allowedDataType":"numeric"},"employerDetails":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"ksession":null};
            spyOn(cService, 'postData').and.returnValue(of(response));
            component.screenRequestObj = {"partner":"metlife","sourceOfOrigin":null,"lob":"Financial","product":"Financial","submittedBy":null,"primaryClaimEvent":null,"selectedClaim":null,"screenName":"TypeOfEvent","eventType":null,"eventRelatedTo":null,"claimType":null,"relatedEventType":null}
            spyOn(component, 'getTypeOfEvent').and.callThrough();
            component.onEventType('');
            expect(component.getTypeOfEvent).toHaveBeenCalled(); 
 });
          
        
});
