import { Component, OnInit, ViewChild, HostListener, ViewEncapsulation } from '@angular/core';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { combineAll } from 'rxjs/operators';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators, AbstractControl } from '@angular/forms';
import { config, Observable, Subject } from 'rxjs';
import { CreateFormService } from 'src/app/shared/services/create-form.service';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { ScreenRenderReqModel } from '../models/ScreenRenderReqModel';
import { NewClaimSharedService } from '../add-new-claim.service';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { DataService } from 'src/app/shared/services/data.service';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-type-of-events',
  templateUrl: './type-of-events.component.html',
  styleUrls: ['./type-of-events.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TypeOfEventsComponent implements OnInit {
  typeOfEventForm: FormGroup;
  eventTypeClaim: Array<String>;
  eventTypeClaimBusiness: Array<String> = [];
  eventTypeClaimBusinessSec: Array<String> = [];
  onEventBusinessSelected: boolean = false;
  eventTypeClaimBusinessSec1: Array<String> = [];
  eventInsurance = [];
  labelPropertyFeild: string = "";
  eventSecondaryValue: Array<String> = [];
  eventTypeDisclaimerSection: Array<string> = [];
  disclaimerSectionValue: Array<string> = [];
  toolTipEnableCountry: string = '';
  typeofEventIndividualCountry: string = '';
  individualLifeShow: string = null;
  @ViewChild('labelfinLobText_tooltip', { static: false }) labelfinLobText_tooltip;
  @ViewChild('labelCLLobText_tooltip', { static: false }) labelCLLobText_tooltip;
  @ViewChild('labelgroupLobText_tooltip', { static: false }) labelgroupLobText_tooltip;
  @ViewChild('labelindvLobText_tooltip', { static: false }) labelindvLobText_tooltip;
  @ViewChild('labelTelemarketingLobText_tooltip', { static: false }) labelTelemarketingLobText_tooltip;

  eventTypeModel: EventTypeModel = new EventTypeModel();

  @HostListener('window:scroll', ['$event'])
  scrollHandler(event) {
    if (this.labelfinLobText_tooltip) {
      this.labelfinLobText_tooltip.hide();
    }

    if (this.labelCLLobText_tooltip) {
      this.labelCLLobText_tooltip.hide();
    }
    if (this.labelgroupLobText_tooltip) {
      this.labelgroupLobText_tooltip.hide();
    }
    if (this.labelindvLobText_tooltip) {
      this.labelindvLobText_tooltip.hide();
    }

    if (this.labelTelemarketingLobText_tooltip) {
      this.labelTelemarketingLobText_tooltip.hide();
    }
  }

  constructor(private cService: HttpCommonService, private fb: FormBuilder, public dataService: DataService,
    private translate: TranslateService,
    private createForm: CreateFormService, public newClaimService: NewClaimSharedService, public dialogService: DialogService) {
    //  const flagtest="assets/mocks/ComponentsBySourceOfOrigin.json";   
    //  this.cService.getData(flagtest)
    //  .subscribe( (data) =>{
    //    this.eventTypeClaim=data.lobsRendered.split("|")
    //    });

  }
  baseUrl = environment.host + environment.typeOfEventServiceConfig.url;
  headers = new HttpHeaders();
  screenRequestObj: ScreenRenderReqModel = new ScreenRenderReqModel();
  jsonObj = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.jsonObj.sourceOrigin;
  screenName1: string = 'ComponentsBySourceOfOrigin';
  partner: string = 'metlife';
  product: string = '';
  renderClaimSections;
  eventTypes() {

    this.componentSoucreOrigin();
    this.cService[environment.typeOfEventServiceConfig.method](
      (environment.host + environment.typeOfEventServiceConfig.screenInfoUrl)
      , this.screenRequestObj, this.headers).
      subscribe((response) => {
        //console.log("=========== >", response)
        this.clearradioButtons();
        this.onEventBusinessSelected = false;
        this.eventTypeClaim = (response && response.lobsRendered)?response.lobsRendered.split("|"):[]

      })
  }
  clearradioButtons(): void {
    var ele = document.getElementsByName("newclaim");
    for (var i = 0; i < ele.length; i++) {
      var element = ele[i] as HTMLInputElement;
      element.checked = false;
    }
  }
  componentSoucreOrigin() {
    this.screenRequestObj.sourceOfOrigin = this.sourceOfOrigin;
    this.screenRequestObj.partner = this.partner;
    this.screenRequestObj.screenName = this.screenName1;
  }
  formInitI() {
    this.eventTypeClaim = this.newClaimService.getParamValue('lobsRendered');
    this.renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');
    this.typeOfEventForm = this.fb.group({
      newclaim: new FormControl('', [Validators.required]),
      newclaimCode: this.fb.array([], [Validators.required]),
      claimTypeCode: this.fb.array([], [Validators.required]),
      policyNumber: this.fb.array([this.fb.control(null)]),
      employerDetails: new FormControl(),
      disclaimerSection: new FormControl(),

    });
    this.typeofEventIndividualCountry = eClaimsConstants.typeofEventIndividualCountry;
    this.individualLifeShow = eClaimsConstants.individualLifeShow;
    this.toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
  }
  ngOnInit() {
    this.formInitI();
  }
  submitEventType() {
    ////console.log("this.typeOfEventForm",this.typeOfEventForm);      
    this.createForm.markFormGroupTouched(this.typeOfEventForm);
    // //console.log(this.typeOfEventForm.value);
    this.newClaimService.setClaimData(this.typeOfEventForm.value);
    this.newClaimService.setParamValue('typeDetailsForm', this.typeOfEventForm);
    ////console.log("this.typeOfEventForm touched",this.typeOfEventForm); 
  }
  //service call for typeofeventprimary
  onEventType(e) {
    let fileInAttachment = this.dataService.getOption('uploadNewClaimList');
    if (fileInAttachment && fileInAttachment.fileUpload && fileInAttachment.fileUpload.length > 0) {
      this.dialogService.openDialog(AlertDialogComponent, { 'heading': this.translate.instant('eClaims.existingClaim.confirmationLabel'), 'body': this.translate.instant('reAttachDocument'), 'primaryButton': 'OK', 'fromTypeofevent': true });
    }
    this.eventTypeClaimBusiness = []
    this.eventSecondaryValue = []
    this.eventTypeDisclaimerSection = []
    this.eventTypeClaimBusinessSec1 = []
    this.disclaimerSectionValue = []
    this.eventInsurance = []

    this.onEventBusinessSelected = true
    const arrNewclaimCode = <FormArray>this.typeOfEventForm.controls.newclaimCode;
    arrNewclaimCode.controls = [];
    const arrClaimTypeCode = <FormArray>this.typeOfEventForm.controls.claimTypeCode;
    arrClaimTypeCode.controls = [];
    const arrPolicyNumberCode = <FormArray>this.typeOfEventForm.controls.policyNumber;
    arrPolicyNumberCode.reset();
    this.typeOfEventForm.removeControl('policyNumber');
    // this.typeOfEventForm.addControl('policyNumber', this.fb.array([this.fb.control(null)]));
    this.typeOfEventForm.get('employerDetails').reset();
    // this.typeOfEventForm.removeControl('employerDetails');
    this.typeOfEventForm.get('disclaimerSection').reset();

    this.product = e?e.target.value:'';
    this.screenRequestObj.screenName = 'TypeOfEventPrimary';
    this.screenRequestObj.partner = this.partner;
    this.screenRequestObj.product = this.product;


    this.labelPropertyFeild = e?e.target.value:'';
    //console.log("target", e.target.value)
    //const flagtest1="assets/mocks/TypeOfEventPrimary.json";  
    //this.cService.getData(flagtest1)
    this.cService[environment.typeOfEventServiceConfig.method](
      (environment.host + environment.typeOfEventServiceConfig.primaryEventUrl)
      , this.screenRequestObj, this.headers)
      .subscribe((data1) => {
        this.eventTypeClaimBusiness = data1.claimType? data1.claimType.split("|"):[];
        this.newClaimService.setParamValue('eventTypeList', data1.eventType);
        this.addCheckboxes();
      });

    this.getTypeOfEvent(this.screenRequestObj.product);

  }
  formRulesObj: any;
  getTypeOfEvent(product) {
    this.screenRequestObj.lob = product
    this.screenRequestObj.screenName = 'TypeOfEvent';
    this.screenRequestObj.partner = this.partner;
    //  this.screenRequestObj.sourceOfOrigin = this.sourceOfOrigin;

    //console.log("this.screenRequestObj", this.screenRequestObj, "this.headers", this.headers)
    let formGroupObj: any = {};
    //  const flagtest1="assets/mocks/typeofevent.json";  
    //  this.cService.getData(flagtest1)
    this.cService[environment.typeOfEventServiceConfig.method](
      (environment.host + environment.typeOfEventServiceConfig.url)
      , this.screenRequestObj, this.headers)
      .subscribe((data) => {
        //console.log("typeofevent", data)
        formGroupObj = this.createForm.generateForm(this.eventTypeModel, data);
        this.formRulesObj = this.createForm.generateForm(this.eventTypeModel, data);
        //console.log("typeofeventform formGroupObj", formGroupObj)

        // this.typeOfEventForm.addControl('employerDetails', new FormControl(formGroupObj.get('employerDetails')));
        //console.log(this.typeOfEventForm.get('employerDetails'));
        // (<any>this.typeOfEventForm.controls.employerDetails) = formGroupObj.get('employerDetails');
        this.typeOfEventForm.addControl('employerDetails', new FormControl(formGroupObj.get('employerDetails')));

        (<any>this.typeOfEventForm.get('employerDetails')).validator = this.formRulesObj.get('employerDetails').validator;
        (<any>this.typeOfEventForm.get('employerDetails')).isVisible = this.formRulesObj.get('employerDetails').isVisible;
        (<any>this.typeOfEventForm.get('employerDetails')).restrict = this.formRulesObj.get('employerDetails').restrict;
        (<any>this.typeOfEventForm.get('employerDetails')).fieldName = this.formRulesObj.get('employerDetails').fieldName;

        // (<FormArray>this.typeOfEventForm.controls['policyNumber']).controls = [(formGroupObj.get('policyNumber'))];

        this.typeOfEventForm.addControl('policyNumber', this.fb.array([formGroupObj.get('policyNumber')]));
        (<any>this.typeOfEventForm.get('policyNumber')).isVisible = formGroupObj.get('policyNumber').isVisible;
        (<any>this.typeOfEventForm.get('policyNumber')).controls[0].validator = this.formRulesObj.get('policyNumber').validator;
        (<any>this.typeOfEventForm.get('policyNumber')).controls[0].isVisible = this.formRulesObj.get('policyNumber').isVisible;
        (<any>this.typeOfEventForm.get('policyNumber')).controls[0].restrict = this.formRulesObj.get('policyNumber').restrict;
        (<any>this.typeOfEventForm.get('policyNumber')).controls[0].fieldName = this.formRulesObj.get('policyNumber').fieldName;

        //console.log("typeofeventform", this.typeOfEventForm)
      });
  }

   addCheckboxes() {

    for (let index = 0; index < this.eventTypeClaimBusiness.length; index++) {
      const value = this.eventTypeClaimBusiness[index];
      this.eventInsurance.push({ data: value, isDisabled: false });
    }
    const creds = this.typeOfEventForm.controls.newclaimCode as FormArray;

    this.eventInsurance.forEach(x => {
      creds.push(this.fb.group({
        claimEvent: x.data,
        data: new FormControl({ value: false, disabled: false }),
      }));
    });

  }

  //on select event call for the primary events
  onEventClaimType(claimCode: string, isChecked: boolean, index) {
   try{
    let fileInAttachment = this.dataService.getOption('uploadNewClaimList');
    if (fileInAttachment && fileInAttachment.fileUpload && fileInAttachment.fileUpload.length > 0) {
      this.dialogService.openDialog(AlertDialogComponent, { 'heading': this.translate.instant('eClaims.existingClaim.confirmationLabel'), 'body': this.translate.instant('reAttachDocument'), 'primaryButton': 'OK', 'fromTypeofevent': true });
    }
   } catch(e){
console.log("error",e);
   }
    let secondaryClaimEvent = '';
    const claimCodeFormArray = <FormArray>this.typeOfEventForm.controls.claimTypeCode;
    //  this.newClaimService.setPrimaryClaimType(claimCode);
    //  this.getEventTypeSec(claimCode,index);
    //  this.getDisclaimerSection(claimCode);
    if (isChecked) {
      claimCodeFormArray.push(new FormControl(claimCode));
    } else {
      let index = claimCodeFormArray.controls.findIndex(x => x.value == claimCode)
      claimCodeFormArray.removeAt(index);
    }
    let flagSecondaryClaimEvent = false;
    this.typeOfEventForm.controls.newclaimCode.value.forEach(x => {
      if (secondaryClaimEvent == '') {

        if (x.data == true) {
          flagSecondaryClaimEvent = true
          secondaryClaimEvent += x.claimEvent;
        }
      } else {

        if (x.data == true) {
          flagSecondaryClaimEvent = true
          secondaryClaimEvent += '|' + x.claimEvent;

        }
      }

    })

    this.newClaimService.setPrimaryClaimType(secondaryClaimEvent);

    if (flagSecondaryClaimEvent) {
      this.getEventTypeSec(secondaryClaimEvent, index);
      this.getDisclaimerSection(secondaryClaimEvent);

    } else {
      const control = this.typeOfEventForm.controls.newclaimCode as FormArray;
      control.enable();
      this.disclaimerSectionValue = [];
    }
  }
  //service call for typeofeventsecondary
  getEventTypeSec(claim: string, index) {
    const i = index
    // const flagtest2="assets/mocks/TypeOfEventSecondary.json";   
    // this.cService.getData(flagtest2)
    this.typeOfEventSecondary();
    this.screenRequestObj.primaryClaimEvent = claim;

    this.cService[environment.typeOfEventServiceConfig.method](
      (environment.host + environment.typeOfEventServiceConfig.secondaryEventUrl),
      this.screenRequestObj, this.headers)
      .subscribe((data2) => {

        this.eventTypeClaimBusinessSec1 = data2.secondaryClaimEvent.split("|");
        this.newClaimService.setnewClaimConfirmationCodes(data2.confirmationCode);
        this.newClaimService.updateComponents(data2.confirmationCode);
        // console.log(data2.confirmationCode);
        this.disableCheckbox(i);

      }
      );
  }
  typeOfEventSecondary() {
    this.screenRequestObj.sourceOfOrigin = this.sourceOfOrigin;
    this.screenRequestObj.partner = this.partner;
    this.screenRequestObj.screenName = 'TypeOfEventSecondary';
    this.screenRequestObj.submittedBy = this.jsonObj.submittedBy;

  }
  disableCheckbox(index) {
    this.eventSecondaryValue = this.eventTypeClaimBusinessSec1
    const control = this.typeOfEventForm.controls.newclaimCode as FormArray;
   if(this.eventSecondaryValue && this.eventSecondaryValue.length){
    for (let i = 0; i < this.eventSecondaryValue.length; i++) {

      for (let j = 0; j < this.eventInsurance.length; j++) {
        if (this.eventInsurance[j].data == this.eventSecondaryValue[i]) {
          control.at(j).enable();
          //  //console.log("if:",this.eventInsurance[j].data,'-',this.eventSecondaryValue[i])
        } else {
          if (this.eventSecondaryValue.indexOf(this.eventInsurance[j].data) < 0) {
            control.at(j).disable();
          }

        }
      }
    }
  }
  }

  getDisclaimerSection(claim: string) {
    //     const flagtest2="assets/mocks/TypeOfEventSecondary.json";   

    this.typeOfEventSecondary();
    this.screenRequestObj.primaryClaimEvent = claim;

    this.cService[environment.typeOfEventServiceConfig.method](
      (environment.host + environment.typeOfEventServiceConfig.secondaryEventUrl),
      this.screenRequestObj, this.headers)
      .subscribe((data3) => {
       console.log("type of event",data3.disclaimerCode.split("|"));
        if(data3 && data3.disclaimerCode){
          this.eventTypeDisclaimerSection = data3.disclaimerCode.split("|")
        }
        else{
          this.eventTypeDisclaimerSection = [];
        }
        //console.log(this.eventTypeDisclaimerSection)
        this.getValueDisclaimerSection();
        this.typeOfEventForm.controls['disclaimerSection'].setValue(data3.disclaimerCode)
      }
      );

  }

  getValueDisclaimerSection() {

    this.disclaimerSectionValue = this.eventTypeDisclaimerSection.filter((element, i, arr) => {
      if (arr.indexOf(element) === i) {
        return element
      }
    })
    //console.log("Final disclaimer", this.disclaimerSectionValue);
  }

  addPolicyNumberText(index): void {
    // (this.typeOfEventForm.get('policyNumber') as FormArray).push(
    //   this.formRulesObj.get('policyNumber')
    // );
    // need to assign fieldName and isvisible property to policyNumber 

    if (index < 19) {
      (this.typeOfEventForm.get('policyNumber') as FormArray).push(
        new FormControl('', this.formRulesObj.get('policyNumber').validator)
      );
      (<any>this.typeOfEventForm.get('policyNumber')).controls[index + 1].isVisible = this.formRulesObj.get('policyNumber').isVisible;
      (<any>this.typeOfEventForm.get('policyNumber')).controls[index + 1].restrict = this.formRulesObj.get('policyNumber').restrict;
      (<any>this.typeOfEventForm.get('policyNumber')).controls[index + 1].fieldName = this.formRulesObj.get('policyNumber').fieldName;

    }
  }

  removePolicyNumberText(index) {

    (this.typeOfEventForm.get('policyNumber') as FormArray).removeAt(index);
  }

  getPolicyNumberTextFormControls() {
    if (this.typeOfEventForm.get('policyNumber')) {
      return (<any>this.typeOfEventForm.get('policyNumber')).controls
    }
    return null;
  }
  formSubmit() {
    return this.typeOfEventForm.valid;
  }
}

export class EventTypeModel {
  claimTypeSection: string = null;
  policyDetailsSection: string = null;
  policyNumber: string = null;
  employerDetails: string = null;
}

