import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AddNewClaimComponent } from './add-new-claim.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { PersonalDetailsComponent } from './personal-details/personal-details.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { AttachmentsComponent } from './attachments/attachments.component';
import { ReviewDetailsComponent } from './review-details/review-details.component';
import { MatStepperModule } from '@angular/material';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TypeOfEventsComponent } from './type-of-events/type-of-events.component';
import { NewClaimConfirmationComponent } from './new-claim-confirmation/new-claim-confirmation.component';
import { InsuranceReferSecComponent } from './personal-details/insurance-refer-sec/insurance-refer-sec.component';
import { BenefitSecComponent } from './personal-details/benefit-sec/benefit-sec.component';
import { CorrespondAddressSecComponent } from './personal-details/correspond-address-sec/correspond-address-sec.component';
import { ResidenceAddressSecComponent } from './personal-details/residence-address-sec/residence-address-sec.component';
import { FormDisbursementSecComponent } from './personal-details/form-disbursement-sec/form-disbursement-sec.component';
import { EventInformationSecComponent } from './event-details/event-information-sec/event-information-sec.component';
import { AdditionalDetailsSecComponent } from './event-details/additional-details-sec/additional-details-sec.component';
import { HealthcareEventSecComponent } from './event-details/healthcare-event-sec/healthcare-event-sec.component';
import { HealthcareFamilydocSecComponent } from './event-details/healthcare-familydoc-sec/healthcare-familydoc-sec.component';
import { TypeEventReviewSectionComponent } from './review-details/type-event-review-section/type-event-review-section.component';
import { EventDetailReviewSectionComponent } from './review-details/event-detail-review-section/event-detail-review-section.component';
import { PersonalDetailReviewSectionComponent } from './review-details/personal-detail-review-section/personal-detail-review-section.component';
import { EventInfoReviewSecComponent } from './review-details/event-detail-review-section/event-info-review-sec/event-info-review-sec.component';
import { AdditionalSecReviewComponent } from './review-details/event-detail-review-section/additional-sec-review/additional-sec-review.component';
import { HealthCarePrimaryReviewComponent } from './review-details/event-detail-review-section/health-care-primary-review/health-care-primary-review.component';
import { HealthcareFamilydocRevSecComponent } from './review-details/event-detail-review-section/healthcare-familydoc-rev-sec/healthcare-familydoc-rev-sec.component';
import { BenefitSecReviewComponent } from './review-details/personal-detail-review-section/benefit-sec-review/benefit-sec-review.component';
import { FormDisbursemnetReviewSecComponent } from './review-details/personal-detail-review-section/form-disbursemnet-review-sec/form-disbursemnet-review-sec.component';
import { DeviceDetectorService } from 'ngx-device-detector';
import { NewClaimCommonService } from '../core/services/add-new-claim-common.service';
import {AdditionalFieldAddressInfoModel} from './models/AdditionalFieldAddressInfoModel';
import { NewClaimSharedService } from './add-new-claim.service';
import { AdditionalFieldDetailsModel, EventInformationModel } from './event-details/event-details.model';
import { ClaimAttachmentModel } from './models/ClaimAttachmentModel';
import { ClaimCommunicationAddressModel } from './models/ClaimCommunicationAddressModel';
import { ClaimTypeModel } from './models/ClaimTypeModel';
import { DisbursementBenefitModel } from './models/DisbursementBenefitModel';
import { HealthCareFamilyDocModel } from './models/healthCareFamilyDocModel';
import { PersonProposesClaimInfoModel } from './models/PersonProposesClaimInfoModel';
import { PersonInsuranceInfoModel } from './models/PersonInsuranceInfoModel';
import { HealthCareCenterInfoModel } from './models/HealthCareCenterInfoModel';
import { HCFamilyDocModel } from './models/HCFamilyDocModel';
import { HCAddressInfoModel } from './models/HCAddressInfoModel';



describe('AddNewClaimComponent', () => {
  let component: AddNewClaimComponent;
  let fixture: ComponentFixture<AddNewClaimComponent>;

  let additionalFieldDetailsModel:AdditionalFieldDetailsModel;
  additionalFieldDetailsModel= new AdditionalFieldDetailsModel();
  
  let additionalFieldAddressInfoModel:AdditionalFieldAddressInfoModel;
additionalFieldAddressInfoModel= new AdditionalFieldAddressInfoModel();


let claimAttachmentModel:ClaimAttachmentModel;
claimAttachmentModel= new ClaimAttachmentModel();

let claimCommunicationAddressModel:ClaimCommunicationAddressModel;
claimCommunicationAddressModel= new ClaimCommunicationAddressModel();

let claimTypeModel:ClaimTypeModel;
claimTypeModel= new ClaimTypeModel();

let disbursementBenefitModel:DisbursementBenefitModel;
disbursementBenefitModel= new DisbursementBenefitModel();

let healthCareFamilyDocModel:HealthCareFamilyDocModel;
healthCareFamilyDocModel= new HealthCareFamilyDocModel();

let personProposesClaimInfoModel:PersonProposesClaimInfoModel;
personProposesClaimInfoModel= new PersonProposesClaimInfoModel(); 

let personInsuranceInfoModel:PersonInsuranceInfoModel;
personInsuranceInfoModel= new PersonInsuranceInfoModel();

let healthCareCenterInfoModel:HealthCareCenterInfoModel;
healthCareCenterInfoModel= new HealthCareCenterInfoModel();

let hCFamilyDocModel:HCFamilyDocModel;
hCFamilyDocModel= new HCFamilyDocModel();

let hCAddressInfoModel:HCAddressInfoModel;
hCAddressInfoModel= new HCAddressInfoModel();

let eventInformationModel:EventInformationModel;
eventInformationModel= new EventInformationModel();


let newClaimService: NewClaimSharedService = new NewClaimSharedService();
    const typeOfEventRefComp = jasmine.createSpy('TypeOfEventsComponent');
    const personalDetailsRefComp = jasmine.createSpy('PersonalDetailsComponent');
    const eventDetailsComp = jasmine.createSpy('EventDetailsComponent');

    beforeEach(async(() => {

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, FormsModule ,ReactiveFormsModule,SharedModule,MatStepperModule,HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ AddNewClaimComponent,PersonalDetailsComponent,EventDetailsComponent,
        AttachmentsComponent,ReviewDetailsComponent, TypeOfEventsComponent,NewClaimConfirmationComponent,
        InsuranceReferSecComponent,BenefitSecComponent,CorrespondAddressSecComponent,ResidenceAddressSecComponent,FormDisbursementSecComponent,
        EventInformationSecComponent,AdditionalDetailsSecComponent,HealthcareEventSecComponent,HealthcareFamilydocSecComponent,
        TypeEventReviewSectionComponent,EventDetailReviewSectionComponent,PersonalDetailReviewSectionComponent,EventInfoReviewSecComponent,
        AdditionalSecReviewComponent, HealthCarePrimaryReviewComponent,HealthcareFamilydocRevSecComponent,BenefitSecReviewComponent,
        FormDisbursemnetReviewSecComponent,
      ],
        providers:[ MatStepperModule ,DeviceDetectorService,NewClaimCommonService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    if(!(sessionStorage.getItem('userData'))){
      var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(AddNewClaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('langChangeCalls should call languageJsonChange', () => {
    spyOn(component, 'stepperReset').and.callThrough();
    
    component.personalDetailsSecError = true;
    component.eventDetailsSecError = true;
    component.attachmentSecError = true;
    component.reviewSecError = true;

    component.stepperReset();

    expect(component.personalDetailsSecError).toBe(false);
    expect(component.eventDetailsSecError).toBe(false);
    expect(component.attachmentSecError).toBe(false);
    expect(component.reviewSecError).toBe(false);
  })
  it('componentSoucreOrigin it should set sourceOfOrigin ', () => {
    component.sourceOfOrigin = "O";
    component.partner="P";
    expect(component.screenRequestObj.sourceOfOrigin).toEqual("O")
  
   })
   
   it('it should call all model for submit', () => {
    component.sourceOfOrigin = "O";
    component.partner="P";
    expect(component.screenRequestObj.sourceOfOrigin).toEqual("O")
  
   })
   
   it('save claim', () => {
    
    
    let attachmentResponse=[{"claimAttachmentsId":26679,"orderId":"666600","claimNumber":"666600","claimType":"Financial","documentType":"DT","documentExt":"png","status":3,"exportTime":1617976483321,"fileName":"Capture.PNG","document":null,"id":"00000000000000021064_00000001617976483321_00002","pdfDocumentType":"fin4","sectionRender":false,"fileValue":"c2895634eb1c525b"}];
    let claimNo ='666600';
    let attachmentsComp={};
    
    spyOn(newClaimService, 'getnewClaimConfirmationCodes').and.returnValue("E160|E180");
    // component.personalDetailsRefComp= personalDetailsRefComp;
    // component.eventDetailsComp=eventDetailsComp;
    // component.typeOfEventRefComp=typeOfEventRefComp;

    // component.saveClaim(attachmentResponse, claimNo, attachmentsComp)
   // expect(component.saveClaim).toHaveBeenCalled();
  
   })

});
