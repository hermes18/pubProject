import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { NewClaimConfirmationComponent } from './new-claim-confirmation.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { MatDialogModule } from '@angular/material';
import { NewClaimCommonService } from 'src/app/core/services/add-new-claim-common.service';
import { NewClaimSharedService } from '../add-new-claim.service';
import { Observable,BehaviorSubject } from "rxjs";
import { of } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
export class AlertInputDialogComponent{

}
export class NewClaimCommonServiceAlias{
  selectedLangSubject:any='PL';
  triggerLanguageSeletionValue(): Observable<any> {
    return of(this.selectedLangSubject);
}

}


describe('NewClaimConfirmationComponent', () => {
//  spyOn(window.location, 'reload').and.callFake(function(){});

  let component: NewClaimConfirmationComponent;
  let fixture: ComponentFixture<NewClaimConfirmationComponent>;
  //let claimCommonService: NewClaimCommonService = new NewClaimCommonService();
  const { location } = window;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,
        HttpClientTestingModule,MatDialogModule,BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ NewClaimConfirmationComponent ],
      providers:[{ provide: 'Window', useFactory: () => window },
    {provide: NewClaimCommonService,useClass:NewClaimCommonServiceAlias},NewClaimSharedService]
    })
    //.overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [AlertInputDialogComponent] } })
    .compileComponents();
  }));
  
  beforeEach(() => {
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
 
    fixture = TestBed.createComponent(NewClaimConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    spyOn(component, 'navigateToBack').and.callFake(function(){});
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


it('oninit should call triggerSaveClaimResponseApi', () => {
  let saveClaimResponse = {"claimNo":"666602","lob":"Individual","language":null,"emailId":"sdf@sdf.sdf","claimStatus":"Success","claimAttachmentVO":[{"claimAttachmentsId":0,"orderId":"666602","claimNumber":"666602","claimType":null,"documentType":"DP","documentExt":"png","status":3,"exportTime":null,"fileName":"Capture.PNG","document":"","id":null,"pdfDocumentType":"ALL002","sectionRender":false,"fileValue":"78ce81a7b41fe452"},{"claimAttachmentsId":26682,"orderId":"666602","claimNumber":"666602","claimType":"Individual","documentType":"FO","documentExt":"pdf","status":3,"exportTime":1618296169520,"fileName":"666602.pdf","document":null,"id":"00000000000000021064_00000001618296169519_00005","pdfDocumentType":null,"sectionRender":false,"fileValue":"fa3d48a8c9172f22"}]};  
  let claimcode = "conf3|conf1|conf10|conf13|confi|conf19";
  let newClaimService = TestBed.get(NewClaimSharedService);
  spyOn(newClaimService, 'triggerSaveClaimResponseApi').and.returnValue(of(saveClaimResponse)); 
  spyOn(newClaimService, 'getCNPField').and.returnValue(null); 
  spyOn(newClaimService, 'getIndividual').and.returnValue(true); 
  spyOn(component, 'getCodeValues').and.callThrough(); 
  spyOn(newClaimService, 'triggerApi').and.returnValue(of(claimcode)); 
  
  component.codeListArr=["conf3","conf1","conf10","conf13","confi","conf19"];
  component.ngOnInit();
  
  expect(component.getCodeValues).toHaveBeenCalled();
});
it('gotoReportNextClaim should call redirectTo', () => {
  component.sourceOfOrigin='B';
  spyOn(component, 'redirectTo').and.callThrough(); 
  spyOn(component, 'gotoReportNextClaim').and.callThrough(); 
  spyOn(component.dialogService, 'openDialog').and.callFake(function(){}); 
  component.gotoReportNextClaim('conf21');
  component.isIndividual = true;
  component.pesel = '12345678';
  component.gotoReportNextClaim('conf20');
  component.gotoReportNextClaim('conf19');
  component.isIndividual = true;
  component.pesel = '12345678';
  component.gotoReportNextClaim('conf20');
  component.gotoReportNextClaim('conf19');
  component.gotoReportNextClaim('');
  expect(component.gotoReportNextClaim).toHaveBeenCalled();
});
  
it('splitListToDisplay should call splitListToDisplay', () => {
 component.confirmationCodeList=['conf14','conf21'];
 spyOn(component, 'splitListToDisplay').and.callThrough(); 
  component.splitListToDisplay();
  component.confirmationCodeList=['conf15','conf21'];
  component.splitListToDisplay();
  component.confirmationCodeList=['conf16','conf21'];
  component.splitListToDisplay();
  expect(component.splitListToDisplay).toHaveBeenCalled();
});
it('redirectTo should call redirectTo', () => {
 
  component.sourceOfOrigin='B';
  //spyOn(component, 'redirectTo').and.callThrough(); 
  //expect(component.redirectTo).toHaveBeenCalled();
 });

 it('downloadConfirmFormByClaimNo should call getDownloadPDF', () => {
  component.sourceOfOrigin='B';
  spyOn(window, "confirm").and.returnValue(true);
  spyOn(component, 'getDownloadPDF').and.callThrough(); 
  spyOn(component, 'downloadFile').and.callThrough(); 
  
  component.downloadFile('gddgdgg');

   expect(component.downloadFile).toHaveBeenCalled();
   
 });
 it('gotoMetlife should call window.open ', () => {
    
  spyOn(component, 'gotoMetlife').and.callThrough();
  component.gotoMetlife();
  sessionStorage.setItem("defaultLanguage","pl_en");
  component.gotoMetlife();
  sessionStorage.setItem("defaultLanguage","ro_ro");
  component.gotoMetlife();
  sessionStorage.setItem("defaultLanguage","ro_en");
  component.gotoMetlife();
  expect(component.gotoMetlife).toHaveBeenCalled();
});
it('navigateToBack should call reload ', () => {
  
  //spyOn(component, 'navigateToBack').and.callFake(function(){});
 
  component.navigateToBack();
  
  expect(component.navigateToBack).toHaveBeenCalled();
});

it('navigateToExistedClaim should call router ', () => {
  let event ={target:{
    localName:"a"
  }}
  let code = "class='attachDoc'"
  component['enableExistingClaimNav'] = true;
  spyOn(component.router, 'navigate').and.callThrough();

  component.navigateToExistedClaim(event,code);
    
  component.navigateToBack();
  expect(component.router.navigate ).toHaveBeenCalled();

});

});
