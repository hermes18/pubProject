import { Component, OnInit, AfterViewInit, EventEmitter, Output, Input, ViewEncapsulation } from '@angular/core';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { saveAs } from 'file-saver';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { NewClaimSharedService } from '../add-new-claim.service';
import { TranslateService } from '@ngx-translate/core';
import { DataService } from 'src/app/shared/services/data.service';
import { Router } from '@angular/router';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { AlertInputDialogComponent } from 'src/app/shared/dialog/alert-input-dialog/alert-input-dialog.component';
import { NewClaimCommonService } from 'src/app/core/services/add-new-claim-common.service';

@Component({
  selector: 'new-claim-confirmation',
  templateUrl: './new-claim-confirmation.component.html',
  styleUrls: ['./new-claim-confirmation.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class NewClaimConfirmationComponent implements OnInit, AfterViewInit {
  public newClaimResponse;
  public attachmentDocumentName;
  public confirmationCodes;
  confirmationCodeList: any = [];
  showDownloadBtn: boolean = false;
  claimNumber: any = '';
  codeListArr: any = [];
  pesel: any;
  isIndividual: boolean;
  @Output() isconfirmationTab: EventEmitter<boolean> = new EventEmitter();
  @Output() setClaimCompFlag: EventEmitter<boolean> = new EventEmitter();
  @Input() data;
  enableExistingClaimNav: boolean;
  codeListB4DwnldBtn: any = [];
  codeListAfterDwnldBtn: any = [];
  dwnldBtnIndex: any;
  jsonObj = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.jsonObj.sourceOrigin;

  constructor(private httpService: HttpCommonService,
    public newClaimService: NewClaimSharedService,
    public translate: TranslateService,
    private commonService: HttpCommonService,
    public dataService: DataService,
    public router: Router,
    public dialogService: DialogService,
    public claimCommonService: NewClaimCommonService) {
  }

  ngOnInit() {
    window.scroll(0,0);
    this.newClaimService.triggerApi().subscribe(data => {
     // console.log('subject Data in onInit:', data);
      this.confirmationCodes = data;//this.newClaimService.getnewClaimConfirmationCodes();
      this.codeListArr = this.confirmationCodes ? this.confirmationCodes.split('|') : '';
    });
    this.newClaimService.triggerSaveClaimResponseApi().subscribe(response => {
     // console.log('save subject Data in onInit:', response);
      this.newClaimResponse = response;//this.newClaimService.getNewClaimResponse();
      this.attachmentDocumentName = this.newClaimResponse ? this.newClaimResponse.claimAttachmentVO[this.newClaimResponse.claimAttachmentVO.length - 1].documentExt : '';
      this.claimNumber = this.newClaimResponse ? this.newClaimResponse.claimAttachmentVO[this.newClaimResponse.claimAttachmentVO.length - 1].claimNumber : '';
      this.isIndividual = this.newClaimService.getIndividual() ? this.newClaimService.getIndividual() : false;
      this.pesel = this.newClaimService.getCNPField() ? this.newClaimService.getCNPField() : '';
      this.getCodeValues();
    });

    this.claimCommonService.triggerLanguageSeletionValue().subscribe(defLang => {
     // if (this.confirmationCodeList.length > 0) {
       //console.log('selectedLang:', defLang);
        this.getCodeValues();
      //}
    });
  }

  ngAfterViewInit() {

  }

  ngOnChanges() {

  }
  getCodeValues() {
    this.confirmationCodeList = [];
    if (this.codeListArr.length != 0) {
      this.codeListArr.forEach(value => {
        if ((value != 'conf13') && (value != 'conf15') && (value != 'conf16') && (value != 'conf14')) {
         
          let data = this.translate.instant(value);
         
          //this.translate.get(value).subscribe((data: any) => {
            if (data.includes('XXXXXX') && (!data.includes('class="pdfIcon"'))) {
              /*  data = data.replace('XXXXXX', this.claimNumber);
               this.confirmationCodeList.push(data);*/

              if (data.includes("class='attachDoc'")) {
                this.enableExistingClaimNav = true;
                data = data.replace('XXXXXX', this.claimNumber);
                this.confirmationCodeList.push(data);
                // let data1 =data.slice(0,data.indexOf("<i>")); 
                // this.confirmationCodeList.push(data1);
                // let data2 = data.slice(data.indexOf("<i>"),(data.indexOf("</i>") +  4));
                // this.confirmationCodeList.push(data2);
                // let data3 = data.slice((data.indexOf("</i>") +  4),(data.length-1));
                // this.confirmationCodeList.push(data3);
                // console.log("1: ", data1,"2: ", data2, "3: ", data3);
              } else {
                data = data.replace('XXXXXX', this.claimNumber);
                this.confirmationCodeList.push(data); //msg with claim number
              }

              // let code011 = data.split('XXXXXX.');
              // code011.forEach(index => {
              //   if (code011[index].includes('XXXXXX')) {
              //     code011[index] = code011[index].replace('XXXXXX', this.claimNumber);
              //                 this.confirmationCodeList.push(code011[index])
              //   }
              // });
              //this.confirmationCodeList.push(data); //msg with claim number

              // } else if ((value!= 'conf13 || conf15')  && data.includes('class="pdfIcon"') && data.includes('XXXXXX')) {
              //   this.showDownloadBtn = true;
              //   data = data.replace(data, 'Download Confirmation');
              //   this.confirmationCodeList.push(data);
            } else {
              this.confirmationCodeList.push(data); //msg without claim number
            }
         // });
        } else if ((value == 'conf13') || (value == 'conf15') || (value == 'conf16') || (value == 'conf14')) {
          this.showDownloadBtn = true;
          this.confirmationCodeList.push(value); //download btn code
        } else {
          this.confirmationCodeList.push(value); //report claim button codes 
        }
      });
      if (this.confirmationCodeList.length > 0) {
        this.splitListToDisplay();
      }
    }
  }

  splitListToDisplay() {
    let tempArr = [];
    tempArr = JSON.parse(JSON.stringify(this.confirmationCodeList));
    for (let i = 0; i < tempArr.length; i++) {
      if (tempArr[i] == 'conf13') {
        this.dwnldBtnIndex = i;
        break;
      } else if (tempArr[i] == 'conf14') {
        this.dwnldBtnIndex = i;
        break;
      } else if (tempArr[i] == 'conf15') {
        this.dwnldBtnIndex = i;
        break;
      } else if (tempArr[i] == 'conf16') {
        this.dwnldBtnIndex = i;
        break;
      } else { }
    }
    this.codeListB4DwnldBtn = tempArr.splice(0, this.dwnldBtnIndex);
    this.codeListAfterDwnldBtn = tempArr.splice(1, (tempArr.length - 1));
    // this.codeListB4DwnldBtn = tempArr.splice(0,tempArr.indexOf('conf13' || 'conf14' || 'çonf15' || 'conf16'));
    // this.codeListAfterDwnldBtn = tempArr.splice((tempArr.indexOf('conf13' || 'conf14' || 'çonf15' || 'conf16') + 1),(tempArr.length -1));
    //console.log('b4:', this.codeListB4DwnldBtn, 'áfter:', this.codeListAfterDwnldBtn, 'conformcodelist:', this.confirmationCodeList);
  }
redirectTo(){
  if(this.sourceOfOrigin!='C'){
    this.router.navigate(['/landing']);
  }else{
    window.location.reload();
    //this.router.navigate(['/landing']);
    //this.router.navigate(['/newClaim']);
  }
}
  gotoReportNextClaim(code) {
    if (code == 'conf21') {
      //clear form values and navigate to landing page
      this.redirectTo();
    } else if (code == "conf20") {
      if (this.isIndividual && this.pesel !== '') {
        this.dialogService.openDialog(AlertInputDialogComponent, { 'heading': '', 'body': this.translate.instant('backAlert'), 'cnfmCode': code, 'primaryButton': this.translate.instant('eClaims.newClaim.personalDtails.nextButtonLabel'), 'tertiaryButton': this.translate.instant('Cancel'), 'nextUrl': 'newClaim' });
      } else {
        // navigate to landing with clearing all data
        this.redirectTo();
      }
    } else if (code == "conf19") {
      if (this.isIndividual && this.pesel !== '') {
        this.dialogService.openDialog(AlertInputDialogComponent, { 'heading': '', 'body': this.translate.instant('backAlert'), 'cnfmCode': code, 'primaryButton': this.translate.instant('eClaims.newClaim.personalDtails.nextButtonLabel'), 'tertiaryButton': this.translate.instant('Cancel'), 'nextUrl': 'newClaim' });
        //this.router.navigate(['/newClaim']);
      } else {
        // navigate to landing with clearing all data
        this.redirectTo();
      }
    } else {
      this.redirectTo();
    }

    //this.dialogService.openDialog(AlertInputDialogComponent, { 'heading': this.translate.instant('eClaims.existingClaim.confirmationLabel'), 'body': this.translate.instant('backAlert'), 'primaryButton': this.translate.instant('eClaims.newClaim.personalDtails.nextButtonLabel'), 'tertiaryButton': 'CANCEL', 'nextUrl': '' });
  }

  getDownloadPDF() {
    let fileID = this.newClaimResponse.claimAttachmentVO[this.newClaimResponse.claimAttachmentVO.length - 1].claimnumber;//this.dataService.getOption('claimnumber');
    let docId = this.newClaimResponse.claimAttachmentVO[this.newClaimResponse.claimAttachmentVO.length - 1].fileValue;
   // console.log(docId);

    let url = environment.host + environment.confirmationDownloadServiceConfig.url + docId;
    this.commonService.downloadPDF(url).subscribe((data) => {
      this.downloadFile(data);
    });
  }

  downloadConfirmFormByClaimNo() {
    //if (((code == 'conf13') || (code == 'conf15') || (code == 'conf16') || (code == 'conf14')) && this.showDownloadBtn) {
    let confirmDownload = confirm(this.translate.instant('eClaims.existingClaim.confirmation.CacheWarning'));
    if (confirmDownload == true) {
      this.getDownloadPDF()
    }
    // } else if (code.includes("class='attachDoc'") && this.enableExistingClaimNav) {
    //   this.router.navigateByUrl('/existedClaim');
    // } else { }
  }

  downloadFile(data) {
    window.scroll(0,0);
    let blob = new Blob([data], { type: "application/pdf" });
    if (window.navigator.msSaveOrOpenBlob) {
      //IE11 & Edge
      window.navigator.msSaveOrOpenBlob(blob,'Claim_Form.pdf');
    } else {
      let url = window.URL.createObjectURL(blob);
      window.open(url);
    }
  }

  gotoMetlife() {
    let redirectTo = "https://www.metropolitanlife.ro/";
    let language = sessionStorage.getItem("defaultLanguage");

    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/";
        break;
      case 'ro_ro': redirectTo = "https://www.metropolitanlife.ro/";
        break;
      case 'ro_en': redirectTo = "https://www.metropolitanlife.ro/";
        break;
    }
    window.open(redirectTo, "_blank");
  }

  navigateToExistedClaim(event,code) {
    if (code.includes("class='attachDoc'") && this.enableExistingClaimNav && event.target.localName == 'a') {
      this.router.navigate(['/existedClaim']);
    }
  }

  navigateToBack(){
    //this.newClaimService.updateShowClaimComponent(false); 
    //this.router.navigate(['/landing']);
    window.location.reload();
  }

}