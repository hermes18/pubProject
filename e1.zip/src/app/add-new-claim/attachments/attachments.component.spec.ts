import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule,FormsModule  } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { AttachmentsComponent } from './attachments.component';
import {
  MatDialogModule,  MatSelectModule, MatFormFieldModule
} from '@angular/material';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';


import { DataService } from 'src/app/shared/services/data.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { CreateFormService } from 'src/app/shared/services/create-form.service';

import { BroadcasterService } from '../../shared/services/broadcaster.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { NewClaimSharedService } from '../add-new-claim.service';
import { of } from 'rxjs';


describe('AttachmentsComponent', () => {
  let component: AttachmentsComponent;
  let fixture: ComponentFixture<AttachmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule, MatDialogModule,  
        MatSelectModule, MatFormFieldModule,FormsModule,HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ AttachmentsComponent ],
      providers:[{ provide: 'Window', useFactory: () => window },
      DataService,CreateFormService,NewClaimSharedService,BroadcasterService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(AttachmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('formInit should call getOperationKey if sourceOfOrigin is not "B" ', () => {
    let newClaimService = TestBed.get(NewClaimSharedService);
    let paramval={"ruleFileName":"Eclaims_ComponentRenderBySourceOfOrigin.xls_FIELD_RENDER_DETAILS","sheetName":null,"partner":"metlife","sourceOfOrigin":"O","breadCrumbsRendered":"TypeOfEvent|PersonalDetails|EventDetails|Attachments|Review","lobsRendered":"FI|Grp|Indv|Pen","disclaimerSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"insuranceRefersToSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"entitledForBenefitsSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"correspondenceAddressSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"resideneAddressSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"formOfDisbursementSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"tab2AttachmentsSection":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"tab2AdditionalCommentsSection":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"tab2EmailAddressSection":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"tab2copyPersonalDataFromEc":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"tab2copyAddressFromEc":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"tab2MobilenumberField":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"tab2PreferredModeOfcommunication":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"eventInformationSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"additionalFieldDetailsSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"informationHealthCareEventSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"informationHealthCareFamilyDocSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"attachmentSection":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"additionalCommentsSection":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"browseButton":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"attachmentList":"ALL000_existing|ALL005_existing|ALL001_existing|ALL007_existing|ALL003_existing","tab2renderAmlDeclaration":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"ksession":null}
    let eventDetailVal ={"eventInformationSection":{"dateOfEvent":"","dateOfBirth":"","dateLabel":"","placeOfEvent":"","eventRelatedTo":"sickness","causeOfEvent":"","descriptionOfEvent":""},"additionalFieldDetailsSection":{"dateOffirstSymptomsDisease":"","dateOfRecognitionDisease":"","notApplicableCheckBox":null,"dateWhenPhysicalInjuriesOccurred":null,"sickLeavePeriod":null,"sickLeavePeriodFromDate":null,"sickLeavePeriodToDate":null,"sickLeavePeriodNACheckBox":null,"temporaryDisabilityPeriod":null,"dateCompletionOfMedicalTreatment":null,"medicalTreatmentNotApplicable":null,"medicalTreatmentStillUndergoing":null,"employerPreparedAccidentReport":"","policeConductedInvestigation":null,"houseNumber":"","postalCode":"","postBox":"","caseNumber":"","forwhatperiod":"","employmentPeriod":null,"employmentPeriodFromDate":null,"employmentPeriodToDate":null,"article":null,"county":null,"zipCode":null,"city":null,"flatNo":null,"block":null,"entrance":null,"appartment":null,"sector":null,"otherCountry":"","otherSportsClubCountry":"","eventAfterConsumptionAlcohol":"","sportsClubPlayerDropDown":null,"sportsClubHouseNumber":"","sportsClubPostalCode":"","sportsClubPostBox":"","sportsClubCountyName":null,"sportsClubZipCode":null,"sportsClubCity":null,"sportsClubFlatNo":null,"sportsClubBlock":null,"sportsClubEntrance":null,"sportsClubAppartment":null,"sportsClubSector":null},"informationHealthCareEventSection":[{"healthCareCenterName":"","healthCareCenterStreetName":"","healthCareCenterHouseNumber":"","healthCareCenterCountry":"PL","healthCareCenterPostalCode":"","healthCareCenterPeriodFrom":"","healthCareCenterPostBox":null,"healthCareCenterTown":null,"healthCareCenterPeriodTo":"","healthCareCenterCounty":"","healthCareCenterZipCode":"","healthCareCenterCity":"","healthCareCenterBlock":"","healthCareCenterFlatNo":"","healthCareCenterEntrance":"","healthCareCenterAppartment":"","healthCareCenterSector":"","hcCount":"","healthCareOtherCountry":""}],"informationHealthCareFamilyDocSection":[{"familyDoctorName":"","familyDoctorStreetName":"","familyDoctorHouseNumber":"","familyDoctorFlatNumber":"","familyDoctorCountry":"PL","familyDoctorPostalCode":"","familyDoctorPhoneNumber":"","familyDoctorPostBox":null,"familyDoctorTown":null,"familyDoctorOtherCountry":""}]}
    let personalVal={
      controls:{entitledForBenefitsSection:{
        value:{
          "entitledForBenefitsSection":{"benefitiaryGrp":null,"individual":null,"institutionDifferentThanTrader":null,"trader":null,"nationalityIndv":[{"citizenship":"PL","fillInTheNationalityIndv":"","documentValidupto":""}],"citizenship":null,"peselNumberIndv":null,"NationalityReg":null,"nationality_bu_Inst":[{"nationality":"PL","fillInTheNationalityReg":""}],"nationality_bu_Trader":[{"nationality":"PL","fillInTheNationalityTraderReg":""}],"amlAcceptanceCheck":null,"cnpfieldIndv":null}
        }
      }},
      value:{"insuranceRefersToSection":{"insuranceEventRefersTo":"PrimaryPolicyHolderEvent","nameField":null,"surnameField":null,"citizenship":null,"peselField":null,"dobField":"","sexField":null,"passportNumField":null,"currentProfessionField":null,"qualifiedProfessionField":null,"personalDataProcessingMsg":null,"cnpfield":null,"nationalityField":"PL","copyPersonalDataFromEcustomer":null},"entitledForBenefitsSection":{"benefitiaryGrp":null,"individual":null,"institutionDifferentThanTrader":null,"trader":null,"nationalityIndv":[{"citizenship":"PL","fillInTheNationalityIndv":"","documentValidupto":""}],"citizenship":null,"peselNumberIndv":null,"NationalityReg":null,"nationality_bu_Inst":[{"nationality":"PL","fillInTheNationalityReg":""}],"nationality_bu_Trader":[{"nationality":"PL","fillInTheNationalityTraderReg":""}],"amlAcceptanceCheck":null,"cnpfieldIndv":null},"correspondenceAddressSection":{"copyDataFromEc":null,"streetName":null,"houseNumber":null,"flatNumber":null,"country":"PL","postalCode":"","town":null,"postBox":null,"mobileNumber":null,"isdCode":"+48","email":null,"preferredModeOfCommunication":null,"addressAcceptanceCheck":null,"county":null,"zipCode":null,"city":null,"block":null,"entrance":null,"appartment":null,"sector":null},"formOfDisbursementSection":{"interestedinreinvestment":null,"percentage":null,"viabanktransfer":null,"viapost":null,"copydatafrominfo":null,"copyfromcommn":null,"copyfromlegal":null,"post_copydatafrominfo":null,"post_copyfromcommn":null,"post_copyfromlegal":null,"viafinancialinst":null}}}
  
  
    spyOn(newClaimService, 'getParamValue').and.returnValue(paramval);
    spyOn(newClaimService, 'getEventDetail').and.returnValue({value:eventDetailVal});
    spyOn(newClaimService, 'getPersonalDetails').and.returnValue(personalVal);
    spyOn(component, 'getOperationKey').and.callThrough();
    component.sourceOfOrigin = "C";
    component.formInit();
    component.sourceOfOrigin = "O";
    component.formInit();
    expect(component.getOperationKey).toHaveBeenCalled();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
/*it('fileSelection should call fileSelection ', () => {
    let newClaimService = TestBed.get(NewClaimSharedService);
    spyOn(component, 'fileSelection').and.callThrough();
    expect(component.fileSelection).toHaveBeenCalled();
});
  */  
});
