import { Component, OnInit, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { FileUpload } from 'src/app/core/models/file-upload';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { FilePreviewService } from 'src/app/shared/services/file-preview.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { FilePreviewComponent } from 'src/app/shared/dialog/file-preview/file-preview.component';
import { ConfirmDialogComponent } from 'src/app/shared/dialog/confirm-dialog/confirm-dialog.component';
import { environment } from 'src/environments/environment';
import { TranslateService } from '@ngx-translate/core';
import { NewClaimSharedService } from '../add-new-claim.service';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { DataService } from 'src/app/shared/services/data.service';
import { FormGroup, FormControl, FormBuilder, Validators  } from '@angular/forms';
import { CreateFormService } from 'src/app/shared/services/create-form.service';

import { BroadcasterService } from '../../shared/services/broadcaster.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'attachments',
  templateUrl: './attachments.component.html',
  styleUrls: ['./attachments.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AttachmentsComponent implements OnInit {

  public fileUploadModel = []; //: Array<FileUpload>
  allowedType = ['jpeg', 'jpg', 'tiff', 'pdf', 'gif', 'png', 'bmp', 'tif'];
  fileValidation_Messages = [];
  fileSizeObject = { filesSizeCalculation: 0 };
  documentTypes = [];
  userInfo = JSON.parse(sessionStorage.userData);
  mandatoryDocumentList = [];
  mandatoryError: boolean = false;
  constructor(public dialogService: DialogService,
    public translate: TranslateService, public filePreviewService: FilePreviewService, public httpCommonService: HttpCommonService,
    public newClaimService: NewClaimSharedService, private readonly shared: BroadcasterService,
    public dataService: DataService, private fb: FormBuilder, private readonly createForm: CreateFormService,
    public dialog: MatDialog) {
    this.dataService.setOption('uploadNewClaimList', {});
  }

  @Output() uploadEvent: EventEmitter<any> = new EventEmitter();


  ngOnInit() {
    //this.formInit();
  }
  isEdgeBrowser: any = (/edge\//i).test(window.navigator.userAgent);
  accept = "image/*";
  attachmentForm: FormGroup;
  personalDetail;
  dedicatedOperationKey = [];
  eventDetail;
  renderClaimSections: any = null;
  userData = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.userData.sourceOrigin;
  defaultLanguage: string = this.userData.defaultLanguage;
  getOperationKey() {
    this.dedicatedOperationKey = [];
    let idividualKeys = {
      "plenipotentiaryBenf": "PlenipotentiaryofBeneficiary",
      "statutoryRepBen": "StatutoryRepben",
      "benefitiary": "beneficiaryEntitled"

    }
    if (this.personalDetail) {
      for (const key in idividualKeys) {
        if (this.personalDetail.controls.entitledForBenefitsSection && key === this.personalDetail.controls.entitledForBenefitsSection.value.capacity) {
          this.dedicatedOperationKey.push(idividualKeys[key]);
        }
      }
    }
    if (this.eventDetail && this.eventDetail.value.additionalFieldDetailsSection && this.eventDetail.value.additionalFieldDetailsSection.policeConductedInvestigation == 'yes') {
      this.dedicatedOperationKey.push('InvestigationbyProsecutor');
    }

    if (this.eventDetail && this.eventDetail.value.additionalFieldDetailsSection && this.eventDetail.value.additionalFieldDetailsSection.employerPreparedAccidentReport == 'yes') {
      this.dedicatedOperationKey.push('EmployerAccidentReport');
    }
    if (this.eventDetail && this.eventDetail.value.additionalFieldDetailsSection && this.eventDetail.value.additionalFieldDetailsSection.sportsClubPlayerDropDown == 'yes') {
      this.dedicatedOperationKey.push('InjuryduetoSports');
    }
  }

  // getPersonalEventType(){
  //   let personalTye={
  //     "EmployeeEvent": "EmployeeEvent",
  //     "SpouseEvent": "SpouseEvent",
  //     "PartnerEvent": "PartnerEvent",
  //     "ChildEvent": "ChildEvent",
  //     "SpouseEventGrp": "SpouseEventGrp",
  //     "PartnerEventGrp": "PartnerEventGrp",
  //     "ChildEventGrp": "ChildEventGrp",
  //     "Insured": "PrimaryPolicyHolderEvent",
  //     "ChildPrimaryPolicyHolderEvent": "ChildPrimaryPolicyHolderEvent",
  //     "OtherNomineeEvent": "OtherNomineeEvent",
  //     "PrimaryOwnerEvent": "Policyholder"
  //   };
  //   let personalEvenRelated;
  //   if (this.personalDetail) {
  //     for (const key in personalTye) {
  //       if (this.personalDetail.value.insuranceRefersToSection && key === this.personalDetail.value.insuranceRefersToSection.insuranceEventRefersTo) {
  //         personalEvenRelated=;
  //       }
  //     }
  //   }
  //   return 
  // }

  formInit() {
    this.renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');
    this.eventDetail = this.newClaimService.getEventDetail();
    this.personalDetail = this.newClaimService.getPersonalDetails();

    this.mandatoryDocumentList = [];
    this.documentTypes = [];
    this.fileUploadModel = [];
    this.fileValidation_Messages = [];
    this.fileSizeObject.filesSizeCalculation = 0;
    if (this.sourceOfOrigin == 'B') {
      let documentTypesFromRule = this.renderClaimSections.attachmentList.split('|');

      /* for (let i = 0; i < documentTypesFromRule.length; i++) {
         if (documentTypesFromRule[i].split('_')) {
           documentTypesFromRule[i] = documentTypesFromRule[i].split('_')[0];
         }
       }*/
      // for (var docType of documentTypesFromRule) {

      //    if(docType.indexOf("_existing")!=-1){
      //     docType = docType.replace("_existing", "");
      //    }
      // }
      this.attachmentForm = this.generateFrom(documentTypesFromRule);
      let fileCommonService = {
        fileUpload: this.fileUploadModel,
        documentTypes: this.documentTypes,
        mandatoryList: this.mandatoryDocumentList
      }
      this.dataService.setOption('mandatoryList', this.mandatoryDocumentList);
      this.dataService.setOption('uploadNewClaimList', fileCommonService);

      for (var docType of documentTypesFromRule) {

        // if(docType.indexOf("_existing")!=-1){
        //  docType = docType.replace("_existing", "");
        // }
        let mandatoryFlag = this.mandatoryDocumentList.indexOf(docType) != -1 ? true : false;
        // "name": eClaimsConstants.doucmentListInNewCalim[this.userInfo.defaultLanguage][docType],
        this.documentTypes.push({
          "id": docType, "name": docType,
          "mandatoryFlag": mandatoryFlag
        });
        // "name": this.translate.instant(docType)
      }
    } else {


      let claimData = this.newClaimService.getClaimData();
      let personalEventType = (this.personalDetail && this.personalDetail.value.insuranceRefersToSection) ? this.personalDetail.value.insuranceRefersToSection.insuranceEventRefersTo : '';
      if (personalEventType && personalEventType.toLowerCase() == 'insured') {
        personalEventType = 'PrimaryPolicyHolderEvent';
      }
      this.getOperationKey();
      let claimTypeCode = null;
      if (claimData && claimData.claimTypeCode.length > 0) {
        claimTypeCode = claimData.claimTypeCode.join('|');
      }
      let requestParam = {
        "partner": "metlife",
        "lob": (claimData ? claimData.newclaim : null),
        "eventType": personalEventType ? personalEventType : 'NoEvent',
        "eventRelatedTo": this.eventDetail ? this.eventDetail.value.eventInformationSection.eventRelatedTo ?
          this.eventDetail.value.eventInformationSection.eventRelatedTo : 'NoEventRelated' : 'NoEventRelated',
        "screenName": "NewClaimsAttachmentsListRender",
        "claimType": claimTypeCode,
        "dedicatedOpeType": this.dedicatedOperationKey ?
          this.dedicatedOperationKey.join('|') : '',
        "sourceOfOrigin": this.sourceOfOrigin
      };
      this.newClaimService.getmandatoryError().subscribe(data => {
        this.mandatoryError = data;

      });
      this.httpCommonService[environment.newClaimsAttachmentsListConfig.method](environment.host + environment.newClaimsAttachmentsListConfig.url, requestParam).subscribe(data => {
        this.documentTypes = [];
        let documentTypesFromRule = data.uploadDocument ? data.uploadDocument.split("|") : [],
          index = documentTypesFromRule.indexOf('ALL015'),
          indexOfRO = documentTypesFromRule.indexOf('ALL018')
        if (index > -1) {
          documentTypesFromRule.splice(index, 1);
          documentTypesFromRule.push('ALL015');
        };
        if (indexOfRO > -1) {
          documentTypesFromRule.splice(indexOfRO, 1);
          documentTypesFromRule.push('ALL018');
        };
        let mandatoryList = data.mandatoryDocument ? data.mandatoryDocument.split("|") : [];
        for (var i = 0; i < mandatoryList.length; i++) {
          this.mandatoryDocumentList.push(mandatoryList[i]);
        };
        this.attachmentForm = this.generateFrom(documentTypesFromRule);
        let fileCommonService = {
          fileUpload: this.fileUploadModel,
          documentTypes: this.documentTypes,
          mandatoryList: this.mandatoryDocumentList
        }
        this.dataService.setOption('mandatoryList', this.mandatoryDocumentList);
        this.dataService.setOption('uploadNewClaimList', fileCommonService);
        // this.mandatoryDocumentList = data.mandatoryDocument.sp

        for (var docType of documentTypesFromRule) {
          docType = docType.replace("_existing", "");
          let mandatoryFlag = this.mandatoryDocumentList.indexOf(docType) != -1 ? true : false;
          // "name": eClaimsConstants.doucmentListInNewCalim[this.userInfo.defaultLanguage][docType],
          this.documentTypes.push({
            "id": docType, "name": docType,
            "mandatoryFlag": mandatoryFlag
          });
          // "name": this.translate.instant(docType)
        }
      });
    }
  }

  generateFrom(documentTypesFromRule) {
    let controls = {};
    documentTypesFromRule.forEach((data) => {
      if (this.mandatoryDocumentList.indexOf(data) !== -1) {
        controls[data] = new FormControl('', Validators.required);
      } else {
        controls[data] = new FormControl('');
      }
    });
    return this.fb.group(controls);
  }

  formSubmit() {
    //if(){

    //}

    if (this.attachmentForm) {

      this.createForm.markFormGroupTouched(this.attachmentForm);
      //   console.log(this.attachmentForm);
      let isEdgeBrowser = (/edge\//i).test(window.navigator.userAgent);
      if (isEdgeBrowser) {
        for (let i = 0; i < this.mandatoryDocumentList.length; i++) {
          let isDocAvailable = false;
          for (let j = 0; j < this.fileUploadModel.length; j++) {
            if (this.mandatoryDocumentList[i] == this.fileUploadModel[j].docName) {
              isDocAvailable = true;
              break;
            }
          }
          if (!isDocAvailable) {
            return false;
          }
        }
        return true;

      } else {
        if (this.attachmentForm.valid) {
          return true;
        }
      }

    }
    return false;
  }
  fileSelection(event, claimdoc: string, fileUploadData: HTMLInputElement, mandatoryFlag: boolean, documentName) {
    // console.log('fileUploadData',fileUploadData);
    let virusFileCheck = environment.host + environment.virusFileCheck.url;
    let removeExistingClaim;
    if (claimdoc.indexOf("_existing") != -1) {
      removeExistingClaim = claimdoc.replace("_existing", "");
    } else {
      removeExistingClaim = claimdoc;
    }
    // this.uploadEvent.emit(event);
    this.fileValidation_Messages = [];
    let isInValidFile = false;
    for (let index = 0; index < event.target.files.length; index++) {
      const file = event.target.files[index];
      const fileContentType = file.name.substring(file.name.lastIndexOf(".") + 1).toLocaleLowerCase();
      if (this.allowedType.indexOf(fileContentType) != -1) {
        const reqPayload = new FormData();
        reqPayload.append('file', file);
         this.httpCommonService[environment.virusFileCheck.method](virusFileCheck, reqPayload, "").subscribe(data => {
           if (data.statusCode == 200) {
        this.fileSizeObject.filesSizeCalculation = this.fileSizeObject.filesSizeCalculation + file.size;
        if (file.size < this.userInfo.minFilesize && this.fileSizeObject.filesSizeCalculation < this.userInfo.maxFilesize) {
          const reader = new FileReader();
          const filenameWithDocType = removeExistingClaim + "_" + file.name;
          //const filenameWithDocType = file.name;
          reader.onload = e => {
            const temp = reader.result as string;
            this.fileUploadModel.push({
              data: file, state: removeExistingClaim, path: temp, name: filenameWithDocType,
              contentType: fileContentType, mandatoryFlag: mandatoryFlag, docName: documentName, fileName: file.name,
              keyToShowInSelect: claimdoc
            });
          }
          reader.readAsDataURL(file);
          // fileUploadData.value = "";
        }
        else {
          isInValidFile = true;
          if (file.size > this.userInfo.minFilesize) {
            // this.fileValidation_Messages.push(file.name + this.translate.instant('errors.attachment.invalidSize'));
            this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidSize' });
          }
          else if (this.fileSizeObject.filesSizeCalculation > this.userInfo.maxFilesize) {
            // this.fileValidation_Messages.push(file.name + this.translate.instant('errors.attachment.invalidSizeMax'));
            this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidSizeMax' });
          }
          this.fileSizeObject.filesSizeCalculation = this.fileSizeObject.filesSizeCalculation - file.size;

        }
           } else {
            this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.virusFile' });
           }
         });
      }
      else {
        // this.fileValidation_Messages.push(file.name + this.translate.instant('errors.attachment.invalidFormat'));
        this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidFormat' });

      }
      let fileCommonService = {
        fileUpload: this.fileUploadModel,
        documentTypes: this.documentTypes,
        mandatoryList: this.mandatoryDocumentList
      }
      this.dataService.setOption('uploadNewClaimList', fileCommonService);
    }
    //fileUploadData.value = "";
    //console.log(" this.attachmentForm selected", this.attachmentForm );
  }


  removeSelectedFile(index, file: FileUpload) {
    //  const message = `${this.translate.instant("eClaims.existingClaim.attachment.confirmDeleteMessage")} ${file.data.name}`;
    const message = ('<span>' + this.translate.instant("eClaims.existingClaim.attachment.confirmDeleteMessage") + '<a>' + file.data.name + '</a></span>');
    //  this.dialogService.openDialog(ConfirmDialogComponent, { 'heading': this.translate.instant("eClaims.existingClaim.attachment.confirmDelete"), 'body': message, "index": index, "fileUploadModel": this.fileUploadModel, "fileSizeObject": this.fileSizeObject });
    this.fileValidation_Messages = [];
    this.removeFileDialog(index, message);
    /*  this.shared.on<any>('removeFileInattachment').subscribe((data) => {
        this.fileUploadModel = data;
        let fileCommonService = {
          fileUpload: this.fileUploadModel,
          documentTypes: this.documentTypes,
          mandatoryList: this.mandatoryDocumentList
        }
        this.dataService.setOption('uploadNewClaimList', fileCommonService);
        console.log(" this.fileUploadModel  ", this.fileUploadModel);
        for (const key in this.attachmentForm.value) {
          console.log("key", key);
          let keyExist = false;
          for (let i = 0; i < this.fileUploadModel.length; i++) {
            if (key == this.fileUploadModel[i].docName) {
              keyExist = true;
              break;
            }
          }
          if (!keyExist) {
            this.attachmentForm.controls[key].setValue(null);
          }
  console.log('this.attachmentForm.controls[key]',this.attachmentForm.controls[key]);
        }
        console.log(" this.attachmentForm ", this.attachmentForm);
  
      });
  */
  }

  filePreview(filePath, contentType) {
    /*if(this.isEdgeBrowser){
      let blob = new Blob(filePath);
      if (window.navigator.msSaveOrOpenBlob) {
        //IE11 & Edge
        window.navigator.msSaveOrOpenBlob(filePath);
      }
    }
  
   else{*/
    this.filePreviewService.openDialog(FilePreviewComponent, { 'filePath': filePath, 'type': contentType });
    // }

  }

  // filePreview(filePath) {
  //   this.filePreviewService.openDialog(FilePreviewComponent, { 'filePath': filePath });
  // }

  fileNameAlter(event, index) {
    let removeExistingClaim;
    if (event.value.indexOf("_existing") != -1) {
      removeExistingClaim = event.value.replace("_existing", "");
    } else {
      removeExistingClaim = event.value;
    }
    let mandatoryFlag = this.mandatoryDocumentList.indexOf(this.fileUploadModel[index].state) != -1 ? true : false;
    this.fileUploadModel[index].name = removeExistingClaim + '_' + this.fileUploadModel[index].data.name;
    this.fileUploadModel[index].mandatoryFlag = mandatoryFlag;
    this.fileUploadModel[index].state = removeExistingClaim;
    this.fileUploadModel[index].docName = removeExistingClaim;
    let fileCommonService = {
      fileUpload: this.fileUploadModel,
      documentTypes: this.documentTypes,
      mandatoryList: this.mandatoryDocumentList
    }
    this.dataService.setOption('uploadNewClaimList', fileCommonService);
  }


  removeFileDialog(index, message) {
    let conf = {
      'heading': this.translate.instant("eClaims.existingClaim.attachment.confirmDelete"),
      'body': message,
      "index": index,
      "fileUploadModel": this.fileUploadModel,
      "fileSizeObject": this.fileSizeObject
    };

    const dialogRef = this.dialog.open(ConfirmDialogComponent,

      {
        width: '300px',
        data: conf,
        disableClose: true
      });

    dialogRef.afterClosed().subscribe(data => {
      // console.log('The dialog was closed');
      if (data) {
        // this.fileUploadModel = data;
        let fileCommonService = {
          fileUpload: this.fileUploadModel,
          documentTypes: this.documentTypes,
          mandatoryList: this.mandatoryDocumentList
        }
        this.dataService.setOption('uploadNewClaimList', fileCommonService);
        //  console.log(" this.fileUploadModel  ", this.fileUploadModel);
        for (const key in this.attachmentForm.value) {
          //  console.log("key", key);
          let keyExist = false;
          for (let i = 0; i < this.fileUploadModel.length; i++) {
            if (key == this.fileUploadModel[i].docName) {
              keyExist = true;
              break;
            }
          }
          if (!keyExist) {
            this.attachmentForm.controls[key].setValue(null);
          }
          // console.log('this.attachmentForm.controls[key]',this.attachmentForm.controls[key]);
        }
        //   console.log(" this.attachmentForm ", this.attachmentForm);


      }
    });
  }




}
