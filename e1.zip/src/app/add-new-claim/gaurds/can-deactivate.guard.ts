import { Injectable } from '@angular/core';
import { CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { PersonalDetailsComponent } from '../personal-details/personal-details.component';

@Injectable()
export class CanDeactivateGuard implements CanDeactivate<PersonalDetailsComponent> {

  constructor() {}

  canDeactivate(
    component: PersonalDetailsComponent,
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {

    // Check with component to see if we're able to deactivate
    //return component.canDeactivate();
    return false;
  }
}
