import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { GetterSetterService } from '../../core/services/getterSetter.service';
import { NewClaimSharedService } from '../add-new-claim.service';

@Injectable()
export class SectionReqConfigService {
    insuranceRefersToModel: InsuranceRefersToModel = new InsuranceRefersToModel();
    correspondenceAddressModel: CorrespondenceAddressModel = new CorrespondenceAddressModel();
    residenceAddressModel: ResidenceAddressModel = new ResidenceAddressModel();
    formofDisbursementModel: FormofDisbursementModel = new FormofDisbursementModel();
    proposesToClaimModel: ProposesToClaimModel = new ProposesToClaimModel();

    constructor(public storage: GetterSetterService,public newClaimService:NewClaimSharedService) { }

     userData = this.storage.getSession('userData');
    
    rulesRequestParam(screenName){
        let claimData= this.newClaimService.getClaimData();
        let primaryClaimType = this.newClaimService.getPrimaryClaimType();
        let req = {
            "partner": "metlife",
            "sourceOfOrigin": this.userData.sourceOrigin,
            "screenName": screenName,
            "lob": (claimData?claimData.newclaim:null),
            "product": (claimData?claimData.newclaim:null),
            "submittedBy": this.userData.submittedBy,
            "primaryClaimEvent": primaryClaimType,
          //  "selectedClaim": this.userData.claimTypeCode?this.userData.claimTypeCode.join('/'):''
          "selectedClaim": primaryClaimType
            }
            return req;
    } 
    api (){
        let apiConfig = [

            {
                name: "correspondenceAddressSection",
                url: environment.host+environment.correspondenceServiceConfig.url,
                ruleFileIncludes: "CorrespondenceAddress",
                modelNames: this.correspondenceAddressModel,
                method: environment.correspondenceServiceConfig.method,
                requestParam: this.rulesRequestParam('CorrespondenceAddressSectionComponentRender')
            },
            {
                name: "entitledForBenefitsSection",
                url: environment.host+environment.benefitsServiceConfig.url,
                ruleFileIncludes: "ProposesToClaim",
                modelNames: this.proposesToClaimModel,
                method: environment.benefitsServiceConfig.method,
                requestParam: this.rulesRequestParam('EntitledtogetBenefitsSectionComponentRender')
            },
            {
                name: "formOfDisbursementSection",
                url: environment.host+environment.disbursementServiceConfig.url,
                ruleFileIncludes: "FormofDisbursement",
                modelNames: this.formofDisbursementModel,
                method: environment.disbursementServiceConfig.method,
                requestParam:this.rulesRequestParam('DisbursementSectionComponentRender')
                
            },
            {
                name: "insuranceRefersToSection",
                url: environment.host+environment.insuranceRefersServiceConfig.url,
                ruleFileIncludes: "InsuranceRefersTo",
                modelNames: this.insuranceRefersToModel,
                method: environment.insuranceRefersServiceConfig.method,
    
                requestParam:this.rulesRequestParam('InsuranceReferstoSectionComponentRender')
            },
            {
                name: "resideneAddressSection",
                url: environment.host+environment.resideneAddressServiceConfig.url,
                ruleFileIncludes: "ResidenceAddress",
                modelNames: this.residenceAddressModel,
                method: environment.resideneAddressServiceConfig.method,
                requestParam:this.rulesRequestParam('ResidenceAddressSectionComponentRender')
            }];

            return apiConfig;
    } 
}

export class CorrespondenceAddressModel {
    copyDataFromEc:string = null;
    streetName: string = null;
    houseNumber: string = null;
    flatNumber: string = null;
    country: string = null;
    otherCountry:string = null;
    postalCode: string = null;
    town: string = null;
    postBox:string = null;
    mobileNumber: string = null;
    isdCode: string = null;
    email: string = null;
    preferredModeOfCommunication: string = null;
    addressAcceptanceCheck: string = null;
    county: string = null;
    zipCode: string = null;
    city: string = null;
    block: string = null;
    entrance: string = null;
    appartment: string = null;
    sector: string = null;
}

export class ResidenceAddressModel {
    streetName: string = null;
    houseNumber: string = null;
    flatNumber: string = null;
    country: string = null;
    otherCountry:string = null;
    postalCode: string = null;
    town: string = null;
    postBox:string = null;
    copyDataFromEc: string = null;
    

}
export class InsuranceRefersToModel {
    insuranceEventRefersTo: string = null;
    nameField: string = null;
    surnameField: string = null;
    citizenship: string = null;
    peselField: string = null;
    dobField: string = null;
    sexField: string = null;
    passportNumField: string = null;
    maidenNameField: string = null;
    otherNationalityField: string = null;
    currentProfessionField:string=null;
    qualifiedProfessionField: string= null;
    personalDataProcessingMsg:string = null;
    cnpfield:string = null;
    nationalityField:string=null;
    copyPersonalDataFromEcustomer:any = null;
}
export class FormofDisbursementModel {

    interestedinreinvestment: string = null;
    policynumber: string = null;
    percentage: string = null;
    amount: string = null;
    currency: string = null;
    viabanktransfer: string = null;
    viapost: string = null;
    countryofbank: string = null;
    bankaccountnumber: string = null;
    codeswift: string = null;
    bankname: string = null;
    bankaddress: string = null;
    copydatafrominfo: string = null;
    businessunit: string = null;
    name: string = null;
    surname: string = null;
    copyfromcommn: string = null;
    copyfromlegal: string = null;
    streetname: string = null;
    streetnumber: string = null;
    flatnumber: string = null;
    country: string = null;
    postalcode: string = null;
    town: string = null;
    postbox: string = null;
    otherNationalityField: string = null;
    postal_otherNationalityField: string = null;
    post_copydatafrominfo: string = null;
    post_businessunit: string = null;
    post_name: string = null;
    post_surname: string = null;
    post_copyfromcommn: string = null;
    post_copyfromlegal: string = null;
    post_streetname: string = null;
    post_streetnumber: string = null;
    post_flatnumber: string = null;
    post_country: string = null;
    post_postalcode: string = null;
    post_town: string = null;
    post_postbox: string = null;
    banknamefinancialinst: string = null;
    county: string = null;
    zipCode: string = null;
    city: string = null;
    block: string = null;
    entrance: string = null;
    appartment: string = null;
    sector: string = null;
    disbursementDisclaimerChkbox: string = null;
    viafinancialinst: string = null;
}
export class ProposesToClaimModel {
    benefitiary: any = null;
    benefitiaryGrp: string =null;
    individual: string = null;
    institutionDifferentThanTrader: string = null;
    trader: string = null;
    capacity: string = null;
    insured: string = null;
    statutoryRepBen: string = null;
    plenipotentiaryBenf: string = null;
    owner: string = null;
    otherPerson: string = null;
    nationalityIndv: Array<any> = [];
    //fillInTheNationalityIndv: string = null;
    idDocumentsValidUptoIndv: string = null;
    taxResidencyCountryIndv: string = null;
    fillInCountryTax: string = null;
    fillInCountryBirth: string = null;
    nameIndv: string = null;
    surNameIndv: string = null;
    //citizenship: Array<any> = [];
    citizenship: string = null;
    peselNumberIndv: string = null;
    dateOfBirthIndv: string = null;
    sexIndv: string = null;
    seriesAndNumberIndv: string = null;
    countryOfBirthIndv: string = null;
    institutionNameInst: string = null;
    nationalityInst: string = null;
    //fillInTheNationalityReg: string = null;
    NationalityReg:string=null;
    nIPInst: string = null;
    regionInst: string = null;
    kRSInst: string = null;
    nameInst: string = null;
    surNameInst: string = null;
    sexInst: string = null;
    nationality_bu_Inst: Array<any> = [];
    fillInTheNationalityInst: string = null;
    institutionNameTrader: string = null;
    nationalityTrader: string = null;
    nIPTrader: string = null;
    regionTrader: string = null;
    kRSTrader: string = null;
    nameTrader: string = null;
    surNameTrader: string = null;
    sexTrader: string = null;
    nationality_bu_Trader: Array<any> = [];
    fillInTheNationalityTrader: string = null;
    //fillInTheNationalityTraderReg: string = null;
    amlAcceptanceCheck: string = null;
    cnpfieldIndv: string = null;
    maidenName: string = null;
    //copyData:string =null;
    otherNationlityBtn :string = null;
}