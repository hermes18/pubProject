import {
  Component, OnInit, Output, EventEmitter, ViewChild, AfterViewInit,
  ChangeDetectorRef, ViewEncapsulation, OnDestroy
} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable, forkJoin } from "rxjs";
import { HttpCommonService } from "../../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { CreateFormService } from '../../shared/services/create-form.service';
import { ErrorMessagesComponent } from '../../shared/component/error-messages/error-messages.component';
import { environment } from 'src/environments/environment';
import { SectionReqConfigService } from './personal-details.model';
import { FormDisbursementSecComponent } from './form-disbursement-sec/form-disbursement-sec.component';
import { InsuranceReferSecComponent } from './insurance-refer-sec/insurance-refer-sec.component';
import { BenefitSecComponent } from './benefit-sec/benefit-sec.component';
import { ResidenceAddressSecComponent } from './residence-address-sec/residence-address-sec.component';
import { CorrespondAddressSecComponent } from './correspond-address-sec/correspond-address-sec.component';
import { NewClaimSharedService } from '../add-new-claim.service';
import { DataService } from 'src/app/shared/services/data.service';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { AttachmentsComponent } from '../attachments/attachments.component';

@Component({
  selector: 'app-personal-details',
  templateUrl: './personal-details.component.html',
  styleUrls: ['./personal-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PersonalDetailsComponent implements OnInit, AfterViewInit, OnDestroy {

  @Output() personalFormStatus: EventEmitter<Event> = new EventEmitter();
  resideneAddressRenderFlag: any = '';
  dynamicForm: FormGroup;
  /*
    insuranceRefersToModel: InsuranceRefersToModel = new InsuranceRefersToModel();
    correspondenceAddressModel: CorrespondenceAddressModel = new CorrespondenceAddressModel();
    residenceAddressModel: ResidenceAddressModel = new ResidenceAddressModel();
    formofDisbursementModel: FormofDisbursementModel = new FormofDisbursementModel();
    proposesToClaimModel: ProposesToClaimModel = new ProposesToClaimModel();
  */
  personalSectionRule;
  personalForm: FormGroup = this.fb.group({});

  userData = JSON.parse(sessionStorage.userData);

  defaultLanguage = this.userData.defaultLanguage.toUpperCase();
  countryCodes = {
    'RO': '+40',
    'PL': '+48'
  };
  renderClaimSections: any = null;
  constructor(private router: Router,
    private route: ActivatedRoute, private commonService: HttpCommonService,
    private createForm: CreateFormService, private fb: FormBuilder,
    public newClaimService: NewClaimSharedService,
    public sectionReqConfig: SectionReqConfigService, public dataService: DataService,
    private cd: ChangeDetectorRef) {

  }

  @ViewChild(InsuranceReferSecComponent, { static: false }) insuranceRefComp: InsuranceReferSecComponent;
  @ViewChild(BenefitSecComponent, { static: false }) benefitRefComp: BenefitSecComponent;
  @ViewChild(ResidenceAddressSecComponent, { static: false }) residenceRefComp: ResidenceAddressSecComponent;
  @ViewChild(CorrespondAddressSecComponent, { static: false }) correspondanceRefComp: CorrespondAddressSecComponent;
  @ViewChild(FormDisbursementSecComponent, { static: false }) disbursementRefComp: FormDisbursementSecComponent;
  @ViewChild(FormDisbursementSecComponent, { static: false }) formdisbursement: FormDisbursementSecComponent;
  @ViewChild(AttachmentsComponent, { static: false }) attachmentsComp: AttachmentsComponent;

  insuranceRefersRenderJson: any = {};
  benefitRenderSecRules: any = {};
  disbursementRenderSecRules: any = {}
  correspondanceRenderSecRules: any = {}

  //patternException : pattern rule exception for date fields pattern which will be handled by someother directive
  patternException = ['dobField', 'dateOfBirthIndv', 'bankaccountnumber'];
  residenceRenderSecRules: any;
  addtionalCommentsShow: any;

  personalSectionsRule: any = null;
  insureReferRenderSecRules: any = null;
  isEmailValid = true;
  patternTypes = eClaimsConstants.patternTypes;

  beneficiaryValue: string = "";
  isPersonalDataLoad = false;

  excludeSubSec = [];

  agentSection: any = {
    emailAddressOfTheAgentFilingClaim: null,
    eventDetailsAdditionalComments: null
  }

  formDetails = [
    {
      "form": "insurance",
      "initFunc": "formInit",
      "formRef": "insuranceRefComp",
      "submit": "formSubmit",
      "renderJson": null,
      "ruleFileIncludes": "InsuranceRefersTo"
    },
    {
      "form": "benefit",
      "initFunc": "formInit",
      "formRef": "benefitRefComp",
      "submit": "formSubmit",
      "renderJson": null,
      "ruleFileIncludes": "ProposesToClaim"
    },
    {
      "form": "residence",
      "initFunc": "formInit",
      "formRef": "residenceRefComp",
      "submit": "formSubmit",
      "renderJson": null,
      "ruleFileIncludes": "ResidenceAddress"
    },
    {
      "form": "correspondAddress",
      "initFunc": "formInit",
      "formRef": "correspondanceRefComp",
      "submit": "formSubmit",
      "renderJson": null,
      "ruleFileIncludes": "CorrespondenceAddress"
    },
    {
      "form": "formDisbursement",
      "initFunc": "formInit",
      "formRef": "disbursementRefComp",
      "submit": "formSubmit",
      "renderJson": null,
      "ruleFileIncludes": "FormofDisbursement"

    }
  ];

  //getSectionDetails: return section validation Json values from response
  getSectionDetails(sectionName) {
    for (let i = 0; i < this.formDetails.length; i++) {
      if (this.formDetails[i].form == sectionName) {
        // console.log('this.formDetails[i].renderJson', this.formDetails[i].renderJson);
        return this.formDetails[i].renderJson;
      }
    }
  }

  /*callSubCompFormInit: calls sub component init function
   each time type of event changed and clicked on personal details*/
  callSubCompFormInit() {


    for (let i = 0; i < this.formDetails.length; i++) {

      if (this[this.formDetails[i].formRef] && this[this.formDetails[i].formRef][this.formDetails[i].initFunc]) {
        this[this.formDetails[i].formRef][this.formDetails[i].initFunc]();
      }

    }
  }

  //callSubCompFormSubmit : calls sub component form submit functions
  callSubCompFormSubmit() {
    //while click on direct submit ref wont be there 
    let isPersonalFormValid = true;
    for (let i = 0; i < this.formDetails.length; i++) {
      //if((this.excludeSubSec.indexOf(this.formDetails[i].formRef)==-1) ){
      if (this[this.formDetails[i].formRef] &&
        this[this.formDetails[i].formRef][this.formDetails[i].submit]) {
        let personalSubCompSubmit = this[this.formDetails[i].formRef][this.formDetails[i].submit]();
        if (!personalSubCompSubmit.isFormValid) {
          isPersonalFormValid = false;
          // return false;
        }
      }
      /*else{
        return false;
      }*/
      //}
      this.newClaimService.setPersonalDetails(this.personalForm);
      // this.newClaimService.setParamValue('personalDetailsOldValue',this.personalForm.value);
    }

    if (!isPersonalFormValid) {
      return isPersonalFormValid;
    }

    if (this.renderClaimSections.tab2EmailAddressSection.renderFlag &&
      (this.personalForm.controls['emailAddressOfTheAgentFilingClaim'].invalid ||
        !this.isEmailValid)) {
      return false;
    }

    return true;
  }

  //submitPersonal : calls on personal details submition
  submitPersonal() {
    //console.log("=======> personalForm", this.personalForm);

    this.createForm.markFormGroupTouched(this.personalForm);
    this.newClaimService.setPersonalDetails(this.personalForm);
    this.callSubCompFormSubmit();
    // let formStatus = this.personalForm;
    // if (formStatus) {

    //   this.personalFormStatus.emit(formStatus);
    // }

  }

  //formSubmit: calls while submit and tab change
  formSubmit() {
    let labelKeys = {
      showCorrespondAddressInst: this.correspondanceRefComp ? this.correspondanceRefComp.showCorrespondAddressInst : false,
      showCorrespondAddressInvd: this.correspondanceRefComp ?
        this.correspondanceRefComp.showCorrespondAddressInvd : false,
      showPersonalDetailCorrespondAddressInst: this.correspondanceRefComp ?
        this.correspondanceRefComp.showPersonalDetailCorrespondAddressInst : false,
      showPersonalDetailCorrespondAddressTrader: this.correspondanceRefComp ?
        this.correspondanceRefComp.showPersonalDetailCorrespondAddressTrader : false,
      showPersonalDetailCorrespondAddressInvd: this.correspondanceRefComp ?
        this.correspondanceRefComp.showPersonalDetailCorrespondAddressInvd : false,
      showResidenceInstLabel: this.residenceRefComp ? this.residenceRefComp.showResidenceInstLabel : false,
      showResidenceInvdLabel: this.residenceRefComp ? this.residenceRefComp.showResidenceInvdLabel : false,
      showResidenceTraderLabel: this.residenceRefComp ? this.residenceRefComp.showResidenceTraderLabel : false
    };
    if (this.benefitRefComp) {
      this.dataService.setOption('capacityValue', this.benefitRefComp.capacityFormRadioGrp);
    }

    this.dataService.setOption('labelKeyinCorres', labelKeys);
    this.createForm.markFormGroupTouched(this.personalForm);
    this.newClaimService.setPersonalDetails(this.personalForm);
    return this.callSubCompFormSubmit();
    //this.submitPersonal();

    ////console.log(formData, "formData");
  }

  // requestDataFromMultipleSources: to make multiple service call and hold it until all calls get success
  public requestDataFromMultipleSources(rulesArr) {

    let responseArr = [];
    for (let i = 0; i < rulesArr.length; i++) {
      responseArr.push(this.commonService[rulesArr[i].method](rulesArr[i].url, rulesArr[i].requestParam));
    }
    return forkJoin(responseArr);
  }

  //getObjFromArr : compare given key and return the array object 
  getObjFromArr(key, arr, compareVal) {
    for (let i = 0; i < arr.length; i++) {
      if (arr[i][key] === compareVal) {
        return arr[i];
      }
    }
    return null;
  }

  ngOnInit() {


  }

  //getCapacityValueChange : capacity value change event
  getCapacityValueChange(event) {
    let primaryClaimType = this.newClaimService.getPrimaryClaimType();
    // && (primaryClaimType.indexOf('E430')!=-1 || primaryClaimType.indexOf('E220')!=-1 )
    if (this.defaultLanguage === 'RO') {
      if (event.capacity == 'otherPerson' && event.benefitiary == 'individual') {
        this.personalSectionsRule.formOfDisbursementSection.renderFlag = false;
        this.personalSectionsRule.formOfDisbursementSection.mandatoryFlag = false;

      } else {

        let oldPersonalSecRenderVal = this.newClaimService.getParamValue('personalRenderListInit')
        this.personalSectionsRule.formOfDisbursementSection.renderFlag = oldPersonalSecRenderVal.formOfDisbursementSection.renderFlag;
        this.personalSectionsRule.formOfDisbursementSection.mandatoryFlag = oldPersonalSecRenderVal.formOfDisbursementSection.mandatoryFlag;
      }
      this.newClaimService.setParamValue('renderSecFlagList', this.personalSectionsRule);

    }

  }

  //getbeneficiaryValueChange : beneficiary value change event
  getbeneficiaryValueChange(event) {
    this.newClaimService.setParamValue('benefitiaryGrp', event);
    if (this.formdisbursement) {
      this.formdisbursement.getformdisbursement(event);
    }

    if (this.resideneAddressRenderFlag == true && this.residenceRefComp) {
      this.residenceRefComp.getResidenceAddress(event);
    }
    if (this.correspondanceRefComp) {
      this.correspondanceRefComp.getCorrespondanceAddress(event);
    }
    if (this.defaultLanguage === 'RO') {

      let oldPersonalSecRenderVal = this.newClaimService.getParamValue('personalRenderListInit')
      this.personalSectionsRule.formOfDisbursementSection.renderFlag = oldPersonalSecRenderVal.formOfDisbursementSection.renderFlag;
      this.personalSectionsRule.formOfDisbursementSection.mandatoryFlag = oldPersonalSecRenderVal.formOfDisbursementSection.mandatoryFlag;
      this.newClaimService.setParamValue('renderSecFlagList', this.personalSectionsRule);

    }

  }

  //blurEmailField: email field blur event calls for email validation
  blurEmailField(event) {
    this.isEmailValid = true;

    let emailValue = event.target.value;
    if (emailValue != '' && emailValue != null) {
      this.getEmailIdValue(emailValue).subscribe((data) => {
        //console.log("email", data)
        if (data == true) {
          this.isEmailValid = true;
          //this.corresspondenceAddressForm.controls.email['invalidFlag'] = this.isEmailValid;
        } else {
          this.isEmailValid = false;
          //this.corresspondenceAddressForm.controls.email['invalidFlag'] = this.isEmailValid;
        }

      });
    }
  }

  //getEmailIdValue : emailId validation
  getEmailIdValue(emailID) {
    //console.log("emailID", emailID)
    let param = {
      "clientId": "",
      "email": emailID,
      "phoneNumber": "",
      "role": "",
      "userId": ""
    }
    const url = `${environment.host + environment.getEmailId.url}`;
    return this.commonService[environment.getBankName.method](url, param);
  }

  //brokerFlowControls: broker flow business logic
  brokerFlowControls() {
    if (this.renderClaimSections.tab2AdditionalCommentsSection.renderFlag) {
      if (this.personalForm.get('eventDetailsAdditionalComments')) {

      } else {
        this.personalForm.addControl('eventDetailsAdditionalComments', new FormControl('', Validators.nullValidator));
      }

    }
    if (this.renderClaimSections.tab2EmailAddressSection.renderFlag) {
      if (this.personalForm.get('emailAddressOfTheAgentFilingClaim')) {

      } else {
        this.personalForm.addControl('emailAddressOfTheAgentFilingClaim', new FormControl('', Validators.required));
      }



    }
  }

  // formInit : calls everytime if we change the type of event values and click on personal details
  formInit() {
    this.renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');
    const sectionUrls = this.sectionReqConfig.api();
    //this.commonService.getData(personalSectionUrl).subscribe((data) => {
    let reqParam = this.sectionReqConfig.rulesRequestParam('PersonalDetailsSectionsRender');
    this.addtionalCommentsShow = false;

    /* personal details sections or sub components rendering service call*/
    this.commonService[environment.personalServiceConfig.method]
      ((environment.host + environment.personalServiceConfig.url), reqParam).subscribe((data) => {
        this.personalSectionsRule = data;
        this.newClaimService.setParamValue('renderSecFlagList', this.personalSectionsRule);
        this.newClaimService.setParamValue('personalRenderListInit', JSON.parse(JSON.stringify(data)));
        this.resideneAddressRenderFlag = data.resideneAddressSection.renderFlag;
        let rulesArr = [];
        rulesArr = this.getSectionDetailsIfMandatory(sectionUrls, data);

        this.requestDataFromMultipleSources(rulesArr).subscribe((responseList) => {
          let formGroupObj = {};
          ////console.log(responseList, "responseList")

          if (this.newClaimService.getPersonalDetails()) {
            this.setSectionRenderValues(sectionUrls, responseList);

            if (this.insuranceRefComp) {
              this.insuranceRefComp.setInsuranceRefersVal();
            }else{
              this.personalForm.get('insuranceRefersToSection').get('insuranceEventRefersTo').setValue(null);
            }
            if (this.correspondanceRefComp) {

              this.correspondanceRefComp.setMobileNumberLength();
              // this.correspondanceRefComp.countryOnChange(this.correspondanceRefComp.corresspondenceAddressForm.get('country').value);
            }
            if (this.disbursementRefComp) {
              this.disbursementRefComp.setBankAccLength();
            }


          } else {
            formGroupObj = this.generateAllForms(sectionUrls, responseList);
            this.personalForm = this.fb.group(formGroupObj);
            this.callSubCompFormInit();
          }

          this.brokerFlowControls();
          this.disbursementRenderSecRules = this.getSectionDetails('formDisbursement');
          this.correspondanceRenderSecRules = this.getSectionDetails('correspondAddress');
          this.benefitRenderSecRules = this.getSectionDetails('benefit');
          this.insureReferRenderSecRules = this.getSectionDetails('insurance');
          this.residenceRenderSecRules = this.getSectionDetails('residence');
          //console.log("personal rule data", formGroupObj);
          //console.log(this.personalForm);
          this.newClaimService.setTraderFlag(this.personalForm.controls.entitledForBenefitsSection['controls'].trader.isVisible);

          this.isPersonalDataLoad = true;



          setTimeout(() => {
            if (this.renderClaimSections.tab2AttachmentsSection.renderFlag && this.attachmentsComp) {
              this.attachmentsComp.formInit();
            }
          }, 0);



        });

      })

  }

  //getSectionDetailsIfMandatory : return the sections which are mandatory
  getSectionDetailsIfMandatory(sectionUrls, data) {
    let rulesArr = []
    for (let [key, value] of Object.entries(data)) {
      if (typeof value === 'object' && value) {
        if (data[key].hasOwnProperty('renderFlag') && data[key]['renderFlag'] === true) {
          //    if (data[key].hasOwnProperty('renderFlag')){
          let sectionDetails = this.getObjFromArr('name', sectionUrls, key);

          if (sectionDetails) {
            rulesArr.push(this.getObjFromArr('name', sectionUrls, key));
          }

        }
      }
    }

    return rulesArr;
  }
  //setSectionRenderValues() : change validation if type of event selection changed 
  setSectionRenderValues(sectionUrls, responseList) {
    //console.log("responseListaaa", responseList);
    //console.log("sectionUrl", sectionUrls);
    for (let i = 0; i < responseList.length; i++) {

      for (let j = 0; j < sectionUrls.length; j++) {
        if (responseList[i]['ruleFileName'].indexOf(sectionUrls[j].ruleFileIncludes) != -1) {
          //console.log("this.personalForm.get(sectionUrls[j]['name']",this.personalForm.get(sectionUrls[j]['name']));
          if (this.personalForm.get(sectionUrls[j]['name'])) {
            this.createForm.setFormValidation(this.personalForm.get(sectionUrls[j]['name']), responseList[i], this.patternException);
          } else {

            this.personalForm.addControl(sectionUrls[j]['name'],
              this.createForm.generateForm(sectionUrls[j].modelNames, responseList[i], this.patternException));

            //call forminit of newly added component
            for (let i = 0; i < this.formDetails.length; i++) {
              if (this.formDetails[i]['ruleFileIncludes'] == sectionUrls[j]['ruleFileIncludes']) {
                if (this[this.formDetails[i].formRef] && this[this.formDetails[i].formRef][this.formDetails[i].initFunc]) {
                  this[this.formDetails[i].formRef][this.formDetails[i].initFunc]();
                }

              }

            }
          }

          break;
        }
      }

      for (let j = 0; j < this.formDetails.length; j++) {
        if (responseList[i]['ruleFileName'].indexOf(this.formDetails[j].ruleFileIncludes) != -1) {

          this.formDetails[j].renderJson = responseList[i];
          break;
        }
      }


    }

  }

  //generateAllForms(): create form group based on the validation response JSON
  generateAllForms(sectionUrls, responseList) {
    let formGroupObj = {};
    for (let i = 0; i < responseList.length; i++) {

      for (let j = 0; j < sectionUrls.length; j++) {
        if (responseList[i]['ruleFileName'].indexOf(sectionUrls[j].ruleFileIncludes) != -1) {
          formGroupObj[sectionUrls[j]['name']] = this.createForm.generateForm(sectionUrls[j].modelNames, responseList[i], this.patternException);
          //formGroupObj[sectionUrls[j]['name']] = responseList[i];
          break;
        }
      }

      for (let j = 0; j < this.formDetails.length; j++) {
        if (responseList[i]['ruleFileName'].indexOf(this.formDetails[j].ruleFileIncludes) != -1) {

          this.formDetails[j].renderJson = responseList[i];
          break;
        }
      }


    }

    //    //console.log("formGroupObj personal details", formGroupObj);
    return formGroupObj;
  }

  ngAfterViewInit() {
    this.cd.detectChanges();
  }
  ngOnDestroy() {
    this.newClaimService.setPersonalDetails(null);
  }
}

