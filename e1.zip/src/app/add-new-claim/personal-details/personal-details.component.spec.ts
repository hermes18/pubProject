import { async, ComponentFixture, TestBed,getTestBed  } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { PersonalDetailsComponent } from './personal-details.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { FormDisbursementSecComponent } from './form-disbursement-sec/form-disbursement-sec.component';
import { InsuranceReferSecComponent } from './insurance-refer-sec/insurance-refer-sec.component';
import { BenefitSecComponent } from './benefit-sec/benefit-sec.component';
import { ResidenceAddressSecComponent } from './residence-address-sec/residence-address-sec.component';
import { CorrespondAddressSecComponent } from './correspond-address-sec/correspond-address-sec.component';
import { NewClaimSharedService } from '../add-new-claim.service';
import { DataService } from 'src/app/shared/services/data.service';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { AttachmentsComponent } from '../attachments/attachments.component';
import { SectionReqConfigService } from './personal-details.model';
import {Injector} from "@angular/core";

export class PersonalRuleMock{
  mockValue={
   "ruleFileName":"Eclaims_ComponentRenderBySourceOfOrigin.xls_FIELD_RENDER_DETAILS",
   "sheetName":null,
   "partner":"metlife",
   "sourceOfOrigin":"O",
   "breadCrumbsRendered":"TypeOfEvent|PersonalDetails|EventDetails|Attachments|Review",
   "lobsRendered":"Cl|Grp|Indv|Tm",
   "disclaimerSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "insuranceRefersToSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "entitledForBenefitsSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "correspondenceAddressSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "resideneAddressSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "formOfDisbursementSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "tab2AttachmentsSection":{
      "renderFlag":false,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "tab2AdditionalCommentsSection":{
      "renderFlag":false,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "tab2EmailAddressSection":{
      "renderFlag":false,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "tab2copyPersonalDataFromEc":{
      "renderFlag":false,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "tab2copyAddressFromEc":{
      "renderFlag":false,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "tab2MobilenumberField":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "tab2PreferredModeOfcommunication":{
      "renderFlag":false,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "eventInformationSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "additionalFieldDetailsSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "informationHealthCareEventSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "informationHealthCareFamilyDocSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "attachmentSection":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "additionalCommentsSection":{
      "renderFlag":false,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "browseButton":{
      "renderFlag":true,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "attachmentList":"ALL000_existing|ALL005_existing|ALL001_existing|ALL007_existing|ALL003_existing",
   "tab2renderAmlDeclaration":{
      "renderFlag":false,
      "mandatoryFlag":false,
      "subQuestionFlag":false,
      "fieldmaxlength":null,
      "fieldminlength":null,
      "allowedDataType":null
   },
   "ksession":null
}
}


describe('PersonalDetailsComponent', () => {
  let component: PersonalDetailsComponent;
  let fixture: ComponentFixture<PersonalDetailsComponent>;
  let injector:  Injector;
  let translate: TranslateService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule, FormsModule,HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ PersonalDetailsComponent,InsuranceReferSecComponent,
        BenefitSecComponent,ResidenceAddressSecComponent,CorrespondAddressSecComponent,
        FormDisbursementSecComponent,AttachmentsComponent ],
        providers :[ HttpClient , SectionReqConfigService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }

    injector = getTestBed();
    translate = injector.get(TranslateService);
   

    fixture = TestBed.createComponent(PersonalDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    translate.use('pl_en');
    expect(component).toBeTruthy();
  });
});
