import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BenefitSecComponent } from './benefit-sec.component';
//import {RadioGroupComponent } from 'src/app/shared/component/radio-group/radio-group.component';
//import {InputFieldComponent } from 'src/app/shared/component/input-field/input-field.component';
import{SharedModule} from 'src/app/shared/shared.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {  FormGroup, FormControl, Validators, FormArray, AbstractControl,FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

export class BenefitSecFormMock{

  constructor(){
    
  }
  formMock ={
    benefitiary: null,
    benefitiaryGrp: null,
    individual: null,
    institutionDifferentThanTrader: null,
    trader: null,
    capacity: null,
    insured: null,
    statutoryRepBen: null,
    plenipotentiaryBenf: null,
    owner: null,
    otherPerson: null,
    nationalityIndv: new FormArray([]),
    //fillInTheNationalityIndv: string = null;
    idDocumentsValidUptoIndv: null,
    taxResidencyCountryIndv: null,
    fillInCountryTax:null,
    fillInCountryBirth: null,
    nameIndv: null,
    surNameIndv: null,
    //citizenship: Array<any> = [];
    citizenship: null,
    peselNumberIndv: null,
    dateOfBirthIndv: null,
    sexIndv: null,
    seriesAndNumberIndv: null,
    countryOfBirthIndv: null,
    institutionNameInst: null,
    nationalityInst:null,
    //fillInTheNationalityReg: string = null;
    NationalityReg:null,
    nIPInst: null,
    regionInst: null,
    kRSInst:null,
    nameInst:   null,
    surNameInst:   null,
    sexInst: null,
    nationality_bu_Inst: new FormArray([]),
    fillInTheNationalityInst: null,
    institutionNameTrader: null,
    nationalityTrader: null,
    nIPTrader: null,
    regionTrader: null,
    kRSTrader: null,
    nameTrader: null,
    surNameTrader: null,
    sexTrader: null,
    nationality_bu_Trader: new FormArray([]),
    fillInTheNationalityTrader:  null,
    //fillInTheNationalityTraderReg: string = null;
    amlAcceptanceCheck: null,
    cnpfieldIndv: null,
    maidenName:  null,
    //copyData:string =null;
    otherNationlityBtn :null
}

benefitRulesMock ={"ruleFileName":"Eclaims_Personal_Details_ProposesToClaim.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","selectedClaim":"E160","sourceOfOrigin":"O","individual":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"institutionDifferentThanTrader":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"trader":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"insured":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"benefitiary":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"statutoryRepBen":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"plenipotentiaryBenf":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"owner":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"otherPerson":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"nationalityIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"fillInTheNationalityIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"idDocumentsValidUptoIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"seriesAndNumberIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"11","fieldminlength":"0","allowedDataType":","},"nameIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"taxResidencyCountryIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"countryOfBirthIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"fillInCountryTax":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"fillInCountryBirth":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"copyData":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"surNameIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-every"},"dateOfBirthIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"sexIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"institutionNameInst":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"100","fieldminlength":"0","allowedDataType":"$5"},"nationalityInst":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"fillInTheNationalityReg":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"nIPInst":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"regionInst":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"14","fieldminlength":"0","allowedDataType":"numeric"},"kRSInst":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"numeric"},"nameInst":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"surNameInst":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-every"},"sexInst":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"nationality_bu_Inst":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"fillInTheNationalityInst":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"institutionNameTrader":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"100","fieldminlength":"0","allowedDataType":"$5"},"nationalityTrader":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"nIPTrader":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"regionTrader":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"14","fieldminlength":"0","allowedDataType":"numeric"},"kRSTrader":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"numeric"},"nameTrader":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"surNameTrader":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-every"},"sexTrader":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"nationality_bu_Trader":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"fillInTheNationalityTrader":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"fillInTheNationalityTraderReg":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"amlAcceptanceCheck":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"otherNationlityBtn":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"maidenName":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-every"},"cnpfieldIndv":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"11","fieldminlength":"0","allowedDataType":"numeric"},"ksession":null}

}

describe('BenefitSecComponent', () => {
  let component: BenefitSecComponent;
  let fixture: ComponentFixture<BenefitSecComponent>;
  const fb: FormBuilder = new FormBuilder();
const benefitSecFormMock: BenefitSecFormMock = new BenefitSecFormMock();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientTestingModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ BenefitSecComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(BenefitSecComponent);
    

    // spyOn(sessionStorage, 'getItem').and.callFake( (key:any) => {
    //   return store[key] || null;
    //  });
    component = fixture.componentInstance;
    component.benefitForm =  fb.group( benefitSecFormMock.formMock);
    component.benefitRenderSecRules = benefitSecFormMock.benefitRulesMock;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});