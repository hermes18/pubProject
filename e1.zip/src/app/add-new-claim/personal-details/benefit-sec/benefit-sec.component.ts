import { Component, OnInit, Input, ViewEncapsulation, Output, EventEmitter, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable, forkJoin } from "rxjs";
import { HttpCommonService } from "../../../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { CreateFormService } from '../../../shared/services/create-form.service';
import { ErrorMessagesComponent } from '../../../shared/component/error-messages/error-messages.component';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { ExistingClaimResolve } from '../../../existing-claim/existing-claim-resolve';
import { environment } from 'src/environments/environment';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { InsuranceReferSecComponent } from '../insurance-refer-sec/insurance-refer-sec.component';
import { TranslateService } from '@ngx-translate/core';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS, MatDatepickerInput } from "@angular/material";
import { AppDateAdapter, APP_DATE_FORMATS } from '../../../shared/component/date-field/date-adapter';


@Component({
  selector: 'benefit-sec',
  templateUrl: './benefit-sec.component.html',
  styleUrls: ['./benefit-sec.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class BenefitSecComponent implements OnInit {
  @Input() benefitForm: any;
  @Input() personalFormControl: FormGroup;
  @Output('beneficiaryValueChange') beneficiaryValue: EventEmitter<Event> = new EventEmitter();
  @Output('capacityValueChange') capacityValue: EventEmitter<any> = new EventEmitter();
  
  
  @Input() insuranceRefComp: any;
  @Input() benefitRenderSecRules: any;
  @Input() insuranceRefersToSectionFlag: any;
  @Input() correspondanceRenderSecRules: any;
  //@ViewChild(InsuranceReferSecComponent, { static: false }) insuranceRefComp: InsuranceReferSecComponent;


  userData = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.userData.sourceOrigin;
  peselEnableCountry = eClaimsConstants.peselEnableCountry;
  CNPEnable = eClaimsConstants.CNPEnable;
  //FI|Grp|Indv
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  countryBirthIndv = eClaimsConstants.countryBirthIndv;
  documentValidUptoEnable = eClaimsConstants.documentValidUptoEnable;
  documentValidUptoShow = eClaimsConstants.documentValidUptoShow;
  addCitizenshipIndvCount = eClaimsConstants.addCitizenshipIndvCount;
  addCitizenshipInstituteCount = eClaimsConstants.addCitizenshipInstituteCount;
  addCitizenshipTraderCount = eClaimsConstants.addCitizenshipTraderCount;
  patternTypes = eClaimsConstants.patternTypes;
  nipEnableCountry = eClaimsConstants.nipEnableCountry;
  defaultLanguage = this.userData.defaultLanguage.toUpperCase();
  showTaxResidencyCountryIndv: boolean = false;
  tomorrow = new Date();
  dobMinDate = new Date(eClaimsConstants.dobMinYear, eClaimsConstants.dobMinMnth, eClaimsConstants.dobMinDate);
  docValidUptoMax = new Date((new Date()).setFullYear((new Date()).getFullYear() + 30));


  constructor(private commonService: HttpCommonService,
    public newClaimService: NewClaimSharedService,
    public fb: FormBuilder, private createForm: CreateFormService) {
    this.tomorrow.setDate(this.tomorrow.getDate());
  }
  citizenshipOptions = [];

  citizenshipGrp() {
    let defaultCountrySet = null;
    let patternAllowed = this.patternTypes[this.benefitRenderSecRules.fillInTheNationalityIndv.allowedDataType];
    let maxLengthAllowed = this.patternTypes[this.benefitRenderSecRules.fillInTheNationalityIndv.fieldmaxlength];
    if (this.benefitForm.get('nationalityIndv').controls.length == 0) {
      defaultCountrySet = this.defaultLanguage;
    }
    return this.fb.group({
      citizenship: [defaultCountrySet, Validators.required],
      fillInTheNationalityIndv: ['', [Validators.pattern(patternAllowed), Validators.maxLength(maxLengthAllowed)]],
      documentValidupto: ['']
    });
  }
  nationalityBuTraderGrp() {
    let defaultCountrySet = null;
    if (this.benefitForm.get('nationality_bu_Trader').controls.length == 0) {
      defaultCountrySet = this.defaultLanguage;
    }
    return this.fb.group({
      nationality: [defaultCountrySet, Validators.required],
      fillInTheNationalityTraderReg: ['', []]
    });
  }
  nationality_bu_InstGrp() {
    let defaultCountrySet = null;
    if (this.benefitForm.get('nationality_bu_Inst').controls.length == 0) {
      defaultCountrySet = this.defaultLanguage;
    }
    return this.fb.group({
      nationality: [defaultCountrySet, Validators.required],
      fillInTheNationalityReg: ['', []]
    });
  }

  addNationality() {
    if (this.benefitForm.get('nationalityIndv').controls.length < this.addCitizenshipIndvCount) {
      this.benefitForm.get('nationalityIndv').push(this.citizenshipGrp());
    }
  }

  addCitizenship() {

    if (this.benefitForm.get('nationalityIndv').controls.length == 0
      || this.benefitForm.get('nationalityIndv').valid) {

      this.addNationality();

    }

    this.createForm.markFormGroupTouched(this.benefitForm.get('nationalityIndv'));
  }

  addNationalityBuTrader() {

    if ((this.benefitForm.get('nationality_bu_Trader').controls.length == 0 ||
      this.benefitForm.get('nationality_bu_Trader').valid) &&
      (this.benefitForm.get('nationality_bu_Trader').controls.length < this.addCitizenshipTraderCount)
    ) {
      this.benefitForm.get('nationality_bu_Trader').push(this.nationalityBuTraderGrp());
    }
    this.createForm.markFormGroupTouched(this.benefitForm.get('nationality_bu_Trader'));
  }

  addNationalityBuInst() {


    if ((this.benefitForm.get('nationality_bu_Inst').controls.length == 0
      || this.benefitForm.get('nationality_bu_Inst').valid) && (this.benefitForm.get('nationality_bu_Inst').controls.length < this.addCitizenshipInstituteCount)) {
      this.benefitForm.get('nationality_bu_Inst').push(this.nationality_bu_InstGrp());
    }
    this.createForm.markFormGroupTouched(this.benefitForm.get('nationality_bu_Inst'));
  }

  clearFormArray = (formArray: any) => {
  if(formArray && formArray.length){
    while (formArray.length !== 0) {
      formArray.removeAt(0)
    }
  }

  }

  formInit() {
    this.peselOldValue = null;
    this.benefitForm.reset();
    if (this.benefitRenderSecRules['individual'].renderFlag ||
      this.benefitRenderSecRules['institutionDifferentThanTrader'].renderFlag ||
      this.benefitRenderSecRules['trader'].renderFlag) {
      this.benefitForm.get('benefitiaryGrp').setValidators([Validators.required]);
    } else {
      this.benefitForm.get('benefitiaryGrp').setValidators([Validators.nullValidator]);
    }
    this.benefitForm.get('benefitiaryGrp').updateValueAndValidity();
    this.citizenshipOptions = this.newClaimService.getParamValue('countryList') ? (this.newClaimService.getParamValue('countryList')) : [];
    this.newClaimService.getCountryList().subscribe((data) => {
      this.citizenshipOptions = data;
      setTimeout(() => {
        this.benefitForm.get('countryOfBirthIndv').setValue(this.defaultLanguage);
        this.benefitForm.get('countryOfBirthIndv').setValue(this.benefitForm.get('countryOfBirthIndv').value);
        this.benefitForm.get('nationalityInst').setValue(this.defaultLanguage);
        this.benefitForm.get('nationalityTrader').setValue(this.defaultLanguage);
      }, 0);
    });

    ////console.log("this.benefitForm.controls",this.benefitForm.controls);
    this.countrynationalityIndv = this.defaultLanguage;
    this.clearFormArray(this.benefitForm.controls.nationalityIndv);
    this.addNationality();
    this.addNationalityBuTrader();
    this.addNationalityBuInst();
    // console.log(this.benefitForm.get('trader'));
    this.newClaimService.getTraderFlag().subscribe((data) => {
      // console.log('from service', data)

      this.benefitiaryFormRadioGrp = [{
        labelName: 'individual',
        translatePattern: 'eClaims.newClaim.personalDtails.',
        controlName: 'individual',
        value: 'individual'
      }
        ,
      {
        labelName: (data ? 'institutionDifferentThanTrader' : 'institution'),
        translatePattern: 'eClaims.newClaim.personalDtails.',
        controlName: 'institutionDifferentThanTrader',
        value: 'institution'
      },
      {
        labelName: 'trader',
        translatePattern: 'eClaims.newClaim.personalDtails.',
        controlName: 'trader',
        value: 'trader'
      }];
    });
    this.inValidPeselNumber = false;
    this.showInstNIPIsValid = false;
    this.showTraderNIPIsValid = false;
    this.dateFromCNP = '';
    this.genderFromCNP = '';



    this.onBenefiaryChange('');

    this.setRequiredFields(this.benefitForm.controls, ['taxResidencyCountryIndv'], 'disable');
    this.setRequiredFields(this.benefitForm.controls, this.capacityRadioFields, 'disable');
    this.setRequiredFields(this.benefitForm.controls, ['idDocumentsValidUptoIndv'], 'disable');
    this.setRequiredFields(this.benefitForm.controls, ['otherNationlityBtn'], 'disable');
    //this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityIndv'], 'disable');
    //his.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityReg'], 'disable');
    //this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityTraderReg'], 'disable');
  }
  changeEvent(event) {

  }
  ngOnInit() {
    this.formInit();
  }
  inValidPeselNumber: boolean = false;
  dateFromCNP = '';
  genderFromCNP = '';
  changeDOB(event) {
    this.dateFromCNP = '';
  }
  changeGender(event) {
    this.genderFromCNP = '';
    this.benefitForm.get('maidenName').setValue(null);
    if (this.benefitForm.get('sexIndv').value === 'F') {
      this.setRequiredFields(this.benefitForm.controls, ['maidenName'], 'enable');
    } else {
      this.setRequiredFields(this.benefitForm.controls, ['maidenName'], 'disable');
    }
  }
  getPseiValidation(nationalId, countryCode) {
    let encodeNationalId = encodeURIComponent(nationalId);
    
    let param = {
      "countryCode": countryCode,
      "nationalId": encodeNationalId
    }
    const url = `${environment.host + environment.getPeselRes.url}`;
    return this.commonService[environment.getPeselRes.method](
      url,param);

  }
  inValidSeriesNumber: any = false;
  countrynationalityIndv: string = ''

  get nationalityIndvFromGroup() {
    return this.benefitForm.controls.nationalityIndv['controls'];
  }

  onNationalityIndvChange(event) {

    this.benefitForm.get('cnpfieldIndv').reset();
    // console.log(this.nationalityIndvFromGroup);
    if (this.dateFromCNP != '') {
      this.benefitForm.get('dateOfBirthIndv').setValue(null);
      this.changeDOB(event);
    }
    if (this.genderFromCNP != '') {
      this.benefitForm.get('sexIndv').setValue(null);
      this.changeGender(event);
    }



    this.inValidPeselNumber = false;
    this.countrynationalityIndv = '';
    //if pl documentValidupto.setValidator required
    for (let i = 0; i < this.benefitForm.controls.nationalityIndv.value.length; i++) {
      // //console.log("value",this.benefitForm.controls.nationalityIndv.value[i].citizenship)
      if (this.benefitForm.controls.nationalityIndv.value[i].citizenship == this.defaultLanguage) {
        this.countrynationalityIndv = this.benefitForm.controls.nationalityIndv.value[i].citizenship;
        break;
      }


    }
//CR starts
    if(this.countrynationalityIndv === this.defaultLanguage){
      this.benefitForm.get('countryOfBirthIndv').disable();
      this.benefitForm.get('fillInCountryBirth').disable();
      this.benefitForm.get('countryOfBirthIndv').setValue('');
      this.benefitForm.get('fillInCountryBirth').setValue('');
}else{
  this.benefitForm.get('countryOfBirthIndv').enable();
}
//CR ends

    this.showTaxResidencyCountryIndv = false;
    for (let i = 0; i < this.benefitForm.controls.nationalityIndv.value.length; i++) {
      // //console.log("value",this.benefitForm.controls.nationalityIndv.value[i].citizenship)
      if (this.benefitForm.controls.nationalityIndv.value[i].citizenship == "US") {
        this.showTaxResidencyCountryIndv = true;
        this.benefitForm.controls.taxResidencyCountryIndv.setValue(this.defaultLanguage);
        break;
      }

    }

    if (this.showTaxResidencyCountryIndv) {
      this.setRequiredFields(this.benefitForm.controls, ['taxResidencyCountryIndv'], 'enable');
    } else {
      this.setRequiredFields(this.benefitForm.controls, ['taxResidencyCountryIndv'], 'disable');
    }


    for (let i = 0; i < this.benefitForm.controls.nationalityIndv.value.length; i++) {

      if (this.benefitForm.controls.nationalityIndv['controls'][i].controls.citizenship.value == 'other') {
        this.benefitForm.controls.nationalityIndv['controls'][i].controls.fillInTheNationalityIndv.setValidators([Validators.required]);
        this.benefitForm.controls.nationalityIndv['controls'][i].controls.fillInTheNationalityIndv.updateValueAndValidity();

      } else {
        this.benefitForm.controls.nationalityIndv['controls'][i].controls.fillInTheNationalityIndv.setValidators([]);
        this.benefitForm.controls.nationalityIndv['controls'][i].controls.fillInTheNationalityIndv.updateValueAndValidity();

      }


      if (this.benefitForm.controls.nationalityIndv['controls'][i].controls.documentValidupto
        && this.benefitForm.get('idDocumentsValidUptoIndv')['isVisible']
        && (this.documentValidUptoShow.indexOf(this.benefitForm.controls.nationalityIndv['controls'][i].controls.citizenship.value) === -1)
        && (this.defaultLanguage != this.benefitForm.controls.nationalityIndv['controls'][i].controls.citizenship.value)) {
        this.benefitForm.controls.nationalityIndv['controls'][i].controls.documentValidupto.setValidators([Validators.required]);
        this.benefitForm.controls.nationalityIndv['controls'][i].controls.documentValidupto.updateValueAndValidity();

      } else {
        this.benefitForm.controls.nationalityIndv['controls'][i].controls.documentValidupto.setValidators([]);
        this.benefitForm.controls.nationalityIndv['controls'][i].controls.documentValidupto.updateValueAndValidity();

      }
      this.benefitForm.controls.cnpfieldIndv.disable();
      if (((this.peselEnableCountry.indexOf(this.countrynationalityIndv) != -1)
        && (this.countrynationalityIndv == this.defaultLanguage)) ||
        (this.CNPEnable.indexOf(this.defaultLanguage) != -1)) {
        this.benefitForm.controls.cnpfieldIndv.enable();
      }
    }

  }

  onNationalityInstituteChange(event) {
    for (let i = 0; i < this.benefitForm.controls.nationality_bu_Inst.value.length; i++) {

      if (this.benefitForm.controls.nationality_bu_Inst['controls'][i].controls.nationality.value == 'other') {
        this.benefitForm.controls.nationality_bu_Inst['controls'][i].controls.fillInTheNationalityReg.setValidators([Validators.required]);
        this.benefitForm.controls.nationality_bu_Inst['controls'][i].controls.fillInTheNationalityReg.updateValueAndValidity();

      } else {
        this.benefitForm.controls.nationality_bu_Inst['controls'][i].controls.fillInTheNationalityReg.setValidators([]);
        this.benefitForm.controls.nationality_bu_Inst['controls'][i].controls.fillInTheNationalityReg.updateValueAndValidity();

      }
    }
  }
  onNationalitytraderChange(event) {
    for (let i = 0; i < this.benefitForm.controls.nationality_bu_Trader.value.length; i++) {

      if (this.benefitForm.controls.nationality_bu_Trader['controls'][i].controls.nationality.value == 'other') {
        this.benefitForm.controls.nationality_bu_Trader['controls'][i].controls.fillInTheNationalityTraderReg.setValidators([Validators.required]);
        this.benefitForm.controls.nationality_bu_Trader['controls'][i].controls.fillInTheNationalityTraderReg.updateValueAndValidity();

      } else {
        this.benefitForm.controls.nationality_bu_Trader['controls'][i].controls.fillInTheNationalityTraderReg.setValidators([]);
        this.benefitForm.controls.nationality_bu_Trader['controls'][i].controls.fillInTheNationalityTraderReg.updateValueAndValidity();

      }
    }
  }
  changeTaxResidencyCountryIndv(event) {
    if (this.benefitForm.get('taxResidencyCountryIndv').value == 'other'
      &&
      this.benefitRenderSecRules['fillInCountryTax'].mandatoryFlag
    ) {
      this.benefitForm.controls['fillInCountryTax'].setValue(null);

      this.setRequiredFields(this.benefitForm.controls, ['fillInCountryTax'], 'enable');
    } else {
      this.setRequiredFields(this.benefitForm.controls, ['fillInCountryTax'], 'disable');
    }
  }
  peselOldValue:any=null;
  blurPseiField(event) {

    if(this.peselOldValue != this.benefitForm.controls.cnpfieldIndv.value){
      let tenantId = sessionStorage.getItem('tenantId');
      if (this.benefitForm.controls.cnpfieldIndv.value == '' && this.countrynationalityIndv == this.defaultLanguage) {
        this.benefitForm.get('maidenName').reset();
        this.benefitForm.get('dateOfBirthIndv').setValue('');
        this.benefitForm.get('sexIndv').reset();
        this.dateFromCNP = '';
        this.genderFromCNP = '';
        this.inValidPeselNumber = false;
      }
  
      if (this.benefitForm.controls.cnpfieldIndv.value != '' &&
        this.benefitForm.controls.cnpfieldIndv.value &&
        this.countrynationalityIndv == this.defaultLanguage) {
        this.getPseiValidation(this.benefitForm.controls.cnpfieldIndv.value,
          this.countrynationalityIndv.toLowerCase()).subscribe((data) => {
            //console.log(data);
            if (data.additionalInfo) {
              //            data.additionalInfo={dateOfBirth : "26/07/1973"};
  
              if (data.additionalInfo.dateOfBirth) {
                let setDate = data.additionalInfo.dateOfBirth.split('/');
  
                if (setDate) {
                  this.benefitForm.get('dateOfBirthIndv').setValue(new Date(setDate.reverse().join('/')));
                  this.dateFromCNP = "*";
                  this.genderFromCNP = "*"
                }
  
              }
              if (data.additionalInfo.gender) {
                this.benefitForm.get('sexIndv').setValue(data.additionalInfo.gender);
                this.changeGender('');
                this.dateFromCNP = "*";
                this.genderFromCNP = "*"
              }
  
              this.inValidPeselNumber = false;
              this.inValidSeriesNumber = false;
              this.benefitForm.controls.cnpfieldIndv['invalidFlag'] = this.inValidPeselNumber;
  
            } else {
  
  
              //data.additionalInfo.insuranceRefersDataDerived
              this.inValidPeselNumber = true;
              this.benefitForm.controls.cnpfieldIndv['invalidFlag'] = this.inValidPeselNumber;
              this.benefitForm.get('cnpfieldIndv').updateValueAndValidity();
              this.benefitForm.get('maidenName').reset();
              this.benefitForm.get('dateOfBirthIndv').setValue('');
              this.benefitForm.get('sexIndv').reset();
              this.dateFromCNP = '';
              this.genderFromCNP = '';
            }
          });
      } else {
        //  this.inValidSeriesNumber = false;
      }
    }
    this.peselOldValue = this.benefitForm.controls.cnpfieldIndv.value;
    this.benefitForm.controls.cnpfieldIndv['invalidFlag'] = this.inValidPeselNumber;
  }


  copyFromEklient(event) {
    // console.log("copydata", event.target.value);
    let clientId = null;
    clientId = this.userData.clientId;
    let param = {
      "clientId": clientId,
      "email": "",
      "phoneNumber": "",
      "role": "",
      "userId": ""
    }

    if(clientId){
    this.commonService[environment.copyInsureEklientListConfig.method](
      (environment.host + environment.copyInsureEklientListConfig.url),param).subscribe((data) => {
        let clientIdentifierDTOs: any = {};
        if (data.clientIdentifierDTOs.length > 0) {
          for (let i = 0; i < data.clientIdentifierDTOs.length; i++) {
            clientIdentifierDTOs[data.clientIdentifierDTOs[i].identifierType] = data.clientIdentifierDTOs[i].identifierValue;
          }
        }
        
       // let nameFieldReplaceVal = this.newClaimService.restrictedPatternValRemove(eClaimsConstants.patternTypes[this.benefitRenderSecRules['nameIndv'].allowedDataType],data.firstName);
        //let surnameFieldReplaceVal = this.newClaimService.restrictedPatternValRemove(eClaimsConstants.patternTypes[this.benefitRenderSecRules['surNameIndv'].allowedDataType],data.lastName);

        this.benefitForm.get('nameIndv').setValue(data.firstName);
        this.benefitForm.get('surNameIndv').setValue(data.lastName);
        //this.insureForm.get('nationalityField').setValue(data.countryCode);
        this.benefitForm.get('cnpfieldIndv').setValue(clientIdentifierDTOs.PESEL);
        //this.insureForm.get('dobField').setValue(data.dobField);
        //this.insureForm.get('sexField').setValue(data.sexField);
        //this.insureForm.get('passportNumField').setValue(data.passportNumField);

        this.blurPseiField('');
      });
    }
  }


  copyDetailsFromInsuranceSec() {
    this.benefitForm.get('nameIndv').setValue(this.personalFormControl.value.insuranceRefersToSection.nameField);
    this.benefitForm.get('surNameIndv').setValue(this.personalFormControl.value.insuranceRefersToSection.surnameField);
    setTimeout(() => {
      this.benefitForm.get('citizenship').setValue(this.personalFormControl.value.insuranceRefersToSection.citizenship);
      this.onNationalityIndvChange('');
      this.inValidPeselNumber = this.insuranceRefComp.inValidCnpNumber;
      this.benefitForm.get('cnpfieldIndv').setValue(this.personalFormControl.value.insuranceRefersToSection.cnpfield);
      this.benefitForm.get('dateOfBirthIndv').setValue(this.personalFormControl.value.insuranceRefersToSection.dobField);
      this.benefitForm.get('sexIndv').setValue(this.personalFormControl.value.insuranceRefersToSection.sexField);
      this.changeGender(this.personalFormControl.value.insuranceRefersToSection.sexField)
      this.benefitForm.get('maidenName').setValue(this.personalFormControl.value.insuranceRefersToSection.maidenNameField);

      this.genderFromCNP = this.insuranceRefComp.genderFromCNP;
      this.dateFromCNP = this.insuranceRefComp.dateFromCNP
    }, 0);
    // setTimeout(() => {
    // this.benefitForm.get('cnpfieldIndv').setValue(this.personalFormControl.value.insuranceRefersToSection.cnpfield);
    // this.blurPseiField(this.personalFormControl.value.insuranceRefersToSection.cnpfield)

    // }, 0);
    this.benefitForm.get('seriesAndNumberIndv').setValue(this.personalFormControl.value.insuranceRefersToSection.passportNumField);
    //console.log(this.personalFormControl.value.insuranceRefersToSection.nationalityField);
    this.benefitForm.controls.nationalityIndv['controls'][0].get('citizenship').setValue(this.personalFormControl.value.insuranceRefersToSection.nationalityField);
    this.benefitForm.controls.nationalityIndv['controls'][0].get('fillInTheNationalityIndv').setValue(this.personalFormControl.value.insuranceRefersToSection.otherNationalityField);
    //this.benefitForm.controls.nationalityIndv['controls'][0].get('fillInTheNationalityInst').updateValueAndValidity();

  }




  benefitiaryFormRadioGrp = [

  ];
  capacityFormRadioGrp = [];
  capacityFormRadioGrp_pl_indv = [
    {
      labelName: 'insured',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'insured',
      value: 'insured',
      tooltip: ''
    }, {
      labelName: 'owner',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'owner',
      value: 'owner',
      tooltip: ''
    },
    {
      labelName: 'otherPerson',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'otherPerson',
      value: 'otherPerson',
      tooltip: ''
    },
    {
      labelName: 'beneficiaryEntitledTo',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'benefitiary',
      value: 'benefitiary',
      tooltip: 'InheritenceLabel'
    },
    {
      labelName: 'statutoryOfBeneficiary',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'statutoryRepBen',
      value: 'statutoryRepBen',
      tooltip: 'StatutoryTooltip'
    },
    {
      labelName: 'plenipotentiaryOfBeneficiary',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'plenipotentiaryBenf',
      value: 'plenipotentiaryBenf',
      tooltip: 'PlenipotentiaryTooltip'
    }
  ];

  capacityFormRadioGrp_pl_instute = [

    {
      labelName: 'beneficiaryEntitledTo',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'benefitiary',
      value: 'benefitiary',
      tooltip: 'InheritenceLabel'
    },
    {
      labelName: 'statutoryOfBeneficiary',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'statutoryRepBen',
      value: 'statutoryRepBen',
      tooltip: 'StatutoryTooltip'
    },
    {
      labelName: 'plenipotentiaryOfBeneficiary',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'plenipotentiaryBenf',
      value: 'plenipotentiaryBenf',
      tooltip: 'PlenipotentiaryTooltip'
    }
  ];
  capacityFormRadioGrp_ro_indv = [
    {
      labelName: 'insured',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'insured',
      value: 'insured'
    }, {
      labelName: 'owner',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'owner',
      value: 'owner'
    },
    {
      labelName: 'otherPerson',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'otherPerson',
      value: 'otherPerson'
    },
    {
      labelName: 'beneficiaryEntitledTo',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'benefitiary',
      value: 'benefitiary',
      tooltip: 'InheritenceLabel'
    },
    {
      labelName: 'statutoryOfBeneficiary',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'statutoryRepBen',
      value: 'statutoryRepBen',
      tooltip: 'StatutoryTooltip'
    },
    {
      labelName: 'plenipotentiaryOfBeneficiary',
      translatePattern: 'eClaims.newClaim.personalDtails.',
      controlName: 'plenipotentiaryBenf',
      value: 'plenipotentiaryBenf',
      tooltip: 'PlenipotentiaryTooltip'
    }
  ];

  capacityFormRadioGrp_ro_instute = [
  ];
  //'benefitiary'
  capacityRadioFields = ['insured', 'owner', 'benefitiary', 'otherPerson', 'plenipotentiaryBenf', 'statutoryRepBen'];
  onCapacityChange(event){
   let sentValue = {
    "capacity":this.benefitForm.get('capacity').value,
    "benefitiary": this.benefitForm.get('benefitiaryGrp').value
   };
      this.capacityValue.emit(sentValue);
    

  }
  onBenefiaryChange(event) {

    this.peselOldValue = '';

    this.setRequiredFields(this.benefitForm.controls, ['taxResidencyCountryIndv'], 'disable');
    this.setRequiredFields(this.benefitForm.controls, this.capacityRadioFields, 'disable');
    this.setRequiredFields(this.benefitForm.controls, ['idDocumentsValidUptoIndv'], 'disable');
    this.setRequiredFields(this.benefitForm.controls, ['otherNationlityBtn'], 'disable');
    //this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityIndv'], 'disable');
    //this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityReg'], 'disable');
    //this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityTraderReg'], 'disable');

    this.beneficiaryValue.emit(this.benefitForm.get('benefitiaryGrp').value);
    ////console.log(event);Validators.nullValidator
    if (this.benefitForm.get('nationalityIndv').controls.length == 0) {

      this.addNationality();
    }
    if (this.benefitForm.get('nationality_bu_Inst').controls.length == 0) {

      this.benefitForm.get('nationality_bu_Inst').push(this.nationality_bu_InstGrp());
    }
    if (this.benefitForm.get('nationality_bu_Trader').controls.length == 0) {

      this.benefitForm.get('nationality_bu_Trader').push(this.nationalityBuTraderGrp());
    }

    // if (this.benefitForm.get('benefitiary').value && this.capacityFormRadioGrp.length > 0) {
    //   this.benefitForm.get('capacity').setValidators([Validators.required]);
    //   this.benefitForm.get('capacity').updateValueAndValidity();
    //   this.setRequiredFields(this.benefitForm.controls, ['capacity'], 'enable');

    // } else {
    //   this.benefitForm.get('capacity').setValidators([Validators.nullValidator]);
    //   this.benefitForm.get('capacity').updateValueAndValidity();
    //   this.setRequiredFields(this.benefitForm.controls, ['capacity'], 'disable');
    // }

    if (this.benefitForm.get('benefitiaryGrp').value === 'individual') {
      //['insured','beneficiary','statutory','plenipotentiary']
      this.newClaimService.setIndividual(true);
      this.capacityFormRadioGrp = this[('capacityFormRadioGrp_' + this.userData.defaultLanguage + '_indv')];
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryIndvFields, 'enable');
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryInstituteFields, 'disable');
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryTraderFields, 'disable');
      this.changeCountryBirthIndv('');
      this.changeTaxResidencyCountryIndv('');
      this.onNationalityIndvChange('');
      this.changeTaxResidencyCountryIndv('');
      this.changeGender('');
    }

    else if (this.benefitForm.get('benefitiaryGrp').value === 'institution') {
      this.capacityFormRadioGrp = this[('capacityFormRadioGrp_' + this.userData.defaultLanguage + '_instute')];

      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryIndvFields, 'disable');
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryInstituteFields, 'enable');
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryTraderFields, 'disable');
      this.changeNationalityInst('');
    } else if (this.benefitForm.get('benefitiaryGrp').value === 'trader') {
      this.capacityFormRadioGrp = this[('capacityFormRadioGrp_' + this.userData.defaultLanguage + '_instute')];
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryIndvFields, 'disable');
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryInstituteFields, 'disable');
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryTraderFields, 'enable');
      this.changeNationalityTrader('');
      this.onNationalitytraderChange('');
    } else {
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryIndvFields, 'disable');
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryInstituteFields, 'disable');
      this.setRequiredFields(this.benefitForm.controls, this.beneficiaryTraderFields, 'disable');
      this.changeCountryBirthIndv('');
      this.changeTaxResidencyCountryIndv('');
      this.onNationalityIndvChange('');
      this.changeTaxResidencyCountryIndv('');
      this.changeGender('');
      this.changeNationalityInst('');
      this.changeNationalityTrader('');
      this.onNationalitytraderChange('');
    }
    if (this.benefitForm.get('benefitiaryGrp').value && this.capacityFormRadioGrp.length > 0
      && (
        this.benefitRenderSecRules['insured'].mandatoryFlag
        || this.benefitRenderSecRules['owner'].mandatoryFlag
        || this.benefitRenderSecRules['otherPerson'].mandatoryFlag
        || this.benefitRenderSecRules['benefitiary'].mandatoryFlag
        || this.benefitRenderSecRules['statutoryRepBen'].mandatoryFlag
        || this.benefitRenderSecRules['plenipotentiaryBenf'].mandatoryFlag
      )
    ) {
      this.benefitForm.get('capacity').setValidators([Validators.required]);
      this.benefitForm.get('capacity').updateValueAndValidity();
      this.setRequiredFields(this.benefitForm.controls, ['capacity'], 'enable');

    } else { 
      
      this.benefitForm.get('capacity').setValidators([Validators.nullValidator]);
      this.benefitForm.get('capacity').updateValueAndValidity();
      this.setRequiredFields(this.benefitForm.controls, ['capacity'], 'disable');
    }

    // this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityIndv'], 'disable');
    // this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityReg'], 'disable');
    // this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityTraderReg'], 'disable');
    // this.setRequiredFields(this.benefitForm.controls, ['fillInCountryBirth'], 'disable');
    // this.setRequiredFields(this.benefitForm.controls, ['fillInCountryTax'], 'disable');
    // this.setRequiredFields(this.benefitForm.controls, ['maidenName'], 'disable');
    // this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityInst'], 'disable');
    // this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityTrader'], 'disable');

    // this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityTrader'], 'disable');
    //'fillInCountryBirth','fillInCountryTax','maidenName','idDocumentsValidUptoIndv'
    //'fillInTheNationalityInst'
    //'fillInTheNationalityTrader'
    //this.onNationalityIndvChange('');  
  }
  //beneficiaryIndvFields
  beneficiaryIndvFields = ['nameIndv', 'surNameIndv', 'countryOfBirthIndv',
    'cnpfieldIndv', 'dateOfBirthIndv', 'sexIndv', 'seriesAndNumberIndv',
    'fillInCountryBirth', 'fillInCountryTax', 'maidenName'];

  beneficiaryInstituteFields = ['nationalityInst',
    'institutionNameInst', 'nIPInst', 'regionInst', 'kRSInst', 'nameInst',
    'surNameInst', 'sexInst', 'fillInTheNationalityInst', 'fillInTheNationalityReg'];

  beneficiaryTraderFields = ['nationalityTrader',
    'institutionNameTrader', 'nIPTrader', 'regionTrader', 'kRSTrader',
    'nameTrader', 'surNameTrader', 'sexTrader', 'fillInTheNationalityTrader',
    'fillInTheNationalityTraderReg'];

  setRequiredFields(parentControl, fieldsArr, validation) {
    for (let i = 0; i < fieldsArr.length; i++) {
      if (parentControl[fieldsArr[i]]) {
        //parentControl[fieldsArr[i]].setValidators(validation);
        //parentControl[fieldsArr[i]].updateValueAndValidity();
        parentControl[fieldsArr[i]][validation]();
      }
    }
  }

  countryOnChange(event) {
    let claimData = this.newClaimService.getClaimData();
    let lob = (claimData ? claimData.newclaim : null);
    this.showTaxResidencyCountryIndv = false;
    //console.log("personal details", lob)
    if (this.peselEnableCountry.indexOf(this.defaultLanguage) != -1 && lob == 'Individual') {
      if (event == 'US') {
        this.showTaxResidencyCountryIndv = true;
        this.benefitForm.get('taxResidencyCountryIndv').setValue(this.defaultLanguage);
        this.setRequiredFields(this.benefitForm.controls, ['taxResidencyCountryIndv'], 'enable');
      } else {
        this.showTaxResidencyCountryIndv = false;
        this.setRequiredFields(this.benefitForm.controls, ['taxResidencyCountryIndv'], 'disable');
      }
    }
  }

  changeNationalityTrader(event) {
    if (this.benefitForm.get('nationalityTrader').value == 'other') {
      this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityTrader'], 'enable');
    } else {
      this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityTrader'], 'disable');
    }
  }

  changeCountryBirthIndv(event) {
    if (this.benefitForm.get('countryOfBirthIndv').value == 'other' &&
      this.benefitRenderSecRules['countryOfBirthIndv'].mandatoryFlag) {
      this.setRequiredFields(this.benefitForm.controls, ['fillInCountryBirth'], 'enable');
    } else {
      this.setRequiredFields(this.benefitForm.controls, ['fillInCountryBirth'], 'disable');
    }

  }
  changeNationalityInst(event) {
    if (this.benefitForm.get('nationalityInst').value == 'other' &&
      this.benefitRenderSecRules['fillInTheNationalityInst'].mandatoryFlag) {

      this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityInst'], 'enable');

    } else {
      this.setRequiredFields(this.benefitForm.controls, ['fillInTheNationalityInst'], 'disable');
    }
  }

  showInstNIPIsValid: boolean = false;
  InstNIPIsValid(event) {
    this.showInstNIPIsValid = false;
    if (this.benefitForm.controls.nIPInst.value != '' && this.nipEnableCountry.indexOf(this.defaultLanguage) != -1) {
      let nip = this.benefitForm.controls.nIPInst.value;
      var weights = [6, 5, 7, 2, 3, 4, 5, 6, 7];
      nip = nip.replace(/[\s-]/g, '');
      if (nip.length == 10 && parseInt(nip, 10) > 0) {
        var sum = 0;
        for (var i = 0; i < 9; i++) {
          sum += nip[i] * weights[i];
        }
        var res = (sum % 11) == nip[9];
        this.showInstNIPIsValid = false;
      } else {
        this.showInstNIPIsValid = true;
      }
    }
  }
  showTraderNIPIsValid: boolean = false;
  TraderNIPIsValid() {
    this.showTraderNIPIsValid = false;
    if (this.benefitForm.controls.nIPTrader.value != '' && this.nipEnableCountry.indexOf(this.defaultLanguage) != -1) {
      let nip = this.benefitForm.controls.nIPTrader.value;
      var weights = [6, 5, 7, 2, 3, 4, 5, 6, 7];
      nip = nip.replace(/[\s-]/g, '');
      if (nip.length == 10 && parseInt(nip, 10) > 0) {
        var sum = 0;
        for (var i = 0; i < 9; i++) {
          sum += nip[i] * weights[i];
        }
        var res = (sum % 11) == nip[9];
        this.showTraderNIPIsValid = false;
      } else {
        this.showTraderNIPIsValid = true;
      }
    }
  }

  /* changeNationalityTrader(event) {
     if (this.benefitForm.get('nationalityInst').value == 'other') {
       this.benefitForm.controls['fillInTheNationalityInst'].setValidators([Validators.required]);
       this.benefitForm.controls['fillInTheNationalityInst'].updateValueAndValidity();
     } else {
       this.benefitForm.controls['fillInTheNationalityInst'].setValidators([]);
       this.benefitForm.controls['fillInTheNationalityInst'].updateValueAndValidity();
     }
   }*/

  formSubmit() {
     //console.log("this.benefitForm", this.benefitForm);
     //console.log("this.benefitForm", this.benefitForm.valid);
   
   if(this.benefitForm.get('benefitiaryGrp')){
    if (this.benefitRenderSecRules['individual'].renderFlag ||
    this.benefitRenderSecRules['institutionDifferentThanTrader'].renderFlag ||
    this.benefitRenderSecRules['trader'].renderFlag) {
    this.benefitForm.get('benefitiaryGrp').setValidators([Validators.required]);
  } else {
    this.benefitForm.get('benefitiaryGrp').setValidators([Validators.nullValidator]);
  }
  this.benefitForm.get('benefitiaryGrp').updateValueAndValidity();
   }


    let formDetails = {
      formInfo: null,
      isFormValid: this.formValid()
    }

    return formDetails;
    /*if(this.insureForm.valid){
      return true;
    }*/
    //return false;
  }

  formValid() {
     //console.log("benefitForm errorFormGroup", this.createForm.errorFormGroup(this.benefitForm));
    if (!this.inValidPeselNumber && this.benefitForm.valid) {
      return true;
    }
    return false;
  }
}