import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { InsuranceReferSecComponent } from './insurance-refer-sec.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { ExistingClaimResolve } from 'src/app/existing-claim/existing-claim-resolve';
import {  FormGroup, FormControl, Validators, FormArray, AbstractControl,FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PersonalRuleMock } from '../personal-details.component.spec';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { DeviceDetectorService } from 'ngx-device-detector';


export class InsuranceReferRulesMock {
  insuranceMock = {"ruleFileName":"Eclaims_Personal_Details_InsuranceRefersTo.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","selectedClaim":"E160","insuranceEventRefersTo":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"copyPersonalDataFromEcustomer":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"nameField":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"surnameField":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-every"},"nationalityField":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"otherNationalityField":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"dobField":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"sexField":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"maidenNameField":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-every"},"passportNumField":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"11","fieldminlength":"0","allowedDataType":","},"currentProfessionField":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"qualifiedProfessionField":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"personalDataProcessingMsg":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"cnpfield":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"11","fieldminlength":"0","allowedDataType":"numeric"},"ksession":null};
}

describe('InsuranceReferSecComponent', () => {
  let component: InsuranceReferSecComponent;
  let fixture: ComponentFixture<InsuranceReferSecComponent>;
  const fb: FormBuilder = new FormBuilder();
  const secValidations: PersonalRuleMock = new PersonalRuleMock();
  const insuranceSecValidations: InsuranceReferRulesMock = new InsuranceReferRulesMock();
  const newClaimService: NewClaimSharedService = new NewClaimSharedService();
 

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientModule,BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ InsuranceReferSecComponent ],
      providers : [ { provide: ExistingClaimResolve },
      { provide : HttpClient },{ provide: FormBuilder, useValue: fb },DeviceDetectorService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    //if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    //}
    fixture = TestBed.createComponent(InsuranceReferSecComponent);
    component = fixture.componentInstance;
    
  let insureModel = {
  insuranceEventRefersTo: null,
  nameField: null,
  surnameField:  null,
  citizenship:  null,
  peselField:  null,
  dobField:  null,
  sexField: null,
  passportNumField:  null,
  maidenNameField:  null,
  otherNationalityField:  null,
  currentProfessionField:null,
  qualifiedProfessionField:  null,
  personalDataProcessingMsg: null,
  cnpfield: null,
  nationalityField:null,
  copyPersonalDataFromEcustomer: null
};
    component.insureForm =  fb.group(insureModel);
    
    
    let typeOfEventData = {
      newclaim: '',
      newclaimCode: '',
      claimTypeCode: '',
      policyNumber: '',
      employerDetails: '',
      disclaimerSection:''
  
    };
    let newClaimService = TestBed.get(NewClaimSharedService);
    
    
   
    spyOn(  newClaimService, 'getClaimData').and.returnValue(typeOfEventData);
   // spyOn(  sessionStorage, 'getClaimData').and.returnValue(typeOfEventData);
    
    
    fixture.detectChanges();
  });
  

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
