import { Component, OnInit, Input, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable, forkJoin } from "rxjs";
import { HttpCommonService } from "../../../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { CreateFormService } from '../../../shared/services/create-form.service';
import { ErrorMessagesComponent } from '../../../shared/component/error-messages/error-messages.component';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { ExistingClaimResolve } from '../../../existing-claim/existing-claim-resolve';
import { environment } from 'src/environments/environment';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { DataService } from 'src/app/shared/services/data.service';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { TranslateService } from '@ngx-translate/core';
import { DeviceDetectorService } from 'ngx-device-detector';
@Component({
  selector: 'insurance-refer-sec',
  templateUrl: './insurance-refer-sec.component.html',
  styleUrls: ['./insurance-refer-sec.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class InsuranceReferSecComponent implements OnInit {
  @Input() insureForm: FormGroup;
  @Input() insureReferRenderSecRules: any;
  tomorrow = new Date();
  dobMinDate = new Date(eClaimsConstants.dobMinYear, eClaimsConstants.dobMinMnth, eClaimsConstants.dobMinDate);
  userData = JSON.parse(sessionStorage.getItem('userData'));
  sourceOfOrigin: string = this.userData.sourceOrigin;
  peselEnableCountry = eClaimsConstants.peselEnableCountry;
  showInsuranceDisclaimer = eClaimsConstants.showInsuranceDisclaimer;
  CNPEnable = eClaimsConstants.CNPEnable;
  //FI|Grp|Indv
  eventRefersToOptions: any;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  defaultLanguage = this.userData.defaultLanguage.toUpperCase();
  inValidCnpNumber: any = false;
  
  dateFromCNP = '';
  genderFromCNP = '';
  peselOldValue:any=null;

  citizenshipOptions = []
  renderClaimSections: any;
  personalDataCopyEC: any = null;

  isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
  isMobile = this.deviceDetector.isMobile();

  constructor(private readonly existingClaimResolve: ExistingClaimResolve, private changeDetector: ChangeDetectorRef,
    private commonService: HttpCommonService, public newClaimService: NewClaimSharedService, public createFormService: CreateFormService,
    public dataService: DataService,public dialogService: DialogService,private translate: TranslateService,
    public deviceDetector:DeviceDetectorService) {
    this.tomorrow.setDate(this.tomorrow.getDate());
  }

  getPseiValidation(nationalId, countryCode) {
    let encodeNationalId = encodeURIComponent(nationalId);
    
    let param = {
      "countryCode": countryCode,
      "nationalId": encodeNationalId
    }
    const url = `${environment.host + environment.getPeselRes.url}`;
    return this.commonService[environment.getPeselRes.method](
      url,param);

  }

  openPrivacyPDF() {
    // yet to confrm
  }
  changeDOB(event) {
    this.dateFromCNP = '';
  }
  changeGender(event) {
    this.genderFromCNP = '';
    this.insureForm.get('maidenNameField').reset();
    if (this.insureForm.get('sexField').value == 'F') {
      this.insureForm.get('maidenNameField').enable();
    } else {
      this.insureForm.get('maidenNameField').disable();
    }
    // console.log('error maidenNameField', this.insureForm.get('maidenNameField').errors)
  }
  changeNationality(event) {

    if (this.dateFromCNP != "") {
      this.changeDOB(event);
    }
    if (this.genderFromCNP != "") {
      this.changeGender(event);
    }

    this.insureForm.get('cnpfield').reset();
    this.insureForm.get('dobField').setValue('');
    this.insureForm.get('sexField').setValue(null);
    if (this.insureForm.get('nationalityField').value == 'other'
      &&
      this.insureReferRenderSecRules['otherNationalityField'].mandatoryFlag
    ) {
      this.insureForm.get('otherNationalityField').enable();

    } else {
      this.insureForm.get('otherNationalityField').disable();
    }
    if (((this.peselEnableCountry.indexOf(this.insureForm.get('nationalityField').value) != -1)
      && (this.insureForm.get('nationalityField').value == this.defaultLanguage)) ||
      (this.CNPEnable.indexOf(this.defaultLanguage) != -1)) {
      this.insureForm.get('cnpfield').enable();
    } else {
      this.insureForm.get('cnpfield').disable();
    }

    this.inValidCnpNumber = false;

  }

  blurPseiField(event) {
   if(this.peselOldValue!= this.insureForm.controls.cnpfield.value){
    let tenantId = sessionStorage.getItem('tenantId');
    //console.log("this.insureForm.controls.cnpfield.value",this.insureForm.controls.cnpfield.value)
    // console.log('error maidenNameField', this.insureForm.get('maidenNameField').errors)
    if (this.insureForm.controls.cnpfield.value == '' &&
      (this.insureForm.controls.nationalityField.value == this.defaultLanguage.toUpperCase())) {
      this.insureForm.get('maidenNameField').reset();
      this.insureForm.get('dobField').setValue('');
      this.insureForm.get('sexField').reset();
      this.dateFromCNP = '';
      this.genderFromCNP = '';
      this.inValidCnpNumber = false;
    }
    // console.log('error maidenNameField', this.insureForm.get('maidenNameField').errors)
    if ((this.insureForm.controls.cnpfield.value && this.insureForm.controls.cnpfield.value != ''
      && (this.insureForm.controls.nationalityField.value == this.defaultLanguage.toUpperCase()))) {
      this.getPseiValidation(this.insureForm.controls.cnpfield.value,
        this.insureForm.controls.nationalityField.value.toLowerCase()).subscribe((data) => {
          //console.log(data);
          if (data.additionalInfo) {
            //            data.additionalInfo={dateOfBirth : "26/07/1973"};

            if (data.additionalInfo.dateOfBirth) {
              let setDate = data.additionalInfo.dateOfBirth.split('/');

              if (setDate) {
                this.insureForm.get('dobField').setValue(new Date(setDate.reverse().join('/')));
                this.dateFromCNP = "*";
                this.genderFromCNP = "*"
              }

            }
            if (data.additionalInfo.gender) {
              this.insureForm.get('sexField').setValue(data.additionalInfo.gender);
              this.changeGender(this.insureForm.get('sexField').value);
              // console.log('error maidenNameField', this.insureForm.get('maidenNameField').errors)
              this.dateFromCNP = "*";
              this.genderFromCNP = "*"
            }


            this.inValidCnpNumber = false;
            this.insureForm.controls.cnpfield['invalidFlag'] = this.inValidCnpNumber;

          } else {


            //data.additionalInfo.insuranceRefersDataDerived
            this.inValidCnpNumber = true;
            this.insureForm.controls.cnpfield['invalidFlag'] = this.inValidCnpNumber;
            this.insureForm.get('cnpfield').updateValueAndValidity();
            this.insureForm.get('maidenNameField').reset();
            this.insureForm.get('dobField').setValue('');
            this.insureForm.get('sexField').reset();
            this.dateFromCNP = '';
            this.genderFromCNP = '';
          }
        });
    } else {
      //  this.inValidSeriesNumber = false;
    }
   }
   this.peselOldValue = this.insureForm.controls.cnpfield.value;
    this.insureForm.controls.cnpfield['invalidFlag'] = this.inValidCnpNumber;

  }


  
  
  
  formInit() {
    this.peselOldValue = null;
    this.personalDataCopyEC = null;
    this.insureForm.get('copyPersonalDataFromEcustomer').setValue(null);
    this.insureForm.reset();
    this.insureForm.get('nationalityField').setValue(this.defaultLanguage.toUpperCase());
    this.citizenshipOptions = this.newClaimService.getParamValue('countryList') ? (this.newClaimService.getParamValue('countryList')) : [];
    this.setInsuranceRefersVal();

    this.newClaimService.getCountryList().subscribe((data) => {
      this.citizenshipOptions = data;
      this.changeDetector.detectChanges();
      setTimeout(() => {
        this.insureForm.get('nationalityField').setValue(this.insureForm.get('nationalityField').value);
      }, 0);
    });
  
    setTimeout(() => {
      this.insureForm.controls['nationalityField'].setValue(this.insureForm.controls['nationalityField'].value);
      // console.log('error maidenNameField', this.insureForm.get('maidenNameField').errors)
      this.changeNationality('');
      this.changeGender('');
      // console.log('error maidenNameField', this.insureForm.get('maidenNameField').errors)
    }, 0);
    // console.log('error maidenNameField', this.insureForm.get('maidenNameField').errors)
    this.dateFromCNP = '';
    this.genderFromCNP = '';
    this.inValidCnpNumber = false;

    this.changeNationality('');
    this.changeGender('');
  }
  ngOnInit() {

    this.formInit();

  }
  setInsuranceRefersVal(){
    this.renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');
    let insuranceValue =  this.insureForm.get('insuranceEventRefersTo').value; 
    let lobValue = this.newClaimService.getClaimData().newclaim;
    let claimTypeValue = this.newClaimService.getPrimaryClaimType();

    if ((lobValue == 'IndividualLife' || lobValue == 'IndividualLifeM')
    && (claimTypeValue.indexOf('E410') != -1)) {
    this.eventRefersToOptions = ['Insured'];
  } else if ((lobValue == 'IndividualLife' || lobValue == 'IndividualLifeM')
    && (claimTypeValue.indexOf('E420') != -1)) {
    this.eventRefersToOptions = ['PrimaryOwnerEvent'];
  }
  else {
    this.eventRefersToOptions = this.newClaimService.getParamValue('eventTypeList') ? (this.newClaimService.getParamValue('eventTypeList').split('|')) : [];
  }
  //IndividualLife IndividualLifeM E420 E410
 
  setTimeout(() => {
  if(this.eventRefersToOptions.indexOf(insuranceValue)!=-1){
    this.insureForm.get('insuranceEventRefersTo').setValue(insuranceValue);
  }else{
    this.insureForm.get('insuranceEventRefersTo').setValue(null);   

  }
})

  }
  
attachmentReset(){
  try{
    let fileInAttachment = this.dataService.getOption('uploadNewClaimList');
    if (fileInAttachment && fileInAttachment.fileUpload && fileInAttachment.fileUpload.length > 0) {
      this.dialogService.openDialog(AlertDialogComponent, { 'heading': this.translate.instant('eClaims.existingClaim.confirmationLabel'), 'body': this.translate.instant('reAttachDocument'), 'primaryButton': 'OK', 'fromTypeofevent': true });
    }
   } catch(e){
console.log("error",e);
   }
}
onEventReferChange(event){
this.attachmentReset();
}
  copyFromEklient(event) {
    // console.log("copydata", event.target.value);
    let clientId = null;
    clientId = this.userData.clientId;
    let param = {
      "clientId": clientId,
      "email": "",
      "phoneNumber": "",
      "role": "",
      "userId": ""
    }
    
    
    this.commonService[environment.copyInsureEklientListConfig.method](
      (environment.host + environment.copyInsureEklientListConfig.url),param).subscribe((data) => {
        let clientIdentifierDTOs: any = {};
        if (data.clientIdentifierDTOs.length > 0) {
          for (let i = 0; i < data.clientIdentifierDTOs.length; i++) {
            clientIdentifierDTOs[data.clientIdentifierDTOs[i].identifierType] = data.clientIdentifierDTOs[i].identifierValue;
          }
        }

       // let nameFieldReplaceVal = this.newClaimService.restrictedPatternValRemove(eClaimsConstants.patternTypes[this.insureReferRenderSecRules['nameField'].allowedDataType],data.firstName);
        //let surnameFieldReplaceVal = this.newClaimService.restrictedPatternValRemove(eClaimsConstants.patternTypes[this.insureReferRenderSecRules['surnameField'].allowedDataType],data.lastName);
        //this.insureForm.get('nameField').setValue(nameFieldReplaceVal);
        this.insureForm.get('nameField').setValue(data.firstName);
        this.insureForm.get('surnameField').setValue(data.lastName);
        //this.insureForm.get('surnameField').setValue(surnameFieldReplaceVal);
        //this.insureForm.get('nationalityField').setValue(data.countryCode);
        this.insureForm.get('cnpfield').setValue(clientIdentifierDTOs.PESEL);
        //this.insureForm.get('dobField').setValue(data.dobField);
        //this.insureForm.get('sexField').setValue(data.sexField);
        //this.insureForm.get('passportNumField').setValue(data.passportNumField);

        this.blurPseiField('');
      });

  }
  formSubmit() {
    // console.log("this.insureForm", this.insureForm);
    // console.log("this.insureForm", this.insureForm.valid);
    let formDetails = {
      formInfo: null,
      isFormValid: this.formValid()
    }

    return formDetails;
    /*if(this.insureForm.valid){
      return true;
    }*/
    //return false;
  }

  formValid() {
    // console.log("errorFormGroup", this.createFormService.errorFormGroup(this.insureForm));
    if (!this.inValidCnpNumber && this.insureForm.valid) {
      return true;
    }
    return false;
  }

}
