import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CorrespondAddressSecComponent } from './correspond-address-sec.component';
import { SharedModule} from 'src/app/shared/shared.module';
import {  FormGroup, FormControl, Validators, FormArray, AbstractControl } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PersonalRuleMock } from '../personal-details.component.spec';

export class CorrespondanceAddressRulesMock {
  corresspondanceMock = {"ruleFileName":"Eclaims_Personal_Details_CorrespondenceAddress.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","selectedClaim":"E160","copyDataFromEc":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"streetName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"houseNumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"flatNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"country":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"otherCountry":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"postalCode":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"town":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"50","fieldminlength":"0","allowedDataType":","},"postBox":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":","},"mobileNumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"9","fieldminlength":"0","allowedDataType":"numeric"},"isdCode":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"3","fieldminlength":"0","allowedDataType":"numeric-plus"},"email":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"preferredModeOfCommunication":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"county":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"zipCode":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric"},"city":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphanumeric-hypen-dot-space"},"block":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"15","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"entrance":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"appartment":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"sector":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"1","fieldminlength":"0","allowedDataType":"numeric"},"addressAcceptanceCheck":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"ksession":null}
}



describe('CorrespondAddressSecComponent', () => {
  let component: CorrespondAddressSecComponent;
  let fixture: ComponentFixture<CorrespondAddressSecComponent>;
  const fb: FormBuilder = new FormBuilder();
const secValidations: PersonalRuleMock = new PersonalRuleMock();
const corrresSecValidations: CorrespondanceAddressRulesMock = new CorrespondanceAddressRulesMock();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientTestingModule,BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ CorrespondAddressSecComponent ],
      providers: [ { provide: FormBuilder, useValue: fb } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }

    fixture = TestBed.createComponent(CorrespondAddressSecComponent);

    component = fixture.componentInstance;

    let corresAddressModel={    copyDataFromEc:'',
  streetName: '',
  houseNumber: '',
  flatNumber: '' ,
  country: '' ,
  otherCountry:'' ,
  postalCode: '' ,
  town: '' ,
  postBox:'' ,
  mobileNumber: '' ,
  isdCode: '' ,
  email: '' ,
  preferredModeOfCommunication: '' ,
  addressAcceptanceCheck: '' ,
  county: '' ,
  zipCode: '' ,
  city: '' ,
  block: '' ,
  entrance: '' ,
  appartment: '',
  sector: '' 
}
component.corresspondenceAddressForm =  fb.group(corresAddressModel);

component.corresspondenceAddressForm.controls.mobileNumber['restrict']={maxlength : '10'};

component.corresspondenceAddressForm.get('mobileNumber').setValidators([Validators.required]);
component.corresspondenceAddressForm.controls.postalCode['restrict']={maxlength : '10'};

component.corresspondenceAddressForm.get('postalCode').setValidators([Validators.required]);
component.personalSectionsRule=secValidations.mockValue;
component.correspondanceRenderSecRules = corrresSecValidations.corresspondanceMock;
fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});