import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable, forkJoin } from "rxjs";
import { HttpCommonService } from "../../../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray, AbstractControl } from '@angular/forms';
import { CreateFormService } from '../../../shared/services/create-form.service';
import { ErrorMessagesComponent } from '../../../shared/component/error-messages/error-messages.component';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { DataService } from 'src/app/shared/services/data.service';
import { environment } from 'src/environments/environment';
import * as utils from 'lodash';

@Component({
  selector: 'correspond-address-sec',
  templateUrl: './correspond-address-sec.component.html',
  styleUrls: ['./correspond-address-sec.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CorrespondAddressSecComponent implements OnInit {
  @Input() corresspondenceAddressForm: FormGroup;
  @Input() correspondanceRenderSecRules: any;
  @Input() personalSectionsRule: any;
  userData = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.userData.sourceOrigin;
  defaultLanguage: string = this.userData.defaultLanguage;
  peselEnableCountry = eClaimsConstants.peselEnableCountry;
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
  corresspondenceAddressEnableCountry = eClaimsConstants.corresspondenceAddressEnableCountry;
  showCountryLabel: boolean = false;
  showTownOptionLabel: boolean = false;
  showwEmailInValid: boolean = false;

  showCorrespondAddressInst: boolean = false;
  showCorrespondAddressInvd: boolean = false;
  showPersonalDetailCorrespondAddressInst: boolean = false;
  showPersonalDetailCorrespondAddressTrader: boolean = false;
  showPersonalDetailCorrespondAddressInvd: boolean = false;
  townOptions = [];
  countryCodes = {
    'RO': '+40',
    'PL': '+48'
  };
  patternTypes = eClaimsConstants.patternTypes;
  countryOptions = []
  townFromEC: string;
  clientAddressDTOs: any;

  constructor(public newClaimService: NewClaimSharedService, public dataService: DataService,
    private commonService: HttpCommonService, public createFormService: CreateFormService) { }

  public postalMasking = {
    guide: false,
    showMask: true,
    mask: [/\d/, /\d/, '-',
      /\d/, /\d/, /\d/]
  };
  mobilMaxLength;
  postalcodeMaxlenthinit;
  renderClaimSections: any;
  formInit() {
    this.corresspondenceAddressForm.get('copyDataFromEc').setValue(null);
    this.addressCopyFromEC = null;
    this.renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');
    this.corresspondenceAddressForm.reset();
    this.showTownOptionLabel = false;
    this.toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;

    this.countryOptions = this.newClaimService.getParamValue('countryList');

    if (this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1) {
      this.setDefaultMobileCode();
    } else {
      this.corresspondenceAddressForm.get('country').setValue(null);
    }
    this.mobilMaxLength = {
      length: this.corresspondenceAddressForm.controls.mobileNumber['restrict'].maxlength,
      required: (this.corresspondenceAddressForm && this.corresspondenceAddressForm.get('mobileNumber').validator({} as AbstractControl)) ? this.corresspondenceAddressForm.get('mobileNumber').validator({} as AbstractControl).required : ''
    }
    this.postalcodeMaxlenthinit = {
      length: this.corresspondenceAddressForm.controls.postalCode['restrict'].maxlength,
      required: this.corresspondenceAddressForm.get('postalCode').validator({} as AbstractControl).required
    };

    let claimData = this.newClaimService.getClaimData();
    let lob = (claimData ? claimData.newclaim : null);
    let primaryClaimType = this.newClaimService.getPrimaryClaimType();
    this.showCorrespondAddressInst = false;
    if (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1 && this.personalSectionsRule.resideneAddressSection.renderFlag) {
      this.showPersonalDetailCorrespondAddressInvd = true;
      this.showCorrespondAddressInst = false;
      this.showCorrespondAddressInvd = false;
    } else {
      this.showCorrespondAddressInvd = true;
      this.showPersonalDetailCorrespondAddressInst = false;
      this.showPersonalDetailCorrespondAddressTrader = false;
      this.showPersonalDetailCorrespondAddressInvd = false;
    }
    // if (this.personalSectionsRule.resideneAddressSection.renderFlag) {
    //   this.showPersonalDetailCorrespondAddressInvd = true;
    //   this.showCorrespondAddressInvd = false;
    // } else {
    //   this.showCorrespondAddressInvd = true;
    //   this.showPersonalDetailCorrespondAddressInvd = false;
    // }

    this.newClaimService.getCountryList().subscribe((data) => {
      //this.corresspondenceAddressForm.get('country').setValue(this.corresspondenceAddressForm.controls['country'].value);
      this.countryOptions = data;
      setTimeout(() => {
        this.corresspondenceAddressForm.controls['country'].patchValue(this.corresspondenceAddressForm.controls['country'].value);
      }, 0);



      // this.corresspondenceAddressForm.get('country').patchValue(this.corresspondenceAddressForm.get('country').value);

    });
    this.countryOnChange(this.corresspondenceAddressForm.get('country').value);
    this.corresspondenceAddressForm.controls['otherCountry'].disable();
    //this.corresspondenceAddressForm.controls['town'].disable();
    this.townFromEC = '';
  }

  ngOnInit() {
    this.formInit();
    this.corresspondenceAddressForm.controls['otherCountry'].disable();
  }

  getCorrespondanceAddress(event) {
    let claimData = this.newClaimService.getClaimData();
    let lob = (claimData ? claimData.newclaim : null);
    let primaryClaimType = this.newClaimService.getPrimaryClaimType();
    //primaryClaimType.indexOf('E160') != -1
    if (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1 && this.personalSectionsRule.resideneAddressSection.renderFlag) {
      this.showCorrespondAddressInst = false;
      this.showCorrespondAddressInvd = false;
      if (event == "institution") {
        this.showPersonalDetailCorrespondAddressInst = true;
        this.showPersonalDetailCorrespondAddressTrader = false;
        this.showPersonalDetailCorrespondAddressInvd = false;
      } else if (event == "trader") {
        this.showPersonalDetailCorrespondAddressTrader = true;
        this.showPersonalDetailCorrespondAddressInvd = false;
        this.showPersonalDetailCorrespondAddressInst = false;
      } else {
        this.showPersonalDetailCorrespondAddressInvd = true;
        this.showPersonalDetailCorrespondAddressTrader = false;
        this.showPersonalDetailCorrespondAddressInst = false;
      }
    } else {
      this.showPersonalDetailCorrespondAddressInst = false;
      this.showPersonalDetailCorrespondAddressTrader = false;
      this.showPersonalDetailCorrespondAddressInvd = false;
      // //console.log("event evnt",event)
      if (event == "institution") {
        this.showCorrespondAddressInst = true;
        this.showCorrespondAddressInvd = false;
      } else {
        this.showCorrespondAddressInst = false;
        this.showCorrespondAddressInvd = true;
      }
    }

  }

  countryOnChange(event) {
    this.corresspondenceAddressForm.get('postalCode').setValue('');
    this.corresspondenceAddressForm.get('postBox').setValue(null);
    this.corresspondenceAddressForm.get('town').setValue(null);
    this.showTownOptionLabel = false;
    this.townFromEC = '';

    this.showCountryLabel = false;
    this.corresspondenceAddressForm.controls.otherCountry.reset();
    if (event.toLowerCase() == 'other') {
      this.corresspondenceAddressForm.controls['otherCountry'].enable();

    } else {
      this.corresspondenceAddressForm.controls['otherCountry'].disable();
    }
    if ((this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1)
      && (event.toLowerCase() == this.defaultLanguage)) {
      this.corresspondenceAddressForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);
    } else if (event.toLowerCase() == 'other') {
      this.showCountryLabel = true;

    }
    let claimData = this.newClaimService.getClaimData();
    let lob = (claimData ? claimData.newclaim : null);
    //console.log("personal details", lob)

    if (this.correspondanceRenderSecRules.postBox.mandatoryFlag && event == 'US') {
      this.corresspondenceAddressForm.controls['postBox'].setValidators([Validators.required]);
      this.corresspondenceAddressForm.controls['postBox'].updateValueAndValidity();
      // //console.log(" this.corresspondenceAddressForm.controls['postBox'] 1", this.corresspondenceAddressForm.get('postBox').validator)
    } else {
      this.corresspondenceAddressForm.controls['postBox'].setValidators([Validators.nullValidator]);
      this.corresspondenceAddressForm.controls['postBox'].updateValueAndValidity();
      // //console.log(" this.corresspondenceAddressForm.controls['postBox']", this.corresspondenceAddressForm.get('postBox').validator)
    }

    this.corresspondenceAddressForm.controls.mobileNumber.reset();
    
this.setMobileNumberLength();

    let validators = this.postalcodeMaxlenthinit.required ? Validators.required : Validators.nullValidator;
    if (this.defaultLanguage.toUpperCase() == 'PL' && this.corresspondenceAddressForm.get('country').value == 'PL') {
      this.corresspondenceAddressForm.controls.postalCode['restrict'].maxlength = this.postalcodeMaxlenthinit.length;
      this.corresspondenceAddressForm.controls.postalCode.setValidators([validators]);
    } else {
      this.corresspondenceAddressForm.controls.postalCode['restrict'].maxlength = 10;
      this.corresspondenceAddressForm.controls.postalCode.setValidators([validators]);
    }
    this.setAddressFields(event);
  }

setMobileNumberLength(){
  let mobileValidators = this.mobilMaxLength.required ? Validators.required : Validators.nullValidator;
    if (this.corresspondenceAddressForm.get('country').value == 'PL' && this.defaultLanguage.toUpperCase() == 'PL') {
      this.corresspondenceAddressForm.controls.mobileNumber['restrict'].maxlength = this.mobilMaxLength.length;
      this.corresspondenceAddressForm.controls.mobileNumber.setValidators([mobileValidators, Validators.maxLength(this.mobilMaxLength.length)]);
      this.corresspondenceAddressForm.controls['mobileNumber'].updateValueAndValidity();
    } else if (this.corresspondenceAddressForm.get('country').value === 'RO' &&
     this.defaultLanguage.toUpperCase() == 'RO'
      ) {
      this.corresspondenceAddressForm.controls.mobileNumber['restrict'].maxlength = this.mobilMaxLength.length;
      this.corresspondenceAddressForm.controls.mobileNumber.setValidators([mobileValidators, Validators.maxLength(this.mobilMaxLength.length)]);
      this.corresspondenceAddressForm.controls['mobileNumber'].updateValueAndValidity();
    } else {
      this.corresspondenceAddressForm.controls.mobileNumber['restrict'].maxlength = 15;
      this.corresspondenceAddressForm.controls.mobileNumber.setValidators([mobileValidators, Validators.maxLength(15)]);
      this.corresspondenceAddressForm.controls['mobileNumber'].updateValueAndValidity();
    }

}

  blurPostalCodeField(event) {
    if (this.corresspondenceAddressForm.controls.postalCode.value !== (this.clientAddressDTOs && this.clientAddressDTOs.postalCode)) {
      if (this.corresspondenceAddressForm.controls.postalCode.value == '' &&
        this.corresspondenceAddressForm.controls.country.value == this.defaultLanguage.toUpperCase()
        && this.showTownOptionLabel) {
        this.corresspondenceAddressForm.get('town').setValue(null);
        this.townFromEC = '';
      }
      this.showTownOptionLabel = false;
      this.townFromEC = '';
      // //console.log("Postal Code",this.corresspondenceAddressForm.controls.postalCode.value)
      if (this.corresspondenceAddressForm.controls.postalCode.value != '' && (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1) && this.corresspondenceAddressForm.controls.country.value == this.defaultLanguage.toUpperCase()) {
        // //console.log("Postal Code",this.corresspondenceAddressForm.controls.postalCode.value)
        let value = this.corresspondenceAddressForm.controls.postalCode.value;
        let postalCodeValue = value;
        //let postalCodeValue=[value.slice(0, 2), '-', value.slice(2)].join('');
        // this.corresspondenceAddressForm.controls.postalCode.setValue('00-780')
        // this.corresspondenceAddressForm.controls['postalCode'].updateValueAndValidity();
        //  //console.log("this.corresspondenceAddressForm.controls.postalCode.value Postalcode",this.corresspondenceAddressForm.controls.postalCode.value)
        this.getPostalCodeValue(postalCodeValue,
          this.defaultLanguage.toUpperCase()).subscribe((data) => {
            // //console.log(data); 
            // //console.log(data); 
            // //console.log(data); 
            // //console.log(data); 
            // //console.log(data); 
            // //console.log(data); 
            // //console.log(data); 
            // //console.log(data); 
            // //console.log(data); 
            this.townOptions = data;
            //console.log(this.townOptions, "test", data[0])
            if (data.length > 0) {
              this.corresspondenceAddressForm.get('town').setValue(data[0]);
              this.showTownOptionLabel = true;
              this.townFromEC = '*';
            } else {
              this.corresspondenceAddressForm.get('town').setValue(null);
              this.showTownOptionLabel = false;
              this.townFromEC = '';
            }
          });
      }
    } else {
      this.showTownOptionLabel = false;
      this.townFromEC = '*';
    }
  }




  getPostalCodeValue(event, countryCode) {
    let param = {
      "countryCode": countryCode,
      "language": "",
      "pinCode": event
    }
        const url = `${environment.host + environment.getPostalCode.url}`;
        return this.commonService[environment.getPostalCode.method](
          url,param);
      }

  onPreferredModeOfCommunication(event) {
    //console.log("event", event)

    if (event == 'post') {
      const validatorMobile = this.corresspondenceAddressForm.get('mobileNumber').validator({} as AbstractControl);
      if (validatorMobile && validatorMobile.required) {
        this.corresspondenceAddressForm.controls['mobileNumber'].setValidators([Validators.nullValidator]);
        this.corresspondenceAddressForm.controls['mobileNumber'].updateValueAndValidity();
      }
      const validatorEmail = this.corresspondenceAddressForm.get('email').validator({} as AbstractControl);
      if (validatorEmail && validatorEmail.required) {
        this.corresspondenceAddressForm.controls['email'].setValidators([Validators.nullValidator]);
        this.corresspondenceAddressForm.controls['email'].updateValueAndValidity();
      }
    } else if (event == 'email') {

      this.corresspondenceAddressForm.controls['email'].setValidators([Validators.required]);
      this.corresspondenceAddressForm.controls['email'].updateValueAndValidity();
      const validator = this.corresspondenceAddressForm.get('mobileNumber').validator({} as AbstractControl);
      // //console.log("mobileNumber",validator)
      if (validator && validator.required) {
        this.corresspondenceAddressForm.controls['mobileNumber'].setValidators([Validators.nullValidator]);
        this.corresspondenceAddressForm.controls['mobileNumber'].updateValueAndValidity();
      }
    } else if (event == 'phone') {


      // //console.log("phone",this.corresspondenceAddressForm.get('email').validator['email'].has)
      this.corresspondenceAddressForm.controls['mobileNumber'].setValidators([Validators.required]);
      this.corresspondenceAddressForm.controls['mobileNumber'].updateValueAndValidity();
      const validator = this.corresspondenceAddressForm.get('email').validator({} as AbstractControl);
      // //console.log("email",validator)
      if (validator && validator.required) {
        this.corresspondenceAddressForm.controls['email'].setValidators([Validators.nullValidator]);
        this.corresspondenceAddressForm.controls['email'].updateValueAndValidity();
      }
    }

  }


  setDefaultMobileCode() {

    this.corresspondenceAddressForm.get('country').setValue(this.defaultLanguage.toUpperCase());

    this.corresspondenceAddressForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);

  }

  blurEmailField(event) {
    this.showwEmailInValid = false;
    //console.log("Email ID", this.corresspondenceAddressForm.controls.email.value)
    if (this.corresspondenceAddressForm.controls.email.value != '' && this.corresspondenceAddressForm.controls.email.value != null) {
      this.getEmailIdValue(this.corresspondenceAddressForm.controls.email.value).subscribe((data) => {
        //console.log("email", data)
        if (data == true) {
          this.showwEmailInValid = false;
          this.corresspondenceAddressForm.controls.email['invalidFlag'] = this.showwEmailInValid;
        } else {
          this.showwEmailInValid = true;
          this.corresspondenceAddressForm.controls.email['invalidFlag'] = this.showwEmailInValid;
        }

      });
    }
  }

  getEmailIdValue(emailID) {
    //console.log("emailID", emailID)
    let param = {
      "clientId": "",
      "email": emailID,
      "phoneNumber": "",
      "role": "",
      "userId": ""
    }
    const url = `${environment.host + environment.getEmailId.url}`;
    return this.commonService[environment.getBankName.method](url,param,{'loader':'true'});
  }


  formSubmit() {
    if (this.corresspondenceAddressForm.controls.isdCode.pristine || !this.corresspondenceAddressForm.controls.isdCode.value) {
      if ((this.corresspondenceAddressForm.value.country == 'PL' &&
        this.defaultLanguage == 'pl') || (this.corresspondenceAddressForm.value.country == 'RO' && this.defaultLanguage == 'ro')) {
        this.corresspondenceAddressForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);
      }
    }
    if (this.corresspondenceAddressForm.get('country').value == 'other') {
      this.corresspondenceAddressForm.controls['otherCountry'].enable();
      // //console.log(" this.corresspondenceAddressForm.controls['postBox'] 1", this.corresspondenceAddressForm.get('postBox').validator)
    } else {
      this.corresspondenceAddressForm.controls['otherCountry'].disable();
    };
    if (this.correspondanceRenderSecRules.postBox.mandatoryFlag && this.corresspondenceAddressForm.get('country').value == 'US') {
      this.corresspondenceAddressForm.controls['postBox'].setValidators([Validators.required]);
      this.corresspondenceAddressForm.controls['postBox'].updateValueAndValidity();
      // //console.log(" this.corresspondenceAddressForm.controls['postBox'] 1", this.corresspondenceAddressForm.get('postBox').validator)
    } else {
      this.corresspondenceAddressForm.controls['postBox'].setValidators([Validators.nullValidator]);
      this.corresspondenceAddressForm.controls['postBox'].updateValueAndValidity();
      // //console.log(" this.corresspondenceAddressForm.controls['postBox']", this.corresspondenceAddressForm.get('postBox').validator)
    }
    // console.log("this.corresspondenceAddressForm", this.corresspondenceAddressForm);
    // console.log("this.corresspondenceAddressForm", this.corresspondenceAddressForm.valid);
    let formDetails = {
      formInfo: null,
      isFormValid: this.formValid()
    }

    return formDetails;
    /*if(this.insureForm.valid){
      return true;
    }*/
    //return false;
  }
  addressCopyFromEC: any = null;
  copyFromEklient(event) {
    // console.log("copydata", event);
    let clientId = null;
    clientId = this.userData.clientId;
    let param = {
      "clientId": clientId,
      "email": "",
      "phoneNumber": "",
      "role": "",
      "userId": ""
    }
    this.commonService[environment.copyAddressEklientListConfig.method](
      (environment.host + environment.copyAddressEklientListConfig.url ),param).subscribe((data) => {

        this.clientAddressDTOs = data.clientAddressDTOs[0];
        this.showTownOptionLabel = false;
        /*this.corresspondenceAddressForm.get('city').setValue(clientAddressDTOs.city);*/
        this.corresspondenceAddressForm.get('streetName').setValue(this.clientAddressDTOs.streetName);
        this.corresspondenceAddressForm.get('houseNumber').setValue(this.clientAddressDTOs.houseNumber);
        this.corresspondenceAddressForm.get('flatNumber').setValue(this.clientAddressDTOs.flatNumber);
        //this.corresspondenceAddressForm.get('block').setValue(data.block);
        this.corresspondenceAddressForm.get('country').setValue(this.clientAddressDTOs.countryCode);
        this.corresspondenceAddressForm.get('postalCode').setValue(this.clientAddressDTOs.postalCode);
        this.corresspondenceAddressForm.get('town').setValue(this.clientAddressDTOs.city);
        this.corresspondenceAddressForm.get('postBox').setValue(this.clientAddressDTOs.postBox);
        this.townFromEC = '*';
        // this.corresspondenceAddressForm.get('town').setValue(data.town);
        // this.corresspondenceAddressForm.get('town').setValue(data.town);
        //this.blurPostalCodeField(''); <!--not required in callcenter flow-->

      });

  }

  formValid() {
    this.setAddressFields(this.corresspondenceAddressForm.get('country').value);
    // console.log("corresspondenceAddressForm errorFormGroup", this.createFormService.errorFormGroup(this.corresspondenceAddressForm));
    if (this.corresspondenceAddressForm.valid && !this.showwEmailInValid) {
      return true;
    }
    return false;
  }


  setAddressFields(event) {
    let countryValueRO = ['county', 'zipCode', 'city', 'block', 'entrance', 'appartment', 'sector'];
    let countryValueROField = ['flatNumber', 'postalCode', 'town', 'postBox'];
    if (this.defaultLanguage == 'ro') {
      if (event.toLowerCase() == this.defaultLanguage) {
        for (let j = 0; j < countryValueRO.length; j++) {
          if (this.correspondanceRenderSecRules[countryValueRO[j]] && this.correspondanceRenderSecRules[countryValueRO[j]].renderFlag && this.correspondanceRenderSecRules[countryValueRO[j]].mandatoryFlag) {
            this.corresspondenceAddressForm.controls[countryValueRO[j]].enable();
            // this.corresspondenceAddressForm.controls[countryValueRO[j]].setValidators(Validators.required);
          }
        }
        for (let j = 0; j < countryValueROField.length; j++) {
          if (this.correspondanceRenderSecRules[countryValueROField[j]] && this.correspondanceRenderSecRules[countryValueROField[j]].renderFlag && this.correspondanceRenderSecRules[countryValueROField[j]].mandatoryFlag) {
            this.corresspondenceAddressForm.controls[countryValueROField[j]].disable();
            // this.corresspondenceAddressForm.controls[countryValueROField[j]].reset();
          }
        }
      } else {
        for (let j = 0; j < countryValueRO.length; j++) {
          if (this.correspondanceRenderSecRules[countryValueRO[j]] && this.correspondanceRenderSecRules[countryValueRO[j]].renderFlag && this.correspondanceRenderSecRules[countryValueRO[j]].mandatoryFlag) {
            this.corresspondenceAddressForm.controls[countryValueRO[j]].disable();
            // this.corresspondenceAddressForm.controls[countryValueRO[j]].reset();
          }
        }
        for (let j = 0; j < countryValueROField.length; j++) {
          if (this.correspondanceRenderSecRules[countryValueROField[j]] && this.correspondanceRenderSecRules[countryValueROField[j]].renderFlag && this.correspondanceRenderSecRules[countryValueROField[j]].mandatoryFlag) {
            this.corresspondenceAddressForm.controls[countryValueROField[j]].enable();
            // this.corresspondenceAddressForm.controls[countryValueROField[j]].setValidators(Validators.required);
          }
        }
      }
    }
  }



}
