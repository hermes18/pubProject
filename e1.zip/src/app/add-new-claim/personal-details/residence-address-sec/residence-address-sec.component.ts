import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable, forkJoin } from "rxjs";
import { HttpCommonService } from "../../../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray, AbstractControl } from '@angular/forms';
import { CreateFormService } from '../../../shared/services/create-form.service';
import { ErrorMessagesComponent } from '../../../shared/component/error-messages/error-messages.component';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { DataService } from 'src/app/shared/services/data.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'residence-address-sec',
  templateUrl: './residence-address-sec.component.html',
  styleUrls: ['./residence-address-sec.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ResidenceAddressSecComponent implements OnInit {
  @Input() residenceAddressForm: FormGroup;
  @Input() personalFormControl: FormGroup;
  @Input() correspondanceRefComp: any;
  @Input() residenceRenderSecRules: any;

  userData = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.userData.sourceOrigin;
  defaultLanguage: string = this.userData.defaultLanguage;
  peselEnableCountry = eClaimsConstants.peselEnableCountry;
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
  showCountryLabel: boolean = false;
  showTownOptionLabel: boolean = false;

  townOptions = [];
  countryCodes = {
    'RO': '+40',
    'PL': '+48'
  };

  countryOptions = []
  showResidenceInstLabel: boolean = false;
  showResidenceInvdLabel: boolean = false;
  showResidenceTraderLabel: boolean = false;
  townFromPoCode: string;

  constructor(public newClaimService: NewClaimSharedService, public dataService: DataService,
    private commonService: HttpCommonService, public createFormService: CreateFormService) { }


  public postalMasking = {
    guide: false,
    showMask: true,
    mask: [/\d/, /\d/, '-',
      /\d/, /\d/, /\d/]
  };
  isTraderCopyLabelVisible: boolean = false;
  postalcodeMaxlenthinit;
  renderClaimSections: any;
  formInit() {
    this.residenceAddressForm.get('copyDataFromEc').setValue(null);
    this.addressCopyFromEC = null;
    this.renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');
    this.showTownOptionLabel = false;
    this.toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
    this.countryOptions = this.newClaimService.getParamValue('countryList');
    this.newClaimService.getCountryList().subscribe((data) => {
      this.countryOptions = data;
      setTimeout(() => {
        this.residenceAddressForm.get('country').setValue(this.residenceAddressForm.get('country').value);

      }, 0);
    });
    this.newClaimService.getTraderFlag().subscribe((data) => {
      this.isTraderCopyLabelVisible = data;
    });
    if (this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1) {
      this.setDefaultMobileCode();
    } else {
      this.residenceAddressForm.get('country').setValue(null);
    }
    this.postalcodeMaxlenthinit = {
      length: this.residenceAddressForm.controls.postalCode['restrict'].maxlength,
      required: (this.residenceAddressForm && this.residenceAddressForm.get('postalCode').validator({} as AbstractControl))
        ? this.residenceAddressForm.get('postalCode').validator({} as AbstractControl).required : ''
    }
    this.showResidenceInvdLabel = true;
    this.showResidenceInstLabel = false;
    this.showResidenceTraderLabel = false;
    this.countryOnChange(this.residenceAddressForm.get('country').value);
  }

  ngOnInit() {
    this.formInit();
  }
  addressCopyFromEC: any = null;
  copyFromEklient(event) {
    //  console.log("copydata", event);
    let clientId = null;
    clientId = this.userData.clientId;
    let param = {
      "clientId": clientId,
      "email": "",
      "phoneNumber": "",
      "role": "",
      "userId": ""
    }
    this.commonService[environment.copyAddressEklientListConfig.method](
      (environment.host + environment.copyAddressEklientListConfig.url ),param).subscribe((data) => {
        let clientAddressDTOs = data.clientAddressDTOs[0];

        this.residenceAddressForm.get('streetName').setValue(clientAddressDTOs.streetName);
        this.residenceAddressForm.get('houseNumber').setValue(clientAddressDTOs.houseNumber);
        this.residenceAddressForm.get('flatNumber').setValue(clientAddressDTOs.flatNumber);
        //this.residenceAddressForm.get('block').setValue(data.block);
        this.residenceAddressForm.get('country').setValue(clientAddressDTOs.countryCode);
        this.residenceAddressForm.get('postalCode').setValue(clientAddressDTOs.postalCode);
        //this.residenceAddressForm.get('town').setValue(data.town);
        //this.residenceAddressForm.get('postBox').setValue(clientAddressDTOs.postBox);
        // this.corresspondenceAddressForm.get('town').setValue(data.town);
        // this.corresspondenceAddressForm.get('town').setValue(data.town);
        /*  if(this.residenceAddressForm.get('city')){
            this.residenceAddressForm.get('city').setValue(clientAddressDTOs.city);
          }*/
        this.blurPostalCodeField('');
      });

  }
  getResidenceAddress(event) {
    if (event == "institution") {
      this.showResidenceInstLabel = true
      this.showResidenceInvdLabel = false
      this.showResidenceTraderLabel = false
    } else if (event == "trader") {
      this.showResidenceTraderLabel = true
      this.showResidenceInstLabel = false
      this.showResidenceInvdLabel = false
    } else {
      this.showResidenceInvdLabel = true
      this.showResidenceInstLabel = false
      this.showResidenceTraderLabel = false
    }
  }

  countryOnChange(event) {
    this.residenceAddressForm.get('postalCode').setValue('');
    this.residenceAddressForm.get('town').setValue(null);
    this.showTownOptionLabel = false;
    this.townFromPoCode = '';

    this.showCountryLabel = false;
    // if ((this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1)
    //   && (event.toLowerCase() == this.defaultLanguage)) {
    //   // this.residenceAddressForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);
    // } else
    if (event.toLowerCase() == 'other') {
      this.showCountryLabel = true;
      this.residenceAddressForm.controls.otherCountry.reset();

      this.residenceAddressForm.controls['otherCountry'].setValidators([Validators.required]);
      this.residenceAddressForm.controls['otherCountry'].updateValueAndValidity();
    } else {
      this.residenceAddressForm.controls['otherCountry'].setValidators([Validators.nullValidator]);
      this.residenceAddressForm.controls['otherCountry'].updateValueAndValidity();

    }

    let validators = this.postalcodeMaxlenthinit.required ? Validators.required : Validators.nullValidator;
    if (this.defaultLanguage.toUpperCase() == 'PL' && this.residenceAddressForm.get('country').value == 'PL') {
      this.residenceAddressForm.controls.postalCode['restrict'].maxlength = this.postalcodeMaxlenthinit.length;
      this.residenceAddressForm.controls.postalCode.setValidators([validators]);
    } else {
      this.residenceAddressForm.controls.postalCode['restrict'].maxlength = 10;
      this.residenceAddressForm.controls.postalCode.setValidators([validators]);
    }



  }

  blurPostalCodeField(event, setVal?: any) {
    if (this.residenceAddressForm.controls.postalCode.value == '' &&
      this.residenceAddressForm.controls.country.value == this.defaultLanguage.toUpperCase()
      && this.showTownOptionLabel) {
      this.residenceAddressForm.get('town').setValue(null);
      this.townFromPoCode = '';
    }
    this.showTownOptionLabel = false;
    //console.log("Postal Code",this.residenceAddressForm.controls.postalCode.value)
    if (this.residenceAddressForm.controls.postalCode.value != '' && (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1) && this.residenceAddressForm.controls.country.value == this.defaultLanguage.toUpperCase()) {
      //console.log("Postal Code")
      let value = this.residenceAddressForm.controls.postalCode.value;
      let postalCode = value;
      // let postalCode=[value.slice(0, 2), '-', value.slice(2)].join('');

      this.getPostalCodeValue(postalCode,
        this.defaultLanguage.toUpperCase()).subscribe((data) => {
          // //console.log(data); 
          this.townOptions = data;
          // //console.log(this.townOptions)

          if (data.length > 0) {
            this.showTownOptionLabel = true;
            this.townFromPoCode = '*';
            if (setVal) {
              this.residenceAddressForm.get('town').setValue(setVal);
            } else {
              this.residenceAddressForm.get('town').setValue(data[0]);
            }


          } else {
            this.showTownOptionLabel = false;
            this.townFromPoCode = '';
            this.residenceAddressForm.get('town').setValue(null);

          }
        });
    }
  }

  getPostalCodeValue(event, countryCode) {
    let param = {
      "countryCode": countryCode,
      "language": "",
      "pinCode": event
    }
        const url = `${environment.host + environment.getPostalCode.url}`;
        return this.commonService[environment.getPostalCode.method](
          url,param);
      }

  setDefaultMobileCode() {

    this.residenceAddressForm.get('country').setValue(this.defaultLanguage.toUpperCase());

    // this.residenceAddressForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);

  }

  copyAddressFromCorresspondSec() {
    this.countryOnChange(this.personalFormControl.value.correspondenceAddressSection.country)
    this.residenceAddressForm.get('streetName').setValue(this.personalFormControl.value.correspondenceAddressSection.streetName);
    this.residenceAddressForm.get('houseNumber').setValue(this.personalFormControl.value.correspondenceAddressSection.houseNumber);
    this.residenceAddressForm.get('flatNumber').setValue(this.personalFormControl.value.correspondenceAddressSection.flatNumber);
    this.residenceAddressForm.get('country').setValue(this.personalFormControl.value.correspondenceAddressSection.country);
    this.residenceAddressForm.get('otherCountry').setValue(this.personalFormControl.value.correspondenceAddressSection.otherCountry);
    // setTimeout(() => {
    // this.blurPostalCodeField(this.personalFormControl.value.correspondenceAddressSection.postalCode);
    // }, 0)

    setTimeout(() => {
      this.residenceAddressForm.get('postalCode').setValue(this.personalFormControl.value.correspondenceAddressSection.postalCode);
      this.residenceAddressForm.get('town').setValue(this.personalFormControl.value.correspondenceAddressSection.town);
      this.showTownOptionLabel = this.correspondanceRefComp.showTownOptionLabel
      if (this.showTownOptionLabel) {
        this.blurPostalCodeField(this.personalFormControl.value.correspondenceAddressSection.postalCode,
          this.personalFormControl.value.correspondenceAddressSection.town);
      }
    }, 0)

    //    this.residenceAddressForm.get('postbox').setValue(this.personalFormControl.value.correspondenceAddressSection.postBox);

  }
  formSubmit() {
    if (this.residenceAddressForm.get('country').value.toLowerCase() == 'other' || this.residenceAddressForm.get('country').value == '') {
      // this.showCountryLabel = true;
      // this.residenceAddressForm.controls.otherCountry.reset();

      this.residenceAddressForm.controls['otherCountry'].setValidators([Validators.required]);
      this.residenceAddressForm.controls['otherCountry'].updateValueAndValidity();
    } else {
      this.residenceAddressForm.controls['otherCountry'].setValidators([Validators.nullValidator]);
      this.residenceAddressForm.controls['otherCountry'].updateValueAndValidity();

    }
    // console.log("this.residenceAddressForm", this.residenceAddressForm);
    // console.log("this.residenceAddressForm", this.residenceAddressForm.valid);
    let formDetails = {
      formInfo: null,
      isFormValid: this.formValid()
    }

    return formDetails;
    /*if(this.insureForm.valid){
      return true;
    }*/
    //return false;
  }

  formValid() {
    // console.log("residenceAddressForm errorFormGroup", this.createFormService.errorFormGroup(this.residenceAddressForm));

    if (this.residenceAddressForm.valid) {
      return true;
    }
    return false;
  }
}