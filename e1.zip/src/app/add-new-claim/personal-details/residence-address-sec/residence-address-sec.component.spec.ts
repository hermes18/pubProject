import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ResidenceAddressSecComponent } from './residence-address-sec.component';
import {SharedModule} from 'src/app/shared/shared.module';
import {  FormGroup, FormControl, Validators, FormArray, AbstractControl,FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PersonalRuleMock } from '../personal-details.component.spec';

export class ResidentialAddressRulesMock {
  residenceMock = {"ruleFileName":"Eclaims_Personal_Details_ResidenceAddress.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","selectedClaim":"E160","copyDataFromEc":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"streetName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"houseNumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"flatNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"country":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"otherCountry":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"postalCode":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"town":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"50","fieldminlength":"0","allowedDataType":","},"postBox":null,"ksession":null};
}


describe('ResidenceAddressSecComponent', () => {
  let component: ResidenceAddressSecComponent;
  let fixture: ComponentFixture<ResidenceAddressSecComponent>;
  const fb: FormBuilder = new FormBuilder();
  const secValidations: PersonalRuleMock = new PersonalRuleMock();
  const residentSecValidations: ResidentialAddressRulesMock = new ResidentialAddressRulesMock();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientTestingModule,BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ ResidenceAddressSecComponent ],
      providers: [ { provide: FormBuilder, useValue: fb } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    if(!(sessionStorage.getItem('userData'))){
      let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(ResidenceAddressSecComponent);
    component = fixture.componentInstance;
    

let residentAddressModel = {
  streetName:  null,
  houseNumber: null,
  flatNumber:  null,
  country:  null,
  otherCountry: null,
  postalCode:  null,
  town: null,
  postBox:null,
  copyDataFromEc: null
}
    component.residenceAddressForm =  fb.group(residentAddressModel);
    component.residenceAddressForm.controls.postalCode['restrict']={maxlength : '10'};

component.residenceAddressForm.get('postalCode').setValidators([Validators.required]);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
