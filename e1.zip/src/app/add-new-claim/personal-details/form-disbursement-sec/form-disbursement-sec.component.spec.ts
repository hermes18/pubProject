import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormDisbursementSecComponent } from './form-disbursement-sec.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SectionReqConfigService } from '../../personal-details/personal-details.model';
import {  FormGroup, FormControl, Validators, FormArray, AbstractControl,FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NewClaimSharedService } from '../../add-new-claim.service';

export class DisbursementRulesMock {
  disbursementDetailsMock = {"ruleFileName":"Eclaims_Personal_Details_FormofDisbursement.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","selectedClaim":"E160","interestedinreinvestment":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"policynumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"15","fieldminlength":"0","allowedDataType":"numeric"},"percentage":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"amount":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"8","fieldminlength":"0","allowedDataType":"numeric"},"currency":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"viabanktransfer":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"viapost":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"countryofbank":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"bankaccountnumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"35","fieldminlength":"0","allowedDataType":"numeric-space"},"codeswift":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":","},"bankname":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"50","fieldminlength":"0","allowedDataType":","},"bankaddress":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"copydatafrominfo":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"businessunit":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"100","fieldminlength":"0","allowedDataType":"$5"},"name":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"surname":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-every"},"copyfromcommn":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"copyfromlegal":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"streetname":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"streetnumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"flatnumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"country":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"postalcode":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"town":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"50","fieldminlength":"0","allowedDataType":","},"postbox":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":","},"otherNationalityField":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"postal_otherNationalityField":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"post_copydatafrominfo":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"post_businessunit":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"100","fieldminlength":"0","allowedDataType":"$5"},"post_name":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"post_surname":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-every"},"post_copyfromcommn":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"post_copyfromlegal":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"post_streetname":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"post_streetnumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"post_flatnumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"post_country":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"post_postalcode":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"post_town":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"50","fieldminlength":"0","allowedDataType":","},"post_postbox":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":","},"banknamefinancialinst":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":"alphanumeric-hyphen-space-underscore"},"county":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"zipCode":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric"},"city":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphanumeric-hypen-dot-space"},"block":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"15","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"entrance":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"appartment":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"sector":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"1","fieldminlength":"0","allowedDataType":"numeric"},"disbursementDisclaimerChkbox":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"viafinancialinst":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"ksession":null};
}



describe('FormDisbursementSecComponent', () => {
  let component: FormDisbursementSecComponent;
  let fixture: ComponentFixture<FormDisbursementSecComponent>;
  const fb: FormBuilder = new FormBuilder();
  //const secValidations: PersonalRuleMock = new PersonalRuleMock();
  const disburdementSecValidations: DisbursementRulesMock = new DisbursementRulesMock();
  const newClaimService: NewClaimSharedService = new NewClaimSharedService();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientTestingModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ FormDisbursementSecComponent ],
      providers : [ SectionReqConfigService,
        { provide : HttpClient },{ provide: FormBuilder, useValue: fb } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }

    fixture = TestBed.createComponent(FormDisbursementSecComponent);
    component = fixture.componentInstance;
   
    let disbursementDetails = {
     interestedinreinvestment:null,
      policynumber: null,
      percentage: null,
      amount:  null,
      currency:  null,
      viabanktransfer:  null,
      viapost: null,
      countryofbank: null,
      bankaccountnumber:  null,
      codeswift:  null,
      bankname:  null,
      bankaddress: null,
      copydatafrominfo: null,
      businessunit: null,
      name:  null,
      surname:  null,
      copyfromcommn:  null,
      copyfromlegal:  null,
      streetname:  null,
      streetnumber: null,
      flatnumber: null,
      country:  null,
      postalcode: null,
      town: null,
      postbox: null,
      otherNationalityField:  null,
      postal_otherNationalityField:  null,
      post_copydatafrominfo:  null,
      post_businessunit:  null,
      post_name:  null,
      post_surname: null,
      post_copyfromcommn: null,
      post_copyfromlegal: null,
      post_streetname:  null,
      post_streetnumber:  null,
      post_flatnumber:  null,
      post_country: null,
      post_postalcode:  null,
      post_town: null,
      post_postbox: null,
      banknamefinancialinst:  null,
      county:  null,
      zipCode: null,
      city:  null,
      block:  null,
      entrance:  null,
      appartment:null,
      sector:  null,
      disbursementDisclaimerChkbox: null,
      viafinancialinst: null
  }
    
    component.disbursementForm =  fb.group(disbursementDetails);
    component.disbursementForm.controls.postalcode['restrict']={maxlength : '10'};

    component.disbursementForm.get('postalcode').setValidators([Validators.required]);
    component.disbursementForm.controls.post_postalcode['restrict']={maxlength : '10'};
    
    component.disbursementForm.get('post_postalcode').setValidators([Validators.required]);
    component.disbursementForm.controls.bankaccountnumber['restrict']={maxlength : '10'};
   
    component.disbursementRenderSecRules =disburdementSecValidations.disbursementDetailsMock;
    
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
