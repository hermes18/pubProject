import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable, forkJoin } from "rxjs";
import { HttpCommonService } from "../../../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray, AbstractControl } from '@angular/forms';
import { CreateFormService } from '../../../shared/services/create-form.service';
import { ErrorMessagesComponent } from '../../../shared/component/error-messages/error-messages.component';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { DataService } from 'src/app/shared/services/data.service';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'form-disbursement-sec',
  templateUrl: './form-disbursement-sec.component.html',
  styleUrls: ['./form-disbursement-sec.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FormDisbursementSecComponent implements OnInit {
  @Input() disbursementForm: FormGroup;
  @Input() personalFormControl: FormGroup;
  @Input() correspondanceRefComp: any;
  @Input() residenceRefComp: any;
  userData = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.userData.sourceOrigin;
  defaultLanguage: string = this.userData.defaultLanguage;
  peselEnableCountry = eClaimsConstants.peselEnableCountry;
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
  corresspondenceAddressEnableCountry = eClaimsConstants.corresspondenceAddressEnableCountry;
  showCountryLabel: boolean = false;
  showcountryOfBankLabel: boolean = false;
  countryOptions = [];
  townOptions = [];
  postTownOptions = [];
  showTranferBusinessUnit: boolean = false;
  showTranferNameSurname: boolean = false;
  showpostcopyfromlegaltrader: boolean = false;
  showResidenceAddressCopy: boolean = false;
  showTownOptionLabel: boolean = false;
  showPostTownOptionLabel: boolean = false;
  showwbankaccountnumberInValid: boolean = false;
  patternTypes = eClaimsConstants.patternTypes;
  isTraderCopyLabelVisible: boolean = false;
  @Input() resideneAddressRenderFlagValue: string
  @Input() disbursementRenderSecRules: any;
  postalcodeMaxlenthinit;
  post_postalcodeMaxlenthinit;
  banAccountNumberMaxLength;
  bankNameGenerated: string;
  townFromRePoCode: string;
  townFromPoCode: string;
  constructor(public newClaimService: NewClaimSharedService, public dataService: DataService,
    private commonService: HttpCommonService, public createFormService: CreateFormService) { }
  formInit() {
    this.oldBankAccVal = null;
    this.disbursementForm.reset();
    this.benefitChecboxError = false;
    this.inValidCountry = false; //
    this.toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
    this.countryOptions = this.newClaimService.getParamValue('countryList');
    this.newClaimService.getCountryList().subscribe((data) => {
      this.countryOptions = data;
      setTimeout(() => {
        this.disbursementForm.get('post_country').setValue(this.disbursementForm.get('post_country').value);
        this.disbursementForm.get('country').setValue(this.disbursementForm.get('country').value);
        this.disbursementForm.get('countryofbank').setValue(this.disbursementForm.get('countryofbank').value);
      }, 0);
    });
    this.showTranferBusinessUnit = false;
    this.showwbankaccountnumberInValid = false;
    this.disbursementForm.controls.bankaccountnumber['invalidFlag'] = this.showwbankaccountnumberInValid;
    this.showTownOptionLabel = false;
    this.showPostTownOptionLabel = false;

    this.newClaimService.getTraderFlag().subscribe((data) => {
      this.isTraderCopyLabelVisible = data;
    });
    if (this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1) {
      this.setDefaultMobileCode();
    } else {
      this.disbursementForm.get('country').setValue(null);
      this.disbursementForm.get('post_country').setValue(null);
      this.disbursementForm.get('countryofbank').setValue(null);
    }
    if (this.defaultLanguage.toUpperCase() === 'RO') {
      this.disbursementForm.get('country').setValue('');
    }
    this.postalcodeMaxlenthinit = {
      length: this.disbursementForm.controls.postalcode['restrict'].maxlength,
      // required: this.disbursementForm.get('postalcode').validator({} as AbstractControl).required
      required: this.disbursementRenderSecRules.postalcode.mandatoryFlag
    };
    this.post_postalcodeMaxlenthinit = {
      length: this.disbursementForm.controls.post_postalcode['restrict'].maxlength,
      required: this.disbursementForm.get('post_postalcode').validator({} as AbstractControl).required
    };
    this.banAccountNumberMaxLength = this.disbursementForm.controls.bankaccountnumber['restrict'].maxlength;

    this.showTranferNameSurname = true
    this.showResidenceAddressCopy = false
    this.getAfterViewInit(this.resideneAddressRenderFlagValue);
    this.disbursementForm.controls.viapost.enable();
    this.disbursementForm.controls.viabanktransfer.enable();
    this.bankTransferValue('');
    this.postValue('');
    this.onChangeReinvestment('');
    this.viafinancialChange('');
    this.countryOnChangePost(this.disbursementForm.get('post_country').value);
    // this.getformdisbursement('');
    this.countryOnChangeTransfer(this.disbursementForm.get('country').value);
    this.countryOfBankOnChange(this.disbursementForm.get('countryofbank').value);
    this.bankNameGenerated = '';

  }
  ngOnInit() {
    if (this.defaultLanguage.toUpperCase() === 'RO') {
      this.bankAccControlType = 'password';
    } else {
      this.bankAccControlType = 'text';
    }
    this.formInit();
  }



  getAfterViewInit(event) {
    if (event == true) {
      this.showResidenceAddressCopy = true
    }
  }
  bankTransferFields: any = ['countryofbank', 'bankaccountnumber', 'codeswift', 'bankname'
    , 'bankaddress', 'name', 'surname', 'businessunit', 'county', 'zipCode', 'city', 'streetname',
    'streetnumber', 'flatnumber', 'block', 'entrance', 'appartment', 'sector', 'country',
    'otherNationalityField', 'postalcode', 'town', 'postbox', 'disbursementDisclaimerChkbox'];

  bankTransferValue(event) {
    // this.disablePostCheckbox = true;
    //console.log("bankTransferValue 1", event.target.checked);
    this.showcountryOfBankLabel = false;
    this.benefitChecboxError = false;
    this.disbursementForm.get('countryofbank').setValue(this.defaultLanguage);
    if (this.disbursementForm.get('viabanktransfer').value == true) {
      this.disbursementForm.controls.viapost.disable();
      this.setRequiredFields(this.disbursementForm.controls, this.viapostFields, 'disable');
    } else {
      this.disbursementForm.controls.viapost.enable();
    }
    if (this.disbursementForm.get('viabanktransfer').value == true) {
      this.setRequiredFields(this.disbursementForm.controls, this.bankTransferFields, 'enable');
      this.getformdisbursement(this.newClaimService.getParamValue('benefitiaryGrp'))

      this.countryOnChangeTransfer(this.disbursementForm.get('country').value);
      this.countryOfBankOnChange(this.disbursementForm.get('countryofbank').value);


    } else {
      this.setRequiredFields(this.disbursementForm.controls, this.bankTransferFields, 'disable');
    }

    // this.getformdisbursement('');

  }


  viapostFields: any = ['post_name', 'post_surname',
    'post_businessunit', 'post_streetname', 'post_streetnumber',
    'post_flatnumber', 'post_country', 'postal_otherNationalityField',
    'post_town', 'post_postbox', 'post_postalcode'];

  postValue(event) {
    // this.disablePostCheckbox = true;
    this.benefitChecboxError = false;
    this.disbursementForm.get('countryofbank').setValue(this.defaultLanguage);
    //console.log("postValue 1", event.target.checked)
    if (this.disbursementForm.get('viapost').value == true) {
      this.disbursementForm.controls.viabanktransfer.disable();
      this.setRequiredFields(this.disbursementForm.controls, this.bankTransferFields, 'disable');
    } else {
      this.disbursementForm.controls.viabanktransfer.enable();
    }
    if (this.disbursementForm.get('viapost').value == true) {
      this.setRequiredFields(this.disbursementForm.controls, this.viapostFields, 'enable');
    } else {
      this.setRequiredFields(this.disbursementForm.controls, this.viapostFields, 'disable');
    }
    this.getformdisbursement(this.newClaimService.getParamValue('benefitiaryGrp'));
    this.countryOnChangePost(this.disbursementForm.get('post_country').value);

  }
  viafinancialFields: any = ['banknamefinancialinst'];

  viafinancialChange(event) {
    this.benefitChecboxError = false;
    if (this.disbursementForm.get('viafinancialinst').value == true) {
      this.setRequiredFields(this.disbursementForm.controls, this.viafinancialFields, 'enable');
    } else {
      this.setRequiredFields(this.disbursementForm.controls, this.viafinancialFields, 'disable');
    }
  }

  countryOnChangeTransfer(event) {
    this.disbursementForm.get('postalcode').setValue('');
    this.disbursementForm.get('postbox').setValue('');
    if (this.disbursementRenderSecRules.postbox.mandatoryFlag
      && (this.disbursementForm.get('country').value == "US")) {
      // this.disbursementForm.get('postbox').enable();
      this.disbursementForm.controls['postbox'].setValidators([Validators.required]);
      this.disbursementForm.controls['postbox'].updateValueAndValidity();
    } else {
      // this.disbursementForm.get('postbox').disable();
      this.disbursementForm.controls['postbox'].setValidators([Validators.nullValidator]);
      this.disbursementForm.controls['postbox'].updateValueAndValidity();
    }
    this.disbursementForm.get('town').setValue(null);
    this.showTownOptionLabel = false;
    this.townFromPoCode = '';
    this.townFromRePoCode = '';
    this.showCountryLabel = false;
    this.disbursementForm.controls.otherNationalityField.disable();
    if ((this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1)
      && (event.toLowerCase() == this.defaultLanguage)) {
      // this.disbursementForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);
    } else if (event.toLowerCase() == 'other') {
      this.showCountryLabel = true;
      this.disbursementForm.controls.otherNationalityField.reset();
      this.disbursementForm.controls.otherNationalityField.enable();
    }

    let validators = this.postalcodeMaxlenthinit.required ? Validators.required : Validators.nullValidator;
    if (this.defaultLanguage.toUpperCase() == 'PL' && this.disbursementForm.get('country').value == 'PL') {
      this.disbursementForm.controls.postalcode['restrict'].maxlength = this.postalcodeMaxlenthinit.length;
      this.disbursementForm.controls.postalcode.setValidators([validators]);
    } else {
      this.disbursementForm.controls.postalcode['restrict'].maxlength = 10;
      this.disbursementForm.controls.postalcode.setValidators([validators]);
    }
    this.enableAddressFieldForRO(event);
    // let countryValueRO = ['county', 'zipCode', 'city', 'block', 'entrance', 'appartment', 'sector'];
    // let countryValueROField = ['flatnumber', 'postalcode', 'town', 'postbox'];
    // if (this.defaultLanguage == 'ro') {
    //   if (event.toLowerCase() == this.defaultLanguage) {
    //     for (let j = 0; j < countryValueRO.length; j++) {
    //       if (this.disbursementRenderSecRules[countryValueRO[j]] && this.disbursementRenderSecRules[countryValueRO[j]].renderFlag && this.disbursementRenderSecRules[countryValueRO[j]].mandatoryFlag) {
    //         this.disbursementForm.controls[countryValueRO[j]].enable();
    //       }
    //     }
    //     for (let j = 0; j < countryValueROField.length; j++) {
    //       if (this.disbursementRenderSecRules[countryValueROField[j]] && this.disbursementRenderSecRules[countryValueROField[j]].renderFlag && this.disbursementRenderSecRules[countryValueROField[j]].mandatoryFlag) {
    //         this.disbursementForm.controls[countryValueROField[j]].disable();
    //       }
    //     }
    //   } else {
    //     for (let j = 0; j < countryValueRO.length; j++) {
    //       if (this.disbursementRenderSecRules[countryValueRO[j]] && this.disbursementRenderSecRules[countryValueRO[j]].renderFlag && this.disbursementRenderSecRules[countryValueRO[j]].mandatoryFlag) {
    //         this.disbursementForm.controls[countryValueRO[j]].disable();
    //       }
    //     }
    //     for (let j = 0; j < countryValueROField.length; j++) {
    //       if (this.disbursementRenderSecRules[countryValueROField[j]] && this.disbursementRenderSecRules[countryValueROField[j]].renderFlag && this.disbursementRenderSecRules[countryValueROField[j]].mandatoryFlag) {
    //         this.disbursementForm.controls[countryValueROField[j]].enable();
    //       }
    //     }
    //   }
    // }
  }

  blurPostalCodeField(event, setVal?: any) {
    if (this.disbursementForm.controls.postalcode.value == '' &&
      this.disbursementForm.controls.country.value == this.defaultLanguage.toUpperCase()
      && this.showTownOptionLabel) {
      this.disbursementForm.get('town').setValue(null);
      this.townFromPoCode = '';
    }
    this.showTownOptionLabel = false;
    //console.log("Postal Code")
    if (this.disbursementForm.controls.postalcode.value != '' && (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1) && this.disbursementForm.controls.country.value == this.defaultLanguage.toUpperCase()) {
      //console.log("Postal Code")
      let value = this.disbursementForm.controls.postalcode.value;
      let postalCode = value;
      //  let postalCode=[value.slice(0, 2), '-', value.slice(2)].join('');
      this.getPostalCodeValue(postalCode,
        this.defaultLanguage.toUpperCase()).subscribe((data) => {
          // //console.log(data); 
          this.townOptions = data;
          // //console.log(this.townOptions)
          if (data.length > 0) {

            this.showTownOptionLabel = true;
            this.townFromPoCode = '*';
            if (setVal) {
              this.disbursementForm.get('town').setValue(setVal);
            } else {
              this.disbursementForm.get('town').setValue(data[0]);
            }
          } else {
            this.disbursementForm.get('town').setValue(null);
            this.showTownOptionLabel = false;
            this.townFromPoCode = '';
          }
        });
    }
  }

  getPostalCodeValue(event, countryCode) {
    let param = {
      "countryCode": countryCode,
      "language": "",
      "pinCode": event
    }
    const url = `${environment.host + environment.getPostalCode.url}`;
    return this.commonService[environment.getPostalCode.method](
      url, param);
  }


  setDefaultMobileCode() {

    this.disbursementForm.get('post_country').setValue(this.defaultLanguage.toUpperCase());
    this.disbursementForm.get('country').setValue(this.defaultLanguage.toUpperCase());
    this.disbursementForm.get('countryofbank').setValue(this.defaultLanguage);
    this.disbursementForm.get('currency').setValue('RON');
    // this.corresspondenceAddressForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);

  }
  onPasteBankAcc() {
    if (this.defaultLanguage.toUpperCase() != 'RO') {
      return false;
    }
  }
  countryOfBankOnChange(event) {
    // //console.log("countryOfBankOnChange",event)
    this.disbursementForm.get('bankaccountnumber').reset();
    this.disbursementForm.get('codeswift').reset();
    this.disbursementForm.get('bankname').reset();
    this.disbursementForm.get('bankaddress').reset();
    this.showcountryOfBankLabel = false;
    this.showwbankaccountnumberInValid = false;
    this.bankNameGenerated = '';
    if (this.disbursementForm.get('countryofbank').value == 'other' ||
      this.disbursementForm.get('countryofbank').value == 'eu') {
      this.showcountryOfBankLabel = true;
      this.setRequiredFields(this.disbursementForm.controls, ['codeswift', 'bankaddress'], 'enable');
    } else {
      this.setRequiredFields(this.disbursementForm.controls, ['codeswift', 'bankaddress'], 'disable');
    }
    this.setBankAccLength();
  }

  setBankAccLength() {
    if (this.disbursementForm.get('countryofbank').value === 'pl') {
      this.disbursementForm.controls.bankaccountnumber['restrict'].maxlength = this.banAccountNumberMaxLength;
      this.disbursementForm.controls.bankaccountnumber.setValidators([Validators.required, Validators.maxLength(this.banAccountNumberMaxLength)]);
    }
    if (this.defaultLanguage.toUpperCase() == 'RO') {
      let validatorsAccNum = [];
      if (this.disbursementRenderSecRules.bankaccountnumber.mandatoryFlag) {
        validatorsAccNum.push(Validators.required)
      }

      if (this.disbursementForm.get('countryofbank').value === 'other') {
        validatorsAccNum.push(Validators.maxLength(30));
      } else if (this.disbursementForm.get('countryofbank').value === 'ro') {
        validatorsAccNum.push(Validators.maxLength(24));
      }
      this.disbursementForm.controls['bankaccountnumber'].setValidators(validatorsAccNum);
      this.disbursementForm.controls['bankaccountnumber'].updateValueAndValidity();
    }


  }

  countryOnChangePost(event) {
    this.disbursementForm.get('post_postalcode').setValue('');
    this.disbursementForm.get('post_town').setValue(null);
    this.disbursementForm.get('post_postbox').setValue(null);

    if (this.disbursementRenderSecRules.post_postbox.mandatoryFlag
      && (this.disbursementForm.get('post_country').value == "US")) {
      // this.disbursementForm.get('post_postbox').enable();
      this.disbursementForm.controls['post_postbox'].setValidators([Validators.required]);
      this.disbursementForm.controls['post_postbox'].updateValueAndValidity();
    } else {
      // this.disbursementForm.get('post_postbox').disable();
      this.disbursementForm.controls['post_postbox'].setValidators([Validators.nullValidator]);
      this.disbursementForm.controls['post_postbox'].updateValueAndValidity();
    }
    this.showPostTownOptionLabel = false;
    this.townFromRePoCode = '';

    this.showCountryLabel = false;
    if ((this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1)
      && (event.toLowerCase() == this.defaultLanguage)) {
      // this.disbursementForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);
    } else if (event.toLowerCase() == 'other') {
      this.showCountryLabel = true;
      this.disbursementForm.controls.postal_otherNationalityField.reset();

    }

    if (event.toLowerCase() == 'other') {
      this.disbursementForm.controls.postal_otherNationalityField.enable();
    } else {
      this.disbursementForm.controls.postal_otherNationalityField.disable();
    }

    let validators = this.postalcodeMaxlenthinit.required ? Validators.required : Validators.nullValidator;
    if (this.defaultLanguage.toUpperCase() == 'PL' && this.disbursementForm.get('post_country').value == 'PL') {
      this.disbursementForm.controls.post_postalcode['restrict'].maxlength = this.post_postalcodeMaxlenthinit.length;
      this.disbursementForm.controls.post_postalcode.setValidators([validators]);
    } else {
      this.disbursementForm.controls.post_postalcode['restrict'].maxlength = 10;
      this.disbursementForm.controls.post_postalcode.setValidators([validators]);
    }

  }

  blurPostPostalCodeField(setVal?: any) {
    if (this.disbursementForm.controls.post_postalcode.value == '' &&
      this.disbursementForm.controls.post_country.value == this.defaultLanguage.toUpperCase()
      && this.showPostTownOptionLabel) {
      this.disbursementForm.get('post_town').setValue(null);
      this.townFromRePoCode = '';
    }
    this.showPostTownOptionLabel = false;
    // //console.log("Postal Code")
    if (this.disbursementForm.controls.post_postalcode.value != '' && (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1) && this.disbursementForm.controls.post_country.value == this.defaultLanguage.toUpperCase()) {
      // //console.log("Postal Code")
      let value = this.disbursementForm.controls.post_postalcode.value;
      let post_postalCode = value;
      //let post_postalCode=[value.slice(0, 2), '-', value.slice(2)].join('');
      this.getPostalCodeValue(post_postalCode,
        this.defaultLanguage.toUpperCase()).subscribe((data) => {
          //  //console.log(data); 
          this.postTownOptions = data;
          //  //console.log(this.townOptions)
          if (data.length > 0) {
            this.showPostTownOptionLabel = true;
            this.townFromRePoCode = '*';
            if (setVal) {
              this.disbursementForm.get('post_town').setValue(setVal);
            } else {
              this.disbursementForm.get('post_town').setValue(data[0]);
            }


          } else {
            this.disbursementForm.get('post_town').setValue(null);
            this.showPostTownOptionLabel = false;
            this.townFromRePoCode = '';
          }
        });
    }
  }
  oldBankAccVal: any = null;
  blurBankAccountNumberField(event) {
    let bankaccountnumberUnmask = this.cleanup(this.disbursementForm.controls.bankaccountnumber.value);
    if (this.oldBankAccVal != bankaccountnumberUnmask) {
      this.showwbankaccountnumberInValid = false;
      this.disbursementForm.controls.bankaccountnumber['invalidFlag'] = this.showwbankaccountnumberInValid;
      // //console.log("bankaccountnumber",this.disbursementForm.controls.bankaccountnumber.value, this.disbursementForm.controls.countryofbank.value)
      if ((this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1) && this.disbursementForm.controls.bankaccountnumber.value != '' && this.disbursementForm.controls.countryofbank.value == this.defaultLanguage) {
        // //console.log("bankaccountnumber",this.disbursementForm.controls.bankaccountnumber.value)

        this.getBankNameValue(bankaccountnumberUnmask).subscribe((data) => {
          //console.log("bankaccountnumber", data)
          if (data.message == 'inValidBank' || data.message == 'noAutoGenerateBank') {
            this.bankNameGenerated = '';
            if (data.message == 'inValidBank') {
              this.showwbankaccountnumberInValid = true;
              this.disbursementForm.controls.bankaccountnumber['invalidFlag'] = this.showwbankaccountnumberInValid;
              this.disbursementForm.get('bankname').reset();
            } else if (data.message == 'noAutoGenerateBank') {
              this.showwbankaccountnumberInValid = false;
              this.disbursementForm.controls.bankaccountnumber['invalidFlag'] = this.showwbankaccountnumberInValid;
              this.disbursementForm.get('bankname').reset();

            }
          } else {
            this.showwbankaccountnumberInValid = false
            this.disbursementForm.controls.bankaccountnumber['invalidFlag'] = this.showwbankaccountnumberInValid;
            this.disbursementForm.get('bankname').setValue(data.message);
            this.bankNameGenerated = '*';
          }
        });
      }

    }
    this.oldBankAccVal = bankaccountnumberUnmask;

  }

  getBankNameValue(bankaccountnumber) {
    //console.log("bankaccountnumber", bankaccountnumber)
    let param = {
      "accountNumber": bankaccountnumber
    }
    // const url = `${environment.host + environment.getBankName.url}/${bankaccountnumber}/`;
    const url = `${environment.host + environment.getBankName.url}`;
    return this.commonService[environment.getBankName.method](
      url, param);
  }



  getformdisbursement(event) {
    //console.log("revecivedbeneficiaryValue", event)
    let transferNameFields = ['name', 'surname'];
    let postNameFields = ['post_name', 'post_surname'];

    if (event == "institution") {
      this.showTranferBusinessUnit = true;
      this.showTranferNameSurname = false;


      if (this.disbursementForm.get('viabanktransfer').value == true) {
        this.setRequiredFields(this.disbursementForm.controls, ['businessunit'], 'enable');
        this.setRequiredFields(this.disbursementForm.controls, transferNameFields, 'disable');
      }

      if (this.disbursementForm.get('viapost').value == true) {

        this.setRequiredFields(this.disbursementForm.controls, ['post_businessunit'], 'enable');
        this.setRequiredFields(this.disbursementForm.controls, postNameFields, 'disable');

      }


    } else if (event == "trader") {
      this.showpostcopyfromlegaltrader = true;
      this.showTranferBusinessUnit = true;
      this.showTranferNameSurname = false;

      if (this.disbursementForm.get('viabanktransfer').value == true) {
        this.setRequiredFields(this.disbursementForm.controls, ['businessunit'], 'enable');
        this.setRequiredFields(this.disbursementForm.controls, transferNameFields, 'disable');
      }

      if (this.disbursementForm.get('viapost').value == true) {

        this.setRequiredFields(this.disbursementForm.controls, ['post_businessunit'], 'enable');
        this.setRequiredFields(this.disbursementForm.controls, postNameFields, 'disable');

      }
    } else if (event == "") {
      this.showTranferBusinessUnit = false;
      this.showTranferNameSurname = false;
      this.setRequiredFields(this.disbursementForm.controls, ['businessunit', 'post_businessunit'], 'disable');
      this.setRequiredFields(this.disbursementForm.controls, transferNameFields, 'disable');
      this.setRequiredFields(this.disbursementForm.controls, postNameFields, 'disable');
    } else {
      this.showTranferBusinessUnit = false;
      this.showTranferNameSurname = true;
      if (this.disbursementForm.get('viabanktransfer').value == true) {
        this.setRequiredFields(this.disbursementForm.controls, ['businessunit'], 'disable');
        this.setRequiredFields(this.disbursementForm.controls, transferNameFields, 'enable');
      }

      if (this.disbursementForm.get('viapost').value == true) {

        this.setRequiredFields(this.disbursementForm.controls, ['post_businessunit'], 'disable');
        this.setRequiredFields(this.disbursementForm.controls, postNameFields, 'enable');

      }
    }

  }


  formSetValue() {

  }
  copyNameFromBenefitSec(disbursement) {
    if (disbursement === 'viapost') {
      this.disbursementForm.get('post_name').setValue(this.personalFormControl.value.entitledForBenefitsSection.nameIndv);
      this.disbursementForm.get('post_surname').setValue(this.personalFormControl.value.entitledForBenefitsSection.surNameIndv);
      this.disbursementForm.get('post_businessunit').setValue(this.personalFormControl.value.entitledForBenefitsSection.institutionNameInst);
      if (this.personalFormControl.value.entitledForBenefitsSection.institutionNameTrader) {
        this.disbursementForm.get('post_businessunit').setValue(this.personalFormControl.value.entitledForBenefitsSection.institutionNameTrader);
      }

    }
    if (disbursement === 'viabanktransfer') {
      this.disbursementForm.get('name').setValue(this.personalFormControl.value.entitledForBenefitsSection.nameIndv);
      this.disbursementForm.get('surname').setValue(this.personalFormControl.value.entitledForBenefitsSection.surNameIndv);
      this.disbursementForm.get('businessunit').setValue(this.personalFormControl.value.entitledForBenefitsSection.institutionNameInst);
      if (this.personalFormControl.value.entitledForBenefitsSection.institutionNameTrader) {
        this.disbursementForm.get('businessunit').setValue(this.personalFormControl.value.entitledForBenefitsSection.institutionNameTrader);
      }
    }

    //console.log(this.personalFormControl, "personalFormControl");
  }
  inValidCountry: boolean = false;

  copyAddressFromResidenceSec(disbursement) {

    if (disbursement === 'viapost') {

      this.countryOnChangePost(this.personalFormControl.value.resideneAddressSection.country)
      this.disbursementForm.get('post_streetname').setValue(this.personalFormControl.value.resideneAddressSection.streetName);
      this.disbursementForm.get('post_streetnumber').setValue(this.personalFormControl.value.resideneAddressSection.houseNumber);
      this.disbursementForm.get('post_flatnumber').setValue(this.personalFormControl.value.resideneAddressSection.flatNumber);
      this.disbursementForm.get('post_country').setValue(this.personalFormControl.value.resideneAddressSection.country);
      this.disbursementForm.get('postal_otherNationalityField').setValue(this.personalFormControl.value.resideneAddressSection.otherCountry);

      setTimeout(() => {
        this.disbursementForm.get('post_postalcode').setValue(this.personalFormControl.value.resideneAddressSection.postalCode);
        this.disbursementForm.get('post_town').setValue(this.personalFormControl.value.resideneAddressSection.town);
        this.showPostTownOptionLabel = this.residenceRefComp.showTownOptionLabel

        if (this.showPostTownOptionLabel) {
          this.blurPostPostalCodeField(this.personalFormControl.value.resideneAddressSection.town);
        }
      }, 0);

      this.disbursementForm.get('post_postbox').setValue(this.personalFormControl.value.resideneAddressSection.postBox);

    }
    if (disbursement === 'viabanktransfer') {
      this.countryOnChangeTransfer(this.personalFormControl.value.resideneAddressSection.country)
      this.disbursementForm.get('streetname').setValue(this.personalFormControl.value.resideneAddressSection.streetName);
      this.disbursementForm.get('streetnumber').setValue(this.personalFormControl.value.resideneAddressSection.houseNumber);
      this.disbursementForm.get('flatnumber').setValue(this.personalFormControl.value.resideneAddressSection.flatNumber);
      this.disbursementForm.get('country').setValue(this.personalFormControl.value.resideneAddressSection.country);
      this.disbursementForm.get('otherNationalityField').setValue(this.personalFormControl.value.resideneAddressSection.otherCountry);

      if (this.disbursementForm.controls.otherNationalityField.value
        && this.disbursementForm.controls.otherNationalityField.value != ''
        && !this.disbursementForm.controls.otherNationalityField.valid) {
        this.disbursementForm.controls.otherNationalityField.markAsTouched();

        this.inValidCountry = true;
      } else {
        this.inValidCountry = false;
      }

      setTimeout(() => {
        this.disbursementForm.get('postalcode').setValue(this.personalFormControl.value.resideneAddressSection.postalCode);
        this.disbursementForm.get('town').setValue(this.personalFormControl.value.resideneAddressSection.town);
        this.showTownOptionLabel = this.residenceRefComp.showTownOptionLabel
        if (this.showTownOptionLabel) {
          this.blurPostalCodeField(this.personalFormControl.value.resideneAddressSection.postalCode,
            this.personalFormControl.value.resideneAddressSection.town);
        }
      }, 0)

      this.disbursementForm.get('postbox').setValue(this.personalFormControl.value.resideneAddressSection.postBox);

    }


    //console.log(this.personalFormControl, "personalFormControl");
  }

  copyAddressFromCorresspondSec(disbursement) {

    if (disbursement === 'viapost') {

      this.countryOnChangePost(this.personalFormControl.value.correspondenceAddressSection.country)
      this.disbursementForm.get('post_streetname').setValue(this.personalFormControl.value.correspondenceAddressSection.streetName);
      this.disbursementForm.get('post_streetnumber').setValue(this.personalFormControl.value.correspondenceAddressSection.houseNumber);
      this.disbursementForm.get('post_flatnumber').setValue(this.personalFormControl.value.correspondenceAddressSection.flatNumber);
      this.disbursementForm.get('post_country').setValue(this.personalFormControl.value.correspondenceAddressSection.country);
      this.disbursementForm.get('postal_otherNationalityField').setValue(this.personalFormControl.value.correspondenceAddressSection.otherCountry);

      setTimeout(() => {
        this.disbursementForm.get('post_postalcode').setValue(this.personalFormControl.value.correspondenceAddressSection.postalCode);
        this.disbursementForm.get('post_town').setValue(this.personalFormControl.value.correspondenceAddressSection.town);
        this.showPostTownOptionLabel = this.correspondanceRefComp.showTownOptionLabel

        if (this.showPostTownOptionLabel) {
          this.blurPostPostalCodeField(this.personalFormControl.value.correspondenceAddressSection.town);
        }
      }, 0);

      this.disbursementForm.get('post_postbox').setValue(this.personalFormControl.value.correspondenceAddressSection.postBox);

    }
    if (disbursement === 'viabanktransfer') {
      this.countryOnChangeTransfer(this.personalFormControl.value.correspondenceAddressSection.country)
      this.disbursementForm.get('streetname').setValue(this.personalFormControl.value.correspondenceAddressSection.streetName);
      this.disbursementForm.get('streetnumber').setValue(this.personalFormControl.value.correspondenceAddressSection.houseNumber);
      this.disbursementForm.get('flatnumber').setValue(this.personalFormControl.value.correspondenceAddressSection.flatNumber);
      this.disbursementForm.get('country').setValue(this.personalFormControl.value.correspondenceAddressSection.country);
      this.disbursementForm.get('otherNationalityField').setValue(this.personalFormControl.value.correspondenceAddressSection.otherCountry);

      if (this.disbursementForm.controls.otherNationalityField.value
        && this.disbursementForm.controls.otherNationalityField.value != ''
        && !this.disbursementForm.controls.otherNationalityField.valid) {
        this.disbursementForm.controls.otherNationalityField.markAsTouched();

        this.inValidCountry = true;
      } else {
        this.inValidCountry = false;
      }

      setTimeout(() => {
        this.disbursementForm.get('postalcode').setValue(this.personalFormControl.value.correspondenceAddressSection.postalCode);
        this.disbursementForm.get('town').setValue(this.personalFormControl.value.correspondenceAddressSection.town);
        this.showTownOptionLabel = this.correspondanceRefComp.showTownOptionLabel
        if (this.showTownOptionLabel) {
          this.blurPostalCodeField(this.personalFormControl.value.correspondenceAddressSection.postalCode,
            this.personalFormControl.value.correspondenceAddressSection.town);
        }
      }, 0)

      this.disbursementForm.get('postbox').setValue(this.personalFormControl.value.correspondenceAddressSection.postBox);
      this.disbursementForm.get('county').setValue(this.personalFormControl.value.correspondenceAddressSection.county);
      this.disbursementForm.get('zipCode').setValue(this.personalFormControl.value.correspondenceAddressSection.zipCode);
      this.disbursementForm.get('city').setValue(this.personalFormControl.value.correspondenceAddressSection.city);
      this.disbursementForm.get('block').setValue(this.personalFormControl.value.correspondenceAddressSection.block);
      this.disbursementForm.get('entrance').setValue(this.personalFormControl.value.correspondenceAddressSection.entrance);
      this.disbursementForm.get('appartment').setValue(this.personalFormControl.value.correspondenceAddressSection.appartment);
      this.disbursementForm.get('sector').setValue(this.personalFormControl.value.correspondenceAddressSection.sector);

    }


    //console.log(this.personalFormControl, "personalFormControl");
  }
  checkNationalityField() {

    if (!this.disbursementForm.controls.otherNationalityField.valid) {
      this.inValidCountry = true;
    } else {
      this.inValidCountry = false;
    }

  }
  benefitChecboxError = false;

  enableTransferBank() {
    if (this.disbursementForm.get('viapost').value == true) {
      this.setRequiredFields(this.disbursementForm.controls, this.viapostFields, 'enable');
      this.getformdisbursement(this.newClaimService.getParamValue('benefitiaryGrp'))
      if (this.disbursementForm.get('post_country').value.toLowerCase() == 'other') {
        this.disbursementForm.controls.postal_otherNationalityField.enable();
      } else {
        this.disbursementForm.controls.postal_otherNationalityField.disable();
      }
    } else {
      this.setRequiredFields(this.disbursementForm.controls, this.viapostFields, 'disable');
    }

    if (this.disbursementForm.get('viabanktransfer').value == true) {
      this.setRequiredFields(this.disbursementForm.controls, this.bankTransferFields, 'enable');
      this.getformdisbursement(this.newClaimService.getParamValue('benefitiaryGrp'))
      // this.enableAddressFieldForRO(this.disbursementForm.get('country').value);
      // this.countryOfBankOnChange(this.disbursementForm.get('countryofbank').value);
      if (this.disbursementForm.get('country').value.toLowerCase() == 'other') {
        // this.showCountryLabel = true;
        // this.disbursementForm.controls.otherNationalityField.reset();
        this.disbursementForm.controls.otherNationalityField.enable();
      } else {
        this.disbursementForm.controls.otherNationalityField.disable();
      }
      if (this.disbursementForm.get('countryofbank').value == 'other' || this.disbursementForm.get('countryofbank').value == 'eu') {
        this.showcountryOfBankLabel = true;
        this.setRequiredFields(this.disbursementForm.controls, ['codeswift', 'bankaddress'], 'enable');
      } else {
        this.setRequiredFields(this.disbursementForm.controls, ['codeswift', 'bankaddress'], 'disable');
      }

    } else {
      this.setRequiredFields(this.disbursementForm.controls, this.bankTransferFields, 'disable');
    }

    if (this.disbursementForm.get('interestedinreinvestment').value == true) {
      this.setRequiredFields(this.disbursementForm.controls, this.reinversementFields, 'enable');
    } else {
      this.setRequiredFields(this.disbursementForm.controls, this.reinversementFields, 'disable');
    }


  }

  enableAddressFieldForRO(event) {
    let countryValueRO = ['county', 'zipCode', 'city', 'block', 'entrance', 'appartment', 'sector'];
    let countryValueROField = ['flatnumber', 'postalcode', 'town', 'postbox'];
    if (this.defaultLanguage == 'ro') {
      if (event.toLowerCase() == this.defaultLanguage) {
        for (let j = 0; j < countryValueRO.length; j++) {
          if (this.disbursementRenderSecRules[countryValueRO[j]] && this.disbursementRenderSecRules[countryValueRO[j]].renderFlag && this.disbursementRenderSecRules[countryValueRO[j]].mandatoryFlag) {
            this.disbursementForm.controls[countryValueRO[j]].enable();
          }
        }
        for (let j = 0; j < countryValueROField.length; j++) {
          if (this.disbursementRenderSecRules[countryValueROField[j]] && this.disbursementRenderSecRules[countryValueROField[j]].renderFlag && this.disbursementRenderSecRules[countryValueROField[j]].mandatoryFlag) {
            this.disbursementForm.controls[countryValueROField[j]].disable();
          }
        }
      } else {
        for (let j = 0; j < countryValueRO.length; j++) {
          if (this.disbursementRenderSecRules[countryValueRO[j]] && this.disbursementRenderSecRules[countryValueRO[j]].renderFlag && this.disbursementRenderSecRules[countryValueRO[j]].mandatoryFlag) {
            this.disbursementForm.controls[countryValueRO[j]].disable();
          }
        }
        for (let j = 0; j < countryValueROField.length; j++) {
          if (this.disbursementRenderSecRules[countryValueROField[j]] && this.disbursementRenderSecRules[countryValueROField[j]].renderFlag && this.disbursementRenderSecRules[countryValueROField[j]].mandatoryFlag) {
            this.disbursementForm.controls[countryValueROField[j]].enable();
          }
        }
      }
    }
  }

  formSubmit() {
    //console.log("this.disbursementForm", this.disbursementForm);
    //console.log("this.disbursementForm.valid", this.disbursementForm.valid);
    this.viafinancialChange('');
    let disbursementBoxchecked = [];

    if (this.disbursementRenderSecRules.interestedinreinvestment.renderFlag) {
      disbursementBoxchecked.push(this.disbursementForm.value.interestedinreinvestment);
    }
    if (this.disbursementRenderSecRules.viabanktransfer.renderFlag) {
      disbursementBoxchecked.push(this.disbursementForm.value.viabanktransfer);
    }
    if (this.disbursementRenderSecRules.viafinancialinst.renderFlag) {
      disbursementBoxchecked.push(this.disbursementForm.value.viafinancialinst);
    }
    if (this.disbursementRenderSecRules.viapost.renderFlag) {
      disbursementBoxchecked.push(this.disbursementForm.value.viapost);
    }
    if (this.disbursementRenderSecRules.viapost.renderFlag) {
      disbursementBoxchecked.push(this.disbursementForm.value.viafinancialinst);
    }


    this.benefitChecboxError = true;
    for (let i = 0; i < disbursementBoxchecked.length; i++) {
      if (disbursementBoxchecked[i] && disbursementBoxchecked[i] != '') {
        this.benefitChecboxError = false;
      }
    }
    /*
    if ((this.disbursementRenderSecRules.interestedinreinvestment.renderFlag &&
      !this.disbursementForm.value.interestedinreinvestment) &&
      (this.disbursementRenderSecRules.viabanktransfer.renderFlag &&
        !this.disbursementForm.value.viabanktransfer) &&
      (this.disbursementRenderSecRules.viapost.renderFlag &&
        !this.disbursementForm.value.viapost) &&
      (this.disbursementRenderSecRules.viafinancialinst.renderFlag &&
        !this.disbursementForm.value.viafinancialinst)) {
      this.benefitChecboxError = true;

    } else {
      this.benefitChecboxError = false;
    }*/
    //console.log("this.disbursementForm.valid",  this.benefitChecboxError );

    this.enableTransferBank();
    //this.postValue('');
    //this.onChangeReinvestment('');


    let formDetails = {
      formInfo: null,
      //isFormValid: true
      isFormValid: this.formValid()
    }
    //this.formValid();
    return formDetails;


  }
  bankAccControlType: any = null;
  passwordMaskEvent(evt) {

    if (this.bankAccControlType == 'password') {
      this.bankAccControlType = 'text';
    } else {
      this.bankAccControlType = 'password';
    }
  }
  formValid() {
    //console.log("this.disbursementForm", this.disbursementForm.valid, this.disbursementForm);
    //console.log("errorFormGroup", this.createFormService.errorFormGroup(this.disbursementForm));

    let benefitVal = (this.disbursementForm.get('interestedinreinvestment').value
      || this.disbursementForm.get('viabanktransfer').value
      || this.disbursementForm.get('viapost').value
      || this.disbursementForm.get('viafinancialinst').value)


    // console.log("benefitVal", benefitVal);
    let accNumberInValidCheck = false;
    if (this.disbursementForm.get('viabanktransfer').value == true) {
      accNumberInValidCheck = this.showwbankaccountnumberInValid;
    }


    if (!accNumberInValidCheck &&
      this.disbursementForm.valid && (benefitVal && benefitVal != '')) {
      return true;
    }
    return false;
  }
  public masking = {
    guide: false,
    showMask: true,
    mask: [/\d/, /\d/, ' ',
      /\d/, /\d/, /\d/, /\d/, ' ',
      /\d/, /\d/, /\d/, /\d/, ' ',
      /\d/, /\d/, /\d/, /\d/, ' ',
      /\d/, /\d/, /\d/, /\d/, ' ',
      /\d/, /\d/, /\d/, /\d/, ' ',
      /\d/, /\d/, /\d/, /\d/]
  };

  public postalMasking = {
    guide: false,
    showMask: true,
    mask: [/\d/, /\d/, '-',
      /\d/, /\d/, /\d/]
  };

  cleanup(maskedData) {

    return (maskedData ? (maskedData.replace(/[\s]/g, '')) : maskedData);

  }

  reinversementFields: any = ['policynumber', 'amount', 'currency'];
  onChangeReinvestment(event) {
    this.disbursementForm.get('currency').setValue('RON');
    if (this.disbursementForm.get('interestedinreinvestment').value == true) {
      this.setRequiredFields(this.disbursementForm.controls, this.reinversementFields, 'enable');
    } else {
      this.setRequiredFields(this.disbursementForm.controls, this.reinversementFields, 'disable');
    }
  }


  setRequiredFields(parentControl, fieldsArr, validation) {
    for (let i = 0; i < fieldsArr.length; i++) {
      if (parentControl[fieldsArr[i]]) {
        //parentControl[fieldsArr[i]].setValidators(validation);
        //parentControl[fieldsArr[i]].updateValueAndValidity();
        parentControl[fieldsArr[i]][validation]();
      }
    }
  }
}
