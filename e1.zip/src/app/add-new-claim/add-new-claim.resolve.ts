import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";
import { Observable } from "rxjs";
import { HttpCommonService } from "../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { ScreenRenderReqModel } from '../add-new-claim/models/ScreenRenderReqModel';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { DataService } from '../shared/services/data.service';

@Injectable()
export class ExistingClaimResolve implements Resolve<any> {
  screenRequestObj: ScreenRenderReqModel = new ScreenRenderReqModel();
  partner: string = 'metlife';
  baseUrl = environment.host + environment.existingPersonalServiceConfig.url;
  headers = new HttpHeaders();

  constructor(private commonService: HttpCommonService, public dataService: DataService) { }
  //type of event primary service call and country service call
  resolve(route: ActivatedRouteSnapshot) {
    const url = "assets/mocks/rule.json";
    //console.log(this.commonService.getData(url), "this.commonService.getData(url)")
    return this.commonService.getData(url);
  }
  getRuleSheetDetails() {
    this.screenRequestObj.screenName = "ExistingClaim";
    let sourceOrigin = JSON.parse(sessionStorage.getItem("userData"));

    this.screenRequestObj.sourceOfOrigin = sourceOrigin.sourceOrigin;
    this.screenRequestObj.partner = this.partner;
    return this.commonService[environment.typeOfEventServiceConfig.method](this.baseUrl, this.screenRequestObj, this.headers);
    // (this.baseUrl,  this.screenRequestObj,this.headers).subscribe((data) => {
    //   return data;
    // });
  }
  CountryList: any;
  countryList: any;
  jsonObj = JSON.parse(sessionStorage.userData);
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  defaultLanguage = this.jsonObj.defaultLanguage;
  getCountries() {

    let countryListURL = environment.host + environment.getCountryListConfig.url;
    //let countryListParam = "language=" + this.jsonObj.displayLanguages + "&country=" + this.jsonObj.defaultLanguage;
    //countryListURL = countryListURL + countryListParam;
    //countryListURL = "http://localhost:4200/assets/mocks/countryList.json";
    this.commonService.getData(countryListURL).subscribe((data) => {
      this.CountryList = data["List"]["item"];
      this.countryList = data["List"]["item"];
      this.dataService.setOption("countryList", data);
      if (this.contactCountryEnable.indexOf(this.defaultLanguage) != -1) {

      } else {
        //   this.existingClaim.get('contactDataCountry').setValue(null);
      }

    });

  }
}





