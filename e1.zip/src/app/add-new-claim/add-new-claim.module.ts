import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, FormControl, FormArray, NgForm, Validators } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddNewClaimRoutingModule } from './add-new-claim-routing.module';
import { PersonalDetailsComponent } from './personal-details/personal-details.component';
import { AddNewClaimComponent } from './add-new-claim.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { AttachmentsComponent } from './attachments/attachments.component';
import { ReviewDetailsComponent } from './review-details/review-details.component';
import { TranslateLoader, TranslateModule, TranslateService } from '@ngx-translate/core';
import {
  MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule, MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatRadioModule, MatInputModule, MatStepperModule, MatDatepickerModule,
  MatNativeDateModule
} from '@angular/material';
import { TypeOfEventsComponent } from './type-of-events/type-of-events.component';
import { InsuranceReferSecComponent } from './personal-details/insurance-refer-sec/insurance-refer-sec.component';
import { BenefitSecComponent } from './personal-details/benefit-sec/benefit-sec.component';
import { CorrespondAddressSecComponent } from './personal-details/correspond-address-sec/correspond-address-sec.component';
import { ResidenceAddressSecComponent } from './personal-details/residence-address-sec/residence-address-sec.component';
import { FormDisbursementSecComponent } from './personal-details/form-disbursement-sec/form-disbursement-sec.component';
import { AdditionalDetailsSecComponent } from './event-details/additional-details-sec/additional-details-sec.component';
import { EventInformationSecComponent } from './event-details/event-information-sec/event-information-sec.component';
import { HealthcareEventSecComponent } from './event-details/healthcare-event-sec/healthcare-event-sec.component';
import { HealthcareFamilydocSecComponent } from './event-details/healthcare-familydoc-sec/healthcare-familydoc-sec.component';
import { SectionReqConfigService } from './personal-details/personal-details.model';
import { NewClaimSharedService } from './add-new-claim.service';
import { EventSecReqConfigService, AdditionalFieldDetailsModel } from './event-details/event-details.model';
import { PersonalDetailReviewSectionComponent } from './review-details/personal-detail-review-section/personal-detail-review-section.component';
import { FormDisbursemnetReviewSecComponent } from './review-details/personal-detail-review-section/form-disbursemnet-review-sec/form-disbursemnet-review-sec.component';
import { BenefitSecReviewComponent } from './review-details/personal-detail-review-section/benefit-sec-review/benefit-sec-review.component';
import { EventDetailReviewSectionComponent } from './review-details/event-detail-review-section/event-detail-review-section.component';
import { EventInfoReviewSecComponent } from './review-details/event-detail-review-section/event-info-review-sec/event-info-review-sec.component';
import { AdditionalSecReviewComponent } from './review-details/event-detail-review-section/additional-sec-review/additional-sec-review.component';
import { HealthCarePrimaryReviewComponent } from './review-details/event-detail-review-section/health-care-primary-review/health-care-primary-review.component';
import { HealthcareFamilydocRevSecComponent } from './review-details/event-detail-review-section/healthcare-familydoc-rev-sec/healthcare-familydoc-rev-sec.component';
import { TypeEventReviewSectionComponent } from './review-details/type-event-review-section/type-event-review-section.component';
import{NewClaimConfirmationComponent} from './../add-new-claim/new-claim-confirmation/new-claim-confirmation.component'
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter, NativeDateAdapter } from '@angular/material';
export class CustomDatePickerAdapter extends NativeDateAdapter {

  parse(value: any): Date | null {
    //console.log(value);
    if ((typeof value === 'string') && (value.indexOf('/') > -1)) {
      const str = value.split('/');
      const year = Number(str[2]);
      const month = Number(str[1]) - 1;
      const date = Number(str[0]);
   // console.log("year, month, date",year, month, date)
    //console.log("year, month, date",new Date(year, month, date))
    if(year>0 && month<12 && date>0 && date<31){
      return new Date(year, month, date);
    }

    
    }
    const timestamp = typeof value === 'number' ? value : Date.parse(value);
    //console.log("timestamp",timestamp)
    return isNaN(timestamp) ? null : new Date(timestamp);
  }

  private _to2digit(n: number) {
    //console.log("_to2digit",('00' + n).slice(-2))
    return ('00' + n).slice(-2);
  }
  format(date: Date, displayFormat: string): string {
    //console.log(displayFormat," ------>",date,displayFormat )

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    //console.log("input",(this._to2digit(day) + '/' + this._to2digit(month) + '/' + year) )
    return this._to2digit(day) + '/' + this._to2digit(month) + '/' + year;

  }
}

@NgModule({
  declarations: [PersonalDetailsComponent, AddNewClaimComponent, EventDetailsComponent,
    AttachmentsComponent, ReviewDetailsComponent, TypeOfEventsComponent,
    InsuranceReferSecComponent, BenefitSecComponent, CorrespondAddressSecComponent,
    ResidenceAddressSecComponent, FormDisbursementSecComponent, AdditionalDetailsSecComponent,
    EventInformationSecComponent, HealthcareEventSecComponent,
    HealthcareFamilydocSecComponent, TypeEventReviewSectionComponent, PersonalDetailReviewSectionComponent, FormDisbursemnetReviewSecComponent, BenefitSecReviewComponent, EventDetailReviewSectionComponent, EventInfoReviewSecComponent, AdditionalSecReviewComponent, HealthCarePrimaryReviewComponent, HealthcareFamilydocRevSecComponent,
    NewClaimConfirmationComponent],
  imports: [
    CommonModule,
    AddNewClaimRoutingModule, TranslateModule, MatIconModule, MatDialogModule, MatToolbarModule,
    MatButtonModule, MatSidenavModule,
    MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
    MatExpansionModule, MatRadioModule, MatInputModule, MatStepperModule, MatDatepickerModule, MatNativeDateModule
    , FormsModule, ReactiveFormsModule, SharedModule],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
  
      {
        provide: DateAdapter,
        useClass: CustomDatePickerAdapter
  
      },
  
      { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
    SectionReqConfigService, EventSecReqConfigService, AdditionalFieldDetailsModel]
})
export class AddNewClaimModule { }
