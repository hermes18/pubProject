import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormGroup, Validators, AbstractControl } from '@angular/forms';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { environment } from 'src/environments/environment';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { DataService } from 'src/app/shared/services/data.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import * as utils from 'lodash';
import { CreateFormService } from '../../../shared/services/create-form.service';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'additional-details-sec',
  templateUrl: './additional-details-sec.component.html',
  styleUrls: ['./additional-details-sec.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AdditionalDetailsSecComponent implements OnInit {
  @Input() workContract: string;
  @Input() additionaldetailsForm: FormGroup;
  @Input() eventDetailFormControl: FormGroup;
  //@Input() additionalRenderSecRules: any;
  @Input() additionalRenderSecRulesBO: any;
  @Input() eventInfoSecRules:any;
  @Output() workContractChange = new EventEmitter();

  _additionalRenderSecRules:any;
  @Input() set additionalRenderSecRules(value) {
    
    this._additionalRenderSecRules = value;
 
 
 }
 
 get additionalRenderSecRules(): any {
 
     return this._additionalRenderSecRules;
 
 }




  displayInjurySportClubLabel: boolean = false
  displayPoliceConductedInvestigation: boolean = false
  additionalDetailsLabel: boolean = false;
  disableDateOfRecognitiontNotApplicable = null;
  disableSickLeavePeriod = null;
  disabledateCompletionOfMedicalTreatment = null;


  userData = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.userData.sourceOrigin;
  defaultLanguage: string = this.userData.defaultLanguage;
  peselEnableCountry = eClaimsConstants.peselEnableCountry;
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
  additionaldetailsFormEnableCountry = eClaimsConstants.additionaldetailsFormEnableCountry;
  showCountryLabel: boolean = false;
  showTownOptionLabel: boolean = false;
  showSportsClubPoliceTownOptionLabel: boolean = false;
  showSportsClubCountryLabel: boolean = false;
  centerPeriodFromMax = new Date();
  centerPeriodFromMin = new Date(eClaimsConstants.dobMinYear, eClaimsConstants.dobMinMnth, eClaimsConstants.dobMinDate);
  sickLeavePeriodToMin = new Date();
  sickLeavePeriodToMax:any = null;
  sickLeavePeriodFromMin:any =null;
  sickLeavePeriodFromMax:any =null;
  sportTownOptions = [];
  townOptions = [];
  countryCodes = {
    'RO': '+40',
    'PL': '+48'
  };

  countryOptions = []
  medicalChecboxError: boolean = false;
  medicalTreatmentChecboxError: boolean = false;
  sickLeaveChecboxError: boolean = false;
  recognitionDiseaseChecboxError: boolean = false;
  forwhatperiodError: boolean = false;
  sportsClubPostalCodeInit;
  postalcodeMaxlenthinit;
  townFromPoCode: string;
  sportsTownFromPoCode: string;
  constructor(public newClaimService: NewClaimSharedService, public dataService: DataService,
    private commonService: HttpCommonService, public createFormService: CreateFormService,
    public dialogService: DialogService,private translate: TranslateService) { }

addMaxYears(addYear){
  let d = new Date();
  let year = d.getFullYear();
  let month = d.getMonth();
  let day = d.getDate();
  let c = new Date((year + addYear), month, day);
  return c;
}
    
  ngOnInit() {
    this.workContract = "pleaseSelect";
    this.formInit();
    this.sickLeavePeriodToMax = this.addMaxYears(100);
  }
  formInit() {
//console.log(this.additionalRenderSecRules,"this.additionalRenderSecRules aaaa");
    this.toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
    this.countryOptions = this.newClaimService.getParamValue('countryList');
    this.setDefaultCode();
    if (this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1) {
      this.setDefaultCode();
    } else {
      this.additionaldetailsForm.get('country').setValue(null);
      this.additionaldetailsForm.get('sportsClubCountry').setValue(null);
    }
    this.newClaimService.getCountryList().subscribe((data) => {
      this.countryOptions = data;
      setTimeout(() => {
        this.additionaldetailsForm.get('country').setValue(this.additionaldetailsForm.get('country').value);
        this.additionaldetailsForm.get('sportsClubCountry').setValue(this.additionaldetailsForm.get('sportsClubCountry').value);
      }, 0);
    });

    this.sportsClubPostalCodeInit = {
      length: this.additionaldetailsForm.controls.sportsClubPostalCode['restrict'].maxlength,
      required: (this.additionaldetailsForm && this.additionaldetailsForm.get('sportsClubPostalCode').validator({} as AbstractControl)) ?
        this.additionaldetailsForm.get('sportsClubPostalCode').validator({} as AbstractControl).required : ''
    };
    this.postalcodeMaxlenthinit = {
      length: this.additionaldetailsForm.controls.postalCode['restrict'].maxlength,
      required: (this.additionaldetailsForm && this.additionaldetailsForm.get('postalCode').validator({} as AbstractControl)) ? this.additionaldetailsForm.get('postalCode').validator({} as AbstractControl).required : ''
    };
    this.medicalChecboxError = false;
    this.medicalTreatmentChecboxError = false;
    this.sickLeaveChecboxError = false;
    this.recognitionDiseaseChecboxError = false;
    this.forwhatperiodError = false;
    // this.countryOnChange(this.additionaldetailsForm.get('country').value);
    // this.otherSportsClubCountryOnChange(this.additionaldetailsForm.get('sportsClubCountry').value);
    this.onInjurySportClubLabel(this.additionaldetailsForm.controls['sportsClubPlayerDropDown'].value);
    this.onPoliceConductedInvestigation(this.additionaldetailsForm.controls['policeConductedInvestigation'].value);
    /*
    if(this.additionalRenderSecRules['dateOfRecognitionDisease'].mandatoryFlag){
      this.inValidDateOfRecognition = false;
    }else{
      this.inValidDateOfRecognition = true;
    }*/
  }

  ngAfterViewInit() {
    this.additionaldetailsForm.addControl('sickLeavePeriodFromDate', this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod);
    //this.additionaldetailsForm.get('sickLeavePeriodFromDate').validator = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod.validator;
    this.additionaldetailsForm.get('sickLeavePeriodFromDate')['isVisible'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod['isVisible'];
    this.additionaldetailsForm.get('sickLeavePeriodFromDate')['restrict'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod['restrict'];
    this.additionaldetailsForm.addControl('sickLeavePeriodToDate', this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod);
    this.additionaldetailsForm.get('sickLeavePeriodToDate')['isVisible'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod['isVisible'];
    //this.additionaldetailsForm.get('sickLeavePeriodToDate').validator = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod.validator;
    this.additionaldetailsForm.get('sickLeavePeriodToDate')['restrict'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod['restrict'];
    this.additionaldetailsForm.addControl('sickLeavePeriodNACheckBox', this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod);
    this.additionaldetailsForm.get('sickLeavePeriodNACheckBox')['isVisible'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod['isVisible'];
    this.additionaldetailsForm.get('sickLeavePeriodNACheckBox').validator = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].sickLeavePeriod.validator;
    this.additionaldetailsForm.addControl('medicalTreatmentNotApplicable', this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].dateCompletionOfMedicalTreatment);
    this.additionaldetailsForm.get('medicalTreatmentNotApplicable')['isVisible'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].dateCompletionOfMedicalTreatment['isVisible'];
    this.additionaldetailsForm.get('medicalTreatmentNotApplicable').validator = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].dateCompletionOfMedicalTreatment.validator;
    this.additionaldetailsForm.addControl('medicalTreatmentStillUndergoing', this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].dateCompletionOfMedicalTreatment);
    this.additionaldetailsForm.get('medicalTreatmentStillUndergoing')['isVisible'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].dateCompletionOfMedicalTreatment['isVisible'];
    this.additionaldetailsForm.get('medicalTreatmentStillUndergoing').validator = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].dateCompletionOfMedicalTreatment.validator;
    this.additionaldetailsForm.addControl('employmentPeriodFromDate', this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].employmentPeriod);
    //this.additionaldetailsForm.get('employmentPeriodFromDate').validator = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].employmentPeriod.validator;
    this.additionaldetailsForm.get('employmentPeriodFromDate')['isVisible'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].employmentPeriod['isVisible'];
    this.additionaldetailsForm.get('employmentPeriodFromDate')['restrict'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].employmentPeriod['restrict'];
    this.additionaldetailsForm.addControl('employmentPeriodToDate', this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].employmentPeriod);
   // this.additionaldetailsForm.get('employmentPeriodToDate').validator = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].employmentPeriod.validator;
    this.additionaldetailsForm.get('employmentPeriodToDate')['isVisible'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].employmentPeriod['isVisible'];
    this.additionaldetailsForm.get('employmentPeriodToDate')['restrict'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].employmentPeriod['restrict'];
    this.additionaldetailsForm.addControl('notApplicableCheckBox', this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].dateOfRecognitionDisease);
    // this.additionaldetailsForm.get('notApplicableCheckBox')['isVisible'] = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].dateCompletionOfMedicalTreatment['isVisible'];
    this.additionaldetailsForm.get('notApplicableCheckBox').validator = this.eventDetailFormControl.controls.additionalFieldDetailsSection['controls'].dateOfRecognitionDisease.validator;

    this.sportClubValidator();
    this.policeFieldValidator();
  }
  ngForminit() {
    (<any>Object).values(this.additionaldetailsForm.controls).forEach(control => {
     // control.setValue(null);
     if(control.hasOwnProperty('isVisible')){
     if(control['isVisible']!=true){
      control.setValue(null);
     }

     } 
     control.markAsUntouched();
      control.updateValueAndValidity();

    })
    this.setDefaultCode();
    this.displayInjurySportClubLabel = false;
    this.displayPoliceConductedInvestigation = false;
    this.medicalChecboxError = false;
    this.medicalTreatmentChecboxError = false;
    this.sickLeaveChecboxError = false;
    this.recognitionDiseaseChecboxError = false;
    this.inValidsickLeavetoDate = false;
    this.inValidemplymentFromDate = false;
    this.inValidemplymentToDate = false;
    this.inValidDateOfSymtomDisease = false;
    this.inValidMedicalTreatmentDate = false;
  
    /*if(this.additionalRenderSecRules['dateOfRecognitionDisease'].mandatoryFlag){
      this.inValidDateOfRecognition = false;
    }else{
      this.inValidDateOfRecognition = true;
    }*/
   if(this.additionaldetailsForm && this.additionaldetailsForm.controls && 
    this.additionaldetailsForm.controls.notApplicableCheckBox){
    if(this.additionalRenderSecRulesBO && this.additionalRenderSecRulesBO['dateOfRecognitionDisease'].mandatoryFlag){
      // this.inValidDateOfRecognition = false;
      this.additionaldetailsForm.controls.notApplicableCheckBox.enable();
     }else{
      // this.inValidDateOfRecognition = true;
      this.additionaldetailsForm.controls.notApplicableCheckBox.disable();
     }
   }

    
   
    this.additionaldetailsForm.controls.sickLeavePeriodNACheckBox.enable();
    this.additionaldetailsForm.controls.sickLeavePeriodFromDate.enable();
    this.additionaldetailsForm.controls.sickLeavePeriodToDate.enable();
    this.additionaldetailsForm.controls.dateOfRecognitionDisease.enable();
    this.additionaldetailsForm.controls.medicalTreatmentNotApplicable.enable();
    this.additionaldetailsForm.controls.medicalTreatmentStillUndergoing.enable();
    this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.enable();
    this.disableDateOfRecognitiontNotApplicable = null;
    this.disableSickLeavePeriod = null;
    this.disabledateCompletionOfMedicalTreatment = null;
    this.forwhatperiodError = false;
    this.additionaldetailsForm.get('forwhatperiod').setValue('');
    this.sportClubValidator();
    this.policeFieldValidator();
    // this.countryOnChange(this.additionaldetailsForm.get('country').value);
    // this.otherSportsClubCountryOnChange(this.additionaldetailsForm.get('sportsClubCountry').value);
  }

  formValid() {
    //console.log(this.disbursementForm.value);
    // console.log("benefitForm errorFormGroup",
    // this.createFormService.errorFormGroup(this.additionaldetailsForm));
    if (this.additionalRenderSecRules && this.additionalRenderSecRules.dateCompletionOfMedicalTreatment.renderFlag) {
      if (this.additionaldetailsForm.value.medicalTreatmentNotApplicable
        || (this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.value != null
          && this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.value != '')
        || (this.additionaldetailsForm.value.medicalTreatmentStillUndergoing
          && this.additionaldetailsForm.controls.medicalTreatmentStillUndergoing.value != '')) {
        this.medicalChecboxError = false;

      } else {
        this.medicalChecboxError = true;
      }
      if (this.additionaldetailsForm.value.medicalTreatmentStillUndergoing
        || (this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.value != null
          && this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.value != '')
        || (this.additionaldetailsForm.value.medicalTreatmentNotApplicable
          && this.additionaldetailsForm.controls.medicalTreatmentNotApplicable.value != '')) {
        this.medicalTreatmentChecboxError = false;

      } else {
        this.medicalTreatmentChecboxError = true;
      }
    }
    if (this.additionalRenderSecRules.sickLeavePeriod.renderFlag) {
      if (this.additionaldetailsForm.value.sickLeavePeriodNACheckBox
        || (this.additionaldetailsForm.controls.sickLeavePeriodToDate.value != null
          && this.additionaldetailsForm.controls.sickLeavePeriodToDate.value != '')
        || (this.additionaldetailsForm.controls.sickLeavePeriodFromDate.value != null
          && this.additionaldetailsForm.controls.sickLeavePeriodFromDate.value != '')) {
        this.sickLeaveChecboxError = false;

      } else {
        this.sickLeaveChecboxError = true;
      }
    }
    if (this.additionalRenderSecRules.dateOfRecognitionDisease.renderFlag ||
      (!utils.isEmpty(this.additionalRenderSecRulesBO) && this.additionalRenderSecRulesBO.dateOfRecognitionDisease.renderFlag
       && this.eventInfoSecRules.eventRelatedTo.renderFlag
      )) {
      if ((this.additionaldetailsForm.value.notApplicableCheckBox)
        || (this.additionaldetailsForm.controls.dateOfRecognitionDisease.value != null
          && this.additionaldetailsForm.controls.dateOfRecognitionDisease.value != '')) {
        this.recognitionDiseaseChecboxError = false;

      } else {
        this.recognitionDiseaseChecboxError = true;
      }
    }

    if (this.additionalRenderSecRules.forwhatperiod.renderFlag) {
      if (this.additionaldetailsForm.value.forwhatperiod != '') {
        this.forwhatperiodError = false;

      } else {
        this.forwhatperiodError = true;
      }
    }
    if (this.additionaldetailsForm.valid && !this.forwhatperiodError && !this.recognitionDiseaseChecboxError && !this.sickLeaveChecboxError
      && !this.medicalTreatmentChecboxError && !this.medicalChecboxError && !this.inValidDateOfSymtomDisease && !this.inValidDateOfRecognition
      && !this.inValidsickLeavetoDate && !this.inValidMedicalTreatmentDate && !this.inValidemplymentFromDate && !this.inValidemplymentToDate) {
      // console.log("this.add", this.additionaldetailsForm.valid)
      // console.log("this.additionaldetailsForm", this.additionaldetailsForm)
      return true;
    } else {
      // console.log("this.add false", this.additionaldetailsForm.valid)
      // console.log("this.additionaldetailsForm", this.additionaldetailsForm)
      return false;

    }

  }

  formSubmit() {
    // console.log("this.eve", this.eventInformationForm)
    // console.log("this.eve", this.eventInformationForm.valid)
    // console.log("this.additionaldetailsForm", this.additionaldetailsForm.valid);
    let formDetails = {
      formInfo: null,
      isFormValid: this.formValid()
    }
    this.newClaimService.setParamValue('additionalDetailsOldValue',this.additionaldetailsForm.value);
    return formDetails;
  }


  inValidsickLeavetoDate: boolean = false;
  validateSickLeavePeriodToDate(event) {
    let toDate = '';
    let fromDate = '';
    if (this.additionaldetailsForm.controls.sickLeavePeriodToDate.value)
      toDate = this.getMMDDYYYY(this.additionaldetailsForm.controls.sickLeavePeriodToDate.value);
    if (this.additionaldetailsForm.controls.sickLeavePeriodFromDate.value)
      fromDate = this.getMMDDYYYY(this.additionaldetailsForm.controls.sickLeavePeriodFromDate.value);
    //const chkBx = document.getElementById('sickLeavePeriodNACheckBoxId') as HTMLInputElement;
    const chkBx = this.additionaldetailsForm.controls.sickLeavePeriodNACheckBox;
    this.additionaldetailsForm.controls.sickLeavePeriod.setValue(fromDate);
    if (fromDate || toDate) {
      if (!chkBx.disabled) {
        this.additionaldetailsForm.controls.sickLeavePeriodNACheckBox.disable();
        this.sickLeaveChecboxError = false;
      }
    } else {
      this.additionaldetailsForm.controls.sickLeavePeriodNACheckBox.enable();
      this.sickLeaveChecboxError = true;
    }
    if (toDate && fromDate) {
      let flag = this.dateCheck(fromDate, toDate);
      if (flag) {
        this.inValidsickLeavetoDate = true;
        this.additionaldetailsForm.controls.sickLeavePeriodToDate['invalidFlag'] = this.inValidsickLeavetoDate;
      } else {
        this.inValidsickLeavetoDate = false;
        this.additionaldetailsForm.controls.sickLeavePeriodToDate['invalidFlag'] = this.inValidsickLeavetoDate;
      }
    }

   
  }
  // fromDateChange(){
  // }
  flag: boolean = false;
  inValidemplymentToDate: boolean = false;
  inValidemplymentFromDate: boolean = false;
  validateEmploymentPeriodToDate(event) {
    let toDate = '';
    let fromDate = '';
    if (this.additionaldetailsForm.controls.employmentPeriodToDate.value)
      toDate = this.getMMDDYYYY(this.additionaldetailsForm.controls.employmentPeriodToDate.value);
    if (this.additionaldetailsForm.controls.employmentPeriodFromDate.value)
      fromDate = this.getMMDDYYYY(this.additionaldetailsForm.controls.employmentPeriodFromDate.value);

    if (event.targetElement.name === "fromDate") {

      let today = this.getMMDDYYYY(new Date());
      let selectedDate = this.getMMDDYYYY(event.value);
      let futureDateFlag = this.dateCheck(selectedDate, today);
      if (futureDateFlag) {
        this.inValidemplymentFromDate = true;
        this.additionaldetailsForm.controls.employmentPeriodFromDate['invalidFlag'] = this.inValidemplymentFromDate;
      }
      else {
        this.inValidemplymentFromDate = false;
        this.additionaldetailsForm.controls.employmentPeriodFromDate['invalidFlag'] = this.inValidemplymentFromDate;
      }
    }

    if (toDate && fromDate) {
      let flag = this.dateCheck(fromDate, toDate);

      if (flag) {
        this.inValidemplymentToDate = true;
        this.additionaldetailsForm.controls.employmentPeriodToDate['invalidFlag'] = this.inValidemplymentToDate;
      } else {
        this.inValidemplymentToDate = false;
        this.additionaldetailsForm.controls.employmentPeriodToDate['invalidFlag'] = this.inValidemplymentToDate;
      }
    }
    this.additionaldetailsForm.controls.employmentPeriod.setValue(fromDate)
  }
  dateCheck(fromDate, toDate) {
    if (new Date(fromDate) > new Date(toDate))
      return true;
    else
      return false;
  }

  getMMDDYYYY(date) {
    let today = new Date(date);
    let dd = today.getDate();
    let mm = today.getMonth() + 1;
    let yyyy = today.getFullYear();

    if (dd < 10)
      dd = dd;
    if (mm < 10)
      mm = mm;
    return mm + '/' + dd + '/' + yyyy;
  }

  setDefaultCode() {

    this.additionaldetailsForm.get('country').setValue(this.defaultLanguage.toUpperCase());
    this.additionaldetailsForm.get('sportsClubCountry').setValue(this.defaultLanguage.toUpperCase());



  }
  queriesValueChanged(){
    // this.attachmentReset();
  }
   
attachmentReset(){
  try{
    let fileInAttachment = this.dataService.getOption('uploadNewClaimList');
    if (fileInAttachment && fileInAttachment.fileUpload && fileInAttachment.fileUpload.length > 0) {
      this.dialogService.openDialog(AlertDialogComponent, { 'heading': this.translate.instant('eClaims.existingClaim.confirmationLabel'), 'body': this.translate.instant('reAttachDocument'), 'primaryButton': 'OK', 'fromTypeofevent': true });
    }
   } catch(e){
console.log("error",e);
   }
}
  workContractOnChange(event) {
    // this.workContractChange.emit(this.workContract);
    this.forwhatperiodError = false
    // let forwhatPrdComp = document.getElementById('workContract') as HTMLInputElement;
    if (this.additionaldetailsForm.value.forwhatperiod == "Determined" || this.additionaldetailsForm.value.forwhatperiod == "Undetermined") {
      // forwhatPrdComp.classList.add('otherValuecss');
      // forwhatPrdComp.classList.remove('firstValuecss');
      this.forwhatperiodError = false
    } else {
      this.forwhatperiodError = true
      // forwhatPrdComp.classList.remove('otherValuecss');
      // forwhatPrdComp.classList.add('firstValuecss');
    }
  }
  

  onInjurySportClubLabel(value) {
    //console.log("onInjurySportClubLabel", value)
    let sportClubFields = ['sportsClubName',
      'sportsClubCountyName',
      'sportsClubZipCode',
      'sportsClubCity',
      'sportsClubStreetName',
      'sportsClubHouseNumber',
      'sportsClubFlatNo',
      'sportsClubBlock',
      'sportsClubEntrance',
      'sportsClubAppartment',
      'sportsClubSector',
      'sportsClubCountry',
      'otherSportsClubCountry',
      'sportsClubPostalCode',
      'sportsClubPoliceTown',
      'sportsClubPostBox']
    if (value == 'yes') {
      this.displayInjurySportClubLabel = true
      for (let j = 0; j < sportClubFields.length; j++) {
        if (this.additionalRenderSecRules[sportClubFields[j]] 
          && this.additionalRenderSecRules[sportClubFields[j]].renderFlag 
          && this.additionalRenderSecRules[sportClubFields[j]].mandatoryFlag) {
          // this.additionaldetailsForm.controls[sportClubFields[j]].setValidators([Validators.required]);
          // this.additionaldetailsForm.controls[sportClubFields[j]].updateValueAndValidity();
          this.additionaldetailsForm.controls[sportClubFields[j]].enable();
        }
      }
      this.otherSportsClubCountryOnChange(this.additionaldetailsForm.get('sportsClubCountry').value);
    } else {
      this.displayInjurySportClubLabel = false
      for (let j = 0; j < sportClubFields.length; j++) {
        if (this.additionalRenderSecRules[sportClubFields[j]] &&
           this.additionalRenderSecRules[sportClubFields[j]].renderFlag && 
           this.additionalRenderSecRules[sportClubFields[j]].mandatoryFlag) {
          // this.additionaldetailsForm.controls[sportClubFields[j]].setValidators([Validators.nullValidator]);
          // this.additionaldetailsForm.controls[sportClubFields[j]].updateValueAndValidity();
          this.additionaldetailsForm.controls[sportClubFields[j]].disable();
        }
      }
    }

  }
  
  
  onPoliceConductedInvestigation(value) {
    //console.log("PoliceConductedInvestigation", value)
    let policeFields = ['nameInvestigationEntities',
      'county',
      'zipCode',
      'city',
      'streetName',
      'houseNumber',
      'flatNo',
      'block',
      'entrance',
      'appartment',
      'sector',
      'country',
      'otherCountry',
      'postalCode',
      'town',
      'postBox',
      'caseNumber']


    if (value == 'yes') {
      this.displayPoliceConductedInvestigation = true

      for (let j = 0; j < policeFields.length; j++) {
        if (this.additionalRenderSecRules[policeFields[j]]
          && this.additionalRenderSecRules[policeFields[j]].renderFlag 
          && this.additionalRenderSecRules[policeFields[j]].mandatoryFlag) {
          // this.additionaldetailsForm.controls[policeFields[j]].setValidators([Validators.required]);
          // this.additionaldetailsForm.controls[policeFields[j]].updateValueAndValidity();
          this.additionaldetailsForm.controls[policeFields[j]].enable();
        }
      }
      this.countryOnChange(this.additionaldetailsForm.get('country').value);
    } else {
      this.displayPoliceConductedInvestigation = false
      for (let j = 0; j < policeFields.length; j++) {
        if (this.additionalRenderSecRules[policeFields[j]] && this.additionalRenderSecRules[policeFields[j]].renderFlag && this.additionalRenderSecRules[policeFields[j]].mandatoryFlag) {
          // this.additionaldetailsForm.controls[policeFields[j]].setValidators([Validators.nullValidator]);
          // this.additionaldetailsForm.controls[policeFields[j]].updateValueAndValidity();
          this.additionaldetailsForm.controls[policeFields[j]].disable();
        }
      }
    }

  }

  checkBoxdateOfRecognitionDisease(event) {
    // //console.log(event)
    if (event.target.checked) {
      // //console.log(event," isChecked: boolean")
      this.recognitionDiseaseChecboxError = false;
      this.additionaldetailsForm.controls.dateOfRecognitionDisease.disable()
      this.disableDateOfRecognitiontNotApplicable = 'true'
    } else {
      // //console.log(event," isChecked: boolean")
      this.recognitionDiseaseChecboxError = true;
      this.additionaldetailsForm.controls.dateOfRecognitionDisease.enable()
      this.disableDateOfRecognitiontNotApplicable = null
    }
  }
  checkBoxsickLeavePeriodToDate(event) {
    if (event) {
      // //console.log(event," isChecked: boolean")
      this.sickLeaveChecboxError = false;
      this.additionaldetailsForm.controls.sickLeavePeriod.disable()
      this.additionaldetailsForm.controls.sickLeavePeriodFromDate.disable()
      this.additionaldetailsForm.controls.sickLeavePeriodToDate.disable()
      this.disableSickLeavePeriod = 'true'
    } else {
      // //console.log(event," isChecked: boolean")
      this.sickLeaveChecboxError = true;
      this.additionaldetailsForm.controls.sickLeavePeriod.enable()
      this.additionaldetailsForm.controls.sickLeavePeriodFromDate.enable()
      this.additionaldetailsForm.controls.sickLeavePeriodToDate.enable()
      this.disableSickLeavePeriod = null
    }
  }
  inValidDateOfRecognition: boolean = false;
  onDateOfRecognitionDisease(event) {
    this.inValidDateOfRecognition = false;
    // //console.log("disable Field",e.target.value)
    let today = this.getMMDDYYYY(new Date());
    let selectedDate = this.getMMDDYYYY(event.value);
    let flag = this.dateCheck(selectedDate, today);

    if (event.value != null) {
      // //console.log("disable Field",e.target.value)
      this.recognitionDiseaseChecboxError = false;
      this.additionaldetailsForm.controls.notApplicableCheckBox.disable()
      if (flag) {
        this.inValidDateOfRecognition = true;
        this.additionaldetailsForm.controls.dateOfRecognitionDisease['invalidFlag'] = this.inValidDateOfRecognition;
      }
      else {
        this.inValidDateOfRecognition = false;
        this.additionaldetailsForm.controls.dateOfRecognitionDisease['invalidFlag'] = this.inValidDateOfRecognition;
      }
    } else {
      // //console.log("disable disable Field",e.target.value)
      this.recognitionDiseaseChecboxError = true;
      this.additionaldetailsForm.controls.notApplicableCheckBox.enable()
    }
  }
  inValidDateOfSymtomDisease: boolean = false;
  onDateFirstSymtomsDisease(event) {
    this.inValidDateOfSymtomDisease = false;
    let today = this.getMMDDYYYY(new Date());
    let selectedDate = this.getMMDDYYYY(event.value);
    let flag = this.dateCheck(selectedDate, today);
    if (flag) {
      this.inValidDateOfSymtomDisease = true;
      this.additionaldetailsForm.controls.dateOffirstSymptomsDisease['invalidFlag'] = this.inValidDateOfSymtomDisease;
    } else {
      this.inValidDateOfSymtomDisease = false;
      this.additionaldetailsForm.controls.dateOffirstSymptomsDisease['invalidFlag'] = this.inValidDateOfSymtomDisease;
    }
  }

  inValidMedicalTreatmentDate: boolean = false;
  changedateCompletionOfMedicalTreatment(event) {
    // console.log("changedateCompletionOfMedicalTreatment", event.value)
    this.inValidMedicalTreatmentDate = false;
    let today = this.getMMDDYYYY(new Date());
    let selectedDate = this.getMMDDYYYY(event.value);
    let flag = this.dateCheck(selectedDate, today);

    if (event.value != null) {
      // this.disableMedicalTreatmentNotApplicable = 'true';
      // this.disableMedicalTreatmentStillUndergoing = 'true';
      this.medicalChecboxError = false;
      this.medicalTreatmentChecboxError = false;
      this.additionaldetailsForm.controls.medicalTreatmentNotApplicable.disable()
      this.additionaldetailsForm.controls.medicalTreatmentStillUndergoing.disable()
      if (flag) {
        this.inValidMedicalTreatmentDate = true;
        this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment['invalidFlag'] = this.inValidMedicalTreatmentDate;
      }
      else {
        this.inValidMedicalTreatmentDate = false;
        this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment['invalidFlag'] = this.inValidMedicalTreatmentDate;
      }


    } else {
      // this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.markAsUntouched();
      // this.disableMedicalTreatmentNotApplicable = null
      // this.disableMedicalTreatmentStillUndergoing = null
      this.medicalChecboxError = true;
      this.medicalTreatmentChecboxError = true;
      this.additionaldetailsForm.controls.medicalTreatmentStillUndergoing.enable()
      this.additionaldetailsForm.controls.medicalTreatmentNotApplicable.enable()
    }
  }

  onMedicalTreatmentNotApplicable(event, value) {
    if (event) {
      // this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.markAsUntouched();
      this.disabledateCompletionOfMedicalTreatment = 'true';
      // this.disableMedicalTreatmentStillUndergoing = 'true';
      this.medicalChecboxError = false;
      this.medicalTreatmentChecboxError = false;
      this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.disable()
      this.additionaldetailsForm.controls.medicalTreatmentStillUndergoing.disable()
    } else {
      // this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.setValue('');
      this.disabledateCompletionOfMedicalTreatment = null
      // this.disableMedicalTreatmentStillUndergoing = null
      this.medicalChecboxError = true;
      this.medicalTreatmentChecboxError = true;
      this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.enable()
      this.additionaldetailsForm.controls.medicalTreatmentStillUndergoing.enable()
    }
  }
  onMedicalTreatmentStillUndergoing(event, value) {

    if (event) {
      // this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.markAsUntouched();
      // this.disableMedicalTreatmentNotApplicable = 'true';
      this.disabledateCompletionOfMedicalTreatment = 'true';
      this.medicalChecboxError = false;
      this.medicalTreatmentChecboxError = false;
      this.additionaldetailsForm.controls.medicalTreatmentNotApplicable.disable()
      this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.disable()
    } else {
      // this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.setValue('');
      // this.disableMedicalTreatmentNotApplicable = null
      this.disabledateCompletionOfMedicalTreatment = null
      this.medicalChecboxError = true
      this.medicalTreatmentChecboxError = true;
      this.additionaldetailsForm.controls.medicalTreatmentNotApplicable.enable()
      this.additionaldetailsForm.controls.dateCompletionOfMedicalTreatment.enable()
    }
  }

  countryOnChange(event) {
    this.additionaldetailsForm.get('postalCode').setValue(null);
    this.additionaldetailsForm.get('postBox').setValue(null);
    this.additionaldetailsForm.get('town').setValue(null);
    this.townFromPoCode = '';
    this.showTownOptionLabel = false;
    this.additionaldetailsForm.controls.otherCountry['isVisible'] = this.additionaldetailsForm.controls.country['isVisible']
    this.additionaldetailsForm.controls['otherCountry'].setValidators([Validators.nullValidator]);
    this.additionaldetailsForm.controls['otherCountry'].updateValueAndValidity();
    this.showCountryLabel = false;
    if ((this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1)
      && (event && event.toLowerCase() == this.defaultLanguage)) {
      // this.additionaldetailsForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);
    } else if (event && event.toLowerCase() == 'other') {
      this.showCountryLabel = true;
      this.additionaldetailsForm.controls.otherCountry.reset();
      this.additionaldetailsForm.controls['otherCountry'].setValidators([Validators.required]);
      this.additionaldetailsForm.controls['otherCountry'].updateValueAndValidity();
    }
    let claimData = this.newClaimService.getClaimData();
    let lob = (claimData ? claimData.newclaim : null);
    //console.log("personal details",lob)
    if (this.additionalRenderSecRules['postBox'].mandatoryFlag && event == 'US') {
      this.additionaldetailsForm.controls['postBox'].setValidators([Validators.required]);
      this.additionaldetailsForm.controls['postBox'].updateValueAndValidity();
    } else {
      this.additionaldetailsForm.controls['postBox'].setValidators([Validators.nullValidator]);
      this.additionaldetailsForm.controls['postBox'].updateValueAndValidity();
    }

    let countryValueRO = ['county', 'zipCode', 'city', 'block', 'entrance', 'appartment', 'sector'];
    let countryValueROField = ['flatNo', 'postalCode', 'town', 'postBox'];
    if (this.defaultLanguage == 'ro' || this.defaultLanguage == 'ro') {
      if (event.toLowerCase() == this.defaultLanguage) {
        for (let j = 0; j < countryValueRO.length; j++) {
          if (this.additionalRenderSecRules[countryValueRO[j]] && this.additionalRenderSecRules[countryValueRO[j]].renderFlag && this.additionalRenderSecRules[countryValueRO[j]].mandatoryFlag) {
            this.additionaldetailsForm.controls[countryValueRO[j]].enable();
          }
        }
        for (let j = 0; j < countryValueROField.length; j++) {
          if (this.additionalRenderSecRules[countryValueROField[j]] && this.additionalRenderSecRules[countryValueROField[j]].renderFlag && this.additionalRenderSecRules[countryValueROField[j]].mandatoryFlag) {
            this.additionaldetailsForm.controls[countryValueROField[j]].disable();
          }
        }
      } else {
        for (let j = 0; j < countryValueRO.length; j++) {
          if (this.additionalRenderSecRules[countryValueRO[j]] && this.additionalRenderSecRules[countryValueRO[j]].renderFlag && this.additionalRenderSecRules[countryValueRO[j]].mandatoryFlag) {
            this.additionaldetailsForm.controls[countryValueRO[j]].disable();
          }
        }
        for (let j = 0; j < countryValueROField.length; j++) {
          if (this.additionalRenderSecRules[countryValueROField[j]] && this.additionalRenderSecRules[countryValueROField[j]].renderFlag && this.additionalRenderSecRules[countryValueROField[j]].mandatoryFlag) {
            this.additionaldetailsForm.controls[countryValueROField[j]].enable();
          }
        }
      }
    }

    let validators = (this.postalcodeMaxlenthinit && this.postalcodeMaxlenthinit.required) ? Validators.required : Validators.nullValidator;
    if (this.defaultLanguage.toUpperCase() == 'PL' && this.additionaldetailsForm.get('country').value == 'PL') {
      this.additionaldetailsForm.controls.postalCode['restrict'].maxlength = this.postalcodeMaxlenthinit.length;
      this.additionaldetailsForm.controls.postalCode.setValidators([validators]);
    } else {
      this.additionaldetailsForm.controls.postalCode['restrict'].maxlength = 10;
      this.additionaldetailsForm.controls.postalCode.setValidators([validators]);
    }
  }

  blurPostalCodeField(event) {
    if (this.additionaldetailsForm.controls.postalCode.value == '' &&
      this.additionaldetailsForm.controls.country.value == this.defaultLanguage.toUpperCase()
      && this.showTownOptionLabel) {
      this.additionaldetailsForm.get('town').setValue(null);
      this.townFromPoCode = '';
    }
    this.showTownOptionLabel = false;
    //console.log("Postal Code")
    if (this.additionaldetailsForm.controls.postalCode.value &&
      this.additionaldetailsForm.controls.postalCode.value != '' &&
       (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1) &&
        this.additionaldetailsForm.controls.country.value == this.defaultLanguage.toUpperCase()) {
      //console.log("Postal Code")
      let value = this.additionaldetailsForm.controls.postalCode.value;
      let postalCodeValue = value;

      this.getPostalCodeValue(postalCodeValue,
        this.defaultLanguage.toUpperCase()).subscribe((data) => {
          // //console.log(data); 
          this.townOptions = data;
          //console.log(this.townOptions,"test",data[0])
          if (data.length > 0) {
            this.additionaldetailsForm.get('town').setValue(data[0]);
            this.showTownOptionLabel = true;
            this.townFromPoCode = '*';
          } else {
            this.additionaldetailsForm.get('town').setValue(null);
            this.showTownOptionLabel = false;
            this.townFromPoCode = '';
          }
        });
    }
  }


  getPostalCodeValue(event, countryCode) {
    let param = {
      "countryCode": countryCode,
      "language": "",
      "pinCode": event
    }
        const url = `${environment.host + environment.getPostalCode.url}`;
        return this.commonService[environment.getPostalCode.method](
          url,param);
      }

  blurSportsClubPostalCodeField(event) {
    if (this.additionaldetailsForm.controls.sportsClubPostalCode.value == '' &&
      this.additionaldetailsForm.controls.sportsClubCountry.value == this.defaultLanguage.toUpperCase()
      && this.showSportsClubPoliceTownOptionLabel) {
      this.additionaldetailsForm.get('sportsClubPoliceTown').setValue(null);
      this.sportsTownFromPoCode = '';
    }
    this.showSportsClubPoliceTownOptionLabel = false;
    //console.log("Postal Code")
    if (this.additionaldetailsForm.controls.sportsClubPostalCode.value != '' && (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1) && this.additionaldetailsForm.controls.sportsClubCountry.value == this.defaultLanguage.toUpperCase()) {
      //console.log("Postal Code")
      let value = this.additionaldetailsForm.controls.sportsClubPostalCode.value;
      let postalCodeValue = value;

      this.getPostalCodeValue(postalCodeValue,
        this.defaultLanguage.toUpperCase()).subscribe((data) => {
          // //console.log(data); 
          this.sportTownOptions = data;
          //console.log(this.sportTownOptions,"test",data[0])
          if (data.length > 0) {
            this.additionaldetailsForm.get('sportsClubPoliceTown').setValue(data[0]);
            this.showSportsClubPoliceTownOptionLabel = true;
            this.sportsTownFromPoCode = '*';
          } else {
            this.additionaldetailsForm.get('sportsClubPoliceTown').setValue(null);
            this.showSportsClubPoliceTownOptionLabel = false;
            this.sportsTownFromPoCode = '';
          }
        });
    }
  }
  otherSportsClubCountryOnChange(event) {
    this.additionaldetailsForm.get('sportsClubPostalCode').setValue('');
    this.additionaldetailsForm.get('sportsClubPostBox').setValue(null);
    this.additionaldetailsForm.get('sportsClubPoliceTown').setValue(null);
    this.showSportsClubPoliceTownOptionLabel = false;
    this.sportsTownFromPoCode = '';

    this.showSportsClubCountryLabel = false;
    this.additionaldetailsForm.controls.otherSportsClubCountry['isVisible'] = this.additionaldetailsForm.controls.sportsClubCountry['isVisible']
    this.additionaldetailsForm.controls['otherSportsClubCountry'].setValidators([Validators.nullValidator]);
    this.additionaldetailsForm.controls['otherSportsClubCountry'].updateValueAndValidity();
    if ((this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1)
      && (event.toLowerCase() == this.defaultLanguage)) {
      // this.additionaldetailsForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);
    } else if (event.toLowerCase() == 'other') {
      this.showSportsClubCountryLabel = true;
      this.additionaldetailsForm.controls.otherSportsClubCountry.reset();
      this.additionaldetailsForm.controls['otherSportsClubCountry'].setValidators([Validators.required]);
      this.additionaldetailsForm.controls['otherSportsClubCountry'].updateValueAndValidity();
    }

    let claimData = this.newClaimService.getClaimData();
    let lob = (claimData ? claimData.newclaim : null);
    //console.log("personal details",lob)
    if (this.additionalRenderSecRules['sportsClubPostBox'].mandatoryFlag && event == 'US') {
      this.additionaldetailsForm.controls['sportsClubPostBox'].setValidators([Validators.required]);
      this.additionaldetailsForm.controls['sportsClubPostBox'].updateValueAndValidity();
    } else {
      this.additionaldetailsForm.controls['sportsClubPostBox'].setValidators([Validators.nullValidator]);
      this.additionaldetailsForm.controls['sportsClubPostBox'].updateValueAndValidity();
    }

    let countryValueRO = ['sportsClubCountyName', 'sportsClubZipCode', 'sportsClubCity', 'sportsClubBlock', 'sportsClubEntrance', 'sportsClubAppartment', 'sportsClubSector'];
    let countryValueROField = ['sportsClubFlatNo', 'sportsClubPostalCode', 'sportsClubPoliceTown', 'sportsClubPostBox'];
    if (this.defaultLanguage == 'ro') {
      if (event.toLowerCase() == this.defaultLanguage) {
        for (let j = 0; j < countryValueRO.length; j++) {
          if (this.additionalRenderSecRules[countryValueRO[j]] && this.additionalRenderSecRules[countryValueRO[j]].renderFlag && this.additionalRenderSecRules[countryValueRO[j]].mandatoryFlag) {
            this.additionaldetailsForm.controls[countryValueRO[j]].enable();
          }
        }
        for (let j = 0; j < countryValueROField.length; j++) {
          if (this.additionalRenderSecRules[countryValueROField[j]] && this.additionalRenderSecRules[countryValueROField[j]].renderFlag && this.additionalRenderSecRules[countryValueROField[j]].mandatoryFlag) {
            this.additionaldetailsForm.controls[countryValueROField[j]].disable();
          }
        }
      } else {
        for (let j = 0; j < countryValueRO.length; j++) {
          if (this.additionalRenderSecRules[countryValueRO[j]] && this.additionalRenderSecRules[countryValueRO[j]].renderFlag && this.additionalRenderSecRules[countryValueRO[j]].mandatoryFlag) {
            this.additionaldetailsForm.controls[countryValueRO[j]].disable();
          }
        }
        for (let j = 0; j < countryValueROField.length; j++) {
          if (this.additionalRenderSecRules[countryValueROField[j]] && this.additionalRenderSecRules[countryValueROField[j]].renderFlag && this.additionalRenderSecRules[countryValueROField[j]].mandatoryFlag) {
            this.additionaldetailsForm.controls[countryValueROField[j]].enable();
          }
        }
      }
    }

    let validators = this.sportsClubPostalCodeInit.required ? Validators.required : Validators.nullValidator;
    if (this.defaultLanguage.toUpperCase() == 'PL' && this.additionaldetailsForm.get('sportsClubCountry').value == 'PL') {
      this.additionaldetailsForm.controls.sportsClubPostalCode['restrict'].maxlength = this.sportsClubPostalCodeInit.length;
      this.additionaldetailsForm.controls.sportsClubPostalCode.setValidators([validators]);
    } else {
      this.additionaldetailsForm.controls.sportsClubPostalCode['restrict'].maxlength = 10;
      this.additionaldetailsForm.controls.sportsClubPostalCode.setValidators([validators]);
    }
  }


  public masking = {
    guide: false,
    showMask: true,
    mask: [/\d/, /\d/, '-', /\d/, /\d/, /\d/]
  };
  additionalRenderSecRulesBOFunc(event) {
    this.additionalRenderSecRulesBO = event
  }
  sportClubValidator() {
    let sportClubFields = ['sportsClubName',
      'sportsClubCountyName',
      'sportsClubZipCode',
      'sportsClubCity',
      'sportsClubStreetName',
      'sportsClubHouseNumber',
      'sportsClubFlatNo',
      'sportsClubBlock',
      'sportsClubEntrance',
      'sportsClubAppartment',
      'sportsClubSector',
      'sportsClubCountry',
      'otherSportsClubCountry',
      'sportsClubPostalCode',
      'sportsClubPoliceTown',
      'sportsClubPostBox']

    if ((this.additionalRenderSecRules && this.additionalRenderSecRules.sportsClubPlayerDropDown.renderFlag) ||
      (!utils.isEmpty(this.additionalRenderSecRulesBO) &&
       this.additionalRenderSecRulesBO.sportsClubPlayerDropDown.renderFlag)) {

      for (let j = 0; j < sportClubFields.length; j++) {if (this.additionalRenderSecRules[sportClubFields[j]]) {

        if(this.additionalRenderSecRules[sportClubFields[j]].renderFlag && 
          this.additionalRenderSecRules[sportClubFields[j]].mandatoryFlag){
            this.additionaldetailsForm.controls[sportClubFields[j]].setValidators([Validators.required]);
            this.additionaldetailsForm.controls[sportClubFields[j]].updateValueAndValidity();
        
          }

          if(!this.additionalRenderSecRules[sportClubFields[j]].renderFlag){
            this.additionaldetailsForm.controls[sportClubFields[j]].setValue(null);
          }
      }
      }

    } else {
      for (let j = 0; j < sportClubFields.length; j++) {
        if (this.additionalRenderSecRules[sportClubFields[j]]) {

          if(this.additionalRenderSecRules[sportClubFields[j]].renderFlag && 
            this.additionalRenderSecRules[sportClubFields[j]].mandatoryFlag){
              this.additionaldetailsForm.controls[sportClubFields[j]].setValidators([Validators.nullValidator]);
              this.additionaldetailsForm.controls[sportClubFields[j]].updateValueAndValidity();
          
            }

            if(!this.additionalRenderSecRules[sportClubFields[j]].renderFlag){
              this.additionaldetailsForm.controls[sportClubFields[j]].setValue(null);
            }
        }
      }
    }
  }

  policeFieldValidator() {
    let policeFields = ['nameInvestigationEntities',
      'county',
      'zipCode',
      'city',
      'streetName',
      'houseNumber',
      'flatNo',
      'block',
      'entrance',
      'appartment',
      'sector',
      'country',
      'otherCountry',
      'postalCode',
      'town',
      'postBox',
      'caseNumber']

    // (this.additionalRenderSecRulesBO &&  this.additionalRenderSecRulesBO.policeConductedInvestigation.renderFlag)
    if ((this.additionalRenderSecRules && 
      this.additionalRenderSecRules.policeConductedInvestigation.renderFlag) ||
      (!utils.isEmpty(this.additionalRenderSecRulesBO) && 
      this.additionalRenderSecRulesBO.policeConductedInvestigation.renderFlag)
    ) {

      for (let j = 0; j < policeFields.length; j++) {
        if (this.additionalRenderSecRules[policeFields[j]] ) {

         if(this.additionalRenderSecRules[policeFields[j]].renderFlag 
          && this.additionalRenderSecRules[policeFields[j]].mandatoryFlag){
          this.additionaldetailsForm.controls[policeFields[j]].setValidators([Validators.required]);
          this.additionaldetailsForm.controls[policeFields[j]].updateValueAndValidity();
        }
        if(!this.additionalRenderSecRules[policeFields[j]].renderFlag){
          this.additionaldetailsForm.controls[policeFields[j]].setValue(null); 
        }

      }
      }
    } else {
      for (let j = 0; j < policeFields.length; j++) {
        if (this.additionalRenderSecRules[policeFields[j]]) {
          
          if(this.additionalRenderSecRules[policeFields[j]].renderFlag && 
            this.additionalRenderSecRules[policeFields[j]].mandatoryFlag){
            this.additionaldetailsForm.controls[policeFields[j]].setValidators([Validators.nullValidator]);
            this.additionaldetailsForm.controls[policeFields[j]].updateValueAndValidity();
         
          }
          if(!this.additionalRenderSecRules[policeFields[j]].renderFlag){
            this.additionaldetailsForm.controls[policeFields[j]].setValue(null); 
          }
          
        }
      }
    }
  }

   isRequired(cntrlName) {
    const form_field =  this.additionaldetailsForm.get(cntrlName);
    //eventDetailFormControl.controls?.additionalFieldDetailsSection
    //console.log(form_field);
    if (!form_field || !form_field.validator) {
      return false;
  }
  const validator = form_field.validator({} as AbstractControl);
      return (validator && validator.required);
      
  }

}
