import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { EventInformationSecComponent } from './event-information-sec.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SectionReqConfigService } from '../../personal-details/personal-details.model';
import {  FormGroup, FormControl, Validators, FormArray, AbstractControl,FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NewClaimSharedService } from '../../add-new-claim.service';

export class EventInfoRulesMock {
  eventInfoMock = {"ruleFileName":"Eclaims_Event_Details_RelatedEvent.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","selectedClaim":"E160","dateOfEvent":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"placeOfEvent":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"eventRelatedTo":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"causeOfEvent":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"300","fieldminlength":"0","allowedDataType":","},"descriptionOfEvent":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"0","fieldminlength":"0","allowedDataType":","},"dateLabel":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"eventRelatedToValues":"sickness|accidental|suicide","ksession":null}
}


describe('EventInformationSecComponent', () => {
  let component: EventInformationSecComponent;
  let fixture: ComponentFixture<EventInformationSecComponent>;
  const fb: FormBuilder = new FormBuilder();
  //const secValidations: PersonalRuleMock = new PersonalRuleMock();
  const eventInfoSecValidations: EventInfoRulesMock = new EventInfoRulesMock();
  const newClaimService: NewClaimSharedService = new NewClaimSharedService();
 
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientTestingModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ EventInformationSecComponent ],
      providers : [ SectionReqConfigService,
        { provide : HttpClient },{ provide: FormBuilder, useValue: fb } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    if(!(sessionStorage.getItem('userData'))){
      let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
   
    fixture = TestBed.createComponent(EventInformationSecComponent);
    component = fixture.componentInstance;
    
    
let eventInfo={
  dateOfEvent:  null,
  dateOfBirth:  null,
  dateLabel: null,
  placeOfEvent: null,
  eventRelatedTo: null,
  causeOfEvent:  null,
  descriptionOfEvent:  null
};
component.eventInformationForm =  fb.group(eventInfo);

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
