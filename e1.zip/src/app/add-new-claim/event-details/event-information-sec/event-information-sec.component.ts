import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { ScreenRenderReqModel } from '../../models/ScreenRenderReqModel';
import { SectionReqConfigService } from '../../personal-details/personal-details.model';
import { TranslateService } from '@ngx-translate/core';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { EventDetailsComponent } from '../event-details.component';
import { CreateFormService } from '../../../shared/services/create-form.service';
import { DataService } from 'src/app/shared/services/data.service';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';


@Component({
  selector: 'event-information-sec',
  templateUrl: './event-information-sec.component.html',
  styleUrls: ['./event-information-sec.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EventInformationSecComponent implements OnInit {
  @Input() eventInformationForm: FormGroup;
  @Input() eventInformationSectionValue: boolean;
  eventRelatedToValueDetail = []

  @Output() eventRelatedToValue: EventEmitter<Event> = new EventEmitter();
  baseUrl = environment.host + environment.eventDetailServiceConfig.url;
  headers = new HttpHeaders();
  screenRequestObj: ScreenRenderReqModel = new ScreenRenderReqModel();
  jsonObj = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.jsonObj.sourceOrigin;
  centerPeriodFromMax = new Date();
  centerPeriodFromMin = new Date(eClaimsConstants.dobMinYear, eClaimsConstants.dobMinMnth, eClaimsConstants.dobMinDate);
  partner: string = 'metlife';
  product: string = '';
  eventRelatedToLableDetail = [];
  eventRelatedToSec: boolean;

  constructor(private commonService: HttpCommonService,
    public eventSecReqConfig: SectionReqConfigService,
    public translate: TranslateService,
    public createFormService: CreateFormService,
    public dataService: DataService,
    public dialogService: DialogService) {

  }
  eventInformationDateOfBirthValue: boolean;
  eventInformationDateOfEventValue: boolean;
  invalidDateOfEvent: boolean = false;
  changeDOE(event) {
    this.invalidDateOfEvent = false;
    let today = this.getMMDDYYYY(new Date());
    let selectedDate = this.getMMDDYYYY(event.value);
    let flag = this.dateCheck(selectedDate, today);
    if (flag) {
      this.invalidDateOfEvent = true;
      this.eventInformationForm.controls.dateOfEvent['invalidFlag'] = this.invalidDateOfEvent;
    } else {
      this.invalidDateOfEvent = false;
      this.eventInformationForm.controls.dateOfEvent['invalidFlag'] = this.invalidDateOfEvent;
    }
  }
  invalidDateOfBirth: boolean = false;
  changeDOB(event) {

    this.invalidDateOfBirth = false;
    let today = this.getMMDDYYYY(new Date());
    let selectedDate = this.getMMDDYYYY(event.value);
    let flag = this.dateCheck(selectedDate, today);
    if (flag) {
      this.invalidDateOfBirth = true;
    } else {
      this.invalidDateOfBirth = false;
    }
  }
  dateCheck(fromDate, toDate) {
    if (new Date(fromDate) > new Date(toDate))
      return true;
    else
      return false;
  }

  getMMDDYYYY(date) {
    let today = new Date(date);
    let dd = today.getDate();
    let mm = today.getMonth() + 1;
    let yyyy = today.getFullYear();

    if (dd < 10)
      dd = dd;
    if (mm < 10)
      mm = mm;
    return mm + '/' + dd + '/' + yyyy;
  }

  formInit() {
    this.invalidDateOfBirth = false;
    this.invalidDateOfEvent = false;

    //console.log(this.eventInformationSectionValue);
    if (this.eventInformationSectionValue) {
      this.eventRelatedToLableDetail = [];
      let eventDetailInfoSec = this.eventSecReqConfig.rulesRequestParam('EventDetailEventInformationSectionRender');
      this.commonService[environment.eventDetailServiceConfig.method](this.baseUrl, eventDetailInfoSec, this.headers)
        //this.commonService.getData(flagtest1)
        .subscribe((dataValue) => {
          //console.log("-------> ", dataValue);
          ///this.clearradioButtons();
          this.eventRelatedToValueDetail = dataValue.eventRelatedToValues.split('|')

          for (let i = 0; i < this.eventRelatedToValueDetail.length; i++) {
            this.eventRelatedToLableDetail.push(this.eventRelatedToValueDetail[i])
          }
          let eventRelatedToValue = this.eventInformationForm.get('eventRelatedTo').value ;
          if(eventRelatedToValue && eventRelatedToValue!='' && this.eventRelatedToLableDetail.indexOf(eventRelatedToValue)!=-1){
            this.getMessage(this.eventInformationForm.get('eventRelatedTo').value);
          }

         
        });
    }
    let countryValue = JSON.parse(sessionStorage.getItem("userData"));
    let eventDetailInfoSec = this.eventSecReqConfig.rulesRequestParam('EventDetailEventInformationSectionRender');

    // if (countryValue.displayLanguages === 'pl') {
    //   if ("E020" === eventDetailInfoSec.primaryClaimEvent ||
    //     "E030" === eventDetailInfoSec.primaryClaimEvent && "Group" === eventDetailInfoSec.lob) {

    //     this.eventInformationDateOfBirthValue = true;
    //     this.eventInformationDateOfEventValue = false;

    //   } else {
    //     this.eventInformationDateOfBirthValue = false;
    //     this.eventInformationDateOfEventValue = true;
    //   }
    // } else {
    //   this.eventInformationDateOfEventValue = true;
    // }


}
  ngOnInit() {
    this.formInit();
  }

  formSubmit() {
    // console.log("this.eve", this.eventInformationForm)
    // console.log("this.eve", this.eventInformationForm.valid)
    let formDetails = {
      formInfo: null,
      isFormValid: this.formValid()
    }

    return formDetails;
  }

  formValid() {
    // console.log("benefitForm errorFormGroup",
    // this.createFormService.errorFormGroup(this.eventInformationForm));
    if (this.eventInformationForm.valid && !this.invalidDateOfBirth && !this.invalidDateOfEvent) {
      return true;
    } else {
      return false;
    }

  }

  getMessage(message) {

    this.eventRelatedToValue.emit(message);
    this.attachmentReset();
    //console.log("eventRelatedTo",message)
  }
  attachmentReset(){
    try{
      let fileInAttachment = this.dataService.getOption('uploadNewClaimList');
      if (fileInAttachment && fileInAttachment.fileUpload && fileInAttachment.fileUpload.length > 0) {
        this.dialogService.openDialog(AlertDialogComponent, { 'heading': this.translate.instant('eClaims.existingClaim.confirmationLabel'), 'body': this.translate.instant('reAttachDocument'), 'primaryButton': 'OK', 'fromTypeofevent': true });
      }
     } catch(e){
  console.log("error",e);
     }
  }

}
