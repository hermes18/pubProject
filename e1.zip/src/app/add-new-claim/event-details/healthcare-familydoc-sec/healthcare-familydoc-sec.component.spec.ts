import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { HealthcareFamilydocSecComponent } from './healthcare-familydoc-sec.component';
import { SharedModule} from 'src/app/shared/shared.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormArray, FormControl } from '@angular/forms';
import { InformationHealthCareFamilyDocModel } from '../event-details.model';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

export class FamilyDocRulesMock {
  familyDocMock = {"ruleFileName":"Eclaims_Event_Details_HealthCareFamilyDoctor.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","selectedClaim":"E160","familyDoctorName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"familyDoctorStreetName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"familyDoctorHouseNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"familyDoctorFlatNumber":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"0","fieldminlength":"0","allowedDataType":","},"familyDoctorCountry":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":","},"familyDoctorPostalCode":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"familyDoctorPhoneNumber":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"0","fieldminlength":"0","allowedDataType":","},"familyDoctorPostBox":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":","},"familyDoctorTown":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"50","fieldminlength":"0","allowedDataType":","},"ksession":null};
}


describe('HealthcareFamilydocSecComponent', () => {
  let component: HealthcareFamilydocSecComponent;
  let fixture: ComponentFixture<HealthcareFamilydocSecComponent>;
  const fb: FormBuilder = new FormBuilder();
  //const secValidations: PersonalRuleMock = new PersonalRuleMock();
  const familyDocValidations: FamilyDocRulesMock = new FamilyDocRulesMock();
  const newClaimService: NewClaimSharedService = new NewClaimSharedService();
 
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientTestingModule,
        FormsModule,BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ HealthcareFamilydocSecComponent ],
      providers: [ { provide: FormBuilder, useValue: fb },
      {provide: HttpClient } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {

    let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(HealthcareFamilydocSecComponent);
    component = fixture.componentInstance;
    component.healthCareDoctorEventSecRules=familyDocValidations.familyDocMock;
    //let informationHealthCareFamilyDocModel: InformationHealthCareFamilyDocModel = new InformationHealthCareFamilyDocModel();
    let familyDocModel = {familyDoctorName:  null,
      familyDoctorStreetName:  null,
      familyDoctorHouseNumber:  null,
      familyDoctorFlatNumber:  null,
      familyDoctorCountry:  null,
      familyDoctorPostalCode:  null,
      familyDoctorPhoneNumber:  null,
      familyDoctorPostBox:  null,
      familyDoctorTown:  null,
      familyDoctorOtherCountry:  null,}
    component.healthCareDocotorInfoForm = fb.group(familyDocModel);
    component.healthCareDocotorInfoForm.controls.familyDoctorPostalCode['restrict']={maxlength : '10'};

component.healthCareDocotorInfoForm.get('familyDoctorPostalCode').setValidators([Validators.required]);

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
