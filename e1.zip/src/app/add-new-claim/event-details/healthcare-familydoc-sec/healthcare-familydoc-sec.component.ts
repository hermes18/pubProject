import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable, forkJoin } from "rxjs";
import { HttpCommonService } from "../../../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray, AbstractControl } from '@angular/forms';
import { CreateFormService } from '../../../shared/services/create-form.service';
import { ErrorMessagesComponent } from '../../../shared/component/error-messages/error-messages.component';
import { GetterSetterService } from 'src/app/core/services/getterSetter.service';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { environment } from 'src/environments/environment';
import { eClaimsConstants } from 'src/app/core/constants/constant';

@Component({
  selector: 'healthcare-familydoc-sec',
  templateUrl: './healthcare-familydoc-sec.component.html',
  styleUrls: ['./healthcare-familydoc-sec.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class HealthcareFamilydocSecComponent implements OnInit {
  @Input() healthCareDocotorInfoForm: FormGroup;
  @Input() indx: number;
  @Input() healthCareDoctorEventSecRules: any;
  ispoland: boolean = false;
  jsonObj = JSON.parse(sessionStorage.userData);
  countryOptions = []
  countryList = [];
  userData = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.userData.sourceOrigin;
  defaultLanguage: string = this.userData.defaultLanguage;
  constructor(private commonService: HttpCommonService, public storage: GetterSetterService,
    public newClaimService: NewClaimSharedService) { }
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
  postalCodeInitialVal;
  townFromPoCode:any;
  public postalMasking = {
    guide: false,
    showMask: true,
    mask: [/\d/, /\d/, '-',
      /\d/, /\d/, /\d/]
  };

  cloneAbstractControl<T extends AbstractControl>(control: T): T {
    let newControl: T;
    // //console.log("control",control)
    if (control instanceof FormGroup) {
      let formGroup = new FormGroup({}, control.validator, control.asyncValidator);
      const controls = control.controls;

      Object.keys(controls).forEach(key => {
        formGroup.addControl(key, this.cloneAbstractControl(controls[key]));
        formGroup.controls[key]['isVisible'] = controls[key]['isVisible'];
        formGroup.controls[key]['fieldName'] = controls[key]['fieldName'];
        formGroup.controls[key]['restrict'] = controls[key]['restrict'];

      })

      newControl = formGroup as any;
    }
    else if (control instanceof FormArray) {
      const formArray = new FormArray([], control.validator, control.asyncValidator);

      control.controls.forEach(formControl => formArray.push(this.cloneAbstractControl(formControl)))
      newControl = formArray as any;
    }
    else if (control instanceof FormControl) {
      newControl = new FormControl(null, control.validator, control.asyncValidator) as any;
    }
    else {
      throw new Error('Error: unexpected control value');
    }

    if (control.disabled) newControl.disable({ emitEvent: false });

    return newControl;
  }

  formInit() {

    const userData = this.storage.getSession('userData');
    //    let tenantId = sessionStorage.getItem('tenantId');
    let tenantId = 'pl';

    if (tenantId = 'pl')
      this.ispoland = true;
    //console.log("this.index>>>>",this.indx)

    if (this.healthCareDoctorEventSecRules.familyDoctorCountry.renderFlag && this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1) {
      this.healthCareDocotorInfoForm.get('familyDoctorCountry').setValue(this.defaultLanguage.toUpperCase());
    } else {
      this.healthCareDocotorInfoForm.get('familyDoctorCountry').setValue(null);
    }
   this.postboxMandate();
    if (tenantId = 'pl')
      this.ispoland = true;

    this.countryOptions = this.newClaimService.getParamValue('countryList') ? (this.newClaimService.getParamValue('countryList')) : [];
    this.newClaimService.getCountryList().subscribe((data) => {
      this.countryOptions = data;
      setTimeout(() => {
        this.healthCareDocotorInfoForm.get('familyDoctorCountry').setValue(this.healthCareDocotorInfoForm.get('familyDoctorCountry').value);
      }, 0);
    }); 
    this.postalCodeInitialVal = {
      length: this.healthCareDocotorInfoForm.controls.familyDoctorPostalCode['restrict'].maxlength,
      required: this.healthCareDoctorEventSecRules.familyDoctorPostalCode.mandatoryFlag
    };
    this.townFromPoCode = '';
    this.countryOnChange(this.healthCareDocotorInfoForm.get('familyDoctorCountry').value);
  }

postboxMandate(){
  if (this.healthCareDoctorEventSecRules.familyDoctorPostBox.mandatoryFlag
    && this.healthCareDocotorInfoForm.get('familyDoctorCountry').value == 'US') {
    this.healthCareDocotorInfoForm.controls['familyDoctorPostBox'].setValidators([Validators.required]);
    this.healthCareDocotorInfoForm.controls['familyDoctorPostBox'].updateValueAndValidity();
  } else {
    this.healthCareDocotorInfoForm.controls['familyDoctorPostBox'].setValidators([Validators.nullValidator]);
    this.healthCareDocotorInfoForm.controls['familyDoctorPostBox'].updateValueAndValidity();
  
  }
}
  ngOnInit() {
    this.formInit();
  }

  // formSubmit() {
  //   if (this.healthCareDocotorInfoForm.valid) {
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }

  countryCodes = {
    'RO': '+40',
    'PL': '+48'
  };

  showTownOptionLabel = null;
  showCountryLabel: boolean = false;
  countryOnChange(event) {
    this.healthCareDocotorInfoForm.get('familyDoctorPostalCode').setValue('');
    this.healthCareDocotorInfoForm.get('familyDoctorPostBox').setValue(null);
    this.healthCareDocotorInfoForm.get('familyDoctorTown').setValue(null);
    this.showTownOptionLabel = false;
    this.townFromPoCode = '';
    this.showCountryLabel = false;
    this.healthCareDocotorInfoForm.controls.familyDoctorOtherCountry['isVisible'] = this.healthCareDocotorInfoForm.controls.familyDoctorCountry['isVisible']
    this.healthCareDocotorInfoForm.controls['familyDoctorOtherCountry'].setValidators([Validators.nullValidator]);
    this.healthCareDocotorInfoForm.controls['familyDoctorOtherCountry'].updateValueAndValidity();
    if ((this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1)
      && (event && event.toLowerCase() == this.defaultLanguage)) {
      // this.healthCareDocotorInfoForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);
    } else if (event && event.toLowerCase() == 'other') {

      this.healthCareDocotorInfoForm.controls.familyDoctorOtherCountry.reset();
      this.healthCareDocotorInfoForm.controls['familyDoctorOtherCountry'].setValidators([Validators.required]);
      this.healthCareDocotorInfoForm.controls['familyDoctorOtherCountry'].updateValueAndValidity();
    }
    let claimData = this.newClaimService.getClaimData();
    let lob = (claimData ? claimData.newclaim : null);
    //console.log("personal details", lob)
    if (this.healthCareDoctorEventSecRules.familyDoctorPostBox.mandatoryFlag && event == 'US') {

      this.healthCareDocotorInfoForm.controls['familyDoctorPostBox'].setValidators([Validators.required]);
      this.healthCareDocotorInfoForm.controls['familyDoctorPostBox'].updateValueAndValidity();
    
    } else {
      this.healthCareDocotorInfoForm.controls['familyDoctorPostBox'].setValidators([Validators.nullValidator]);
      this.healthCareDocotorInfoForm.controls['familyDoctorPostBox'].updateValueAndValidity();
  
    }

  this.postalCodeSetValidation();
  }
  postalCodeSetValidation(){
  let validators = this.postalCodeInitialVal.required ? Validators.required : Validators.nullValidator;
  if (this.defaultLanguage.toUpperCase() == 'PL' && this.healthCareDocotorInfoForm.get('familyDoctorOtherCountry').value == 'PL') {
    this.healthCareDocotorInfoForm.controls.familyDoctorPostalCode['restrict'].maxlength = this.postalCodeInitialVal.length;
    this.healthCareDocotorInfoForm.controls.familyDoctorPostalCode.setValidators([validators]);
  } else {
    this.healthCareDocotorInfoForm.controls.familyDoctorPostalCode['restrict'].maxlength = 10;
    this.healthCareDocotorInfoForm.controls.familyDoctorPostalCode.setValidators([validators]);
  }
  this.healthCareDocotorInfoForm.controls['familyDoctorPostalCode'].updateValueAndValidity();
  
}

  townOptions = [];
  blurPostalCodeField(event) {
    if (this.healthCareDocotorInfoForm.controls.familyDoctorPostalCode.value == '' &&
      this.healthCareDocotorInfoForm.controls.familyDoctorCountry.value == this.defaultLanguage.toUpperCase()
      && this.showTownOptionLabel) {
      this.healthCareDocotorInfoForm.get('familyDoctorTown').setValue(null);
      this.townFromPoCode = '';
    }
    this.showTownOptionLabel = false;
    //console.log("Postal Code")
    if (this.healthCareDocotorInfoForm.controls.familyDoctorPostalCode.value != ''
      && (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1) &&
      this.healthCareDocotorInfoForm.controls.familyDoctorCountry.value == this.defaultLanguage.toUpperCase()) {
      //console.log("Postal Code")
      let value = this.healthCareDocotorInfoForm.controls.familyDoctorPostalCode.value;
      let postalCodeValue = value;

      this.getPostalCodeValue(postalCodeValue,
        this.defaultLanguage.toUpperCase()).subscribe((data) => {
          // //console.log(data); 
          this.townOptions = data;
          //console.log(this.townOptions,"test",data[0])
          if (data.length > 0) {
            this.healthCareDocotorInfoForm.get('familyDoctorTown').setValue(data[0]);
            this.showTownOptionLabel = true;
            this.townFromPoCode = '*';
          } else {
            this.healthCareDocotorInfoForm.get('familyDoctorTown').setValue(null);
            this.showTownOptionLabel = false;
            this.townFromPoCode = '';
          }
        });
    }
  }




  getPostalCodeValue(event, countryCode) {
    let param = {
      "countryCode": countryCode,
      "language": "",
      "pinCode": event
    }
        const url = `${environment.host + environment.getPostalCode.url}`;
        return this.commonService[environment.getPostalCode.method](
          url,param);
      }
}
