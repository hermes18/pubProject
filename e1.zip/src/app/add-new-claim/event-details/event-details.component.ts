import { Component, OnInit, ChangeDetectorRef, ViewChildren, AfterViewInit, ViewChild, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormArray, FormControl } from '@angular/forms';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { CreateFormService } from 'src/app/shared/services/create-form.service';
import { forkJoin } from 'rxjs';
import { HealthcareFamilydocSecComponent } from './healthcare-familydoc-sec/healthcare-familydoc-sec.component';
import { HealthcareEventSecComponent } from './healthcare-event-sec/healthcare-event-sec.component';
import { EventSecReqConfigService, AdditionalFieldDetailsModel } from './event-details.model';
import { SectionReqConfigService } from '../personal-details/personal-details.model';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { EventInformationSecComponent } from './event-information-sec/event-information-sec.component';
import { GetterSetterService } from 'src/app/core/services/getterSetter.service';
import { AdditionalDetailsSecComponent } from './additional-details-sec/additional-details-sec.component';
import { NewClaimSharedService } from '../add-new-claim.service';
import { eClaimsConstants } from 'src/app/core/constants/constant';

@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.scss']
})
export class EventDetailsComponent implements OnInit, AfterViewInit, OnDestroy {
  eventDetailForm: FormGroup = this.fb.group({});

  userData = JSON.parse(sessionStorage.userData);
  defaultLanguage: string = this.userData.defaultLanguage;
  eventSectionInformation = [];
  additionalDetailRenderValue = [];
  eventInformationSectionValue: boolean = false;
  additionalFieldDetailsSectionValue: boolean = false;
  informationHealthCareEventSectionValue: boolean = false;
  informationHealthCareFamilyDocSectionValue: boolean = false;
  eventDetailAddButtonShow = eClaimsConstants.eventDetailAddButtonShow;

  eventRelatedToValueDetail = []
  isPersonalDataLoad: boolean = false;
  @ViewChild(EventInformationSecComponent, { static: false }) eventDetailInfoComp: EventInformationSecComponent;
  @ViewChild(HealthcareEventSecComponent, { static: false }) hcEventSecComp: HealthcareEventSecComponent;
  @ViewChild(HealthcareFamilydocSecComponent, { static: false }) hcFamilyDocComp: HealthcareFamilydocSecComponent;
  @ViewChild(AdditionalDetailsSecComponent, { static: false }) additionalDtailSecComp: AdditionalDetailsSecComponent;

  healthCareInfoRuleform: any;
  healthCareDoctrInfoRuleform: any;
  baseUrl = environment.host + environment.eventDetailServiceConfig.url;
  headers = new HttpHeaders();
  renderClaimSections: any = null;
  constructor(private commonService: HttpCommonService, private fb: FormBuilder,
    public storage: GetterSetterService, public newClaimService: NewClaimSharedService,
    private createForm: CreateFormService, private cd: ChangeDetectorRef,
    public secReqConfig: SectionReqConfigService, public eventSecReqConfig: EventSecReqConfigService, public additionalFieldDetailsModel: AdditionalFieldDetailsModel) { }


  formDetails = [
    {
      "form": "eventInfo",
      "initFunc": "formInit",
      "formRef": "eventDetailInfoComp",
      "submit": "formSubmit",
      "renderJson": null,
      "ruleFileIncludes": "RelatedEvent"
    },
    {
      "form": "hcEvent",
      "initFunc": "formInit",
      "formRef": "hcEventSecComp",
      "submit": "formSubmit",
      "renderJson": null,
      "ruleFileIncludes": "HealthCareCenterInfo"
    },
    {
      "form": "hcFamilyDoc",
      "initFunc": "formInit",
      "formRef": "hcFamilyDocComp",
      "submit": "formSubmit",
      "renderJson": null,
      "ruleFileIncludes": "HealthCareFamilyDoctor"
    },
    {
      "form": "additionalDtail",
      "initFunc": "formInit",
      "formRef": "additionalDtailSecComp",
      "submit": "formSubmit",
      "renderJson": null,
      "ruleFileIncludes": "AdditionalDetails"
    }
  ];

  getSectionDetails(sectionName) {
    for (let i = 0; i < this.formDetails.length; i++) {
      if (this.formDetails[i].form == sectionName) {
        return this.formDetails[i].renderJson;
      }
    }
  }

  additionalRenderSecRules: any = null;
  additionalRenderSecRulesBO: any = null;
  callSubCompInit() {
    // setTimeout(() => {

    for (let i = 0; i < this.formDetails.length; i++) {

      if (this[this.formDetails[i].formRef] &&
        this[this.formDetails[i].formRef][this.formDetails[i].initFunc]) {
        this[this.formDetails[i].formRef][this.formDetails[i].initFunc]();
      }

    }

    // }, 0);
  }
  callSubCompFormSubmit() {
    let submitFormValid = true;
    for (let i = 0; i < this.formDetails.length; i++) {

      if (this[this.formDetails[i].formRef] && this[this.formDetails[i].formRef][this.formDetails[i].submit]) {
        let eventFormSubmit = this[this.formDetails[i].formRef][this.formDetails[i].submit]();
        if (!eventFormSubmit.isFormValid) {
          submitFormValid = false;
        }
      }

    }
    if (!submitFormValid) {
      return false;
    }
    // console.log("formData doctor", this.eventDetailForm.controls.informationHealthCareFamilyDocSection.valid);
    // console.log("formData ", this.eventDetailForm.controls.informationHealthCareEventSection.valid);
    // console.log("errorFor",this.createForm.errorFormGroup(this.eventDetailForm['controls'].informationHealthCareFamilyDocSection));
    if (this.informationHealthCareFamilyDocSectionValue) {

      let familyDocSec = this.eventDetailForm.controls.informationHealthCareFamilyDocSection;
      if ((!familyDocSec)) {
        return false;
      }
      for (let i = 0; i < familyDocSec['controls'].length; i++) {
        if (familyDocSec['controls'][i].invalid) {
          return false;
        }
      }
    }
    if (this.informationHealthCareEventSectionValue) {
      let healthcareSec = this.eventDetailForm.controls.informationHealthCareEventSection;
      if ((!healthcareSec)) {
        return false;
      }
      for (let i = 0; i < healthcareSec['controls'].length; i++) {
        if (healthcareSec['controls'][i].invalid) {
          return false;
        }
      }


    }
    /* if (!this.eventDetailForm.controls.informationHealthCareFamilyDocSection
       || !this.eventDetailForm.controls.informationHealthCareEventSection
       || !this.eventDetailForm.controls.informationHealthCareFamilyDocSection.valid
       || !this.eventDetailForm.controls.informationHealthCareEventSection.valid) {
       return false;
     }*/

    return true;

  }
  setEventDetails() {
    this.newClaimService.setEventDetail(this.eventDetailForm);

  }

  addtionalCommentsShow: any = false;
  callCenterFlowControls() {
    if (this.renderClaimSections.additionalCommentsSection.renderFlag) {
      if (this.eventDetailForm.get('eventDetailsAdditionalComments')) {

      } else {
        this.eventDetailForm.addControl('eventDetailsAdditionalComments', new FormControl('', Validators.nullValidator));
      }

    }

  }


  ngOnInit() {
    //this.formInit(); 
  }
  formInit() {
    this.renderClaimSections = null;
    //this.addtionalCommentsShow = false;
    this.renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');

    this.eventDetailsRender();

  }
  eventInfoSecRules: any;
  healthCareEventSecRules: any;
  healthCareDoctorEventSecRules: any;
  renderEventDetailsFlag: any;
  eventDetailsRender() {
    const userData = this.storage.getSession('userData');

    this.additionalFieldDetailsSectionValue = false;
    let eventDetailsSec = this.eventSecReqConfig.rulesRequestParam('EventDetailsSectionRender');
    this.eventRelatedToValueDetail = []
    //this.commonService.getData(flagtest)
    this.commonService[environment.eventDetailServiceConfig.method](this.baseUrl, eventDetailsSec, this.headers)
      .subscribe((data) => {
        //console.log("Value of event", data)

        const sectionUrls1 = this.eventSecReqConfig.api();

        let rulesArr = [];

        rulesArr = this.getSectionDeailsIfMandatory(sectionUrls1, data);
        //console.log("-1---rulesArr > ", rulesArr)
        this.requestDataFromMultipleSources(rulesArr).subscribe((responseList) => {
          let formGroupObj: any = {};
          //console.log("-2---responseList > ", responseList)
          if (this.newClaimService.getParamValue('eventDetailsOldValue')) {
            this.setSectionRenderValues(sectionUrls1, responseList);
            this.additionalRenderSecRules = this.getSectionDetails('additionalDtail');
            this.healthCareEventSecRules = this.getSectionDetails('hcEvent');
  
            this.healthCareDoctorEventSecRules = this.getSectionDetails('hcFamilyDoc');
            this.eventInfoSecRules = this.getSectionDetails('eventInfo');
            this.newClaimService.setParamValue('healthCareDoctorEventSecRules', this.healthCareDoctorEventSecRules);
         
            if (this.additionalDtailSecComp && this.additionalDtailSecComp.formInit) {
              this.additionalDtailSecComp.formInit() ;
            }
            if (this.eventDetailInfoComp && this.eventDetailInfoComp.formInit) {
              this.eventDetailInfoComp.formInit();
            }
            this.healthCareViewChildren.forEach((healthChild) =>{
              //console.log(healthChild)
              healthChild.postboxMandate();
              healthChild.postalCodeSetValidation();
            } );
            this.healthCareDoctrViewChildren.forEach((healthChild) =>{
              //console.log(healthChild)
              healthChild.postboxMandate();
              healthChild.postalCodeSetValidation();
            } );
            
            // if (this.hcEventSecComp && this.hcEventSecComp.postboxMandate) {
            //   this.hcEventSecComp.postboxMandate();
            // }
            // if (this.hcEventSecComp && this.hcEventSecComp.postalCodeSetValidation) {
            //   this.hcEventSecComp.postalCodeSetValidation();
            // }
            // if (this.hcFamilyDocComp && this.hcFamilyDocComp.postboxMandate) {
            //   this.hcFamilyDocComp.postboxMandate();
            // }
            
            // if (this.hcFamilyDocComp && this.hcFamilyDocComp.postalCodeSetValidation) {
            //   this.hcFamilyDocComp.postalCodeSetValidation();
            // }

          } else {
            formGroupObj = this.generateAllForms(sectionUrls1, responseList);
            let formGroupObjCopy: any = {};
            if (formGroupObj.informationHealthCareEventSection) {

              this.healthCareInfoRuleform = formGroupObj.informationHealthCareEventSection;
              formGroupObjCopy = formGroupObj;
              formGroupObjCopy.informationHealthCareEventSection = this.fb.array([this.healthCareInfoRuleform]);

            }
            if (formGroupObj.informationHealthCareFamilyDocSection) {
              this.healthCareDoctrInfoRuleform = formGroupObj.informationHealthCareFamilyDocSection;
              formGroupObjCopy = formGroupObj;
              formGroupObjCopy.informationHealthCareFamilyDocSection = this.fb.array([this.healthCareDoctrInfoRuleform]);
            }

            this.eventDetailForm = this.fb.group(formGroupObjCopy);
         
            this.additionalRenderSecRules = this.getSectionDetails('additionalDtail');
            this.healthCareEventSecRules = this.getSectionDetails('hcEvent');
  
            this.healthCareDoctorEventSecRules = this.getSectionDetails('hcFamilyDoc');
            this.eventInfoSecRules = this.getSectionDetails('eventInfo');
            this.newClaimService.setParamValue('healthCareDoctorEventSecRules', this.healthCareDoctorEventSecRules);
           
            this.callSubCompInit();
            // if (this.hcFamilyDocComp && this.hcFamilyDocComp.postboxMandate) {
            //   this.hcFamilyDocComp.postboxMandate();
            // }
          }
          //this.newClaimService.setParamValue('eventDetailsOldValue',this.eventDetailForm);
          //console.log("-3---formGroupObj > ", formGroupObj)
          this.renderEventDetailsFlag = data;
          if (data.eventInformationSection.renderFlag == true) {
            this.eventInformationSectionValue = data.eventInformationSection.renderFlag
          } else {
            this.eventInformationSectionValue = false
          }



          this.isPersonalDataLoad = true;

          // if (data.eventInformationSection.renderFlag && this.eventDetailInfoComp.eventRelatedTovalueRender) {

          //   this.eventDetailInfoComp.eventRelatedTovalueRender();
          // }

          if (data.additionalFieldDetailsSection.renderFlag == true) {
            this.additionalFieldDetailsSectionValue = data.additionalFieldDetailsSection.renderFlag
          } else {
            this.additionalFieldDetailsSectionValue = false
          }
          if (data.informationHealthCareEventSection.renderFlag == true) {
            this.informationHealthCareEventSectionValue = data.informationHealthCareEventSection.renderFlag
          } else {
            this.informationHealthCareEventSectionValue = false
          }
          if (data.informationHealthCareFamilyDocSection.renderFlag == true) {
            this.informationHealthCareFamilyDocSectionValue = data.informationHealthCareFamilyDocSection.renderFlag
          } else {
            this.informationHealthCareFamilyDocSectionValue = false
          }

          this.callCenterFlowControls();
        });

      });


  }
  showAddressSection: boolean = false;
  additionalDetailsFieldsArray = ['article', 'employmentPeriod', 'forwhatperiod',
    'sickLeavePeriod', 'employerPreparedAccidentReport', 'dateOffirstSymptomsDisease',
    'dateCompletionOfMedicalTreatment', 'dateOfRecognitionDisease',
    'policeConductedInvestigation', 'eventAfterConsumptionAlcohol',
    'sportsClubPlayerDropDown'];
  get eventFormValue() {
    let showAddSec = false;
    if (this.eventDetailForm.controls.additionalFieldDetailsSection
      && this.eventDetailForm.controls.additionalFieldDetailsSection['controls']) {

      for (let i = 0; i < this.additionalDetailsFieldsArray.length; i++) {
        if (this.eventDetailForm.controls.additionalFieldDetailsSection['controls'][this.additionalDetailsFieldsArray[i]].isVisible) {
          showAddSec = true;
        }
      }

      /*(<any>Object).values(this.eventDetailForm.controls.additionalFieldDetailsSection['controls']).forEach(control => {
          
        if(control.isVisible){
          showAddSec = true;
            
        }
    })
      
      */
    }
    this.showAddressSection = showAddSec;
    return showAddSec;
  }


  formSubmit() {
    //console.log(formData, "formData");

    this.createForm.markFormGroupTouched(this.eventDetailForm);
    const renderFlag = {
      'data': this.renderEventDetailsFlag,
      'additionalFieldDetailsSectionValue': this.additionalFieldDetailsSectionValue,
      'eventInfo': this.showAddressSection
    };
    this.newClaimService.setParamValue('renderEventDetails', renderFlag);
    this.setEventDetails();
    this.newClaimService.setParamValue('eventDetailsOldValue', this.eventDetailForm);

    return this.callSubCompFormSubmit();
    // console.log("formData doctor", this.eventDetailForm.controls.informationHealthCareFamilyDocSection.valid);
    // console.log("formData ", this.eventDetailForm.controls.informationHealthCareEventSection.valid);
  }

  public requestDataFromMultipleSources(rulesArr) {

    let responseArr = [];
    for (let i = 0; i < rulesArr.length; i++) {
      if (rulesArr[i].url) {

        const baseUrl = rulesArr[i].url;
        let requestparam = rulesArr[i].requestParam;
        let head = this.headers;

        responseArr.push(this.commonService[environment.eventDetailServiceConfig.method](
          baseUrl, requestparam, head));

      }
    }

    // if (this.eventInformationSectionValue)
    //   responseArr.push(this.eventDetailInfoComp.eventDetailInfoSecRender());


    return forkJoin(responseArr);
  }
  getObjFromArr(key, arr, compareVal) {
    for (let i = 0; i < arr.length; i++) {
      if (arr[i][key] === compareVal) {
        return arr[i];
      }
    }
    return null;
  }

  count: number = 0;
  addHealthCare() {

    let isControlsValid = true;
    for (let i = 0; i < this.eventDetailForm.controls.informationHealthCareEventSection['controls'].length; i++) {
      if (this.eventDetailForm.controls.informationHealthCareEventSection['controls'][i].invalid) {
        isControlsValid = false;
        return;
      }
    }
    // if(this.eventDetailForm.controls.informationHealthCareEventSection.valid){
    // this.eventDetailForm.controls.informationHealthCareEventSection['controls'].
    //   push(this.hcEventSecComp.cloneAbstractControl(this.healthCareInfoRuleform));
    
      (this.eventDetailForm.get('informationHealthCareEventSection') as FormArray).
      push(this.hcEventSecComp.cloneAbstractControl(this.healthCareInfoRuleform));
     
      //  }
  }
  removeHealthCare() {

    //this.eventDetailForm.controls.informationHealthCareEventSection['controls'].pop(this.healthCareInfoRuleform);
    (this.eventDetailForm.get('informationHealthCareEventSection') as FormArray).
    removeAt((this.eventDetailForm.controls.informationHealthCareEventSection['controls'].length)-1);
     
  }

  addDoctor() {
    let isControlsValid = true;
    for (let i = 0; i < this.eventDetailForm.controls.informationHealthCareFamilyDocSection['controls'].length; i++) {
      if (this.eventDetailForm.controls.informationHealthCareFamilyDocSection['controls'][i].invalid) {
        isControlsValid = false;
        return;
      }
    }

    //if(this.eventDetailForm.controls.informationHealthCareFamilyDocSection.valid){
    
    // this.eventDetailForm.controls.informationHealthCareFamilyDocSection['controls'].
    //   push(this.hcFamilyDocComp.cloneAbstractControl(this.healthCareDoctrInfoRuleform));
     
     
      (this.eventDetailForm.get('informationHealthCareFamilyDocSection') as FormArray).
      push(this.hcFamilyDocComp.cloneAbstractControl(this.healthCareDoctrInfoRuleform));
     
      // this.eventDetailForm.controls.informationHealthCareFamilyDocSection['controls'].updateValueAndValidity();
    //  this.eventDetailForm.controls.informationHealthCareFamilyDocSection['value'].
    //  push(this.hcFamilyDocComp.cloneAbstractControl(this.healthCareDoctrInfoRuleform));
    
     //}
  }
  removeDoctor() {
    //this.eventDetailForm.controls.informationHealthCareFamilyDocSection['controls'].pop(this.healthCareDoctrInfoRuleform);
    (this.eventDetailForm.get('informationHealthCareFamilyDocSection') as FormArray).
    removeAt((this.eventDetailForm.controls.informationHealthCareFamilyDocSection['controls'].length)-1);
     
  }

  @ViewChildren(HealthcareEventSecComponent) healthCareViewChildren;
  @ViewChildren(HealthcareFamilydocSecComponent) healthCareDoctrViewChildren;

  ngAfterViewInit() {
    //console.log("healthViewChildren before", this.healthCareViewChildren);
    this.cd.detectChanges();
    //console.log("healthDoctorViewChildren after", this.healthCareDoctrViewChildren);

  }



  getSectionDeailsIfMandatory(sectionUrls, data) {
    let rulesArr = []
    for (let [key, value] of Object.entries(data)) {
      if (typeof value === 'object' && value) {
        if (data[key].hasOwnProperty('renderFlag') &&
          data[key].hasOwnProperty('renderFlag') === true) {
          let sectionDetails = this.getObjFromArr('name', sectionUrls, key);

          if (sectionDetails) {
            rulesArr.push(this.getObjFromArr('name', sectionUrls, key));
          }

        }
      }
    }
    return rulesArr;
  }

  //pattern exception for date fields

  patternException = ['healthCareCenterPeriodFrom',
    'healthCareCenterPeriodTo',
    'dateOfEvent',
    'dateOfBirth',
    'dateOffirstSymptomsDisease',
    'dateWhenPhysicalInjuriesOccurred',
    'dateOfRecognitionDisease',
    'sickLeavePeriod',
    'sickLeavePeriodFromDate',
    'sickLeavePeriodToDate',
    'dateCompletionOfMedicalTreatment',
    'employmentPeriod',
    'employmentPeriodFromDate',
    'employmentPeriodToDate'];
  generateAllForms(sectionUrls, responseList) {
    let formGroupObj = {};
    for (let i = 0; i < responseList.length; i++) {

      for (let j = 0; j < sectionUrls.length; j++) {
        if (sectionUrls[j].ruleFileIncludes && sectionUrls[j].modelNames) {
          if (responseList[i]['ruleFileName'].indexOf(sectionUrls[j].ruleFileIncludes) != -1) {
            formGroupObj[sectionUrls[j]['name']] = this.createForm.generateForm(sectionUrls[j].modelNames, responseList[i], this.patternException);
            break;
          }

        } else {
          formGroupObj[sectionUrls[j]['name']] = this.createForm.generateFormGroup();
        }

      }
      for (let j = 0; j < this.formDetails.length; j++) {
        if (responseList[i]['ruleFileName'].indexOf(this.formDetails[j].ruleFileIncludes) != -1) {

          this.formDetails[j].renderJson = responseList[i];
          break;
        }
      }


    }
    return formGroupObj;
  }

  getCopyObj(obj) {
    return JSON.parse(JSON.stringify(obj));
  }



  public requestDataFrom(valueEventRelatedTo) {

    let responseArr = [];

    let eventDetailAddInfoSecByRelatedEvnt = this.eventSecReqConfig.rulesRequestParam('EventDetailAdditionalInformationSectionbyRelatedEvent');
    eventDetailAddInfoSecByRelatedEvnt.relatedEventType = valueEventRelatedTo;
    responseArr.push(
      this.commonService[environment.eventDetailServiceConfig.method](
        this.baseUrl, eventDetailAddInfoSecByRelatedEvnt, this.headers)

    );
    return forkJoin(responseArr);
  }

  geteventRelatedToValue(valueEventRelatedTo) {

    //console.log("geteventRelatedToValue",valueEventRelatedTo);
    //console.log("this.eventDetailInfoComp.eventInformationForm.value.eventRelatedTo",this.eventDetailInfoComp.eventInformationForm.value.eventRelatedTo)
    let countryValue = JSON.parse(sessionStorage.getItem("userData"));

    this.additionalDetailRenderValue = []

    let eventDetailAddInfoSecByRelatedEvnt = this.eventSecReqConfig.rulesRequestParam('EventDetailAdditionalInformationSectionRender');
    eventDetailAddInfoSecByRelatedEvnt.relatedEventType = valueEventRelatedTo;
    this.additionalDetailRenderValue.push(
      this.commonService[environment.eventDetailServiceConfig.method](
        this.baseUrl, eventDetailAddInfoSecByRelatedEvnt, this.headers)
    )
    let sectionUrlsAdditional =
    {
      name: "additionalFieldDetailsSection",
      ruleFileIncludes: "RelatedEventRenderBO",
      // url: "assets/mocks/additionalDetailRenderSection.json",
      url: this.baseUrl,
      modelNames: this.additionalFieldDetailsModel
    }

    if (countryValue.displayLanguages === 'pl') {
      //this.additionalFieldDetailsSectionValue = true;
      this.requestDataFrom(valueEventRelatedTo).subscribe((responseList) => {
        this.markGroupValue(responseList)
        this.additionalRenderSecRulesBO = responseList[0]
        this.additionalFieldDetailsSectionValue = true;
        //console.log("eventFormValue",this.eventDetailForm.controls);
        // setTimeout(() => {
        try {
          this.additionalDtailSecComp.additionalRenderSecRulesBOFunc(this.additionalRenderSecRulesBO)
        } catch (err) {
          console.log("Error", err);
        }
        // }, 0);
        if (this.additionalDtailSecComp && this.additionalDtailSecComp.ngForminit) {
          this.additionalDtailSecComp.ngForminit();

        } else {

          this.additionalFieldDetailsSectionValue = true;
          setTimeout(() => {
            try {
              this.additionalDtailSecComp.ngForminit();
            } catch (err) {
              console.log('error:', err)
            }

          }, 0);

        }
      });
    } else {

      //console.log("geteventRelatedToValue($event)", valueEventRelatedTo, this.additionalFieldDetailsSectionValue)
      this.requestAdditionalDetailsForm(valueEventRelatedTo).subscribe((responseList) => {
        let formGroupObj = {};
        //console.log(responseList, "true responseList")
        let sesionURlRo = this.eventSecReqConfig.apiRo();
        if (this.additionalRenderSecRules) {
          this.setSectionRenderValues(sesionURlRo, responseList);
        } else {

          formGroupObj = this.generateForms(sesionURlRo, responseList);
          this.additionalRenderSecRules = this.getSectionDetails('additionalDtail');
          this.eventDetailForm.controls['additionalFieldDetailsSection'] = <any>formGroupObj['additionalFieldDetailsSection'];

        }
        setTimeout(() => {
          this.additionalFieldDetailsSectionValue = true;
          this.requestDataFrom(valueEventRelatedTo).subscribe((responseList) => {
            this.markGroupValue(responseList)
            this.additionalRenderSecRulesBO = responseList[0]
            this.additionalDtailSecComp.additionalRenderSecRulesBOFunc(this.additionalRenderSecRulesBO)
            this.additionalDtailSecComp.ngForminit();
            this.additionalDtailSecComp.setDefaultCode();


          });
        }, 0);


      });



    }
  }

  public requestAdditionalDetailsForm(valueEventRelatedTo) {

    let responseArr = [];

    let eventDetailAddInfoSecByRelatedEvnt = this.eventSecReqConfig.rulesRequestParam('EventDetailAdditionalInformationSectionRender');
    eventDetailAddInfoSecByRelatedEvnt.relatedEventType = valueEventRelatedTo;
    responseArr.push(
      this.commonService[environment.eventDetailServiceConfig.method](
        this.baseUrl, eventDetailAddInfoSecByRelatedEvnt, this.headers)

    );
    return forkJoin(responseArr);
  }
  setSectionRenderValues(sectionUrls, responseList) {
    //console.log("responseListaaa",responseList);
    //console.log("sectionUrl",sectionUrls);
    for (let i = 0; i < responseList.length; i++) {

      for (let j = 0; j < sectionUrls.length; j++) {
        if (responseList[i]['ruleFileName'].indexOf(sectionUrls[j].ruleFileIncludes) != -1) {
          this.createForm.setFormValidation(this.eventDetailForm.get(sectionUrls[j]['name']), responseList[i], this.patternException);

          break;
        }
      }

      for (let j = 0; j < this.formDetails.length; j++) {
        if (responseList[i]['ruleFileName'].indexOf(this.formDetails[j].ruleFileIncludes) != -1) {

          this.formDetails[j].renderJson = responseList[i];
          break;
        }
      }


    }

  }

  generateForms(sectionUrls, responseList) {
    let formGroupObj1 = {}
    for (let i = 0; i < responseList.length; i++) {
      if (responseList[i]['ruleFileName'].indexOf(sectionUrls.ruleFileIncludes) != -1) {
        formGroupObj1[sectionUrls.name] = this.createForm.generateForm(sectionUrls.modelNames, responseList[i], this.patternException);
      }
      for (let j = 0; j < this.formDetails.length; j++) {
        if (responseList[i]['ruleFileName'].indexOf(this.formDetails[j].ruleFileIncludes) != -1) {

          this.formDetails[j].renderJson = responseList[i];
          break;
        }
      }
    }

    return formGroupObj1;
  }

  markGroupValue(formGroupObj) {
    //console.log("markGroupValue 1",formGroupObj)

    for (let [key, value] of Object.entries(formGroupObj[0])) {
      for (let [key1, value1] of Object.entries(this.eventDetailForm.controls.additionalFieldDetailsSection['controls'])) {
        if (key == key1) {
          let validatorsValue = [];
          validatorsValue = this.createForm.getValidators(value, key, this.patternException)
          value1['isVisible'] = value['renderFlag'];
          this.eventDetailForm.controls.additionalFieldDetailsSection.get(key1).setValidators(validatorsValue);
          //          if (value) 
          //             {
          //                 value1['restrict']={}
          //                 if( value['renderFlag'] ){
          //                   value1['isVisible'] = value['renderFlag'];

          // }
          // if (value1['allowedDataType'] && value['allowedDataType']) {
          //   value1['restrict'].pattern = value['allowedDataType'];
          // }
          // if (value1['fieldmaxlength'] && value['fieldmaxlength']) {
          //   value1['restrict'].restrict.maxlength  = value['fieldmaxlength'];
          // }
          // if (value1['fieldminlength'] && value['fieldminlength'] ) {
          //   value1['restrict'].restrict.minlength  = value['fieldminlength'];
          // }

          //             }

        }
      }
    }

  }

  ngOnDestroy() {
    this.newClaimService.setParamValue('eventDetailsOldValue', null);

  }


}