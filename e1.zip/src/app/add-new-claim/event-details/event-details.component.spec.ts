import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { EventDetailsComponent } from './event-details.component';
import { EventInformationSecComponent } from './event-information-sec/event-information-sec.component';

import { HealthcareFamilydocSecComponent } from './healthcare-familydoc-sec/healthcare-familydoc-sec.component';
import { HealthcareEventSecComponent } from './healthcare-event-sec/healthcare-event-sec.component';
import { AdditionalDetailsSecComponent } from './additional-details-sec/additional-details-sec.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SectionReqConfigService } from '../personal-details/personal-details.model';
import { AdditionalFieldDetailsModel, EventSecReqConfigService } from './event-details.model';

describe('EventDetailsComponent', () => {
  let component: EventDetailsComponent;
  let fixture: ComponentFixture<EventDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ EventDetailsComponent,EventInformationSecComponent,HealthcareFamilydocSecComponent,
        HealthcareEventSecComponent,AdditionalDetailsSecComponent ],
        providers :[ HttpClient , SectionReqConfigService ,EventSecReqConfigService , AdditionalFieldDetailsModel ]
    })
    .compileComponents(); 
  }));

  beforeEach(() => {
    if(!(sessionStorage.getItem('userData'))){
      let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
   
    fixture = TestBed.createComponent(EventDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
