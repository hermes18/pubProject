import { Injectable, ViewChild } from '@angular/core';
import { GetterSetterService } from 'src/app/core/services/getterSetter.service';
import { NewClaimSharedService } from '../add-new-claim.service';
import { environment } from 'src/environments/environment';
import { SectionReqConfigService } from '../personal-details/personal-details.model';
import { EventInformationSecComponent } from './event-information-sec/event-information-sec.component';


@Injectable()
export class EventSecReqConfigService {

  eventInformationModel: EventInformationModel = new EventInformationModel();
  additionalFieldDetailsModel: AdditionalFieldDetailsModel = new AdditionalFieldDetailsModel();
  informationHealthCareEventModel: InformationHealthCareEventModel = new InformationHealthCareEventModel();
  informationHealthCareFamilyDocModel: InformationHealthCareFamilyDocModel = new InformationHealthCareFamilyDocModel();

  constructor(public storage: GetterSetterService, public newClaimService: NewClaimSharedService,

    public personalDetailSecReqConfig: SectionReqConfigService) { }

  userData = this.storage.getSession('userData');
  rulesRequestParam(screenName) {
    let claimData = this.newClaimService.getClaimData();
    let primaryClaimType = this.newClaimService.getPrimaryClaimType();



    let req = {
      "partner": "metlife",
      "sourceOfOrigin": this.userData.sourceOrigin,
      "screenName": screenName,
      "lob": (claimData ? claimData.newclaim : null),
      "product": (claimData ? claimData.newclaim : null),
      "submittedBy": this.userData.submittedBy,
      "primaryClaimEvent": primaryClaimType,
      //  "selectedClaim": this.userData.claimTypeCode?this.userData.claimTypeCode.join('/'):''
      "selectedClaim": primaryClaimType,
      "claimType": primaryClaimType,
      "relatedEventType": "",
    }
    return req;
  }
  api() {
    let apiConfig = [

      {
        name: "eventInformationSection",
        url: environment.host + environment.eventDetailServiceConfig.url,
        ruleFileIncludes: "RelatedEvent",
        modelNames: this.eventInformationModel,
        method: environment.eventDetailServiceConfig.method,
        requestParam: this.personalDetailSecReqConfig.rulesRequestParam('EventDetailEventInformationSectionRender')
      },
      {
        name: "informationHealthCareEventSection",
        url: environment.host + environment.eventDetailServiceConfig.url,
        ruleFileIncludes: "HealthCareCenterInfo",
        modelNames: this.informationHealthCareEventModel,
        method: environment.eventDetailServiceConfig.method,
        requestParam: this.personalDetailSecReqConfig.rulesRequestParam('EventDetailPrimaryHelathCareSectionRender')
      },
      {
        name: "informationHealthCareFamilyDocSection",
        url: environment.host + environment.eventDetailServiceConfig.url,
        ruleFileIncludes: "HealthCareFamilyDoctor",
        modelNames: this.informationHealthCareFamilyDocModel,
        method: environment.eventDetailServiceConfig.method,
        requestParam: this.personalDetailSecReqConfig.rulesRequestParam('EventDetailFamilyDoctSectionRender')
      }
      // {

      //   name: "additionalFieldDetailsSection",
      //   //url: "assets/mocks/additionalFieldDetailsSection.json",
      //   url: environment.host + environment.eventDetailServiceConfig.url,
      //   ruleFileIncludes: "AdditionalDetails",
      //   modelNames: this.additionalFieldDetailsModel,
      //   method: environment.eventDetailServiceConfig.method,
      //   requestParam: this.personalDetailSecReqConfig.rulesRequestParam('EventDetailAdditionalInformationSectionRender')
      // }

    ];

    if (this.userData.defaultLanguage === 'pl') {
      let url = {
        name: "additionalFieldDetailsSection",
        //url: "assets/mocks/additionalFieldDetailsSection.json",
        url: environment.host + environment.eventDetailServiceConfig.url,
        ruleFileIncludes: "AdditionalDetails",
        modelNames: this.additionalFieldDetailsModel,
        method: environment.eventDetailServiceConfig.method,
        requestParam: this.personalDetailSecReqConfig.rulesRequestParam('EventDetailAdditionalInformationSectionRender')
      }
      let indx = null;
      for (let i = 0; i < apiConfig.length; i++) {
        if (apiConfig[i].name.indexOf(url.name)) {
          indx = i;
          break;
        }
      }

      apiConfig.push(<any>url)
    }
    return apiConfig;
  }

  apiRo() {
    let apiConfig =
    {
      name: "additionalFieldDetailsSection",
      //url: "assets/mocks/additionalFieldDetailsSection.json",
      url: environment.host + environment.eventDetailServiceConfig.url,
      ruleFileIncludes: "AdditionalDetails",
      modelNames: this.additionalFieldDetailsModel,
      method: environment.eventDetailServiceConfig.method,
      requestParam: this.personalDetailSecReqConfig.rulesRequestParam('EventDetailAdditionalInformationSectionRender')
    }

    return apiConfig;
  }


}
export class EventInformationModel {
  dateOfEvent: string = null;
  dateOfBirth: string = null;
  dateLabel: string = null;
  placeOfEvent: string = null;
  eventRelatedTo: string = null;
  causeOfEvent: string = null;
  descriptionOfEvent: string = null;
}
export class AdditionalFieldDetailsModel {
  dateOffirstSymptomsDisease: string = null;
  dateOfRecognitionDisease: string = null;
  notApplicableCheckBox: string = null;
  dateWhenPhysicalInjuriesOccurred: string = null;
  sickLeavePeriod: string = null;
  sickLeavePeriodFromDate: string = null;
  sickLeavePeriodToDate: string = null;
  sickLeavePeriodNACheckBox: string = null;
  temporaryDisabilityPeriod: string = null;
  dateCompletionOfMedicalTreatment: string = null;
  medicalTreatmentNotApplicable: string = null;
  medicalTreatmentStillUndergoing: string = null;
  employerPreparedAccidentReport: string = null;
  policeConductedInvestigation: string = null;
  nameInvestigationEntities: string = null;
  streetName: string = null;
  houseNumber: string = null;
  // flatNumber: string = null;
  country: string = null;
  postalCode: string = null;
  postBox: string = null;
  town: string = null;
  caseNumber: string = null;
  forwhatperiod: string = null;
  employmentPeriod: string = null;
  employmentPeriodFromDate: string = null;
  employmentPeriodToDate: string = null;
  article: string = null;
  county: string = null;
  zipCode: string = null;
  city: string = null;
  flatNo: string = null;
  block: string = null;
  entrance: string = null;
  appartment: string = null;
  sector: string = null;
  otherCountry: string = null;
  otherSportsClubCountry: string = null;
  eventAfterConsumptionAlcohol: string = null;
  sportsClubPlayerDropDown: string = null;
  sportsClubName: string = null;
  sportsClubStreetName: string = null;
  sportsClubHouseNumber: string = null;
  sportsClubPoliceTown: string = null;
  sportsClubPostalCode: string = null;
  sportsClubCountry: string = null;
  sportsClubPostBox: string = null;
  sportsClubCountyName: string = null;
  sportsClubZipCode: string = null;
  sportsClubCity: string = null;
  sportsClubFlatNo: string = null;
  sportsClubBlock: string = null;
  sportsClubEntrance: string = null;
  sportsClubAppartment: string = null;
  sportsClubSector: string = null;
  // sportsFlatNumber: string = null;
}
export class InformationHealthCareEventModel {
  healthCareCenterName: string = null;
  healthCareCenterStreetName: string = null;
  healthCareCenterHouseNumber: string = null;
  //healthCareCenterFlatNumber: string = null;
  healthCareCenterCountry: string = null;
  healthCareCenterPostalCode: string = null;
  healthCareCenterPeriodFrom: string = null;
  healthCareCenterPostBox: string = null;
  healthCareCenterTown: string = null;
  healthCareCenterPeriodTo: string = null;
  healthCareCenterCounty: string = null;
  healthCareCenterZipCode: string = null;
  healthCareCenterCity: string = null;
  healthCareCenterBlock: string = null;
  healthCareCenterFlatNo: string = null;
  healthCareCenterEntrance: string = null;
  healthCareCenterAppartment: string = null;
  healthCareCenterSector: string = null;
  hcCount: string = null;
  healthCareOtherCountry: string = null;
}
export class InformationHealthCareFamilyDocModel {
  familyDoctorName: string = null;
  familyDoctorStreetName: string = null;
  familyDoctorHouseNumber: string = null;
  familyDoctorFlatNumber: string = null;
  familyDoctorCountry: string = null;
  familyDoctorPostalCode: string = null;
  familyDoctorPhoneNumber: string = null;
  familyDoctorPostBox: string = null;
  familyDoctorTown: string = null;
  familyDoctorOtherCountry: string = null;
}