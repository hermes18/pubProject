import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable, forkJoin } from "rxjs";
import { HttpCommonService } from "../../../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray, AbstractControl } from '@angular/forms';
import { CreateFormService } from '../../../shared/services/create-form.service';
import { ErrorMessagesComponent } from '../../../shared/component/error-messages/error-messages.component';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { GetterSetterService } from 'src/app/core/services/getterSetter.service';
import { format } from 'util';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { eClaimsConstants } from 'src/app/core/constants/constant';

@Component({
  selector: 'healthcare-event-sec',
  templateUrl: './healthcare-event-sec.component.html',
  styleUrls: ['./healthcare-event-sec.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HealthcareEventSecComponent implements OnInit {
  @Input() healthCareInfoForm: FormGroup;
  @Input() indx: number;
  @Input() healthCareEventSecRules: any;
  healthCareCenterTown: string = null;
  baseUrl = environment.host + environment.eventDetailServiceConfig.url;
  headers = new HttpHeaders();
  userData = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.userData.sourceOrigin;
  defaultLanguage: string = this.userData.defaultLanguage;
  townFromPoCode: string;

  constructor(private commonService: HttpCommonService, public storage: GetterSetterService,
    public newClaimService: NewClaimSharedService) { }
  //jsonObj = JSON.parse(sessionStorage.userData);
  countryOptions = []
  countryList = [];
  ispoland: boolean = false;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
  //public customPatterns = { '0': { pattern: new RegExp('[0-9]{2}\-[0-9]{3}')} };
  centerPeriodFromMax = new Date();
  centerPeriodFromMin = new Date(eClaimsConstants.dobMinYear, eClaimsConstants.dobMinMnth, eClaimsConstants.dobMinDate);

  centerPeriodToMax = new Date(eClaimsConstants.dobMinYear, eClaimsConstants.dobMinMnth, eClaimsConstants.dobMinDate);
  centerPeriodToMin = new Date();

  addressEnableCountry = eClaimsConstants.corresspondenceAddressEnableCountry;
  postalCodeInitialVal;
  ngOnInit() {
    this.formInit();
  }


  isfuture: boolean = false;

  isDateNotValid: boolean = false;
  inValidHCFromDate: boolean = false;
  healthCarePeriodFromDate;
  validateHCPeriodToDate(event) {

    let toDate = '';
    let fromDate = '';
    this.healthCarePeriodFromDate = new Date(this.healthCareInfoForm.controls.healthCareCenterPeriodFrom.value);
    if (this.healthCareInfoForm.controls.healthCareCenterPeriodTo.value)
      toDate = this.getMMDDYYYY(this.healthCareInfoForm.controls.healthCareCenterPeriodTo.value);
    if (this.healthCareInfoForm.controls.healthCareCenterPeriodFrom.value)
      fromDate = this.getMMDDYYYY(this.healthCareInfoForm.controls.healthCareCenterPeriodFrom.value);

    if (event.targetElement.name === "periodFrom") {

      let today = this.getMMDDYYYY(new Date());
      let selectedDate = this.getMMDDYYYY(event.value);
      let futureDateFlag = this.dateCheck(selectedDate, today);
      if (futureDateFlag)
        this.inValidHCFromDate = true;
      else
        this.inValidHCFromDate = false;
    }

    if (toDate && fromDate) {
      let flag = this.dateCheck(fromDate, toDate);
      if (flag)
        this.isDateNotValid = true;
      else
        this.isDateNotValid = false;
    }
  }
  dateCheck(fromDate, toDate) {
    if (new Date(fromDate) > new Date(toDate))
      return true;
    else
      return false;
  }

  getMMDDYYYY(date) {
    let today = new Date(date);
    let dd = today.getDate();
    let mm = today.getMonth() + 1;
    let yyyy = today.getFullYear();

    if (dd < 10)
      dd = dd;
    if (mm < 10)
      mm = mm;
    return mm + '/' + dd + '/' + yyyy;
  }
  showCountryLabel: boolean = false;
  countryCodes = {
    'RO': '+40',
    'PL': '+48'
  };

  cloneAbstractControl<T extends AbstractControl>(control: T): T {
    let newControl: T;
    //console.log("control",control)
    if (control instanceof FormGroup) {
      let formGroup = new FormGroup({}, control.validator, control.asyncValidator);
      const controls = control.controls;

      Object.keys(controls).forEach(key => {
        formGroup.addControl(key, this.cloneAbstractControl(controls[key]));
        formGroup.controls[key]['isVisible'] = controls[key]['isVisible'];
        formGroup.controls[key]['fieldName'] = controls[key]['fieldName'];
        formGroup.controls[key]['restrict'] = controls[key]['restrict'];

      })

      newControl = formGroup as any;
    }
    else if (control instanceof FormArray) {
      const formArray = new FormArray([], control.validator, control.asyncValidator);

      control.controls.forEach(formControl => formArray.push(this.cloneAbstractControl(formControl)))
      newControl = formArray as any;
    }
    else if (control instanceof FormControl) {
      newControl = new FormControl(null, control.validator, control.asyncValidator) as any;
    }
    else {
      throw new Error('Error: unexpected control value');
    }

    if (control.disabled) newControl.disable({ emitEvent: false });

    return newControl;
  }



  showTownOptionLabel = null;
  countryOnChange(event) {
    this.healthCareInfoForm.get('healthCareCenterPostalCode').setValue('');
    this.healthCareInfoForm.get('healthCareCenterPostBox').setValue(null);
    this.healthCareInfoForm.get('healthCareCenterTown').setValue(null);
    this.showTownOptionLabel = false;
    this.townFromPoCode = ''

    this.showCountryLabel = false;
    this.healthCareInfoForm.controls.healthCareOtherCountry['isVisible'] = this.healthCareInfoForm.controls.healthCareCenterCountry['isVisible']
    this.healthCareInfoForm.controls['healthCareOtherCountry'].setValidators([Validators.nullValidator]);
    this.healthCareInfoForm.controls['healthCareOtherCountry'].updateValueAndValidity();
    if ((this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1)
      && (event.toLowerCase() == this.defaultLanguage)) {
      //      this.corresspondenceAddressForm.controls.isdCode.setValue(this.countryCodes[this.defaultLanguage.toUpperCase()]);
    } else if (event.toLowerCase() == 'other') {
      this.showCountryLabel = true;
      this.healthCareInfoForm.controls.healthCareOtherCountry.reset();
      this.healthCareInfoForm.controls['healthCareOtherCountry'].setValidators([Validators.required]);
      this.healthCareInfoForm.controls['healthCareOtherCountry'].updateValueAndValidity();
    }
    let claimData = this.newClaimService.getClaimData();
    let lob = (claimData ? claimData.newclaim : null);
    //console.log("personal details",lob)
    if (this.healthCareEventSecRules.healthCareCenterPostBox.mandatoryFlag && event == 'US') {
      this.healthCareInfoForm.controls['healthCareCenterPostBox'].setValidators([Validators.required]);
      this.healthCareInfoForm.controls['healthCareCenterPostBox'].updateValueAndValidity();
     
    } else {
      this.healthCareInfoForm.controls['healthCareCenterPostBox'].setValidators([Validators.nullValidator]);
      this.healthCareInfoForm.controls['healthCareCenterPostBox'].updateValueAndValidity();
     
    }

    this.postalCodeSetValidation();
  
   }

postalCodeSetValidation(){
  let validators = (this.postalCodeInitialVal && this.postalCodeInitialVal.required) ? Validators.required : Validators.nullValidator;
    if (this.defaultLanguage.toUpperCase() == 'PL' && 
    this.healthCareInfoForm.get('healthCareCenterCountry').value == 'PL') {
     // this.healthCareInfoForm.controls.healthCareCenterPostalCode['restrict'].maxlength = this.postalCodeInitialVal.length;
     this.healthCareInfoForm.controls.healthCareCenterPostalCode['restrict'].maxlength = this.healthCareEventSecRules.healthCareCenterPostalCode.fieldmaxlength;
     this.healthCareInfoForm.controls.healthCareCenterPostalCode.setValidators([validators]);
    } else {
      this.healthCareInfoForm.controls.healthCareCenterPostalCode['restrict'].maxlength = 10;
      this.healthCareInfoForm.controls.healthCareCenterPostalCode.setValidators([validators]);
    }
    this.healthCareInfoForm.controls['healthCareCenterPostalCode'].updateValueAndValidity();
  
}

  townOptions = [];
  blurPostalCodeField(event) {
    if (this.healthCareInfoForm.controls.healthCareCenterPostalCode.value == '' &&
      this.healthCareInfoForm.controls.healthCareCenterCountry.value == this.defaultLanguage.toUpperCase()
      && this.showTownOptionLabel) {
      this.healthCareInfoForm.get('healthCareCenterTown').setValue(null);
      this.townFromPoCode = '';
    }
    this.showTownOptionLabel = false;
    //console.log("Postal Code")
    if (this.healthCareInfoForm.controls.healthCareCenterPostalCode.value != ''
      && (this.postBoxEnableCountry.indexOf(this.defaultLanguage.toUpperCase()) != -1) &&
      this.healthCareInfoForm.controls.healthCareCenterCountry.value == this.defaultLanguage.toUpperCase()) {
      //console.log("Postal Code")
      let value = this.healthCareInfoForm.controls.healthCareCenterPostalCode.value;
      let postalCodeValue = value;

      this.getPostalCodeValue(postalCodeValue,
        this.defaultLanguage.toUpperCase()).subscribe((data) => {
          // //console.log(data); 
          this.townOptions = data;
          //console.log(this.townOptions,"test",data[0])
          if (data.length > 0) {
            this.healthCareInfoForm.get('healthCareCenterTown').setValue(data[0]);
            this.showTownOptionLabel = true;
            this.townFromPoCode = '*';
          } else {
            this.healthCareInfoForm.get('healthCareCenterTown').setValue(null);
            this.showTownOptionLabel = false;
            this.townFromPoCode = '';
          }
        });
    }
  }




  getPostalCodeValue(event, countryCode) {
let param = {
  "countryCode": countryCode,
  "language": "",
  "pinCode": event
}
    const url = `${environment.host + environment.getPostalCode.url}`;
    return this.commonService[environment.getPostalCode.method](
      url,param);
  }



  formInit() {

    const userData = this.storage.getSession('userData');
    let tenantId = sessionStorage.getItem('tenantId');
    //let tenantId = 'pl';
    if (this.contactCountryEnable.indexOf(this.defaultLanguage.toUpperCase()) != -1) {
      this.healthCareInfoForm.get('healthCareCenterCountry').setValue(this.defaultLanguage.toUpperCase());
    } else {
      this.healthCareInfoForm.get('healthCareCenterCountry').setValue(null);
    }
  this.postboxMandate();
    if (tenantId = 'pl')
      this.ispoland = true;

    this.countryOptions = this.newClaimService.getParamValue('countryList') ? (this.newClaimService.getParamValue('countryList')) : [];
    this.newClaimService.getCountryList().subscribe((data) => {
      this.countryOptions = data;
      setTimeout(() => {
        this.healthCareInfoForm.get('healthCareCenterCountry').setValue(this.healthCareInfoForm.get('healthCareCenterCountry').value);
      }, 0);
    });
    // this.hcEvntDetailsObj.elemntRendHcHcare();

    //console.log("healthCareInfoForm",this.healthCareInfoForm);
    this.postalCodeInitialVal = { 
      length: this.healthCareInfoForm.controls.healthCareCenterPostalCode['restrict'].maxlength,
      required: this.healthCareEventSecRules.healthCareCenterPostalCode.mandatoryFlag
    }
    this.inValidHCFromDate = false;
    this.isDateNotValid = false;
    this.healthCareInfoForm.get('healthCareCenterPostBox').setValue(null);
    this.townFromPoCode = '';
    this.countryOnChange(this.healthCareInfoForm.controls.healthCareCenterCountry.value);
  }

  postboxMandate(){
    
    if (this.healthCareEventSecRules.healthCareCenterPostBox.mandatoryFlag && this.healthCareInfoForm.get('healthCareCenterCountry').value == 'US') {
      this.healthCareInfoForm.controls['healthCareCenterPostBox'].setValidators([Validators.required]);
      this.healthCareInfoForm.controls['healthCareCenterPostBox'].updateValueAndValidity();
     
    } else {
      this.healthCareInfoForm.controls['healthCareCenterPostBox'].setValidators([Validators.nullValidator]);
      this.healthCareInfoForm.controls['healthCareCenterPostBox'].updateValueAndValidity();
     
    }
  }

  public postalMasking = {
    guide: false,
    showMask: true,
    mask: [/\d/, /\d/, '-',
      /\d/, /\d/, /\d/]
  };
}
