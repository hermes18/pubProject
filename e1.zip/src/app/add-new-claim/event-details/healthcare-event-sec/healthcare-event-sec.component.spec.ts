import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { HealthcareEventSecComponent } from './healthcare-event-sec.component';
import { SharedModule} from 'src/app/shared/shared.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SectionReqConfigService } from '../../personal-details/personal-details.model';
import {  FormGroup, FormControl, Validators, FormArray, AbstractControl,FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NewClaimSharedService } from '../../add-new-claim.service';

export class HealthCareRulesMock {
  rulesMock = {"ruleFileName":"Eclaims_Event_Details_HealthCareCenterInfo.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","selectedClaim":"E160","sourceOfOrigin":null,"healthCareCenterName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"healthCareCenterStreetName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"healthCareCenterHouseNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"healthCareCenterFlatNumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"healthCareCenterCountry":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":","},"healthCareCenterPostalCode":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"healthCareCenterPeriodFrom":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"healthCareCenterPostBox":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":","},"healthCareCenterTown":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"50","fieldminlength":"0","allowedDataType":","},"healthCareCenterPeriodTo":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"healthCareCenterCounty":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"healthCareCenterZipCode":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric"},"healthCareCenterCity":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphanumeric-hypen-dot-space"},"healthCareCenterBlock":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"15","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"healthCareCenterFlatNo":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"healthCareCenterEntrance":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"healthCareCenterAppartment":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"healthCareCenterSector":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"1","fieldminlength":"0","allowedDataType":"numeric"},"ksession":null};
}



describe('HealthcareEventSecComponent', () => {
  let component: HealthcareEventSecComponent;
  let fixture: ComponentFixture<HealthcareEventSecComponent>;
  const fb: FormBuilder = new FormBuilder();
  //const secValidations: PersonalRuleMock = new PersonalRuleMock();
  const healthCareValidations: HealthCareRulesMock = new HealthCareRulesMock();
  const newClaimService: NewClaimSharedService = new NewClaimSharedService();


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule, SharedModule,HttpClientTestingModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ HealthcareEventSecComponent ],
      providers : [ SectionReqConfigService,
        { provide : HttpClient },{ provide: FormBuilder, useValue: fb } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    let healthcareDetails ={  healthCareCenterName:  null,
      healthCareCenterStreetName:  null,
      healthCareCenterHouseNumber:  null,
      healthCareCenterCountry:  null,
      healthCareCenterPostalCode:  null,
      healthCareCenterPeriodFrom:  null,
      healthCareCenterPostBox:  null,
      healthCareCenterTown:  null,
      healthCareCenterPeriodTo:  null,
      healthCareCenterCounty:  null,
      healthCareCenterZipCode:  null,
      healthCareCenterCity:  null,
      healthCareCenterBlock:  null,
      healthCareCenterFlatNo:  null,
      healthCareCenterEntrance:  null,
      healthCareCenterAppartment:  null,
      healthCareCenterSector:  null,
      hcCount:  null,
      healthCareOtherCountry:  null}   
    
    fixture = TestBed.createComponent(HealthcareEventSecComponent);
    component = fixture.componentInstance;

    component.healthCareInfoForm =  fb.group(healthcareDetails);

    component.healthCareEventSecRules = healthCareValidations.rulesMock;
    component.healthCareInfoForm.controls.healthCareCenterPostalCode['restrict']={maxlength : '10'};


    fixture.detectChanges();




  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
