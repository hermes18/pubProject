

export class ScreenRenderReqModel{

    partner: string = null; 
    sourceOfOrigin: string = null; 
    lob: string = null; 
    product: string = null; 
    submittedBy: string = null; 
    primaryClaimEvent: string = null; 
    selectedClaim: string = null; 
    screenName: string = null; 
    eventType: string = null; 
    eventRelatedTo: string = null; 
    claimType: string = null; 
    relatedEventType: string = null; 


}