import { HCAddressInfoModel } from './HCAddressInfoModel';


export class HealthCareCenterInfoModel{

    hcAddressInfo: Array<HCAddressInfoModel>;
    sectionRender :string = null;

    primaryHCPeriodFrom: string = null;
    primaryHCName: string = null;
    primaryHCStreetName: string = null;
    primaryHCHouseNumber: string = null;
    primaryHCFlatNumber: string = null;
    primaryHCCountry: string = null;
    primaryHCCountry_Name: string = null;
    primaryHCOtherCountry: string = null;
    primaryHCTown: string = null;
    primaryHCOtherTown: string = null;
    primaryHCPostalCode: string = null;
    primaryHCPostBox: string = null;

    secondaryHC1PeriodFrom: string = null;
    secondaryHC1Name: string = null;
    secondaryHC1StreetName: string = null;
    secondaryHC1HouseNumber: string = null;
    secondaryHC1FlatNumber: string = null;
    secondaryHC1Country: string = null;
    secondaryHC1Country_Name: string = null;
    secondaryHC1OtherCountry: string = null;
    secondaryHC1Town: string = null;
    secondaryHC1OtherTown: string = null;
    secondaryHC1PostalCode: string = null;
    secondaryHC1PostBox: string = null;

    secondaryHC2PeriodFrom: string = null;
    secondaryHC2Name: string = null;
    secondaryHC2StreetName: string = null;
    secondaryHC2HouseNumber: string = null;
    secondaryHC2FlatNumber: string = null;
    secondaryHC2Country: string = null;
    secondaryHC2Country_Name: string = null;
    secondaryHC2OtherCountry: string = null;
    secondaryHC2Town: string = null;
    secondaryHC2OtherTown: string = null;
    secondaryHC2PostalCode: string = null;
    secondaryHC2PostBox: string = null;

    secondaryHC3PeriodFrom: string = null;
    secondaryHC3Name: string = null;
    secondaryHC3StreetName: string = null;
    secondaryHC3HouseNumber: string = null;
    secondaryHC3FlatNumber: string = null;
    secondaryHC3Country: string = null;
    secondaryHC3Country_Name: string = null;
    secondaryHC3OtherCountry: string = null;
    secondaryHC3Town: string = null;
    secondaryHC3OtherTown: string = null;
    secondaryHC3PostalCode: string = null;
    secondaryHC3PostBox: string = null;


}