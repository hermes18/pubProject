import { EclaimsModel } from './EclaimsModel';

describe('EclaimsVO', () => {
 let eclaimsModel: EclaimsModel;
 beforeEach(() => { (1)
  eclaimsModel = new EclaimsModel();
});
  it('should create an instance', () => {
    expect(new EclaimsModel()).toBeTruthy();
  });
});
