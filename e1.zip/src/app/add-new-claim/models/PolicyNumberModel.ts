

export class PolicyNumberModel{
    policyNumber :string=null;
   }
