import {PolicyNumberModel} from  './PolicyNumberModel';
import {ClaimTypeModel} from  './ClaimTypeModel';
import {ClaimAttachmentModel} from  './ClaimAttachmentModel';
import {ClaimCommunicationAddressModel} from  './ClaimCommunicationAddressModel';
import {AdditionalFieldDetailsModel} from  './AdditionalFieldDetailsModel';
import {HealthCareFamilyDocModel} from  './healthCareFamilyDocModel';
import {PersonInsuranceInfoModel} from  './PersonInsuranceInfoModel';
import {PersonProposesClaimInfoModel} from  './PersonProposesClaimInfoModel';
import {HealthCareCenterInfoModel } from './HealthCareCenterInfoModel';
import {DisbursementBenefitModel } from './DisbursementBenefitModel';
import {EventInformationModel } from './EventInformationModel';
import { ScreenRenderReqModel } from './ScreenRenderReqModel';

export class EclaimsModel {    
    
    lineOfBusiness: string = null;  
    claimTypeList : Array<ClaimTypeModel> ;
    userName: string = null;
    uploadedDocumentList : Array<ClaimAttachmentModel> ;
    employerDetails: string = null;
    employerTextKey : string = null;
    claimAddressInfo:  Array<ClaimCommunicationAddressModel>  ;
    disbursementBenefitVO: DisbursementBenefitModel;    
    eventInformationVO : EventInformationModel;
    personInsuranceInfoVO: PersonInsuranceInfoModel ;
    personProposesClaimInfoVO : PersonProposesClaimInfoModel;
    healthCareCenterInfoVO:  HealthCareCenterInfoModel ;
    healthCareFamilyDocVO:   HealthCareFamilyDocModel ;
    eventDetailsAdditionalComments: string = null;
    additionalFieldDetailsVO : AdditionalFieldDetailsModel;
    claimsType: string = null;
    claimNumber: string = null;
    uploadedDocumentSecondaryList: Array<ClaimAttachmentModel>  ;
    policyList : Array<PolicyNumberModel> ;
    brokerOrAgentName: string = null;
    sourceOfOrigin : string= null;
    confirmationTextList: Array<string>  = null;
    emailDeliveryStatus : string= null;
    submittedBy : string = null;
    map = new Map;
    screenRequest : ScreenRenderReqModel;
    documentList :Array<string> ;
}
