 
export class HCAddressInfoModel{


    hcAddressType:  string = null;
    hcPeriodFrom:  string = null;
    hcName:  string = null;
    hcStreetName:  string = null;
    hcHouseNumber:  string = null;
    hcFlatNumber:  string = null;
    hcCountry:  string = null;
    hcCountryName:  string = null;
    hcOtherCountry:  string = null;
    hcTown:  string = null;
    hcOtherTown:  string = null;
    hcPostalCode:  string = null;
    hcPostBox:  string = null;
    hcPeriodTo:  string = null;
    hcCity:  string = null;
    hcBlock:  string = null;
    hcEntrance:  string = null;
    hcAppartment:  string = null;
    hcSector:  string = null;
    hcCounty:  string = null;
    hcPhoneNumber:  string = null;
    hcZipCode : string = null;
    hcCountryCode : string = null;
}