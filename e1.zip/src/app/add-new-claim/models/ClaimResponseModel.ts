
import {ClaimAttachmentModel} from  './ClaimAttachmentModel';
export class ClaimResponseModel{

     claimNo : string =null;
	
	  lob: string =null;
	
	  language: string =null;
    
      claimAttachmentVO : Array<ClaimAttachmentModel> ;
	

}