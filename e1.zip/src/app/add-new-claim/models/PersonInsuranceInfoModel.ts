

export class PersonInsuranceInfoModel {

  title: string = null
  name: string = null
  surName: string = null
  maidenName: string = null
  peselNumber: string = null
  dateOfBirth: string = null
  seriesAndNumber: string = null
  profession: string = null
  qualifiedProfession: string = null
  nameTrimmed: string = null
  surnameTrimmed: string = null
  insuranceEventRefersto: string = null
  insuranceEventTypeList: Array<string> = null;
  insuranceEventCode: string = null
  nameEncoded: string = null
  surNameEncoded: string = null
  maidenNameEncoded: string = null
  seriesAndNumberEncoded: string = null
  professionEncoded: string = null
  countryName: string = null
  copyPersonalDataFromEc: boolean = null
  copyAddressFromEc: boolean = null
  otherCountryName: string = null
  emailAddressOfTheAgentFilingClaim: string = null
  commentsByAgent: string = null
  insuranceRefersCountryName: string = null
  insuranceRefersSex: string = null
  eventSelected: string = null;
  cnpField: string = null;
  sectionRender :string = null;
}