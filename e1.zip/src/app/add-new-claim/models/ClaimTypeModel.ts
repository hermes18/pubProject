export class ClaimTypeModel{ 

    claimTypeValue: string = null; 
    claimTypecheckBoxId: string = null;
    claimConfirmationCode: string = null; 
    claimTypeLabelValue : string = null;
  }
  