
 
export class EventInformationModel{
    accidentEvent : string = null;
      eventRelatedTo : string = null;
      eventRelatedToKey : string = null;
      eventInvolvesDeath : string = null;
      deathWasNatural : string = null;
      dateOfEvent : string = null;
      placeOfEvent : string = null;
      cause : string = null;
      descriptionOfInjuries : string = null;
      causeOfEvent:string = null;
      sectionRender :string = null;
  }