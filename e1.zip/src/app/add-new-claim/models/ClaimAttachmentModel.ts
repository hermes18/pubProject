

export class ClaimAttachmentModel{ 
  fileValue: string = null;
    claimAttachmentsId: string = null; 
    orderId: string = null; 
    claimNumber: string = null; 
    claimType : string;
    documentType: string = null; 
    documentExt: string = null;
    status:  number = 0;
    exportTime : Date;
    fileName: string = null;
    document : string = null;
    id: string = null;
    pdfDocumentType: string = null;
    sectionRender :string = null;
     
  } 