import { AdditionalFieldAddressInfoModel } from './AdditionalFieldAddressInfoModel';


export class AdditionalFieldDetailsModel {

    firstSymptomsOfDisease: string = null;
    recognitionOfDisease: string = null;
    recognitionOfDiseaseNotApplicable: boolean = false;
    physicalInjuriesOccured: string = null;
    sickLeaveFromDate: string = null;
    sickLeaveToDate: string = null;
    sickLeaveNotApplicable: boolean = false;
    noSickLeavePeriodSpecified: boolean = false;
    temporaryDisabilityFromDate: string = null;
    temporaryDisabilityToDate: string = null;
    temporaryDisabilityNotApplicable: boolean = false;
    medicalTreatmentFromDate: string = null;
    medicalTreatmentToDate: string = null;
    medicalTreatmentNotApplicable: boolean = false
    medicalTreatmentStillUndergoing: boolean = false
    investigationConductedDropDown: string = null;
    investigationEntities: string = null;
    address: string = null;
    caseNumber: string = null;
    eventAfterAlchoholConsumtion: string = null;
    employerAccidentReport: string = null;
    employerDocName: string = null;
    policeInvestigationDocName: string = null;
    sportsClubPlayerDropDown: string = null;
    addressInfo: Array<AdditionalFieldAddressInfoModel>;
    disableSickLeaveNotApplicable: boolean = false;
    disableMedicalLeaveNotApplicable: boolean = false;
    renderAttachementSectionForEmpReport: boolean = false;
    removePoliceInvestigationFile: boolean = false;
    forwhatperiod: string = null;
    article: string = null;
    employmentPeriodFrom: string = null;
    employmentPeriodTo: string = null;
    sportsClubPoliceTown: string = null;
    sportsClubOtherTown: string = null;

    investigatedPoliceCountry: string = null;
    investigatedPoliceStreetName: string = null;
    investigatedPoliceHouseNumber: string = null;
    investigatedPolicePostalCode: string = null;
    investigatedPoliceOtherCountry: string = null;
    investigatedPoliceTown: string = null;
    investigatedPoliceOtherTown: string = null;
    investigatedPolicePostBox: string = null;
    sportsClubName: string = null;
    sportsClubCountry: string = null;
    sportsClubStreetName: string = null;
    sportsClubOtherCountry: string = null;
    sportsClubPostalCode: string = null;
    sportsClubHouseNumber: string = null;
    sportsClubPostBox: string = null;
    sectionRender :string = null;
}