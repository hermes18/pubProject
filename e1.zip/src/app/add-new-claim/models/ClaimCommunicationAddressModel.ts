


export class ClaimCommunicationAddressModel{

  addressType: string 	= null;
  streetName: string 	= null;
  streetNumber: string 	= null;
  flatNumber: string 	= null;
  postalCode: string 	= null;
  town: string 	= null;
  stateCountry: string 	= null;
  stateCountry_cntrynme: string 	= null;
  otherCountry: string 	= null;
  mobileNumber: string 	= null;
  email: string 	= null;
  modeOfCommunication: string 	= null;
  authorizeDetails: string 	= null;
  isdCode: string 	= null;
  county: string 	= null;
  city: string 	= null;
  zipCode: string 	= null;
  block: string 	= null;
  entrance: string 	= null;
  appartment: string 	= null;
  sector: string 	= null;
  mailingAddressConfirmation: string 	= null;
  postBox: string 	= null;
  houseNo: string 	= null;
  country: string 	= null;
  countryCode  : string = null;
  
  }