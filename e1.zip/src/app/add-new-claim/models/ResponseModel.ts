
export class ResponseModel{

     claimNo : number
	
	 
	

}