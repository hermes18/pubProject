

export class HCFamilyDocModel{

    familyDocName: string = null; 
    familyDocStreetName: string = null; 
    familyDocHouseNumber: string = null; 
    familyDocFlatNumber: string = null; 
    familyDocCountry: string = null; 
    familyDocCountry_Name: string = null; 
    familyDocOtherCountry: string = null; 
    familyDocTown: string = null; 
    familyDocOtherTown: string = null; 
    familyDocPostalCode: string = null; 
    familyDocPostBox: string = null; 
    familyDocPhoneNumber: string = null; 
    familyDocCountryCode: string = null; 
    familyDocType: string = null; 

}