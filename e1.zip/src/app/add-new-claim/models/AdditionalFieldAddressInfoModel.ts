

export class AdditionalFieldAddressInfoModel{

    addressTpe:  string = null;
    streetName: string = null; 
    houseNumber: string = null; 
    town: string = null; 
    otherTown: string = null; 
    postalCode: string = null; 
    country: string = null; 
    country_Name: string = null; 
    countryCode: string = null;  
    otherCountry: string = null; 
    postBox: string = null; 
    name: string = null; 
    city: string = null; 
    flatNo: string = null; 
    block: string = null; 
    entrance: string = null; 
    appartment: string = null; 
    sector: string = null; 
    countyName: string = null; 

}