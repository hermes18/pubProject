import { HCFamilyDocModel } from './HCFamilyDocModel';

export class HealthCareFamilyDocModel {

     familyDocInfo: Array<HCFamilyDocModel>;
     sectionRender :string = null;

     primaryFamilyDocName: string = null;
     primaryFamilyDocStreetName: string = null;
     primaryFamilyDocHouseNumber: string = null;
     primaryFamilyDocFlatNumber: string = null;
     primaryFamilyDocCountry: string = null;
     primaryFamilyDocCountry_Name: string = null;
     primaryFamilyDocOtherCountry: string = null;
     primaryFamilyDocTown: string = null;
     primaryFamilyDocOtherTown: string = null;
     primaryFamilyDocPostalCode: string = null;
     primaryFamilyDocPostBox: string = null;
     primaryFamilyDocPhoneNumber: string = null;
     primaryFamilyDocCountryCode: string = null;

     secondaryFamilyDoc1Name: string = null;
     secondaryFamilyDoc1StreetName: string = null;
     secondaryFamilyDoc1HouseNumber: string = null;
     secondaryFamilyDoc1FlatNumber: string = null;
     secondaryFamilyDoc1Country: string = null;
     secondaryFamilyDoc1Country_Name: string = null;
     secondaryFamilyDoc1OtherCountry: string = null;
     secondaryFamilyDoc1Town: string = null;
     secondaryFamilyDoc1OtherTown: string = null;
     secondaryFamilyDoc1PostalCode: string = null;
     secondaryFamilyDoc1PostBox: string = null;
     secondaryFamilyDoc1PhoneNumber: string = null;
     secondaryFamilyDoc1CountryCode: string = null;

     secondaryFamilyDoc2Name: string = null;
     secondaryFamilyDoc2StreetName: string = null;
     secondaryFamilyDoc2HouseNumber: string = null;
     secondaryFamilyDoc2FlatNumber: string = null;
     secondaryFamilyDoc2Country: string = null;
     secondaryFamilyDoc2Country_Name: string = null;
     secondaryFamilyDoc2OtherCountry: string = null;
     secondaryFamilyDoc2Town: string = null;
     secondaryFamilyDoc2OtherTown: string = null;
     secondaryFamilyDoc2PostalCode: string = null;
     secondaryFamilyDoc2PostBox: string = null;
     secondaryFamilyDoc2PhoneNumber: string = null;
     secondaryFamilyDoc2CountryCode: string = null;

}