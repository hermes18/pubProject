
export class LandingReqModel{

	sourceOrigin: string = null; 
	identifierToken: string = null; 
	applicationType: string = null; 
	userName: string = null; 
	pesel: string = null; 
	requesterName: string = null; 
	requesterSurName: string = null; 
	requesterAddress: string = null; 
	requesterEmail: string = null; 
	requestFrom: string = null; 
	countryCode: string = null; 


}