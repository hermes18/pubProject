import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { NewClaimSharedService } from '../../add-new-claim.service';

@Component({
  selector: 'type-event-review-section',
  templateUrl: './type-event-review-section.component.html',
  styleUrls: ['./type-event-review-section.component.scss']
})
export class TypeEventReviewSectionComponent implements OnInit {

  typeClaimDetails: any = {};
  typeOfBusiness;
  policyNumber: Array<string>;
  typeDetailFormGroup: any;
  @ViewChild('lineOfBusiness_tooltip', { static: false }) lineOfBusiness_tooltip;

  @HostListener('window:scroll', ['$event'])
  scrollHandler(event) {
    if (this.lineOfBusiness_tooltip) {
      this.lineOfBusiness_tooltip.hide();
    }
  }
  constructor(public newClaimService: NewClaimSharedService) { }


  ngOnInit() {

  }

  initMethod() {
    this.typeClaimDetails = this.newClaimService.getClaimData() ? this.newClaimService.getClaimData() : '';
    this.typeDetailFormGroup = this.newClaimService.getParamValue('typeDetailsForm') ? this.newClaimService.getParamValue('typeDetailsForm') : '';
    this.typeOfBusiness = this.typeClaimDetails ? this.typeClaimDetails['newclaim'] : '';
    this.policyNumber = this.typeClaimDetails ? this.typeClaimDetails['policyNumber'] : '';
  }

}
