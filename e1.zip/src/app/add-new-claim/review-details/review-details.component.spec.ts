import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { httpTranslateLoader } from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { ReviewDetailsComponent } from './review-details.component';
import { TypeEventReviewSectionComponent } from './type-event-review-section/type-event-review-section.component';
import { PersonalDetailReviewSectionComponent } from './personal-detail-review-section/personal-detail-review-section.component';
import { EventDetailReviewSectionComponent } from './event-detail-review-section/event-detail-review-section.component';
import { LabelFieldComponent } from 'src/app/shared/component/label-field/label-field.component';
import { BenefitSecReviewComponent } from './personal-detail-review-section/benefit-sec-review/benefit-sec-review.component';
import { FormDisbursemnetReviewSecComponent } from './personal-detail-review-section/form-disbursemnet-review-sec/form-disbursemnet-review-sec.component';
import { EventInfoReviewSecComponent } from './event-detail-review-section/event-info-review-sec/event-info-review-sec.component';
import { AdditionalSecReviewComponent } from './event-detail-review-section/additional-sec-review/additional-sec-review.component';
import { HealthCarePrimaryReviewComponent } from './event-detail-review-section/health-care-primary-review/health-care-primary-review.component';
import { HealthcareFamilydocRevSecComponent } from './event-detail-review-section/healthcare-familydoc-rev-sec/healthcare-familydoc-rev-sec.component';
import { MatDialog } from '@angular/material';

describe('ReviewDetailsComponent', () => {
  let component: ReviewDetailsComponent;
  let fixture: ComponentFixture<ReviewDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule, HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        })
      ],
      declarations: [ReviewDetailsComponent, TypeEventReviewSectionComponent,
        PersonalDetailReviewSectionComponent, EventDetailReviewSectionComponent, LabelFieldComponent,
        HealthcareFamilydocRevSecComponent, HealthCarePrimaryReviewComponent, AdditionalSecReviewComponent,
        EventInfoReviewSecComponent, BenefitSecReviewComponent, FormDisbursemnetReviewSecComponent],
      providers: [{ provide: HttpClient },
      { provide: MatDialog }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(ReviewDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
