import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { FormDisbursemnetReviewSecComponent } from './form-disbursemnet-review-sec.component';
import {LabelFieldComponent} from 'src/app/shared/component/label-field/label-field.component';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { of } from 'rxjs';


describe('FormDisbursemnetReviewSecComponent', () => {
  let component: FormDisbursemnetReviewSecComponent;
  let fixture: ComponentFixture<FormDisbursemnetReviewSecComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ FormDisbursemnetReviewSecComponent,LabelFieldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(FormDisbursemnetReviewSecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  

  it('initMethod should call initMethod', () => {
    
    spyOn(component, 'initMethod').and.callThrough();
    component.initMethod();
    expect(component.initMethod).toHaveBeenCalled();
  });
 

  it('editData should call stepperEdit.emit', () => {
    spyOn(component.stepperEdit, 'emit').and.callFake(function () { });
    spyOn(component, 'editData').and.callThrough();
    component.editData(1);
    expect(component.editData).toHaveBeenCalled();
  });
  it('getCountry should call getCountry' , () => {
 
 
    let countryList = [
      {"countryCode":"AF","countryName":" Afganistan"},
      {"countryCode":"AL","countryName":" Albania"},
      {"countryCode":"DZ","countryName":" Algieria"},
      {"countryCode":"AD","countryName":" Andora"},
      {"countryCode":"AO","countryName":" Angola"},
      {"countryCode":"AI","countryName":" Anguilla"},
      {"countryCode":"AQ","countryName":" Antarktyka"}
    ];
    let newClaimService = TestBed.get(NewClaimSharedService);
    spyOn(component,'getCountry').and.callThrough();
    spyOn(newClaimService,'getCountryList').and.returnValue(of(countryList));
  
    component.getCountry('pl');

    expect(component.getCountry ).toHaveBeenCalled();
  });

  

  it('getformdisbursement should call getformdisbursement' , () => {
    spyOn(component, 'getformdisbursement').and.callThrough();
    component.getformdisbursement('institution');
    component.getformdisbursement('trader');
    component.getformdisbursement('');
    expect(component.getformdisbursement ).toHaveBeenCalled();
  });

  it('toShowotherBankDetails should set showcountryOfBankLabel    value to true' , () => {
    spyOn(component, 'toShowotherBankDetails').and.callThrough();
    component.formDisbursementGroup={get:function(val){
      return {value:'other'} }
    }
    component.showcountryOfBankLabel   = false;
    component.toShowotherBankDetails();
    expect(component.showcountryOfBankLabel ).toEqual(true);
  });
  it('showBankNumberField should set showBankNumberValue   value to true' , () => {
    spyOn(component, 'showBankNumberField').and.callThrough();
    component.formDisburseSectionValues ={bankaccountnumber:''}
    component.showBankNumberValue  = false;
    component.showBankNumberField();
    expect(component.showBankNumberValue ).toEqual(true);
  });
  it('toggleFieldTextType should set showBankNumberValue  value', () => {
    spyOn(component, 'toggleFieldTextType').and.callThrough();
    component.showBankNumberValue  = false;
    component.toggleFieldTextType();
    expect(component.showBankNumberValue ).toEqual(true);
  });
  
});
