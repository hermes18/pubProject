import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { ReviewDetailsCommon } from '../../review-details.common';
import { eClaimsConstants } from 'src/app/core/constants/constant';

@Component({
  selector: 'form-disbursemnet-review-sec',
  templateUrl: './form-disbursemnet-review-sec.component.html',
  styleUrls: ['./form-disbursemnet-review-sec.component.scss']
})
export class FormDisbursemnetReviewSecComponent implements OnInit {
  @Output() stepperEdit = new EventEmitter();
  formDisburseSectionValues;

  bankCountryDefaultList = [{
    'countryCode': 'pl',
    'countryName': 'Poland'
  },
  {
    'countryCode': 'ro',
    'countryName': 'Romania'
  },
  {
    'countryCode': 'eu',
    'countryName': 'European Union'
  },
  {
    'countryCode': 'other',
    'countryName': 'other country'
  }]
  bankCountryName;
  countryNameInTransferBank;
  postCountryName;
  formDisbursementGroup;
  showTranferBusinessUnit: boolean = false;
  showTranferNameSurname: boolean = false;
  showpostcopyfromlegaltrader: boolean = false;
  userData = JSON.parse(sessionStorage.userData);
  defaultLanguage: string = this.userData.defaultLanguage;
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  showcountryOfBankLabel: boolean = false;
  peselEnableCountry = eClaimsConstants.peselEnableCountry;
  toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
  corresspondenceAddressEnableCountry = eClaimsConstants.corresspondenceAddressEnableCountry;

  constructor(public newClaimService: NewClaimSharedService) { }

  ngOnInit() {
  }

  initMethod() {
    const formDisburseSectionValues = this.newClaimService.getPersonalDetails() ? this.newClaimService.getPersonalDetails() : '';
    this.showTranferBusinessUnit = false;
    this.showTranferNameSurname = false;
    this.showpostcopyfromlegaltrader = false;
    if (formDisburseSectionValues) {
      this.formDisburseSectionValues = formDisburseSectionValues.value.formOfDisbursementSection;
      this.formDisbursementGroup = formDisburseSectionValues.controls.formOfDisbursementSection;
      this.getformdisbursement(formDisburseSectionValues.value.entitledForBenefitsSection.benefitiaryGrp);
      this.toShowotherBankDetails();
      this.bankCountryName = this.formDisburseSectionValues ? this.formDisburseSectionValues.countryofbank ?
        ReviewDetailsCommon.countryNameList(this.bankCountryDefaultList, this.formDisburseSectionValues.countryofbank) : '' : '';
      this.countryNameInTransferBank = this.formDisburseSectionValues ? this.formDisburseSectionValues.country ?
        ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), this.formDisburseSectionValues.country) : '' : '';
      this.postCountryName = this.formDisburseSectionValues ? this.formDisburseSectionValues.post_country ?
        ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), this.formDisburseSectionValues.post_country) : '' : '';
      this.showBankNumberField();
    }
  }

  countryeValue: any;
  getCountry(event) {

    this.newClaimService.getCountryList().subscribe((data) => {

      this.countryeValue = ReviewDetailsCommon.countryNameList(data, event);

    });

    return this.countryeValue;

  }
  getformdisbursement(event) {
    //console.log("revecivedbeneficiaryValue", event)
    if (event == "institution") {
      this.showTranferBusinessUnit = true;
      this.showTranferNameSurname = false;
    } else if (event == "trader") {
      this.showpostcopyfromlegaltrader = true;
      this.showTranferBusinessUnit = true;
      this.showTranferNameSurname = false;
    } else {
      this.showTranferBusinessUnit = false;
      this.showTranferNameSurname = true;
    }

  }

  toShowotherBankDetails() {
    this.showcountryOfBankLabel = false;
    if (this.formDisbursementGroup.get('countryofbank').value == 'other' || (this.formDisbursementGroup.get('countryofbank').value == 'eu')) {
      this.showcountryOfBankLabel = true;
    }
  }

  editData(pageStepper) {
    this.stepperEdit.emit(pageStepper);
  }

  showBankNumberValue: boolean = false;
  bankaccountnumberFieldMask;
  showBankNumberField() {
    this.bankaccountnumberFieldMask = this.formDisburseSectionValues.bankaccountnumber ? this.formDisburseSectionValues.bankaccountnumber.split('') : [];
    this.showBankNumberValue = true;

  }
  toggleFieldTextType() {
    this.showBankNumberValue = !this.showBankNumberValue;
  }
}
