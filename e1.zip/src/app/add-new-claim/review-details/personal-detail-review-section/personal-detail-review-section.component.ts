import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { FormDisbursemnetReviewSecComponent } from './form-disbursemnet-review-sec/form-disbursemnet-review-sec.component';
import { BenefitSecReviewComponent } from './benefit-sec-review/benefit-sec-review.component';

import { ReviewDetailsCommon } from '../review-details.common';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { DataService } from 'src/app/shared/services/data.service';

@Component({
  selector: 'personal-detail-review-section',
  templateUrl: './personal-detail-review-section.component.html',
  styleUrls: ['./personal-detail-review-section.component.scss']
})
export class PersonalDetailReviewSectionComponent implements OnInit {

  @ViewChild(FormDisbursemnetReviewSecComponent, { static: false }) formDisburseSection: FormDisbursemnetReviewSecComponent;
  @ViewChild(BenefitSecReviewComponent, { static: false }) benefitReviewSection: BenefitSecReviewComponent;

  personaDetailsFormValues;
  insuranceSectionValue: any = {};
  beneficiarySection = {};
  dateOfBirth;
  correspondenceSection;
  individualNationalityList = [];
  // benefCapacityLabel: string;
  countryOfRegistrationOfInst = [];
  nationalityFieldInsurance;
  insuranceFormGroup;

  formDetails = [
    {
      "form": "formDisburseSection",
      "initFunc": "initMethod",
      "formRef": "formDisburseSection"
    },
    {
      "form": "benefitReview",
      "initFunc": "initMethod",
      "formRef": "benefitReviewSection"
    }];
  newCalimDetails;
  correspondanceCountry;
  corresPondanceControlGroup;
  residanceSectionValue;
  residanceFormGroup;
  renderFlagList: any = {};
  residanceCountry: any;
  userData = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.userData.sourceOrigin;
  defaultLanguage: string = this.userData.defaultLanguage;
  corresspondenceAddressEnableCountry = eClaimsConstants.corresspondenceAddressEnableCountry;
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  peselEnableCountry = eClaimsConstants.peselEnableCountry;
  CNPEnable = eClaimsConstants.CNPEnable;



  @Output() stepperEdit = new EventEmitter();
  constructor(public newClaimService: NewClaimSharedService, public dataService: DataService, ) { }

  ngOnInit() {
  }

  correspondanceLabelKey;
  cnpFieldMask;
  initMethod() {
    this.renderFlagList = this.newClaimService.getParamValue('renderSecFlagList');
    this.newCalimDetails = this.newClaimService.getClaimData() ? this.newClaimService.getClaimData() : '';
    this.personaDetailsFormValues = this.newClaimService.getPersonalDetails() ? this.newClaimService.getPersonalDetails() : '';
    this.correspondanceLabelKey = this.dataService.getOption('labelKeyinCorres');

    if (this.personaDetailsFormValues) {

      if (this.personaDetailsFormValues.value['insuranceRefersToSection']) {
        this.insuranceSectionValue = this.personaDetailsFormValues.value['insuranceRefersToSection'];
        this.dateOfBirth = ReviewDetailsCommon.dateFormat(this.insuranceSectionValue['dobField']);
        this.nationalityFieldInsurance = this.insuranceSectionValue['nationalityField'] ?
          ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), this.insuranceSectionValue['nationalityField']) : '';
      }
      if (this.personaDetailsFormValues.controls.insuranceRefersToSection) {
        this.insuranceFormGroup = this.personaDetailsFormValues.controls.insuranceRefersToSection;

      }
      if (this.personaDetailsFormValues.value['resideneAddressSection']) {
        this.residanceSectionValue = this.personaDetailsFormValues.value['resideneAddressSection'];
        this.residanceCountry = (this.residanceSectionValue && this.residanceSectionValue['country']) ?
          ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), this.residanceSectionValue['country']) : '';

      }

      if (this.personaDetailsFormValues.controls.resideneAddressSection) {
        this.residanceFormGroup = this.personaDetailsFormValues.controls.resideneAddressSection;

      }

      if (this.personaDetailsFormValues.controls.correspondenceAddressSection) {
        this.correspondenceSection = this.personaDetailsFormValues.value['correspondenceAddressSection'];
        this.corresPondanceControlGroup = this.personaDetailsFormValues.controls.correspondenceAddressSection;
        this.correspondanceCountry = this.correspondenceSection.country ?
          ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), this.correspondenceSection.country) : '';

      }



      this.showPeselField();

    }
    this.callSubCompInit();

  }

  countryeValue: any;
  getCountry(event) {

    this.newClaimService.getCountryList().subscribe((data) => {

      this.countryeValue = ReviewDetailsCommon.countryNameList(data, event);

    });

    return this.countryeValue;

  }

  editData(pageStepper) {
    this.stepperEdit.emit(pageStepper);
  }

  callSubCompInit() {
    setTimeout(() => {
      for (let i = 0; i < this.formDetails.length; i++) {
        if (this[this.formDetails[i].formRef] &&
          this[this.formDetails[i].formRef][this.formDetails[i].initFunc]) {
          this[this.formDetails[i].formRef][this.formDetails[i].initFunc]();
        }

      }
    }, 0)

  }


  showError(controlName) {
    if (this.personaDetailsFormValues && this.personaDetailsFormValues.controls.insuranceRefersToSection.controls[controlName].errors) {
      return true;
    } else {
      return false;
    }

  }

  showPeselFieldValue: boolean = false;
  showPeselField() {
    this.cnpFieldMask = this.insuranceSectionValue.cnpfield ? this.insuranceSectionValue.cnpfield.split('') : [];
    this.showPeselFieldValue = true;

  }
  toggleFieldTextType() {
    this.showPeselFieldValue = !this.showPeselFieldValue;
  }
}
