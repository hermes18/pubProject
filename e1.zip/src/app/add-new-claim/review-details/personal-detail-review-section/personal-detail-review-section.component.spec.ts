import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { PersonalDetailReviewSectionComponent } from './personal-detail-review-section.component';
import {LabelFieldComponent} from 'src/app/shared/component/label-field/label-field.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { of } from 'rxjs';

describe('PersonalDetailReviewSectionComponent', () => {
  let component: PersonalDetailReviewSectionComponent;
  let fixture: ComponentFixture<PersonalDetailReviewSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ PersonalDetailReviewSectionComponent,LabelFieldComponent ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(PersonalDetailReviewSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('initMethod should call showPeselField', () => {
    spyOn(component, 'initMethod').and.callThrough();
    spyOn(component, 'showPeselField').and.callThrough();
    component.initMethod();
    expect(component.initMethod).toHaveBeenCalled();
  });


  it('getCountry should call getCountry' , () => {
 
 
    let countryList = [
      {"countryCode":"AF","countryName":" Afganistan"},
      {"countryCode":"AL","countryName":" Albania"},
      {"countryCode":"DZ","countryName":" Algieria"},
      {"countryCode":"AD","countryName":" Andora"},
      {"countryCode":"AO","countryName":" Angola"},
      {"countryCode":"AI","countryName":" Anguilla"},
      {"countryCode":"AQ","countryName":" Antarktyka"}
    ];
    let newClaimService = TestBed.get(NewClaimSharedService);
    spyOn(component,'getCountry').and.callThrough();
    spyOn(newClaimService,'getCountryList').and.returnValue(of(countryList));
  
    component.getCountry('pl');

    expect(component.getCountry ).toHaveBeenCalled();
  });
  it('editData should call stepperEdit.emit', () => {
    spyOn(component.stepperEdit, 'emit').and.callFake(function () { });
    spyOn(component, 'editData').and.callThrough();
    component.editData(1);
    expect(component.editData).toHaveBeenCalled();
  });
  it('toggleFieldTextType should set showPeselFieldValue   value', () => {
    spyOn(component, 'toggleFieldTextType').and.callThrough();
    component.showPeselFieldValue   = false;
    component.toggleFieldTextType();
    expect(component.showPeselFieldValue  ).toEqual(true);
  });
  it('showError should return true or false', () => {
    spyOn(component, 'showError').and.callThrough();
    component.showPeselFieldValue = false;
    component.showError('controlName');
    expect(component.showPeselFieldValue).toEqual(false);
  });


  it('callSubCompInit should cal callSubCompInit', () => {
    spyOn(component, 'callSubCompInit').and.callThrough();
    component.callSubCompInit();
    expect(component.callSubCompInit).toHaveBeenCalled();
  });
  it('showPeselField should cal showPeselFieldValue ', () => {
    spyOn(component, 'showPeselField').and.callThrough();
    component.insuranceSectionValue={cnpfield : ''}
    component.showPeselFieldValue = false;
    component.showPeselField();
    expect(component.showPeselFieldValue ).toEqual(true);
  });

  
  
});
