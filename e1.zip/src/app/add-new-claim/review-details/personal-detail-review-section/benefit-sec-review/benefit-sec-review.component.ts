import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { ReviewDetailsCommon } from '../../review-details.common';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { DataService } from 'src/app/shared/services/data.service';

@Component({
  selector: 'benefit-sec-review',
  templateUrl: './benefit-sec-review.component.html',
  styleUrls: ['./benefit-sec-review.component.scss']
})
export class BenefitSecReviewComponent implements OnInit {
  benefCapacityLabel: string;
  beneficiarySection: any;
  individualNationalityList = [];
  countryOfRegInstitution = [];
  countryOfTrader = [];

  capacityFormRadioGrp_pl_indv =
    {
      'insured': 'eClaims.newClaim.personalDtails.insured',

      'owner': 'eClaims.newClaim.personalDtails.owner',

      'otherPerson': 'eClaims.newClaim.personalDtails.otherPerson',

      'benefitiary': 'eClaims.newClaim.personalDtails.beneficiaryEntitledTo',


      'statutoryRepBen': 'eClaims.newClaim.personalDtails.statutoryOfBeneficiary',

      'plenipotentiaryBenf': 'eClaims.newClaim.personalDtails.plenipotentiaryOfBeneficiary'
    };
  countryOfBirthIndv;
  dateOfBirthIndv;
  benefitSectionFormGroup;
  userData = JSON.parse(sessionStorage.userData);

  documentValidUptoShow = eClaimsConstants.documentValidUptoShow;
  defaultLanguage = this.userData.defaultLanguage.toUpperCase();
  peselEnableCountry = eClaimsConstants.peselEnableCountry;
  countrynationalityIndv = [];
  CNPEnable = eClaimsConstants.CNPEnable;
  isTraderVisible: boolean = false;
  countryBirthIndv = eClaimsConstants.countryBirthIndv;
  @Output() stepperEdit = new EventEmitter();
  constructor(public newClaimService: NewClaimSharedService, public dataService: DataService) { }

  ngOnInit() {
  }
  citizenShipInd;
  capacityRadioValues;
  initMethod() {
    this.individualNationalityList = [];
    this.countryOfRegInstitution = [];
    this.countryOfTrader = [];
    this.countrynationalityIndv = [];
    const personaDetailsFormValues = this.newClaimService.getPersonalDetails() ? this.newClaimService.getPersonalDetails() : '';
    if (personaDetailsFormValues) {
      this.capacityRadioValues = this.dataService.getOption('capacityValue');
      this.beneficiarySection = personaDetailsFormValues.value['entitledForBenefitsSection'];
      this.benefitSectionFormGroup = personaDetailsFormValues.controls.entitledForBenefitsSection;;
      this.benefCapacityLabel = this.getCapacityValue();
      this.newClaimService.getTraderFlag().subscribe((data) => {
        this.isTraderVisible = data;
      });
      this.dateOfBirthIndv = ReviewDetailsCommon.dateFormat(this.beneficiarySection['dateOfBirthIndv']);
      this.countryOfBirthIndv = this.beneficiarySection['countryOfBirthIndv'] ?
        ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), this.beneficiarySection['countryOfBirthIndv']) : '';
      this.getIndividualNationality();
      this.citizenShipInd = this.beneficiarySection['citizenship'] ?
        ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), this.beneficiarySection['citizenship']) : '';
      this.showPeselField();
    }
  }

  documnetDateFormat;
  getDocumentFormat(documentDate) {
    return documentDate ? ReviewDetailsCommon.dateFormat(documentDate) : '';

  }
  editData(pageStepper) {
    this.stepperEdit.emit(pageStepper);
  }

  getCapacityValue() {
    for (const key in this.capacityFormRadioGrp_pl_indv) {
      if (key === this.benefitSectionFormGroup.controls.capacity.value) {
        // this.beneficiarySection['capacity']
        return this.capacityFormRadioGrp_pl_indv[key];

      }
    }

  }


  IndividualCitizenshipValue: any;
  getIndividualCitizenship(citizenShip) {
    this.countrynationalityIndv.push(citizenShip);
    // console.log(this.countrynationalityIndv)

    // return citizenShip ? ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), citizenShip) : '';
    this.newClaimService.getCountryList().subscribe((data) => {

      this.IndividualCitizenshipValue = ReviewDetailsCommon.countryNameList(data, citizenShip);

    });

    return this.IndividualCitizenshipValue;
  }
  TraderNationalityValue: any;
  getTraderNationality(nationTrader) {
    // return nationTrader ? ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), nationTrader) : '';
    this.newClaimService.getCountryList().subscribe((data) => {

      this.TraderNationalityValue = ReviewDetailsCommon.countryNameList(data, nationTrader);

    });

    return this.TraderNationalityValue;
  }
  InstNationValue: any;
  getInstNation(nationaInstitution) {

    // return nationaInstitution ? ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), nationaInstitution) : '';
    this.newClaimService.getCountryList().subscribe((data) => {

      this.InstNationValue = ReviewDetailsCommon.countryNameList(data, nationaInstitution);

    });

    return this.InstNationValue;
  }
  getIndividualNationality() {
    this.beneficiarySection['nationalityIndv'].forEach(country => {
      let otherNationalityInst = ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), country.citizenship);

      this.individualNationalityList.push(otherNationalityInst);
    });
    this.beneficiarySection['nationality_bu_Inst'].forEach(nation_bu_inst => {
      let countryOfRegInst = ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), nation_bu_inst.nationality);
      this.countryOfRegInstitution.push(countryOfRegInst);

    });
    this.beneficiarySection['nationality_bu_Trader'].forEach(nationality_bu_Trader => {
      let countryOfTrader = ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), nationality_bu_Trader.nationality);
      this.countryOfTrader.push(countryOfTrader)

    });

  }

  InstitutionNationalityValue: any;
  getInstitutionNationality(country) {
    // return country ? ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), country) : '';
    this.newClaimService.getCountryList().subscribe((data) => {

      this.InstitutionNationalityValue = ReviewDetailsCommon.countryNameList(data, country);

    });

    return this.InstitutionNationalityValue;
  }

  countryeValue: any;
  getcountryOfBirthIndv(event) {

    this.newClaimService.getCountryList().subscribe((data) => {

      this.countryeValue = ReviewDetailsCommon.countryNameList(data, event);

    });

    return this.countryeValue;

  }

  showError(controlName) {
    if (this.benefitSectionFormGroup && this.benefitSectionFormGroup.controls[controlName]
      && !this.benefitSectionFormGroup.controls[controlName].value && this.capacityRadioValues.length > 0) {
      return true;
    }
    return false;
  }

  showErrorInnerField(nationalityArrEle, controlName) {
    if (this.benefitSectionFormGroup && nationalityArrEle.controls[controlName].validator && nationalityArrEle.controls[controlName].validator(controlName).required
      && nationalityArrEle.controls[controlName].errors) {
      return true;
    }
    return false;
  }
  showPeselFieldValue: boolean = false;
  cnpFieldMask;
  showPeselField() {
    this.cnpFieldMask = this.beneficiarySection.cnpfieldIndv ? this.beneficiarySection.cnpfieldIndv.split('') : [];
    this.showPeselFieldValue = true;

  }
  toggleFieldTextType() {
    this.showPeselFieldValue = !this.showPeselFieldValue;
  }
}
