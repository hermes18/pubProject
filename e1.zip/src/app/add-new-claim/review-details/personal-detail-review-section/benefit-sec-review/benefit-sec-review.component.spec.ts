import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { httpTranslateLoader } from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BenefitSecReviewComponent } from './benefit-sec-review.component';
import { LabelFieldComponent } from 'src/app/shared/component/label-field/label-field.component';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { of } from 'rxjs';


describe('BenefitSecReviewComponent', () => {
  let component: BenefitSecReviewComponent;
  let fixture: ComponentFixture<BenefitSecReviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        })
      ],
      declarations: [BenefitSecReviewComponent, LabelFieldComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    var userData = { "sourceOrigin": "O", "identifierToken": null, "userName": null, "authToken": null, "isAdminUser": null, "submittedBy": "Customer", "defaultLanguage": "pl", "displayLanguages": "pl", "landingPage": "/newClaim", "minFilesize": "5242880", "maxFilesize": "52428800", "clientId": null, "tablet": false, "mobileDevice": false };

    if (!(sessionStorage.getItem('userData'))) {
      sessionStorage.setItem('userData', JSON.stringify(userData));
    }

    fixture = TestBed.createComponent(BenefitSecReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('initMethod should call getIndividualNationality, showPeselField', () => {
    spyOn(component, 'initMethod').and.callThrough();
    spyOn(component, 'getIndividualNationality').and.callThrough();
    spyOn(component, 'showPeselField').and.callThrough();
    component.initMethod();
    expect(component.initMethod).toHaveBeenCalled();
  });

  it('toggleFieldTextType should set showPeselFieldValue value', () => {
    spyOn(component, 'toggleFieldTextType').and.callThrough();
    component.showPeselFieldValue = false;
    component.toggleFieldTextType();
    expect(component.showPeselFieldValue).toEqual(true);
  });

  it('showErrorInnerField should return true or false', () => {
    spyOn(component, 'showErrorInnerField').and.callThrough();

    component.showErrorInnerField({}, 'controlName');
    expect(component.showErrorInnerField).toHaveBeenCalled();
  });

  it('showError should return true or false', () => {
    spyOn(component, 'showError').and.callThrough();
    component.showPeselFieldValue = false;
    component.showError('controlName');
    expect(component.showPeselFieldValue).toEqual(false);
  });
  it('getcountryOfBirthIndv should return countryeValue', () => {
    spyOn(component, 'getcountryOfBirthIndv').and.callThrough();
    component.countryeValue = '';
    component.getcountryOfBirthIndv('pl');
    expect(component.countryeValue).toBeUndefined();
  });
  it('getInstitutionNationality should return InstitutionNationalityValue', () => {
    spyOn(component, 'getcountryOfBirthIndv').and.callThrough();
    component.InstitutionNationalityValue = '';
    component.getInstitutionNationality('pl');
    expect(component.InstitutionNationalityValue).toBeUndefined();
  });


  it('getIndividualNationality should return getIndividualNationality', () => {
    component.beneficiarySection = {nationalityIndv:[],nationality_bu_Inst:[],
      nationality_bu_Trader:[]};
    spyOn(component, 'getIndividualNationality').and.callThrough();
    // component.InstitutionNationalityValue  ='';
    component.getIndividualNationality();
    expect(component.getIndividualNationality).toHaveBeenCalled();
  });

  it('getInstNation should return InstNationValue', () => {
    spyOn(component, 'getInstNation').and.callThrough();
    component.InstNationValue = '';
    component.getInstNation('pl');
    expect(component.InstNationValue).toBeUndefined();
  });

  it('getTraderNationality should return TraderNationalityValue', () => {
    let countryList = [
      {"countryCode":"AF","countryName":" Afganistan"},
      {"countryCode":"AL","countryName":" Albania"},
      {"countryCode":"DZ","countryName":" Algieria"},
      {"countryCode":"AD","countryName":" Andora"},
      {"countryCode":"AO","countryName":" Angola"},
      {"countryCode":"AI","countryName":" Anguilla"},
      {"countryCode":"AQ","countryName":" Antarktyka"}
    ];
    let newClaimService = TestBed.get(NewClaimSharedService);
    
    spyOn(newClaimService,'getCountryList').and.returnValue(of(countryList));

    spyOn(component, 'getTraderNationality').and.callThrough();
    component.TraderNationalityValue = '';
    component.getTraderNationality('pl');
    expect(component.TraderNationalityValue).toBeUndefined();
  });
  it('getIndividualCitizenship should return IndividualCitizenshipValue', () => {
    spyOn(component, 'getIndividualCitizenship').and.callThrough();
    component.IndividualCitizenshipValue = '';
    component.getIndividualCitizenship('pl');
    expect(component.IndividualCitizenshipValue).toBeUndefined();
  });

  it('getCapacityValue should return capacityFormRadioGrp_pl_indv', () => {
    spyOn(component, 'getCapacityValue').and.callThrough();
    component.benefitSectionFormGroup = {
      controls: {
        capacity: {
          value: ''
        }
      }
    };
    component.getCapacityValue();
    expect(component.getCapacityValue).toHaveBeenCalled();
  });

  it('getDocumentFormat should return documentDate', () => {
    spyOn(component, 'getDocumentFormat').and.callThrough();

    component.getDocumentFormat('10/10/2020');
    expect(component.IndividualCitizenshipValue).toBeUndefined();
  });



  it('editData should call stepperEdit.emit', () => {
    spyOn(component.stepperEdit, 'emit').and.callFake(function () { });
    spyOn(component, 'editData').and.callThrough();
    component.editData(1);
    expect(component.editData).toHaveBeenCalled();
  });

  


  it('showPeselField should call showPeselFieldValue ', () => {
    component.beneficiarySection={cnpfieldIndv :''};
    spyOn(component, 'showPeselField').and.callThrough();
    component.showPeselField();
    expect(component.showPeselFieldValue ).toEqual(true);
  });

});
