import { Injectable } from '@angular/core';
import { NewClaimSharedService } from '../add-new-claim.service';
import * as lodashUtils from 'lodash';

@Injectable({
    providedIn: 'root'
})
export class ReviewDetailsCommon {
constructor(private  newClaimService: NewClaimSharedService){}

    static dateFormat(dateValue) {
        if (dateValue) {
            var date = new Date(dateValue),
                mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                day = ("0" + date.getDate()).slice(-2);
            return [day, mnth, date.getFullYear()].join("/");
        } else {
            return '';
        }
    }

    static countryNameList(countryList,countryCode){
       return  lodashUtils.result(lodashUtils.find(countryList, function(list) {
            return list.countryCode === countryCode;
        }), 'countryName');
       
    //   return  lodashUtils.filter(countryList,(list)=> {
    //         if(list.countryCode === countryCode){
    //             return list.countryName;
    //         }
    //          });
//    return countryList.filter(list =>{
//             if(list.countryCode === countryCode){
//                 return list.countryName;
//             }
//         });
        // return test;
     
    }

}