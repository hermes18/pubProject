import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { HealthcareFamilydocRevSecComponent } from './healthcare-familydoc-rev-sec.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {  FormGroup, FormControl, Validators, FormArray, AbstractControl,FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NewClaimSharedService } from '../../../add-new-claim.service';



export class FamilyDocRulesMock {
  familyDocMock = {"ruleFileName":"Eclaims_Event_Details_AdditionalDetails.xls_CLAIMTYPE_FIELD_RENDER","sheetName":null,"partner":"metlife","lob":"Individual","selectedClaim":"E180","sourceOfOrigin":"O","dateOffirstSymptomsDisease":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"dateOfRecognitionDisease":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"notApplicableCheckBox":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"dateWhenPhysicalInjuriesOccurred":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"sickLeavePeriod":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"temporaryDisabilityPeriod":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"0","fieldminlength":"0","allowedDataType":","},"dateCompletionOfMedicalTreatment":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":"numeric-slash"},"employerPreparedAccidentReport":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"policeConductedInvestigation":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"nameInvestigationEntities":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"streetName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"houseNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"flatNumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"country":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":","},"postalCode":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"postBox":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":","},"town":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"50","fieldminlength":"0","allowedDataType":","},"caseNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":","},"forwhatperiod":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"employmentPeriod":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"0","fieldminlength":"0","allowedDataType":","},"article":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"0","fieldminlength":"0","allowedDataType":","},"county":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"zipCode":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric"},"city":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphanumeric-hypen-dot-space"},"flatNo":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"block":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"15","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"entrance":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"appartment":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"sector":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"1","fieldminlength":"0","allowedDataType":"numeric"},"eventAfterConsumptionAlcohol":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"attachments":null,"sportsClubPlayerDropDown":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"sportsClubName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"sportsClubStreetName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"40","fieldminlength":"0","allowedDataType":","},"sportsClubHouseNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"sportsClubPoliceTown":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"50","fieldminlength":"0","allowedDataType":","},"sportsClubPostalCode":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric-hyphen"},"sportsClubCountry":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":","},"sportsClubPostBox":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"10","fieldminlength":"0","allowedDataType":","},"sportsClubCountyName":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"sportsClubZipCode":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"numeric"},"sportsClubCity":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphanumeric-hypen-dot-space"},"sportsClubFlatNo":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"sportsClubBlock":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"15","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"sportsClubEntrance":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"sportsClubAppartment":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":"alphanumeric-hyphen-space"},"sportsClubSector":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"1","fieldminlength":"0","allowedDataType":"numeric"},"sportsFlatNumber":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"6","fieldminlength":"0","allowedDataType":","},"ksession":null};
}


describe('HealthcareFamilydocRevSecComponent', () => {
  let component: HealthcareFamilydocRevSecComponent;
  let fixture: ComponentFixture<HealthcareFamilydocRevSecComponent>;
  const fb: FormBuilder = new FormBuilder();
  //const secValidations: PersonalRuleMock = new PersonalRuleMock();
  const familyDocValidations: FamilyDocRulesMock = new FamilyDocRulesMock();
  const newClaimService: NewClaimSharedService = new NewClaimSharedService();
 
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,HttpClientModule,SharedModule,HttpClientTestingModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ HealthcareFamilydocRevSecComponent ],
      providers : [ HttpClient ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    
    fixture = TestBed.createComponent(HealthcareFamilydocRevSecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
