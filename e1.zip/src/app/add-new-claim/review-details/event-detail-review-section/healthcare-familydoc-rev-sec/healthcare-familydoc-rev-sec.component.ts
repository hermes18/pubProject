import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { ReviewDetailsCommon } from '../../review-details.common';

@Component({
  selector: 'healthcare-familydoc-rev-sec',
  templateUrl: './healthcare-familydoc-rev-sec.component.html',
  styleUrls: ['./healthcare-familydoc-rev-sec.component.scss']
})
export class HealthcareFamilydocRevSecComponent implements OnInit {

  healthCarePrimaryDoctorSec;
  healthCarePrimaryDoctorFormControl;
  userData = JSON.parse(sessionStorage.userData);
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  addressEnableCountry = eClaimsConstants.corresspondenceAddressEnableCountry;
  defaultLanguage: string = this.userData.defaultLanguage;
  @Output() stepperEdit = new EventEmitter();

  constructor(public newClaimService: NewClaimSharedService) { }

  ngOnInit() {
  }

  initMethod() {
    const primaryHealthCare = this.newClaimService.getEventDetail() ? this.newClaimService.getEventDetail() : '';
    //console.log(primaryHealthCare);
    // this.healthCarePrimaryDoctorSec = (primaryHealthCare && primaryHealthCare!='')?primaryHealthCare.value.informationHealthCareFamilyDocSection:'';
    if (primaryHealthCare) {
      this.healthCarePrimaryDoctorSec = primaryHealthCare.value.informationHealthCareFamilyDocSection;
      this.healthCarePrimaryDoctorFormControl = primaryHealthCare.controls.informationHealthCareFamilyDocSection;
    }
  }
  public trackItem (indx: number, item) {
    return indx;
  }
  countryeValue: any;
  getPrimaryHealthCareCountry(event) {
    this.newClaimService.getCountryList().subscribe((data) => {

      // setTimeout(() => {
      this.countryeValue = ReviewDetailsCommon.countryNameList(data, event);

      // }, 0);
    });
    // this.countryeValue = event ?
    //   ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), event) : '';
    return this.countryeValue;
  }
  editData(pageStepper) {
    this.stepperEdit.emit(pageStepper);
  }
}
