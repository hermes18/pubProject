import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { FormGroup,AbstractControl } from '@angular/forms';
import { ReviewDetailsCommon } from '../../review-details.common';
import { eClaimsConstants } from 'src/app/core/constants/constant';
@Component({
  selector: 'additional-sec-review',
  templateUrl: './additional-sec-review.component.html',
  styleUrls: ['./additional-sec-review.component.scss']
})
export class AdditionalSecReviewComponent implements OnInit {
  additionalSecValues;
  additionalFormControl;
  eventRelatedTo;
  dateOfFirstSymptoms;
  dateOfRecognization;
  sickLeavePeriodFromDate;
  sickLeavePeriodToDate;
  employmentPeriodFromDate;
  employmentPeriodToDate;
  dateCompletionOfMedicalTreatment;
  dateWhenPhysicalInjuriesOccurred;
  policeCountry;
  sportsClubCountry;
  userData = JSON.parse(sessionStorage.userData);
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  additionaldetailsFormEnableCountry = eClaimsConstants.additionaldetailsFormEnableCountry;
  defaultLanguage: string = this.userData.defaultLanguage;
  @Output() stepperEdit = new EventEmitter();
  constructor(public newClaimService: NewClaimSharedService) { }

  ngOnInit() {
  }

  initMethod() {
    this.sickLeavePeriodFromDate = '';
    const eventDetailsForm = this.newClaimService.getEventDetail() ? this.newClaimService.getEventDetail() : '';
    //console.log(eventDetailsForm);
    if (eventDetailsForm) {
      this.eventRelatedTo = eventDetailsForm.value.eventInformationSection.eventRelatedTo;
      this.additionalSecValues = eventDetailsForm.controls.additionalFieldDetailsSection ?
        eventDetailsForm.controls.additionalFieldDetailsSection.value : '';
      this.additionalFormControl = eventDetailsForm.controls.additionalFieldDetailsSection;
      this.dateOfFirstSymptoms = this.additionalSecValues.dateOffirstSymptomsDisease ?
        ReviewDetailsCommon.dateFormat(this.additionalSecValues.dateOffirstSymptomsDisease) : '';
      this.dateWhenPhysicalInjuriesOccurred = this.additionalSecValues.dateWhenPhysicalInjuriesOccurred ?
        ReviewDetailsCommon.dateFormat(this.additionalSecValues.dateWhenPhysicalInjuriesOccurred) : '';
      this.dateOfRecognization = this.additionalSecValues.dateOfRecognitionDisease ?
        ReviewDetailsCommon.dateFormat(this.additionalSecValues.dateOfRecognitionDisease) : '';
      this.dateCompletionOfMedicalTreatment = this.additionalSecValues.dateCompletionOfMedicalTreatment ?
        ReviewDetailsCommon.dateFormat(this.additionalSecValues.dateCompletionOfMedicalTreatment) : '';

      if (this.additionalSecValues.sickLeavePeriodFromDate) {
        this.sickLeavePeriodFromDate = this.additionalSecValues.sickLeavePeriodFromDate ?
          ReviewDetailsCommon.dateFormat(this.additionalSecValues.sickLeavePeriodFromDate) : '';
        this.sickLeavePeriodToDate = this.additionalSecValues.sickLeavePeriodToDate ?
          ReviewDetailsCommon.dateFormat(this.additionalSecValues.sickLeavePeriodToDate) : '';
      }
      if (this.additionalSecValues.employmentPeriodFromDate) {
        this.employmentPeriodFromDate = this.additionalSecValues.employmentPeriodFromDate ?
          ReviewDetailsCommon.dateFormat(this.additionalSecValues.employmentPeriodFromDate) : '';
        this.employmentPeriodToDate = this.additionalSecValues.employmentPeriodToDate ?
          ReviewDetailsCommon.dateFormat(this.additionalSecValues.employmentPeriodToDate) : '';
      }
      this.policeCountry = this.additionalSecValues.country ?
        ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), this.additionalSecValues.country) : '';
      this.sportsClubCountry = this.additionalSecValues.sportsClubCountry ?
        ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), this.additionalSecValues.sportsClubCountry) : '';

    }
  }

  countryeValue: any;
  getCountry(event) {

    this.newClaimService.getCountryList().subscribe((data) => {

      this.countryeValue = ReviewDetailsCommon.countryNameList(data, event);

    });

    return this.countryeValue;

  }
  editData(pageStepper) {
    this.stepperEdit.emit(pageStepper);
  }

  showError(controlName) {

    if (this.additionalFormControl && this.additionalFormControl.controls[controlName]['isVisible'] != undefined && this.additionalFormControl && this.additionalFormControl.controls[controlName]['isVisible']) {
      if (this.additionalFormControl.controls[controlName].errors && this.additionalFormControl.get(controlName).validator(controlName).required
        || (this.additionalFormControl.get(controlName)['invalidFlag'] != undefined && this.additionalFormControl.get(controlName)['invalidFlag'])) {
        return true;
      } else {
        return false;
      }

    }
  }

   isRequired(controlName) {
    const form_field =  this.additionalFormControl.get(controlName);
    
    //console.log(form_field);
    if (!form_field || !form_field.validator) {
      return false;
  }
  const validator = form_field.validator({} as AbstractControl);
      return (validator && validator.required);
      
  }

}
