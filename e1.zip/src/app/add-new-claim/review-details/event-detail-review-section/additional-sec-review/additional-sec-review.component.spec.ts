import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AdditionalSecReviewComponent } from './additional-sec-review.component';
import { LabelFieldComponent } from 'src/app/shared/component/label-field/label-field.component';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { of } from 'rxjs';

describe('AdditionalSecReviewComponent', () => {
  let component: AdditionalSecReviewComponent;
  let fixture: ComponentFixture<AdditionalSecReviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ AdditionalSecReviewComponent,LabelFieldComponent ],
      providers : [ HttpClient ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(AdditionalSecReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('initMethod should call initMethod', () => {
    let newClaimService = TestBed.get(NewClaimSharedService);
    let eventValues = {"eventInformationSection":{"dateOfEvent":"2021-04-12T18:30:00.000Z","dateOfBirth":"","dateLabel":"","placeOfEvent":"kkjhh","eventRelatedTo":"sickness","causeOfEvent":"hgjg","descriptionOfEvent":""},"additionalFieldDetailsSection":{"dateOffirstSymptomsDisease":"2021-04-12T18:30:00.000Z","dateOfRecognitionDisease":"2021-04-13T18:30:00.000Z","dateWhenPhysicalInjuriesOccurred":null,"sickLeavePeriod":null,"sickLeavePeriodFromDate":null,"sickLeavePeriodToDate":null,"sickLeavePeriodNACheckBox":null,"temporaryDisabilityPeriod":null,"dateCompletionOfMedicalTreatment":null,"medicalTreatmentNotApplicable":null,"medicalTreatmentStillUndergoing":null,"employerPreparedAccidentReport":"yes","policeConductedInvestigation":null,"houseNumber":"","postalCode":"","caseNumber":"","forwhatperiod":"","employmentPeriod":null,"employmentPeriodFromDate":null,"employmentPeriodToDate":null,"article":null,"county":null,"zipCode":null,"city":null,"flatNo":null,"block":null,"entrance":null,"appartment":null,"sector":null,"otherCountry":"","otherSportsClubCountry":"","eventAfterConsumptionAlcohol":null,"sportsClubPlayerDropDown":null,"sportsClubHouseNumber":"","sportsClubPostalCode":"","sportsClubCountyName":null,"sportsClubZipCode":null,"sportsClubCity":null,"sportsClubFlatNo":null,"sportsClubBlock":null,"sportsClubEntrance":null,"sportsClubAppartment":null,"sportsClubSector":null},"informationHealthCareEventSection":[{"healthCareCenterName":"hgj","healthCareCenterStreetName":"mnb","healthCareCenterHouseNumber":"","healthCareCenterCountry":"PL","healthCareCenterPostalCode":"","healthCareCenterPeriodFrom":"2021-04-07T18:30:00.000Z","healthCareCenterPostBox":null,"healthCareCenterTown":"nvgj","healthCareCenterPeriodTo":"","healthCareCenterCounty":"","healthCareCenterZipCode":"","healthCareCenterCity":"","healthCareCenterBlock":"","healthCareCenterFlatNo":"","healthCareCenterEntrance":"","healthCareCenterAppartment":"","healthCareCenterSector":"","hcCount":"","healthCareOtherCountry":""}],"informationHealthCareFamilyDocSection":[{"familyDoctorName":"mjmjgjg","familyDoctorStreetName":"jgh","familyDoctorHouseNumber":"","familyDoctorFlatNumber":"","familyDoctorCountry":"PL","familyDoctorPostalCode":"","familyDoctorPhoneNumber":"","familyDoctorPostBox":null,"familyDoctorTown":"jhgjhg","familyDoctorOtherCountry":""}]};
   
    spyOn(component,'initMethod').and.callThrough();
    
    spyOn(newClaimService,'getEventDetail').and.returnValue({controls:{
      additionalFieldDetailsSection:{value:eventValues.additionalFieldDetailsSection}
    },value:eventValues});
    component.additionalFormControl={get:function(val){
      return false;
    }}
    component.initMethod();
    expect(component.initMethod).toHaveBeenCalled();
  });
  it('getCountry should return getCountry', () => {
    let countryList = [
      {"countryCode":"AF","countryName":" Afganistan"},
      {"countryCode":"AL","countryName":" Albania"},
      {"countryCode":"DZ","countryName":" Algieria"},
      {"countryCode":"AD","countryName":" Andora"},
      {"countryCode":"AO","countryName":" Angola"},
      {"countryCode":"AI","countryName":" Anguilla"},
      {"countryCode":"AQ","countryName":" Antarktyka"}
    ];
    let newClaimService = TestBed.get(NewClaimSharedService);
    
    spyOn(newClaimService,'getCountryList').and.returnValue(of(countryList));
    spyOn(component,'getCountry').and.callThrough();
    
    component.getCountry('pl');
    expect(component.getCountry).toHaveBeenCalled();
  });

  it('editData should call stepperEdit.emit', () => {
    spyOn(component.stepperEdit,'emit').and.callFake(function(){});
    spyOn(component,'editData').and.callThrough();
    component.editData(1);
    expect(component.editData).toHaveBeenCalled();
  });
  it('showError should return true or false to show error', () => {
    spyOn(component,'showError').and.callThrough();
    let errormsg = component.showError('controlname');
    expect(errormsg).toBeUndefined();
  });
  it('isRequired should return true or false to for required', () => {
    spyOn(component,'isRequired').and.callThrough();
   // spyOn(component.additionalFormControl,'get').and.returnValue({validator:false});
   component.additionalFormControl={get:function(val){
    return false;
  }}
   let reqiredField =  component.isRequired('controlname');
    expect(reqiredField).toBeFalsy();
  });
  
  
});
