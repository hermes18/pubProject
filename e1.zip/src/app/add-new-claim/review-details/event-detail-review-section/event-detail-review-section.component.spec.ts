import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { EventDetailReviewSectionComponent } from './event-detail-review-section.component';
import { EventInfoReviewSecComponent } from './event-info-review-sec/event-info-review-sec.component';
import { AdditionalSecReviewComponent } from './additional-sec-review/additional-sec-review.component';
import { HealthCarePrimaryReviewComponent } from './health-care-primary-review/health-care-primary-review.component';
import { HealthcareFamilydocRevSecComponent } from './healthcare-familydoc-rev-sec/healthcare-familydoc-rev-sec.component';
import { LabelFieldComponent } from 'src/app/shared/component/label-field/label-field.component';



describe('EventDetailReviewSectionComponent', () => {
  let component: EventDetailReviewSectionComponent;
  let fixture: ComponentFixture<EventDetailReviewSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ EventDetailReviewSectionComponent,EventInfoReviewSecComponent,
        AdditionalSecReviewComponent, HealthCarePrimaryReviewComponent,
        HealthcareFamilydocRevSecComponent,LabelFieldComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventDetailReviewSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('initMethod should call getIndividualNationality, showPeselField', () => {
    spyOn(component, 'initMethod').and.callThrough();
    component.initMethod();
    expect(component.initMethod).toHaveBeenCalled();
  });


  it('editData should call stepperEdit.emit', () => {
    spyOn(component.stepperEdit, 'emit').and.callFake(function () { });
    spyOn(component, 'editData').and.callThrough();
    component.editData(1);
    expect(component.editData).toHaveBeenCalled();
  });

  
});
