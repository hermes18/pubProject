import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';

import { ReviewDetailsCommon } from '../../review-details.common';
@Component({
  selector: 'event-info-review-sec',
  templateUrl: './event-info-review-sec.component.html',
  styleUrls: ['./event-info-review-sec.component.scss']
})
export class EventInfoReviewSecComponent implements OnInit {
  eventDetailsFormValue: any;
  dateOfEvent;
  @Output() stepperEdit = new EventEmitter();
  constructor(public newClaimService: NewClaimSharedService) { }

  ngOnInit() {
  }
  eventDetailsFormGroup;
  initMethod() {
    const eventDetailsForm = this.newClaimService.getEventDetail() ? this.newClaimService.getEventDetail() : '';

    //console.log(eventDetailsForm);
    if (eventDetailsForm) {
      this.eventDetailsFormValue = eventDetailsForm.value.eventInformationSection;
      this.eventDetailsFormGroup = eventDetailsForm.controls.eventInformationSection;
      this.dateOfEvent = ReviewDetailsCommon.dateFormat(this.eventDetailsFormValue.dateOfEvent);
    }
  }
  editData(pageStepper) {
    this.stepperEdit.emit(pageStepper);
  }
}
