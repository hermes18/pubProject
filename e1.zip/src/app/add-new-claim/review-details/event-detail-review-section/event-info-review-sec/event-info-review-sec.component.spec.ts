import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { EventInfoReviewSecComponent } from './event-info-review-sec.component';
import { LabelFieldComponent } from 'src/app/shared/component/label-field/label-field.component';

describe('EventInfoReviewSecComponent', () => {
  let component: EventInfoReviewSecComponent;
  let fixture: ComponentFixture<EventInfoReviewSecComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ EventInfoReviewSecComponent,LabelFieldComponent ],
      providers : [ HttpClient ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    var userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(EventInfoReviewSecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
