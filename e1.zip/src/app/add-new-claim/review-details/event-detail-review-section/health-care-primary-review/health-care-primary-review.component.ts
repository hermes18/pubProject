import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';

import { ReviewDetailsCommon } from '../../review-details.common';
import { eClaimsConstants } from 'src/app/core/constants/constant';
@Component({
  selector: 'health-care-primary-review',
  templateUrl: './health-care-primary-review.component.html',
  styleUrls: ['./health-care-primary-review.component.scss']
})
export class HealthCarePrimaryReviewComponent implements OnInit {
  primaryPeriodDate;
  healthCarePrimarySection;
  healthCarePrimaryFormControl;
  primaryPeriodToDate;
  primaryPeriodFromDate;
  healthCareCenterCountry;
  userData = JSON.parse(sessionStorage.userData);
  postBoxEnableCountry = eClaimsConstants.postBoxEnableCountry;
  contactCountryEnable = eClaimsConstants.contactCountryEnable;
  addressEnableCountry = eClaimsConstants.corresspondenceAddressEnableCountry;
  defaultLanguage: string = this.userData.defaultLanguage;
  @Output() stepperEdit = new EventEmitter();
  constructor(public newClaimService: NewClaimSharedService) { }

  ngOnInit() {
  }

  initMethod() {
    const primaryHealthCare = this.newClaimService.getEventDetail() ? this.newClaimService.getEventDetail() : '';
    //console.log(primaryHealthCare);
    if (primaryHealthCare) {
      this.healthCarePrimarySection = primaryHealthCare.value.informationHealthCareEventSection;
      this.healthCarePrimaryFormControl = primaryHealthCare.controls.informationHealthCareEventSection;


    }
    
  }
  public trackItem (indx: number, item) {
    return indx;
  }
  countryeValue: any;
  getHealthCareCenterCountry(event) {
    // return event ?
    //   ReviewDetailsCommon.countryNameList(this.newClaimService.getParamValue('countryList'), event) : '';
    this.newClaimService.getCountryList().subscribe((data) => {

      this.countryeValue = ReviewDetailsCommon.countryNameList(data, event);

    });

    return this.countryeValue;

  }
  getDate(event) {
    return ReviewDetailsCommon.dateFormat(event);
  }
  editData(pageStepper) {
    this.stepperEdit.emit(pageStepper);
  }

}
