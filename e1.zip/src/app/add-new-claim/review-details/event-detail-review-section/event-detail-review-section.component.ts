import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { NewClaimSharedService } from '../../add-new-claim.service';
import { EventInfoReviewSecComponent } from './event-info-review-sec/event-info-review-sec.component';
import { AdditionalSecReviewComponent } from './additional-sec-review/additional-sec-review.component';
import { HealthCarePrimaryReviewComponent } from './health-care-primary-review/health-care-primary-review.component';
import { HealthcareFamilydocRevSecComponent } from './healthcare-familydoc-rev-sec/healthcare-familydoc-rev-sec.component';

@Component({
  selector: 'event-detail-review-section',
  templateUrl: './event-detail-review-section.component.html',
  styleUrls: ['./event-detail-review-section.component.scss']
})
export class EventDetailReviewSectionComponent implements OnInit {


  constructor(public newClaimService: NewClaimSharedService) { }

  @ViewChild(EventInfoReviewSecComponent, { static: false }) eventInfoReview: EventInfoReviewSecComponent;
  @ViewChild(AdditionalSecReviewComponent, { static: false }) additionalSecReview: AdditionalSecReviewComponent;

  @ViewChild(HealthCarePrimaryReviewComponent, { static: false }) healthCarePrimarySection: HealthCarePrimaryReviewComponent;
  @ViewChild(HealthcareFamilydocRevSecComponent, { static: false }) healthCareFamilyDocSec: HealthcareFamilydocRevSecComponent;
  @Output() stepperEdit = new EventEmitter();
  formDetails = [
    {
      "form": "eventInfoReviewSec",
      "initFunc": "initMethod",
      "formRef": "eventInfoReview"
    },
    {
      "form": "additionalReviewSec",
      "initFunc": "initMethod",
      "formRef": "additionalSecReview"
    },
    {
      "form": "healthCarePrimarySec",
      "initFunc": "initMethod",
      "formRef": "healthCarePrimarySection"
    },
    {
      "form": "healthCareFamilyDocSec",
      "initFunc": "initMethod",
      "formRef": "healthCareFamilyDocSec"
    }

  ];

  eventDetailsFormValue;

  ngOnInit() {
    // this.callSubCompInit();
  }

  callSubCompInit() {
    // if (this.eventInfoReview) {
    setTimeout(() => {

      for (let i = 0; i < this.formDetails.length; i++) {
        if (this[this.formDetails[i].formRef] &&
          this[this.formDetails[i].formRef][this.formDetails[i].initFunc]) {
          this[this.formDetails[i].formRef][this.formDetails[i].initFunc]();
        }

      }
    }, 0)

    // }
  }

  renderFlagList;
  renderClaimSections;
  healthCareDoctorEventSecRules: any = null;
  healthCareDoctorReviewSec: any = false;
  initMethod() {
    this.renderFlagList = this.newClaimService.getParamValue('renderEventDetails');
    this.renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');
    this.callSubCompInit();
    const eventDetailsForm = this.newClaimService.getEventDetail() ? this.newClaimService.getEventDetail() : '';
    this.eventDetailsFormValue = eventDetailsForm;
    this.healthCareDoctorEventSecRules = this.newClaimService.getParamValue('healthCareDoctorEventSecRules');
    //    console.log("healthCareDoctorEventSecRules",this.healthCareDoctorEventSecRules);
    //    console.log("this.eventDetailsFormValue",this.eventDetailsFormValue);
    try {
      let familyDocValue = this.eventDetailsFormValue.value.informationHealthCareFamilyDocSection;
      let familyDocHasValue = false;
      Object.keys(familyDocValue).forEach(property => {
        //console.log("keys", property);
        Object.keys(familyDocValue[property]).forEach(flags => {
          // console.log("flags",flags);
          // console.log("flags",familyDocValue[property]);

          if (familyDocValue[property][flags] && familyDocValue[property][flags] != '') {
            familyDocHasValue = true;
          }
        });

      });

      let docRulesMandatory = false;
      Object.keys(this.healthCareDoctorEventSecRules).forEach(property => {

        if (property['mandatoryFlag']) {
          //       console.log(property,this.healthCareDoctorEventSecRules[property]['mandatoryFlag']);
          docRulesMandatory = true;
        }
      });

      if (familyDocHasValue || docRulesMandatory) {
        this.healthCareDoctorReviewSec = true;
      } else {
        this.healthCareDoctorReviewSec = false;
      }
      //console.log(familyDocHasValue,docRulesMandatory,this.healthCareDoctorReviewSec);

    }

    catch (e) {
      console.log('error', e);
    }
  }

  editData(pageStepper) { // You can give any function name

    this.stepperEdit.emit(pageStepper);
  }


}
