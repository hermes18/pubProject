import { Component, OnInit, Output, EventEmitter, ViewChild, ViewEncapsulation } from '@angular/core';
import { DataService } from 'src/app/shared/services/data.service';
import { TranslateService } from '@ngx-translate/core';
import { FilePreviewService } from 'src/app/shared/services/file-preview.service';
import { FilePreviewComponent } from 'src/app/shared/dialog/file-preview/file-preview.component';
import { TypeEventReviewSectionComponent } from './type-event-review-section/type-event-review-section.component';
import { PersonalDetailReviewSectionComponent } from './personal-detail-review-section/personal-detail-review-section.component';
import { EventDetailReviewSectionComponent } from './event-detail-review-section/event-detail-review-section.component';
import { NewClaimSharedService } from '../add-new-claim.service';

import * as utils from 'lodash';
@Component({
  selector: 'app-review-details',
  templateUrl: './review-details.component.html',
  styleUrls: ['./review-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ReviewDetailsComponent implements OnInit {
  uploadedInAttachmentSection: any = {};
  constructor(public dataService: DataService, public translate: TranslateService, 
    public filePreviewService: FilePreviewService,public newClaimService: NewClaimSharedService) { }

  @Output() stepperEdit = new EventEmitter();
  @ViewChild(TypeEventReviewSectionComponent, { static: false }) typeReviewSection: TypeEventReviewSectionComponent;
  @ViewChild(PersonalDetailReviewSectionComponent, { static: false }) personalReviewSection: PersonalDetailReviewSectionComponent;
  @ViewChild(EventDetailReviewSectionComponent, { static: false }) eventDetailsReview: EventDetailReviewSectionComponent;

  Counter = 0;
  formDetails = [
    {
      "form": "typeReviewSec",
      "initFunc": "initMethod",
      "formRef": "typeReviewSection"
    },
    {
      "form": "personalDetail",
      "initFunc": "initMethod",
      "formRef": "personalReviewSection"
    },
    {
      "form": "eventDetailsReview",
      "initFunc": "initMethod",
      "formRef": "eventDetailsReview"
    }
    // {
    //   "form": "residence",
    //   "initFunc": "formInit",
    //   "formRef": "residenceRefComp"
    // },
    // {
    //   "form": "correspondAddress",
    //   "initFunc": "formInit",
    //   "formRef": "correspondanceRefComp"
    // },
    // {
    //   "form": "formDisbursement",
    //   "initFunc": "formInit",
    //   "formRef": "disbursementRefComp"
    // }
  ];
  documentList;

  editData(pageStepper) { // You can give any function name

    this.stepperEdit.emit(pageStepper);
  }

  formSubmit() {
    return true;
  }
  ngOnInit() {

  }
  renderClaimSections;
  formInit() {
    this.renderClaimSections = this.newClaimService.getParamValue('renderClaimSections');
    this.uploadedInAttachmentSection = [];
    let constantValue = this.dataService.getOption('uploadNewClaimList');
    // this.uploadedInAttachmentSection = Object.assign({}, constantValue);

    this.uploadedInAttachmentSection = utils.cloneDeep(constantValue);
    if (this.uploadedInAttachmentSection && this.uploadedInAttachmentSection.documentTypes && this.uploadedInAttachmentSection.documentTypes.length > 0) {

      this.uploadedInAttachmentSection.documentTypes.map((docType, index) => {
        let fileListArr = [];
        if (this.uploadedInAttachmentSection.fileUpload && this.uploadedInAttachmentSection.fileUpload.length) {
          this.uploadedInAttachmentSection.fileUpload.forEach(fileList => {
            if (fileList.state === docType.id) {
              this.uploadedInAttachmentSection.documentTypes[index]['hasFile'] = true;
              fileListArr.push(fileList);
              this.uploadedInAttachmentSection.documentTypes[index]['uploadList'] = fileListArr;
            }
          });
        } else {
          this.uploadedInAttachmentSection.documentTypes[index]['hasFile'] = false;
        }

      });
    }
    this.callSubCompInit();
  }

  callSubCompInit() {
    for (let i = 0; i < this.formDetails.length; i++) {
      if (this[this.formDetails[i].formRef][this.formDetails[i].initFunc]) {
        this[this.formDetails[i].formRef][this.formDetails[i].initFunc]();
      }

    }
  }

  filePreview(filePath, contentType) {
    this.filePreviewService.openDialog(FilePreviewComponent, { 'filePath': filePath, 'type': contentType });
  }
}
