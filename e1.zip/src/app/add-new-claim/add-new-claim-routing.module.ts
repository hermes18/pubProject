import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddNewClaimComponent} from './add-new-claim.component';
import {PersonalDetailsComponent} from './personal-details/personal-details.component';
import {EventDetailsComponent} from './event-details/event-details.component';
import {AttachmentsComponent} from './attachments/attachments.component';
import { TypeOfEventsComponent } from './type-of-events/type-of-events.component';

const routes: Routes = [
  {path: '',
  component: AddNewClaimComponent,
  children: [
    { path: 'personalDetails', component: PersonalDetailsComponent,
  //   canActivate: [service],
  //   canDeactivate: []
  // 
 },
   { path: 'eventDetails', component: EventDetailsComponent,
    // canActivate: [],
    // canDeactivate: []
   },
   { path: 'attachments', component: AttachmentsComponent,
    // canActivate: [],
    // canDeactivate: []
   }, { path: 'typeofevent', component: TypeOfEventsComponent,
   // canActivate: [],
   // canDeactivate: []
  }, 

  ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddNewClaimRoutingModule { }
