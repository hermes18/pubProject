import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { HttpCommonService } from "src/app/shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { ScreenRenderReqModel } from 'src/app/add-new-claim/models/ScreenRenderReqModel';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class CountryResolve implements Resolve<any> {
  screenRequestObj: ScreenRenderReqModel = new ScreenRenderReqModel();
  partner: string = 'metlife';
  baseUrl = environment.host + environment.existingPersonalServiceConfig.url;
  headers = new HttpHeaders();
  //userdata = JSON.parse(sessionStorage.userData);
  constructor(private commonService: HttpCommonService) { }


  resolve(route: ActivatedRouteSnapshot) {
    let countryListURL = environment.host + environment.getCountryListConfig.url;
    //  let countryListParam = "language=" + this.userdata.displayLanguages + "&country=" + this.userdata.defaultLanguage;
    //  countryListURL = countryListURL + countryListParam;
    //countryListURL = "http://localhost:4200/assets/mocks/countryList.json";
    return this.commonService.getData(countryListURL).pipe(catchError((err) => {
    //  return of([]);
    return this.getCountriesFromLocal();
    }));

  }
  getCountriesFromLocal() {
    let envHost = environment.localhost;
    let language = sessionStorage.getItem('defaultLanguage');
   // let countryListURL = environment.host + environment.getCountryListLocalConfig.url +'_'+language+'.json';
   let countryListURL = envHost + environment.getCountryListLocalConfig.url +'_'+language+'.json';
   return this.commonService.getData(countryListURL).pipe();
}

} 