import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";
import { Observable } from "rxjs";
import { HttpCommonService } from "src/app/shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class EventTypesResolve implements Resolve<any> {

  partner: string = 'metlife';
  baseUrl = environment.host + environment.existingPersonalServiceConfig.url;
  headers = new HttpHeaders();

  constructor(private commonService: HttpCommonService) { }

  resolve(route: ActivatedRouteSnapshot) {
    let userData = JSON.parse(sessionStorage.userData);
    let screenRequestObj = {
          'screenName' : 'TypeOfEventPrimary',
          'sourceOfOrigin':userData.sourceOrigin,
          'partner':'metlife'
          
        };
    return '';
        /*return this.commonService[environment.typeOfEventServiceConfig.method](
        (environment.host + environment.typeOfEventServiceConfig.screenInfoUrl)
        , screenRequestObj, this.headers);*/
  }


} 