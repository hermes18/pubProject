import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { observable, Subject, Observable } from 'rxjs';

@Injectable({providedIn:'root'})
export class NewClaimSharedService {
    private claimDetails: any = null;
    private primaryClaimType: any = null;
    private personalDetail: any = null;
    private eventDetails: any = null;
    private traderFlag: BehaviorSubject<boolean>;
    private langBasedCountry: BehaviorSubject<any>;
    private mandatoryError: BehaviorSubject<boolean>;
    private newClaimResponse: any = null;
    public newClaimConfirmationCodes: any = null;
    public isIndividual: boolean;
    cnpField: any = '';
    showConfrmComp: boolean = true;
    public subject: Subject<any> = new Subject();
    public responsesubject: Subject<any> = new Subject();
    public showClaimCompSubject: Subject<boolean> = new Subject();
    //public selectedLang:Subject<any> = new Subject();

    public typeOfEventOldValue :any = null;
    public personalDetailsOldValue :any = null;
    public eventDetailsOldValue :any = null;
    public attachmentOldValue :any = null;
    public additionalDetailsOldValue: any = null;
    eventTypes: any = null;
    CountryList: any = null;
    countryList: any = null;
    renderSecFlagList: any = null;
    renderEventDetails: any = null;
    typeDetailsForm: any;
    benefitiary:any;
    benefitiaryGrp:any;
    lobsRendered:any = null;
    renderClaimSections:any =null;
    healthCareDoctorEventSecRules:any = null;
    personalRenderListInit:any = null;
    constructor() {
        this.traderFlag = new BehaviorSubject(null);
        this.langBasedCountry = new BehaviorSubject(null);
        this.mandatoryError = new BehaviorSubject(false);
    }

    setnewClaimConfirmationCodes(data: any) {
        this.newClaimConfirmationCodes = data;
    }

    getnewClaimConfirmationCodes(): any {
        return this.newClaimConfirmationCodes;
    }

    setClaimData(data: any) {
        this.claimDetails = data;
    }

    getClaimData(): any {
        return this.claimDetails;
    }
    setPrimaryClaimType(data: any) {
        this.primaryClaimType = data;
    }

    getPrimaryClaimType(): any {
        return this.primaryClaimType;
    }

    getParamValue(param) {
        return this[param];
    }
    setParamValue(param, value) {
        this[param] = value;
    }
    setPersonalDetails(data) {
        this.personalDetail = data;
    }

    getPersonalDetails() {
        return this.personalDetail;
    }

    setEventDetail(data) {
        this.eventDetails = data;
    }

    getEventDetail() {
        return this.eventDetails;
    }

    setTraderFlag(data) {
        this.traderFlag.next(data);
    }

    getTraderFlag() {
        return this.traderFlag.asObservable();
    }

    setCountryList(data) {
        this.langBasedCountry.next(data);
    }

    getCountryList() {
        return this.langBasedCountry.asObservable();
    }

    setmandatoryError(data) {
        this.mandatoryError.next(data);
    }

    getmandatoryError() {
        return this.mandatoryError.asObservable();
    }

    setNewClaimResponse(data: any) {
        this.newClaimResponse = data;
    }

    getNewClaimResponse() {
        return this.newClaimResponse;
    }

    setIndividual(data: boolean) {
        this.isIndividual = data;
    }
    getIndividual() {
        return this.isIndividual;
    }

    setCNPFieldValue(data: any) {
        this.cnpField = data;
    }

    getCNPField() {
        return this.cnpField;
    }

    setShowConfitrmationComp(data) {
        this.showConfrmComp = data;
    }

    getShowConfirmationComp() {
        return this.showConfrmComp;
    }

    triggerApi(): Observable<any> {
        return this.subject.asObservable();
    }

    updateComponents(component) {
        this.subject.next(component);
    }

    triggerSaveClaimResponseApi(): Observable<any> {
        return this.responsesubject.asObservable();
    }

    updateSaveClaimResponseComponents(component) {
        this.responsesubject.next(component);
    }

    triggerShowClaimCompApi(): Observable<any> {
        return this.showClaimCompSubject.asObservable();
    }

    updateShowClaimComponent(component) {
        this.showClaimCompSubject.next(component);
    }
    // triggerLanguageSeletionValue(): Observable<any> {
    //     return this.selectedLang.asObservable();
    // }

    // updateLanguageSelectionValue(component) {
    //     this.selectedLang.next(component);
    // }

    restrictedPatternValRemove(pattern,val){
        let nameFieldPatten = pattern;
        if(nameFieldPatten.match(/\[(.*?)\]/)){
          nameFieldPatten = nameFieldPatten.match(/\[(.*?)\]/)[1];
        }
        let nameFieldRegex  = new RegExp(('[^'+nameFieldPatten+"]"), "g");
        let nameFieldReplaceVal = (val).replace(nameFieldRegex,'');
        return nameFieldReplaceVal;
      }
    
}