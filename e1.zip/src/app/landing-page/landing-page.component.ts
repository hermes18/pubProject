import { Component, OnInit, ViewEncapsulation, HostListener, ViewChild } from '@angular/core';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LandingPageComponent implements OnInit {
  @ViewChild('tooltip1', { static: false }) tooltip1;
  @ViewChild('tooltip2', { static: false }) tooltip2;

  @HostListener('window:scroll', ['$event'])
  scrollHandler(event) {
   // this.tooltip1.hide();
    //this.tooltip2.hide();
  }
  constructor() { }

  ngOnInit() {
  }

}
