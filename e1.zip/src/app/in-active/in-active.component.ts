import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'in-active',
  templateUrl: './in-active.component.html',
  styleUrls: ['./in-active.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class InActiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
