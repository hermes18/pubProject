import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import {AddNewClaimModule} from './add-new-claim/add-new-claim.module';
import { AddNewClaimComponent } from './add-new-claim/add-new-claim.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { ErrorComponent } from './error/error.component';
import { SessionExpiredComponent } from './session-expired/session-expired.component';
import { PageNotFoundComponent } from './core/components';
import { ExistingClaimComponent } from './existing-claim/existing-claim.component';
import { ExistingClaimResolve } from './existing-claim/existing-claim-resolve';
import { InActiveComponent } from './in-active/in-active.component';
import { NewClaimConfirmationComponent } from './add-new-claim/new-claim-confirmation/new-claim-confirmation.component';
import { AccessDeniedEnComponent } from './access-denied-en/access-denied-en.component';
import { CanDeactivateGuardService } from './core/gaurds/can-deactivate-gaurd.service';
import { BroadcasterService } from './shared/services/broadcaster.service';
import { EventTypesResolve } from './add-new-claim/resolvers/event-types.resolve';
import { CountryResolve } from './add-new-claim/resolvers/country.resolver';
import { ErrorPageComponent } from './error-page/error-page.component';
//import { PreloadAllModules } from '@angular/router';
import { PreloadStrategy } from './core/services/preload-strategy';
const routes: Routes = [

  { path: '', redirectTo: '/landing', pathMatch: 'full' }, // redirect to `landing page component`
  { path: 'landing', component: LandingPageComponent },
  { path: 'access-denied', component: AccessDeniedComponent },
  { path: 'session-expired', component: SessionExpiredComponent },
  { path: 'error', component: ErrorComponent },
  { path: 'page-not-found', component: PageNotFoundComponent },
  { path: 'in-active', component: InActiveComponent },
  { path: 'submitNewClaimConfirmation', component: NewClaimConfirmationComponent },
  {
    path: 'existedClaim', component: ExistingClaimComponent,resolve: {
        existClaimData: ExistingClaimResolve
       }
  },
  // , resolve: {
  //   existClaimData: ExistingClaimResolve
  // }
  //  canDeactivate: [CanDeactivateGuardService]
  {
    path: 'newClaim', component: AddNewClaimComponent, resolve: {
      countryList: CountryResolve,
      eventTypes: EventTypesResolve
    }
  },
  /*{ path: 'newClaim',
  data: { preload: true },
  loadChildren:'./add-new-claim/add-new-claim.module#AddNewClaimModule',
  resolve: {
   countryList: CountryResolve,
   eventTypes: EventTypesResolve
 }},
   */
  { path: 'access-denied-en', component: AccessDeniedEnComponent },
  {path: 'errorPage',component: ErrorPageComponent }

  /*{ path: 'newClaim',
   data: { preload: true },
   loadChildren: () =>  AddNewClaimModule},
   */
  //,{ path: '**', pathMatch: 'full', redirectTo: '/landing' } // catch any unfound routes and redirect to home page

];

@NgModule({
  imports: [RouterModule.forRoot(routes,{
    preloadingStrategy: PreloadStrategy, useHash: true 
  })],
  exports: [RouterModule],
  providers: [PreloadStrategy,ExistingClaimResolve, CanDeactivateGuardService, BroadcasterService]
})
export class AppRoutingModule { }
