import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { httpTranslateLoader, CustomDatePickerAdapter } from './app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SidenavListComponent } from './core/components/sidenav-list/sidenav-list.component';
import { HeaderComponent } from './core/components/header/header.component';
import { FooterComponent } from './core/components/footer/footer.component';
import { MatIconModule, MatListModule, MatSelectModule, MatSidenavModule, MatToolbarModule } from '@angular/material';
import {
  MatDialogModule, MatFormFieldModule, MatDialog
} from '@angular/material';
import { SharedModule } from 'src/app/shared/shared.module';
import { AuthService } from './core/services/auth.service';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive'
import { Http } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ErrorPageComponent } from './error-page/error-page.component';
import { of } from 'rxjs';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { VersionCheckService } from './core/services/version-check.service';

describe('AppComponent', () => {

  const authService: AuthService = new AuthService();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes(
        [{ path: 'landing', component: LandingPageComponent },
        {path: 'errorPage',component: ErrorPageComponent }
      ]
      ), ReactiveFormsModule,
        MatSidenavModule, SharedModule, FormsModule, HttpClientModule, BrowserAnimationsModule,
      TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader,
          useFactory: httpTranslateLoader,
          deps: [HttpClient]
        }
      }),
      NgIdleKeepaliveModule.forRoot()
      ],
      declarations: [
        AppComponent, SidenavListComponent, HeaderComponent, FooterComponent,
        ErrorPageComponent, LandingPageComponent 
      ],
      // providers : [ HttpClient , Window ]
      providers: [HttpClient, { provide: 'Window', useFactory: () => window },
        { provide: MatDialog }, AuthService, Idle,CustomDatePickerAdapter,VersionCheckService
      ]
    }).compileComponents();
  }));

  it('should create the app', () => {
    sessionStorage.setItem('defaultLanguage', 'pl_en');
    let authService = TestBed.get(AuthService);
    let versionCheckService = TestBed.get(VersionCheckService);
   
  

    spyOn(authService, 'tokenGeneration').and.returnValue(of({ "userName": "eClaims", "token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJlQ2xhaW1zIiwidXNlciI6eyJ1c2VyTmFtZSI6ImVDbGFpbXMiLCJmaXJzdE5hbWUiOm51bGwsImxhc3ROYW1lIjpudWxsLCJlbWFpbCI6bnVsbCwicHJlZmVycmVkTGFuZ3VhZ2UiOm51bGwsImNyZWF0aW9uRGF0ZSI6bnVsbCwicGFzc3dvcmRUeXBlIjpudWxsLCJjdXN0b21lclBhc3N3b3JkRXhwcmF0aW9uQ29kZSI6bnVsbCwicGFzc3dvcmRTdGF0dXNDb2RlIjpudWxsLCJzZWN1cml0eVBvbGljeUlkIjpudWxsLCJ0b2tlbkV4cGlyYXRpb25EYXRlIjpudWxsLCJlbXBsb3llZU51bWJlciI6bnVsbCwicHdkRXhwaXJhdGlvbkRhdGUiOm51bGwsImZhaWxlZExvZ2luQ291bnRzIjpudWxsLCJhdXRob3JpemVkQXBwbGljYXRpb25Db2RlIjpudWxsLCJ0ZW1wb3JhcnlMb2NrRGF0ZSI6bnVsbCwicm91dGUiOm51bGwsInB3ZEV4cGlyZWQiOm51bGwsImRheXNTaW5jZVB3ZE5vdENoYW5nZWQiOm51bGwsInB3ZENoYW5nZURhdGUiOm51bGwsInJvbGVJbmZvIjpudWxsLCJjbGllbnRJZCI6bnVsbCwicmVxdWVzdGVySWQiOm51bGwsInJlcXVlc3RlclJvbGUiOm51bGwsInVzZXJEbiI6bnVsbCwicHdkRXhwaXJhdGlvbkRlbGF5IjpudWxsLCJ1c2VyQ2hlY2siOmZhbHNlfSwiaWF0IjoxNjEyNzgxNTU1LCJleHAiOjE2MTI4MjQ3NTV9.VgDxkjybbCR5ez27uyvGrVE27qVdRRgwkMw1AJ06AsM" }));

    spyOn(authService, 'loginTo').and.returnValue(of({ "sourceOrigin": "M", "identifierToken": null, "userName": null, "authToken": null, "isAdminUser": null, "submittedBy": "Customer", "defaultLanguage": "pl", "displayLanguages": "pl", "landingPage": "landing", "minFilesize": "5242880", "maxFilesize": "52428800", "clientId": null, "mobileDevice": false, "tablet": false }));

    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    app.headerRef = {
      "timeLeft": 0,
      "secStarts": null
    }
    spyOn(app.router, 'navigate').and.returnValue(true);
    // const headerComp = TestBed.createComponent(HeaderComponent);
    // const headerCompRef = headerComp.debugElement.componentInstance;

    // expect(headerCompRef).toBeTruthy();
    expect(app).toBeTruthy();
  });
  /*
    it(`should have as title 'eClaims'`, () => {
      const fixture = TestBed.createComponent(AppComponent);
      const app = fixture.debugElement.componentInstance;
      expect(app.title).toEqual('eClaims');
    });
  
    it('should render title', () => {
      const fixture = TestBed.createComponent(AppComponent);
      fixture.detectChanges();
      const compiled = fixture.debugElement.nativeElement;
      expect(compiled.querySelector('.content span').textContent).toContain('eClaims app is running!');
    });*/


  it('switchLang should call langChangeCalls', () => {
    let versionCheckService = TestBed.get(VersionCheckService);
   
    const fixture = TestBed.createComponent(AppComponent);

    const app = fixture.debugElement.componentInstance;
    app.headerRef = {
      "timeLeft": 0,
      "secStarts": null
    }
    spyOn(app, 'langChangeCalls').and.callThrough();
    app.switchLang('pl_en');

    expect(app.langChangeCalls).toHaveBeenCalled();
  })


  it('langChangeCalls should call languageJsonChange', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    app.headerRef = {
      "timeLeft": 0,
      "secStarts": null
    }
    spyOn(app, 'languageJsonChange').and.callThrough();
    app.langChangeCalls('pl_en');

    expect(app.languageJsonChange).toHaveBeenCalled();
  })

  /* it('languageJsonChange should call setLanguageForConfirmation', () => {
     const fixture = TestBed.createComponent(AppComponent);
     const app = fixture.debugElement.componentInstance;
     spyOn(app, 'setLanguageForConfirmation').and.callThrough();
     app.languageJsonChange('pl_en');
     expect(app.setLanguageForConfirmation).toHaveBeenCalled();
 })*/
 it('dateparse should return valid date', () => {
  //const fixture = TestBed.createComponent(CustomDatePickerAdapter);
  //const app = fixture.debugElement.componentInstance;
  
  let datepicker = TestBed.get(CustomDatePickerAdapter);
  spyOn(datepicker, 'parse').and.callThrough();
  
  var result = datepicker.parse("03/10/1991");
  let testDate=new Date(1991, (10-1), 3)
  expect(result).toEqual(testDate);
})

it('dateparse should return null value for not a number', () => {
  //const fixture = TestBed.createComponent(CustomDatePickerAdapter);
  //const app = fixture.debugElement.componentInstance;
  
  let datepicker = TestBed.get(CustomDatePickerAdapter);
  spyOn(datepicker, 'parse').and.callThrough();
  
  var result = datepicker.parse("abcd");
  //let testDate=new Date(1991, (10-1), 3)
  expect(result).toEqual(null);
})


});
