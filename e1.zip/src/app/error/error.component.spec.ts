import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule,FormsModule  } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { ErrorComponent } from './error.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ErrorComponent', () => {
  let component: ErrorComponent;
  let fixture: ComponentFixture<ErrorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,FormsModule,HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ ErrorComponent ],
      providers:[{ provide: 'Window', useFactory: () => window }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('metLifeHome should call window.open ', () => {
    
    spyOn(component, 'metLifeHome').and.callThrough();
    component.metLifeHome();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.metLifeHome();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.metLifeHome();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.metLifeHome();
    expect(component.metLifeHome).toHaveBeenCalled();
  });
  it('notifyMe should assign flag value to false', () => {
    
    spyOn(component, 'notifyMe').and.callThrough();
    component.notifyMe();
    
    expect(component.flag).toEqual(false);
  });
  
});
