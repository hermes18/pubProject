import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { HttpCommonService } from '../shared/services/http-common.service';
import { NgForm } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import {environment} from 'src/environments/environment';
@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss'],
})
export class ErrorComponent implements OnInit {
  flag: boolean = true;
  emailID;
  flagtestdata={};
  constructor(private cService: HttpCommonService) {
    
   }

  ngOnInit() {
  
  }

  notifyMe(){
    this.flag=false;
    //http://localhost:9080/api/v1/documents/connectionfailure/info
    const flagtest = environment.host+environment.notifyServiceConfig.url;
    // this.cService.postData(this.emailID,"")
    // .subscribe(data =>this.flagtestdata=data);
   
    let params ={
      requesterEmail :  this.emailID
    }
    this.cService[environment.notifyServiceConfig.method](flagtest,JSON.stringify(params),"")
    .subscribe(data =>this.flagtestdata=data);
    }

    
  metLifeHome(){
    let redirectTo = "https://www.metropolitanlife.ro/";
    let language = sessionStorage.getItem("defaultLanguage");
    
    switch(language){
          case 'pl_pl' : redirectTo = "https://www.metlife.pl/";
          break;
          case 'pl_en' : redirectTo = "https://www.metlife.pl/";
          break;
          case 'ro_ro' : redirectTo = "https://www.metropolitanlife.ro/";
          break;
          case 'ro_en' : redirectTo = "https://www.metropolitanlife.ro/";
          break;
        }
    window.open(redirectTo,"_blank");
          
        
  }


}
