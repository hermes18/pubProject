import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'access-denied-en',
  templateUrl: './access-denied-en.component.html',
  styleUrls: ['./access-denied-en.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class AccessDeniedEnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
