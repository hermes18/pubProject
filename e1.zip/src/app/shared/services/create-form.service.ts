import { Injectable, Output, EventEmitter, Inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray, AbstractControl } from '@angular/forms';
import { eClaimsConstants } from '../../core/constants/constant';

//{ providedIn: 'root'} visible to whole application
@Injectable({ providedIn: 'root' })
export class CreateFormService {

    constructor(private fb: FormBuilder) { }
    markFormGroupTouched(formGroup: FormGroup) {
        (<any>Object).values(formGroup.controls).forEach(control => {
            control.markAsTouched();
            // control.updateValueAndValidity();
            if (control['controls']) {
                this.markFormGroupTouched(control);

            }
        })

    }
    errorFormGroup(formGroup: FormGroup) {
        let errorArr = [];
        (<any>Object).values(formGroup.controls).forEach(control => {

            if (control.errors) {
                errorArr.push(this.getControlName(control));

            }
            // if (control['controls']) {
            //     this.markFormGroupTouched(control);

            // }
        })
        return errorArr;
    }

    newFormControl(value: any, validators: any, updateOn: 'blur' | 'change' | 'submit' = 'blur'): FormControl {
        return new FormControl('', { updateOn, validators });
    }
    newFormArray(value: any, validators: any, updateOn: 'blur' | 'change' | 'submit' = 'blur'): any {
        return new FormArray([], { updateOn, validators });
    }


    getControlName(field: AbstractControl): string | null {
        const formGroup = field.parent.controls;
        return Object.keys(formGroup).find(name => field === formGroup[name]) || null;
    }

    clearFieldValidation(field) {
        field.setValue(null);
        field.clearValidators();
        field.setErrors(null);

    }
    getPattern(stringVal) {
        let stringPattern = stringVal;
        /*  let stringArr = stringVal ;
        if(stringVal.split('-').length>1){
            stringArr = stringVal.split('-');
        }else{
            stringArr=[stringArr];
        }
        */
        let regexPatternObj = eClaimsConstants.patternTypes;
        /*
        let regexPattern = '';
            for(let i=0;i<stringArr.length;i++){
                regexPattern=regexPattern+ regexPatternObj[stringArr[i]];
            }
            regexPattern = '^['+regexPattern+']+$';
            //console.log(regexPattern,);
            return new RegExp(regexPattern);
            */
        let regPattern = null;
        if (stringPattern != '' && stringPattern != null && regexPatternObj.hasOwnProperty(stringPattern)) {
            regPattern = regexPatternObj[stringPattern];
        }

        if (regPattern) {
            ////console.log("regPattern",regPattern);
            return new RegExp(regPattern);
        }

        return null;
    }

    getValidators(validationRules: any, prop?: any, patternExcept?: any): Validators[] {
        const validators = [];
        if (!validationRules) {
            return validators;
        }
        if (validationRules.allowedDataType) {
            // //console.log(this.getPattern(validationRules.allowedDataType),"this.getPattern(validationRules.allowedDataType)");
            if ((patternExcept) && patternExcept.indexOf(prop) != -1) {

            } else {
                let isPatternValidate = this.getPattern(validationRules.allowedDataType);
                if (isPatternValidate) {
                    validators.push(Validators.pattern(isPatternValidate));
                }
            }


        }
        if (validationRules.mandatoryFlag) {
            validators.push(Validators.required);
        }
        if (validationRules.fieldmaxlength) {
            // //console.log(validationRules.fieldmaxlength,"asdfadf");
            validators.push(Validators.maxLength(validationRules.fieldmaxlength));

        }
        if (validationRules.fieldminlength) {
            validators.push(Validators.minLength(validationRules.fieldminlength));

        }
        return validators;
    }


    isArray(obj: any) {
        return Array.isArray(obj)
    }

    //setFormValidation : set form validation if type of event data changed
    setFormValidationLogic(models, data, patternExceptions?: any) {
        Object.keys(data).forEach(property => {

            if (models.get(property)) {
                let validations = this.getValidators(data[property], property, patternExceptions);

                /* if(form.get(key)){
                          form.get(key).setValidators();
                      }
              */
                //console.log('property',property,validations,data[property],models.get(property));
                if (data[property]
                    && data[property].hasOwnProperty('renderFlag')
                    && data[property].renderFlag != true) {
                    if (this.isArray(models.get(property).controls)) {

                    } else {

                        models.get(property).setValue(null);
                    }

                }
                models.get(property).setValidators(validations);
                models.get(property).updateValueAndValidity();
            }


            if (data[property] && models.get(property)) {

                if (data[property].hasOwnProperty('renderFlag')) {
                    if (models.get(property)) {
                        models.get(property).isVisible = data[property].renderFlag;
                    }
                }
                if (data[property].hasOwnProperty('allowedDataType')) {
                    if (models.get(property).restrict)
                        models.get(property).restrict.pattern = data[property].allowedDataType;
                }
                if (data[property].hasOwnProperty('fieldmaxlength')) {
                    if (models.get(property).restrict)
                        models.get(property).restrict.maxlength = data[property].fieldmaxlength;
                }
                if (data[property].hasOwnProperty('fieldminlength')) {
                    if (models.get(property).restrict)
                        models.get(property).restrict.minlength = data[property].fieldminlength;
                }




            }


        });
    }
    setFormValidation(models, data, patternExceptions?: any) {
        if (this.isArray(models.controls)) {
            for (let i = 0; i < models.controls.length; i++) {
                this.setFormValidationLogic(models.controls[i], data, patternExceptions);
            }
        } else {
            this.setFormValidationLogic(models, data, patternExceptions);
        }


    }

    generateForm(models, data, patternExceptions?: any) {
        const controls = {};
        Object.keys(models).forEach(property => {
            let validations = this.getValidators(data[property], property, patternExceptions);
            // console.log(property,"===> ",validations)
            controls[property] = this.newFormControl(models[property], validations, 'change');

            if (models[property] != null) {
                //  //console.log(models[property].constructor);
                controls[property] = this.newFormArray(models[property], validations, 'change');

            }



            if (data[property]) {
                controls[property].restrict = {}
                if (data[property].hasOwnProperty('renderFlag')) {
                    controls[property].isVisible = data[property].renderFlag;

                }
                if (data[property].hasOwnProperty('allowedDataType') && data[property].allowedDataType) {
                    controls[property].restrict.pattern = data[property].allowedDataType;
                }
                if (data[property].hasOwnProperty('fieldmaxlength') && data[property].fieldmaxlength) {
                    controls[property].restrict.maxlength = data[property].fieldmaxlength;
                }
                if (data[property].hasOwnProperty('fieldminlength') && data[property].fieldminlength) {
                    controls[property].restrict.minlength = data[property].fieldminlength;
                }

            }


            controls[property].fieldName = property;
        });
        return this.fb.group(controls);
    }
    generateFormGroup() {
        const controls = {};

        return this.fb.group(controls);
    }
}
export function patternValidator(regularPattern, maskingPattern) {
    return (control): { [key: string]: any } | null => {
        let patternPassed = true;
        if (control.value && maskingPattern && control.value.toString().indexOf('*') !== -1) {
            patternPassed = new RegExp(maskingPattern).test(control.value);
        } else if (control.value && regularPattern) {
            patternPassed = new RegExp(maskingPattern).test(control.value);
        }
        if (patternPassed) {
            return;
        } else {
            return {
                pattern: true
            }
        }
    }
}