import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Injectable({
  providedIn: 'root'
})
export class DialogService {
  public isDialogOpen: Boolean = false;
  constructor(public dialog: MatDialog) { }
  openDialog(dialogComponent,data,callback?:Function): any {
    if (this.isDialogOpen) {
        return false;
    }
    this.isDialogOpen = true;
    const dialogRef = this.dialog.open(dialogComponent, {
        width: '300px',
        data: data,
        disableClose: true
    });
    dialogRef.afterClosed().subscribe(result => {
      //console.log('The dialog was closed');
      this.isDialogOpen = false;
      if(result && callback)
      {
        callback(result);
      }
  });


  
  
}
  closeDialog(){
    this.dialog.closeAll();
  }
}
