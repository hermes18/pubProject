import { Injectable, Output, EventEmitter, Inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { Observable, throwError, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class HttpCommonService {
    // port = '4200';
    //servicePort = '9080';
    //baseUrl= 'http://localhost:4200';
    //baseUrl = `${this.window.location.protocol}//${this.window.location.hostname}:${this.port}`;
    // authUrl = this.baseUrl + '/api/auth';
    isAuthenticated = true;
    redirectUrl: string;
    //serviceUrl = `${this.window.location.protocol}//${this.window.location.hostname}:${this.servicePort}`;
    constructor(private http?: HttpClient, @Inject('Window') private window?: Window) { }
    postDataResponseText(url, data): Observable<any> {
        let headerOptions = {
           
            params:  (new HttpParams().set('loader', 'true')),
            responseType: 'text' 
        }
        return this.http.post(url, data,{
           
            params:  (new HttpParams().set('loader', 'true')),
            responseType: 'text' 
        });
    }

    postData(url, data, options?: any): Observable<any> {

        //let headerOptions ={};
        let headerObj = {
            'accept-language': sessionStorage.getItem('defaultLanguage'),
            'x-tenant-id': sessionStorage.getItem('tenantId'),
            'content-type': 'application/json',
            'accept': 'application/json'
        };

        let headerOptions = {
            headers: new HttpHeaders(headerObj),
            params: (options && options.loader == 'true') ? (new HttpParams().set('loader', 'true')) : (new HttpParams())
        }


        // if (headers) {
        //     headerOptions = {
        //         headers: new HttpHeaders()
        //     }
        //     return this.http.post(url, data, headerOptions);
        // }
        return this.http.post(url, data, headerOptions);

    }


    postDataFileUpload(url, data, headers): Observable<any> {
        let header = new HttpHeaders();
        header.set('Content-Type', 'multipart/form-data; charset=utf-8');
        return this.http.post(url, data, { headers: header });

    }


    getData(url, header?: any,option?:any): Observable<any> {
        let options =option ? option: null;
        let headerOption = header ? header : this.setDefaultHeaders(options);
       
       
        return this.http.get(url, headerOption);

    }

    /*'Cache-Control': 'no-cache',
     'Pragma': 'no-cache'*/
    setDefaultHeaders(options?:any) {
        let headerOptions = {
            headers: new HttpHeaders({
                'accept-language': sessionStorage.getItem('defaultLanguage'),
                'x-tenant-id': sessionStorage.getItem('tenantId')
            }),
            params: (options && options.loader == 'true') ? (new HttpParams().set('loader', 'true')) : (new HttpParams())
        }
        return headerOptions;
    }

    getDownload() {

    }

    putData(url, data, headers): Observable<any> {
        let header = new HttpHeaders();
        header.set('Content-Type', 'multipart/form-data; charset=utf-8');

        //console.log(JSON.stringify(data));
        return this.http.put<any>(url, data, { headers: header });
        catchError(this.handleError)

    }

    downloadForm(fileId, baseUrl) {
        //  const baseUrl: string = "http://localhost:9083/api/v1/claim/downloadFile/";
        let headers = new HttpHeaders();
        const REQUEST_PARAMS = new HttpParams().set('fileId', fileId)
        headers = headers.append('Accept', 'text/csv; charsedatat=utf-8');
        return this.http.get(`${baseUrl}`, {
            params: REQUEST_PARAMS,
            headers: headers,
            responseType: 'arraybuffer'

        });
    }

    downloadPDF(url) {
        return this.http.get(url, {
            responseType: 'arraybuffer' as 'json'
        });
    }


    private handleError(error: HttpErrorResponse) {
        console.error('server error:', error);
        if (error.error instanceof Error) {
            const errMessage = error.error.message;
            return throwError(errMessage);
            // Use the following instead if using lite-server
            // return Observable.throw(err.text() || 'backend server error');
        }
        return throwError(error || 'Server error');
    }


}
