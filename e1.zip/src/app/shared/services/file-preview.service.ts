import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Injectable({
  providedIn: 'root'
})
export class FilePreviewService {

  public isDialogOpen: Boolean = false;
  constructor(public dialog: MatDialog) { }
  openDialog(filePreview,data): any {
      if (this.isDialogOpen) {
          return false;
      }
      this.isDialogOpen = true;
      const dialogRef = this.dialog.open(filePreview, {
          width: '300px',
          data: data
      });

      dialogRef.afterClosed().subscribe(result => {
          //console.log('The dialog was closed');
          this.isDialogOpen = false;
          let animal;
          animal = result;
      });
  }

  closeDialog(){
      //console.log("dsfs");
    this.dialog.closeAll();
}
}