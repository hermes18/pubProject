import { Component, Input ,OnInit} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ValidationService } from '../../../core/utils/validators';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'error-messages',
  templateUrl: './error-messages.component.html',
  styleUrls: ['./error-messages.component.scss']
})
export class ErrorMessagesComponent implements OnInit {

  constructor(public translate: TranslateService) { }

  ngOnInit() {
  }

  errorMessage: string;
  @Input() control: any;
  @Input() errMessageStr: any;
  get errorMessages() {
    if(this.control && this.control.errors){
      for (let propertyName in this.control.errors) {
        if (
          this.control.errors.hasOwnProperty(propertyName) &&
          this.control.touched
        ) {
          return ValidationService.getValidatorErrorMessage(
            propertyName,
            this.control.errors[propertyName],this.errMessageStr
          );
          /*return this.translate.instant(ValidationService.getValidatorErrorMessage(
            propertyName,
            this.control.errors[propertyName],this.control.fieldName
          ));*/
          //return this.translate.instant('E010');
        }
      }
    }
  

    return null;
  }
}
