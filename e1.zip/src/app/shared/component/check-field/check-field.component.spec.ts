import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { CheckFieldComponent } from './check-field.component';
import {ErrorMessagesComponent} from '../error-messages/error-messages.component';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormArray, FormControl } from '@angular/forms';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';


import { RestrictDirective } from '../../directives/patternRestrict.directive';
import { LengthRestrictDirective } from '../../directives/lengthRestrict.directive';
import { TextMaskModule } from 'angular2-text-mask';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


describe('CheckFieldComponent', () => {
  let component: CheckFieldComponent;
  let fixture: ComponentFixture<CheckFieldComponent>;
  const fb: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,HttpClientModule,HttpClientTestingModule,BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ CheckFieldComponent,ErrorMessagesComponent,RestrictDirective,LengthRestrictDirective  ],
      providers: [HttpClient, { provide: FormBuilder, useValue: fb } ]
     
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckFieldComponent);
    component = fixture.componentInstance;
    component.fdGroupName = fb.group({
      'inputArray': fb.array([fb.group({
        'inputTest':null
      })])
    });

    component.fdGroupName = fb.group({
      'inputTest':null
    });
    component.fdControlName='inputTest';
    
    component.fdGroupName.get('inputTest')['restrict']={maxlength:'',minlength:'',pattern:''};
 
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
