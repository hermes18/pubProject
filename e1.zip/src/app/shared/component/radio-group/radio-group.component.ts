import { Component, EventEmitter, Input, OnInit, Output, ElementRef, Renderer2, ViewChild,
  ViewEncapsulation } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ErrorMessagesComponent } from '../error-messages/error-messages.component';

@Component({
  selector: 'radio-group',
  templateUrl: './radio-group.component.html',
  styleUrls: ['./radio-group.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class RadioGroupComponent implements OnInit {
  private el: ElementRef;
  @Input('translateValuePattern') TranslateValuePattern: string;


  constructor(private _el: ElementRef, public renderer: Renderer2) {

    this.el = this._el;

  }

  ngOnInit() {
    if(!this.fdControlType){
      this.fdControlType  = "text";
    }

   // //console.log(JSON.stringify(this.fdLabelTrans));
  }


  @Input() fdControlName: any;
  @Input() fdGroupName: FormGroup;
  @Input() fdId: any;
  @Input() fdName: any;
  @Input() fdValue: any;
  @Input() fdLabel: any;
  @Input() fdPLabel: any;
  @Input() fdPlaceHolder: any;
  @Input() fdClassName: any;
  @Input() fdPClassName: any;
  @Input() fdTooltip: any;
  @Input() fdDisabled: any;
  @Input() fdControlType: any;
  @Input() fdMask: any;
  @Input() fdLabelTrans:any; 
  @Input() fdLabelControlName:any;
  @Input() fdRadioLabelGrp:any
  @Input() errMessage: any;

  @Output() touchEvent: EventEmitter<Event> = new EventEmitter();
  @Output() changeValue: EventEmitter<Event> = new EventEmitter();

  isFocused: boolean = false;

  @Output() eventValue: EventEmitter<Event> = new EventEmitter();

  fdEventValue(value){
     this.eventValue.emit(value);
   }  
   
  onTouch(event) {
    this.touchEvent.emit(event);
  }

  onInputFocus(input: any) {
    this.isFocused = !this.isFocused;
    if (this.fdMask) {
      input.setAttribute('type', 'text');
    }
  }

  onInputBlur(input: any) {
    this.isFocused = !this.isFocused;
    if (this.fdMask) {
      input.setAttribute('type', 'password');
    }
  }

  changeEvent(event) {
    //console.log(event,event.target.value);
    this.changeValue.emit(event);
  }
  get isValid() { return this.fdGroupName.controls[this.fdControlName.name].valid; }
  get isDirty() { return this.fdGroupName.controls[this.fdControlName.name].dirty; }


}
