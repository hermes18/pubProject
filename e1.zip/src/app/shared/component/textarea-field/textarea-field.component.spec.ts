import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { TextareaFieldComponent } from './textarea-field.component';

import {
MatFormFieldModule,MatInputModule
} from '@angular/material';

import { RestrictDirective } from '../../directives/patternRestrict.directive';
import { LengthRestrictDirective } from '../../directives/lengthRestrict.directive';
import { TextMaskModule } from 'angular2-text-mask';
import { ErrorMessagesComponent } from '../error-messages/error-messages.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormArray, FormControl } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('TextareaFieldComponent', () => {
  let component: TextareaFieldComponent;
  let fixture: ComponentFixture<TextareaFieldComponent>;
  const fb: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,HttpClientTestingModule,MatFormFieldModule,MatInputModule,BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ TextareaFieldComponent,ErrorMessagesComponent,RestrictDirective,LengthRestrictDirective  ]
      ,providers: [ { provide: FormBuilder, useValue: fb } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextareaFieldComponent);
    component = fixture.componentInstance;
   
    component.fdGroupName = fb.group({
      'inputArray': fb.array([fb.group({
        'inputTest':null
      })])
    });

    component.fdGroupName = fb.group({
      'inputTest':null
    });
    component.fdControlName='inputTest';
  
    component.fdGroupName.get('inputTest')['restrict']={maxlength:'',minlength:'',pattern:''};
   
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
