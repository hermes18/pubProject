import { Component, OnInit, ElementRef, Renderer2, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { eClaimsConstants } from 'src/app/core/constants/constant';

@Component({
  selector: 'textarea-field',
  templateUrl: './textarea-field.component.html',
  styleUrls: ['./textarea-field.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class TextareaFieldComponent implements OnInit {
  private el: ElementRef;
  constructor(private _el: ElementRef, public renderer: Renderer2) {

    this.el = this._el;

  }
  patternTypes = eClaimsConstants.patternTypes;
  ngOnInit() {
    if(!this.fdControlType){
      this.fdControlType  = "textarea";
    }
    if (!this.fdLabel) {
      this.fdLabel = "";
    }
  }


  @Input() fdControlName: any;
  @Input() fdGroupName: FormGroup;
  @Input() fdId: any;
  @Input() fdName: any;
  @Input() fdLabel: any;
  @Input() fdPlaceHolder: any;
  @Input() fdClassName: any;
  @Input() fdPClassName: any;
  @Input() fdTooltip: any;
  @Input() fdDisabled: any;
  @Input() fdControlType: any;
  @Input() fdMask: any;
  @Input() errMessage: any;
@Input() noRestrict:any;

  @Output() touchEvent: EventEmitter<Event> = new EventEmitter();
  @Output() changeValue: EventEmitter<Event> = new EventEmitter();

  isFocused: boolean = false;

  onTouch(event) {
    this.touchEvent.emit(event);
  }

  onInputFocus(input: any) {
    this.isFocused = !this.isFocused;
    if (this.fdMask) {
      input.setAttribute('type', 'textarea');
    }
  }

  onInputBlur(input: any) {
    this.isFocused = !this.isFocused;
    if (this.fdMask) {
      input.setAttribute('type', 'password');
    }
  }

  changeEvent(event) {
    this.changeValue.emit(event);
  }
  get isValid() { return this.fdGroupName.controls[this.fdControlName.name].valid; }
  get isDirty() { return this.fdGroupName.controls[this.fdControlName.name].dirty; }
}
