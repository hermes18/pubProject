import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { DateFieldComponent } from './date-field.component';
import {ErrorMessagesComponent} from '../error-messages/error-messages.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {
   MatFormFieldModule, MatDatepickerModule,
  MatNativeDateModule, MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter,
  MatSnackBarModule, MatInputModule
} from '@angular/material';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormArray, FormControl } from '@angular/forms';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


describe('DateFieldComponent', () => {
  let component: DateFieldComponent;
  let fixture: ComponentFixture<DateFieldComponent>;
  const fb: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,
         MatFormFieldModule,BrowserAnimationsModule,
         MatDatepickerModule,
        MatNativeDateModule,HttpClientTestingModule,MatInputModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ DateFieldComponent,ErrorMessagesComponent ],
      providers: [ { provide: FormBuilder, useValue: fb } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DateFieldComponent);
    component = fixture.componentInstance;
    component.fdGroupName = fb.group({
      
      'dateTest':null
    
  });

  component.fdControlName='dateTest';
  
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
