import { Component, OnInit, Input, TemplateRef } from '@angular/core';

@Component({
  selector: 'appTooltip',
  templateUrl: './tooltip.component.html',
  styleUrls: [ './tooltip.component.scss' ]
})
export class TooltipComponent {
  @Input() text: any;
  @Input() content: TemplateRef<any>;
}