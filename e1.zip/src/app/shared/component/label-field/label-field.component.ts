import { Component, OnInit, Input, ViewEncapsulation, AfterViewChecked, ChangeDetectorRef } from '@angular/core';
import { FormGroup, AbstractControl } from '@angular/forms';

@Component({
  selector: 'label-field',
  templateUrl: './label-field.component.html',
  styleUrls: ['./label-field.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LabelFieldComponent implements OnInit, AfterViewChecked {

  constructor(private cdRef: ChangeDetectorRef) { }

  ngOnInit() {
  }

  @Input() fdControlName: any;
  @Input() fdGroupName: FormGroup;
  @Input() fdId: any;
  @Input() fdName: any;
  @Input() fdLabel: any;
  @Input() fdClassName: any;
  showErrorMsg = false;
  @Input() fdArrayName: any;

  showError(controlName) {
    const isRequiredAttribute = this.fdGroupName.get(this.fdControlName).validator(this.fdControlName) ? this.fdGroupName.get(this.fdControlName).validator(this.fdControlName).required ? true : false : false;
    // this.fdGroupName && this.fdGroupName.controls[controlName].errors ? return true : false;
    if (this.fdGroupName && this.fdGroupName.get(this.fdControlName)['isVisible'] != undefined && this.fdGroupName.get(this.fdControlName)['isVisible']) {
      if (this.fdGroupName.controls[controlName].errors && isRequiredAttribute
        ///this.fdGroupName.get(this.fdControlName).validator(this.fdControlName).required
        || (this.fdGroupName.get(this.fdControlName)['invalidFlag'] != undefined && this.fdGroupName.get(this.fdControlName)['invalidFlag'])) {
        return true;
      } else {
        return false;
      }

    }
  }

  // showError(controlName) {
  //   // this.fdGroupName && this.fdGroupName.controls[controlName].errors ? return true : false;
  //   if (this.fdGroupName && this.fdGroupName.get(this.fdControlName)['isVisible'] != undefined && this.fdGroupName.get(this.fdControlName)['isVisible']) {
  //     if ((this.fdGroupName.controls[controlName].errors || (this.fdGroupName.get(this.fdControlName).validator(this.fdControlName) && this.fdGroupName.get(this.fdControlName).validator(this.fdControlName).required))
  //       || (this.fdGroupName.get(this.fdControlName)['invalidFlag'] != undefined && this.fdGroupName.get(this.fdControlName)['invalidFlag'])) {
  //       return true;
  //     } else {
  //       return false;
  //     }

  //   }
  // }

  ngAfterViewChecked() {

    this.cdRef.detectChanges();

  }

  get isRequired() {
    const form_field = this.fdGroupName.get(this.fdControlName);

    //console.log(form_field);
    if (!form_field || !form_field.validator) {
      return false;
    }
    const validator = form_field.validator({} as AbstractControl);
    return (validator && validator.required);

  }
}
