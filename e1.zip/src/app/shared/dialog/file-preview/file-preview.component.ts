import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { FilePreviewService } from '../../services/file-preview.service';
import { DomSanitizer } from '@angular/platform-browser';
 
@Component({
  selector: 'app-file-preview',
  templateUrl: './file-preview.component.html',
  styleUrls: ['./file-preview.component.scss']
})
export class FilePreviewComponent implements OnInit {
  isEdgeBrowser:any = (/edge\//i).test(window.navigator.userAgent);
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,public filePreview : FilePreviewService,private sanitizer: DomSanitizer) {}
 
  public getSantizeUrl(url : string) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
}
 
  ngOnInit() {
  }
 
}