import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatIconModule,MatSelectModule,MatFormFieldModule,MatToolbarModule} from '@angular/material';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AlertInputDialogComponent } from './alert-input-dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { SessionExpiredComponent } from 'src/app/session-expired/session-expired.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BroadcasterService } from '../../services/broadcaster.service';
import {Injector} from "@angular/core";
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
//import { LandingPageComponent } from 'src/app/landing-page/landing-page.component';


describe('HeaderComponent', () => {
  let component: AlertInputDialogComponent;
  let fixture: ComponentFixture<AlertInputDialogComponent>;

  let injector:  Injector;
  let dialog: DialogService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,FormsModule,
        MatToolbarModule,MatIconModule,MatSelectModule,MatFormFieldModule,HttpClientModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }),
        RouterTestingModule.withRoutes([
          
      ]) 
      ],
      declarations: [ AlertInputDialogComponent ],
      providers:[{ provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
        { provide: MatDialog, useValue: {} },DialogService,BroadcasterService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    injector = getTestBed();
    dialog = injector.get(DialogService);
    fixture = TestBed.createComponent(AlertInputDialogComponent);
    component = fixture.componentInstance;
   
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('call on passwordMaskEvent should change inputType value password to text and vice versa', () => {
    component.sourceOfOrigin = '';
    spyOn(component, 'redirectTo').and.callThrough();
    component.inputType = 'password';
    component.passwordMaskEvent();
    expect(component.inputType).toEqual('text');
    component.inputType = 'text';
    component.passwordMaskEvent();
    expect(component.inputType).toEqual('password');
  });

  
  it('call on closeDialog should call dialog.closeDialog', () => {
    component.sourceOfOrigin = '';
    spyOn(component, 'redirectTo').and.callThrough();
    spyOn(component.dialog, 'closeDialog').and.returnValue(null);
    component.closeDialog();
   // expect(router.navigate).toHaveBeenCalledWith(["/login"]);
    expect(component.dialog.closeDialog).toHaveBeenCalled();
  });

  it('call on redirectTo should redirect landing if sourceOfOrigin is "C" ', () => {
   
    component.sourceOfOrigin = '';
    spyOn(component.router, 'navigate').and.callThrough();
    spyOn(component, 'redirectTo').and.callThrough();
    component.redirectTo();

//    expect(component.router.navigate).toHaveBeenCalledWith(["landing"]);
    expect(component.router.navigate).toHaveBeenCalled();
    //component.sourceOfOrigin = 'C';
    //spyOn(window.location, 'reload').and.callThrough();
    //component.redirectTo();

    //expect(window.location.reload).toHaveBeenCalled();
  });

  it(' onPrimaryFunctionhandler  ', () => {
    component.sourceOfOrigin = '';
    let newClaimService = TestBed.get(NewClaimSharedService);
    component.enteredPeselValue="79090304017";
    spyOn(newClaimService, 'getCNPField').and.returnValue('79090304017');
    spyOn(newClaimService, 'updateShowClaimComponent').and.callThrough();
    spyOn(component, 'redirectTo').and.callThrough();    
    component.onPrimaryFunctionhandler('conf19'); 
   
    expect(newClaimService.updateShowClaimComponent).toHaveBeenCalledWith(false);
    component.onPrimaryFunctionhandler('conf20'); 
    expect(newClaimService.updateShowClaimComponent).toHaveBeenCalledWith(false);
    component.onPrimaryFunctionhandler('');

   
//    expect(component.redirectTo).toHaveBeenCalled();
    
    //spyOn(window.location, 'reload').and.callThrough();
    //component.redirectTo();

    //expect(window.location.reload).toHaveBeenCalled();
    component.enteredPeselValue="";
    component.onPrimaryFunctionhandler('');
  });

  it('onInputFocus', () => {
    spyOn(component, 'onInputFocus').and.callThrough();
    component.isFocused = false;
    let input ={
      setAttribute: function(type,text){}
    }
    component.onInputFocus(input);
    
    expect(component.isFocused).toEqual(true);
  });
  it('blurPseiField', () => {
    component.sourceOfOrigin = '';
    spyOn(component, 'redirectTo').and.callThrough();
    spyOn(component, 'blurPseiField').and.callThrough();
    spyOn(component, 'onInputFocus').and.callThrough();
    component.isFocused = false;
    console.log("component.isFocused",component.isFocused);
    let event ={
      target:{
        setAttribute: function(type,text){},
        value:"79090304017"
      }
      
    }
    let focusParam = {
      setAttribute: function(type,text){}
    }
    component.blurPseiField(event);
    component.onInputFocus(focusParam);
    
    console.log("component.isFocused",component.isFocused);
    expect(component.isFocused).toEqual(true);
  });
   
});
