import { Component, OnInit, Inject, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { DialogService } from '../../services/dialog.service';
import { BroadcasterService } from '../../services/broadcaster.service';
import { Router } from '@angular/router';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { Location } from '@angular/common';
import { Subject } from 'rxjs';

@Component({
  selector: 'alert-input-dialog',
  templateUrl: './alert-input-dialog.component.html',
  styleUrls: ['./alert-input-dialog.component.scss']
})
export class AlertInputDialogComponent implements OnInit {

  componentDetails;
  enteredPeselValue: any = '';
  //@Output() setClaimCompFlag  :EventEmitter<boolean> = new EventEmitter();

  public confirmBack$: Subject<boolean> = new Subject();
  inValidPeselNumber: boolean = false;
  jsonObj = (sessionStorage && sessionStorage.userData)?JSON.parse(sessionStorage.userData):{};
  sourceOfOrigin: string = this.jsonObj.sourceOrigin;
  inputType:string = 'password';
  constructor(@Inject(MAT_DIALOG_DATA) public data: string, public dialog: DialogService,
    public router: Router, private readonly shared: BroadcasterService,
    private newClaimService: NewClaimSharedService,
    private location: Location, private dialogRef: MatDialogRef<AlertInputDialogComponent>) {
    this.componentDetails = data;
  }

  ngOnInit() {
  }
  passwordMaskEvent(){
 
    if(this.inputType == 'password'){
      this.inputType = 'text';
    }else{
      this.inputType = 'password';
    }
  }
  redirectTo(){
    if(this.sourceOfOrigin!='C'){
      this.router.navigate(['/landing']);
    }else{
      window.location.reload();
      // this.router.navigate(['/landing']);
      //this.router.navigate(['/newClaim']);
    }
  }
  onPrimaryFunctionhandler(code) {
    //console.log('yes');
    // if (this.componentDetails.nextUrl) {     
    if ((this.enteredPeselValue !== '')) {
      if (this.enteredPeselValue == this.newClaimService.getCNPField()) {
        if (code == 'conf19') {
          // this.router.navigate(['newClaim']);     
          // this.setClaimCompFlag.emit(false);
          this.shared.broadcast('navigateToNextPage', true);
          this.newClaimService.updateShowClaimComponent(false);          
        } else if (code == 'conf20') {
          this.shared.broadcast('navigateToNextPage', true);
          this.newClaimService.updateShowClaimComponent(false);          
         /*  this.router.navigate(['landing']);
          this.shared.broadcast('navigateToNextPage', true);*/
        }
      } else {
        this.redirectTo();
        this.shared.broadcast('navigateToNextPage', true);
      }
    } else {
      // this.inValidPeselNumber = true;
      // this.dialog.isDialogOpen = true;
      this.redirectTo();
      // this.router.navigate(['landing']);
      this.shared.broadcast('navigateToNextPage', true);
    }
    // }
  }
  isFocused: any = false;

  onInputFocus(input) {
    this.isFocused = !this.isFocused;
    input.setAttribute('type', 'text');
  }

  blurPseiField(event) {
    if (event.target.value != '') {

      event.target.setAttribute('type', 'password');
    }
  }

  closeDialog() {
    this.inValidPeselNumber = true;
    this.enteredPeselValue = '';
    this.dialog.closeDialog();
  }
}

