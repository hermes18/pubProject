import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { DialogService } from '../../services/dialog.service';
import { BroadcasterService } from '../../services/broadcaster.service';
import { Router } from '@angular/router';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-alert-dialog',
  templateUrl: './alert-dialog.component.html',
  styleUrls: ['./alert-dialog.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AlertDialogComponent implements OnInit {

  componentDetails;

  constructor(@Inject(MAT_DIALOG_DATA) public data: string, public dialog: DialogService,
  public router: Router, public shared: BroadcasterService,
    public newClaimService: NewClaimSharedService, public dataService: DataService) {
    this.componentDetails = data;
  }

  ngOnInit() {
  }

  onPrimaryFunctionhandler() {
    //console.log('yes');
    if (this.componentDetails.nextUrl) {
      this.router.navigate(['landing']);
      this.shared.broadcast('navigateToNextPage', true);
    } else if (this.componentDetails.fromTypeofevent) {
      let fileInAttachment = this.dataService.getOption('uploadNewClaimList');
      fileInAttachment.fileUpload = [];

    } else {
      this.dialog.closeDialog();
    }
  }


}
