import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatIconModule,MatSelectModule,MatFormFieldModule,MatToolbarModule} from '@angular/material';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AlertDialogComponent } from './alert-dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { SessionExpiredComponent } from 'src/app/session-expired/session-expired.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BroadcasterService } from '../../services/broadcaster.service';
import {Injector} from "@angular/core";
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
//import { LandingPageComponent } from 'src/app/landing-page/landing-page.component';
import { DataService } from '../../services/data.service';


describe('HeaderComponent', () => {
  let component: AlertDialogComponent;
  let fixture: ComponentFixture<AlertDialogComponent>;

  let injector:  Injector;
  let dialog: DialogService;
  let dataService: DataService
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,FormsModule,
        MatToolbarModule,MatIconModule,MatSelectModule,MatFormFieldModule,HttpClientModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }),
        RouterTestingModule.withRoutes([
          
      ]) 
      ],
      declarations: [ AlertDialogComponent ],
      providers:[{ provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
        { provide: MatDialog, useValue: {} },DialogService,BroadcasterService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    injector = getTestBed();
    dialog = injector.get(DialogService);
    fixture = TestBed.createComponent(AlertDialogComponent);
    component = fixture.componentInstance;
   
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
 
  it(' onPrimaryFunctionhandler  ', () => {
    let newClaimService = TestBed.get(NewClaimSharedService);
    let dataService = TestBed.get(DataService);
    component.componentDetails = {nextUrl:"landingPage",fromTypeofevent:null};
    spyOn(dataService, 'getOption').and.returnValue({fileUpload:[]}); 
    spyOn(component.router, 'navigate').and.callThrough(); 
    spyOn(component.dialog, 'closeDialog').and.callFake(function(){});
   
    component.onPrimaryFunctionhandler(); 
    expect(component.router.navigate).toHaveBeenCalled();

    component.componentDetails = {nextUrl:null,fromTypeofevent:true};

    component.onPrimaryFunctionhandler(); 
    
    component.componentDetails = {nextUrl:null,fromTypeofevent:null};

    component.onPrimaryFunctionhandler(); 
   
  });

   
});
