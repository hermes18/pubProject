import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { DialogService } from '../../services/dialog.service';
import { BroadcasterService } from '../../services/broadcaster.service';
import { Router } from '@angular/router';

@Component({
  selector: 'security-dialog',
  templateUrl: './security-dialog.component.html',
  styleUrls: ['./security-dialog.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class SecurityDialogComponent implements OnInit {
  componentDetails:any;
  constructor(@Inject(MAT_DIALOG_DATA) public data: string, public dialog: DialogService,
    private readonly router: Router, private readonly shared: BroadcasterService) {
    this.componentDetails = data;
  }

  ngOnInit() {
  }

}
