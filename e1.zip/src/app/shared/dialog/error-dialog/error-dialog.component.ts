import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { DialogService } from '../../services/dialog.service';


@Component({
  selector: 'error-dialog',
  templateUrl: './error-dialog.component.html',
  styleUrls: ['./error-dialog.component.scss']
})
export class ErrorDialogComponent implements OnInit {

  isDataAvail = null;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,public dialog: DialogService) { 
this.isDataAvail = data;
  }

  country:any = null;
  ngOnInit() {
    this.country =  sessionStorage.getItem('tenantId');
  }
ngOnDestroy(){
  this.isDataAvail = null;
}

}
