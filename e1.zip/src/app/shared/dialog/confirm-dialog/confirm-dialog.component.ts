import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { DialogService } from '../../services/dialog.service';
import { BroadcasterService } from './../../../shared/services/broadcaster.service';

@Component({
  selector: 'app-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ConfirmDialogComponent implements OnInit {

  componentDetails;
  constructor(@Inject(MAT_DIALOG_DATA) public data: string, public dialog: DialogService,
    public dialogRef: MatDialogRef<ConfirmDialogComponent>,
    private readonly shared: BroadcasterService,
    public matDialog: MatDialog) {
    this.componentDetails = data;
    //console.log('confirm dialog data', data);
  }

  removeFile(index, fileUploadModel, fileSizeObject) {
    fileSizeObject.filesSizeCalculation = fileSizeObject.filesSizeCalculation - fileUploadModel[index].data["size"];
    fileUploadModel.splice(index, 1);
    this.dialogRef.close(fileUploadModel);
    //this.shared.broadcast('removeFileInattachment', fileUploadModel);
    //this.dialog.closeDialog();
  }

  ngOnInit() {
  }

}
