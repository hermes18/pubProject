import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfirmDialogComponent } from './confirm-dialog.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { MatDialogModule } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { BroadcasterService } from '../../services/broadcaster.service';
import { DialogService } from '../../services/dialog.service';

describe('ConfirmDialogComponent', () => {
  let component: ConfirmDialogComponent;
  let fixture: ComponentFixture<ConfirmDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,HttpClientTestingModule,MatDialogModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ ConfirmDialogComponent ],
      providers:[ { provide: MAT_DIALOG_DATA, useValue: {} },
        {provide: MatDialogRef,useValue: []},
        { provide: MatDialog, useValue: {} },
        DialogService,BroadcasterService,
        { provide: MatDialogModule },
        { provide: 'Window', useFactory: () => window }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    if(!(sessionStorage.getItem('userData'))){
      let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
   
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }

    fixture = TestBed.createComponent(ConfirmDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('removeFile should remove file from array', () => {
    let filesArray =[{
   contentType: "pdf",
    data:{
    lastModified: 1594279692000,
    lastModifiedDate: "Thu Jul 09 2020 12:58:12 GMT+0530 (India Standard Time)",
    name: "dummy.pdf",
    size: 13264,
    type: "application/pdf",
    webkitRelativePath: "",
    },
    fileName: "dummy.pdf",
    name: "ALL005_dummy.pdf",
    path: "data:application/pdf;base64,JVBERi0xLjQKJcOkw7zDts",
    state: "ALL005_existing",
    
    },
    {contentType: "pdf",
    data:{
    lastModified: 1594279692000,
    lastModifiedDate: "Thu Jul 09 2020 12:58:12 GMT+0530 (India Standard Time)",
    name: "dummy.pdf",
    size: 13264,
    type: "application/pdf",
    webkitRelativePath: ""
    },
    fileName: "dummy.pdf",
    name: "ALL005_dummy.pdf",
    path: "data:application/pdf;base64,JVBERi0xLjQKJcOkw7zDts",
    state: "ALL005_existing"
    
    }];
   // let dialogRef: MatDialogRef<ConfirmDialogComponent>;
    component.dialogRef.close=function(){};
    
    spyOn(component.dialogRef, 'close').and.callFake(function(){});
   //spyOn(dialogRef, 'close').and.callThrough();
   //jasmine.createSpy('dialogRef.close').and.callThrough();
    spyOn(component, 'removeFile').and.callThrough();
     component.removeFile(1,filesArray,{filesSizeCalculation: 13264})
     expect(filesArray.length).toEqual(1);
   });
 
});
