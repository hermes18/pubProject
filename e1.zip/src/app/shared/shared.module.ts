import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InputFieldComponent, SelectFieldComponent, RadioFieldComponent, CheckFieldComponent } from "./component/";
import { AlertDialogComponent } from './dialog/alert-dialog/alert-dialog.component';
import { ConfirmDialogComponent } from './dialog/confirm-dialog/confirm-dialog.component';
import { DialogService } from './services/dialog.service';
import { CreateFormService } from './services/create-form.service';
import { ErrorMessagesComponent } from './component/error-messages/error-messages.component';
import { FilePreviewComponent } from './dialog/file-preview/file-preview.component';
import { FilePreviewService } from './services/file-preview.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextareaFieldComponent } from './component/textarea-field/textarea-field.component';
import { TooltipComponent } from './component/tool-tip/tooltip.component';
import { TooltipDirective } from './component/tool-tip/tooltip.directive';
// import { SatPopoverModule } from '@ncstate/sat-popover';
// import { TooltipModule } from 'ng2-tooltip-directive';

import { DateFieldComponent, MaskDateDirective } from './component/date-field/date-field.component';
import {
  MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule, MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule,
  MatNativeDateModule, MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter,
  MatSnackBarModule, MatInputModule
} from '@angular/material';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { PdfViewerModule } from 'ng2-pdf-viewer';
// import { NgxMaskModule } from 'ngx-mask';
import { TextMaskModule } from 'angular2-text-mask';
import { RestrictDirective } from './directives/patternRestrict.directive';
import { LengthRestrictDirective } from './directives/lengthRestrict.directive';
import { RadioGroupComponent } from './component/radio-group/radio-group.component';
import { SecurityDialogComponent } from './dialog/security-dialog/security-dialog.component';
import { LabelFieldComponent } from './component/label-field/label-field.component';
import { AlertInputDialogComponent } from './dialog/alert-input-dialog/alert-input-dialog.component';
import { ErrorDialogComponent } from './dialog/error-dialog/error-dialog.component';
const sharedComp = [
  InputFieldComponent,
  SelectFieldComponent,
  RadioFieldComponent,
  CheckFieldComponent,
  TextareaFieldComponent,
  DateFieldComponent,
  RadioGroupComponent,
  LabelFieldComponent
];

const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, TextMaskModule,PdfViewerModule];

@NgModule({
  declarations: [...sharedComp, AlertDialogComponent, ConfirmDialogComponent,TooltipComponent, TooltipDirective,
    ErrorMessagesComponent, FilePreviewComponent, TextareaFieldComponent, RestrictDirective, MaskDateDirective,
     SecurityDialogComponent, AlertInputDialogComponent,LengthRestrictDirective, ErrorDialogComponent],
  imports: [
    CommonModule,
    FormsModule, ReactiveFormsModule, ...materialModule, TranslateModule
    //NgxMaskModule.forRoot()
    //,PdfViewerModule
  ],
  exports: [
    ...sharedComp, AlertDialogComponent, ConfirmDialogComponent, FilePreviewComponent, SecurityDialogComponent, AlertInputDialogComponent,
    ErrorMessagesComponent,ErrorDialogComponent, ...materialModule, RestrictDirective, MaskDateDirective,TooltipDirective,LengthRestrictDirective
  ],
  entryComponents: [...sharedComp, AlertDialogComponent, ConfirmDialogComponent, FilePreviewComponent,TooltipComponent, SecurityDialogComponent,
     AlertInputDialogComponent,ErrorDialogComponent],
  providers: [DialogService, FilePreviewService, CreateFormService,
    { provide: 'Window', useValue: window }],
})
export class SharedModule {
  public static forRoot() {
    return {
      ngModule: SharedModule, providers: [
      ]
    };
  }
}