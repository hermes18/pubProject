import { Directive, ElementRef, HostListener, Input, Optional } from '@angular/core';
import { NgControl } from '@angular/forms'
import { environment_constants } from 'src/environments/environment';

@Directive({
  selector: '[restrict]'
})
export class RestrictDirective {
  @Input()
  set restrict(value) {
    if(value){
      this.regExpr = new RegExp(value);
    }

  }

  private _oldvalue: string = "";
  private regExpr: any;
  constructor(@Optional() private control: NgControl) {
  }

  /*@HostListener('paste', ['$event'])
  onPaste($event) {
   this._oldvalue = $event.target.value;  
 }*/

  @HostListener('input', ['$event'])
  change($event) {
    
    if($event.inputType==='insertFromPaste'){
      // $event.target.value = this.restrictedPatternValRemove(this.regExpr,value);
       
       //console.log("this.regExpr",this.restrictedPatternValRemove(this.regExpr,value));
      // console.log("emdash",$event.target.value);
 //en-dash
      //let unkownSpecialChars = ["—","'̨'","„","–","˙","”"]; 
      let unkownSpecialChars = (environment_constants && environment_constants.unkownSpecialChars) ?
      environment_constants.unkownSpecialChars :[] ;
      
      for(let i=0;i<unkownSpecialChars.length;i++){
        if( $event.target.value.indexOf(unkownSpecialChars[i])>-1){
          $event.target.value=($event.target.value).replaceAll(unkownSpecialChars[i],'');
           
         }
      }
         
       if (this.control){
         this.control.control.setValue($event.target.value, { emit: false });
       }
       
     }
    
    if(this.regExpr){
      let item = $event.target
      let value = item.value;
      let pos = item.selectionStart;
      let matchvalue = value;
     if($event.inputType==='insertFromPaste'){
    
    }else{
      
      if($event.inputType!='deleteContentBackward'){
        let noMatch: boolean = (value && !(this.regExpr ? this.regExpr.test(matchvalue) : true));
      
        if (noMatch) {
          item.selectionStart = item.selectionEnd = pos - 1;
          if (item.value.length < this._oldvalue.length && pos == 0){
            pos = 2;
          }

          if (this.control){
            this.control.control.setValue(this._oldvalue, { emit: false });
          }
            
          item.value = this._oldvalue;
          item.selectionStart = item.selectionEnd = pos - 1;
        }
        else{
          this._oldvalue = value;
    
        }
      }else{
        //$event.target.value= $event.target.value; 
        this._oldvalue = $event.target.value;
      } 
      
    
    
    
    }
     

        
    }

  }
  @HostListener('blur', ['$event'])
  onBlur($event) {
    if(this.regExpr){
      this._oldvalue = null;      
    }

  }
  @HostListener('focus', ['$event'])
  onFocus($event) {
    if(this.regExpr){
      this._oldvalue = $event.target.value;      
    }

  }

  restrictedPatternValRemove(pattern,val){
    let nameFieldPatten = pattern+'';
    try{
      if(nameFieldPatten.match(/\[(.*?)\]/)){
        nameFieldPatten = nameFieldPatten.match(/\[(.*?)\]/)[1];
      }
    }catch(e){
console.log(e);
    }

    let nameFieldRegex  = new RegExp(('[^'+nameFieldPatten+"]"), "g");
    let nameFieldReplaceVal = (val).replace(nameFieldRegex,'');
    return nameFieldReplaceVal;
  } 

}