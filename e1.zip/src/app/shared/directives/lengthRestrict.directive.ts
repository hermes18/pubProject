import { Directive, ElementRef, HostListener, Input, Optional } from '@angular/core';
import { FormGroup, NgControl } from '@angular/forms';
import { DeviceDetectorService } from 'ngx-device-detector';

@Directive({
  selector: '[lengthRestrict]'
})
export class LengthRestrictDirective {
  @Input() lengthRestrict;
 
  constructor(@Optional() private control: NgControl, public deviceDetector:DeviceDetectorService) {
  //  console.log("deviceDetector",deviceDetector);
  }

  /*@HostListener('paste', ['$event'])
  onPaste($event) {
   this._oldvalue = $event.target.value;  
 }*/

 @HostListener('keyup', ['$event'])
 onKeyup($event){
   //console.log("keyup");
 }

 @HostListener('keydown', ['$event'])
 onKeydown($event){
   //console.log("keydown");
 }
 
 @HostListener('keypress', ['$event'])
 onKeypress($event){
   //console.log("keypress");
 
   
  }

  @HostListener('input', ['$event'])
  change($event) {
  //  console.log("input");

const isMobile = this.deviceDetector.isMobile();
if(isMobile){


const limit = this.lengthRestrict;
    const element = event.target as HTMLInputElement;
    
    if (limit && element.value) {
        const value = element.value.substr(0, limit);
        
       let position = element.selectionStart; // Capture initial position
      // Set the cursor back to the initial position.
        if (value.length <= limit) {
          element.value = value;
        } else {
          element.value = value.substr(0, limit-1);
        }
        element.selectionEnd = position; 
        //this.ngModelChange.emit(element.value);
        this.control.control.patchValue(element.value,{ emit: false }); // updates the model
      //console.log("this.control.control",this.control.control);
      }

    }
  }

 

}