import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER,Injectable,Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
//import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HeaderComponent, FooterComponent, PageNotFoundComponent } from './core/components';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { ErrorComponent } from './error/error.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { SessionExpiredComponent } from './session-expired/session-expired.component';
import { SharedModule } from './shared/shared.module';
import { HttpConfigInterceptor } from './core/interceptors/http-config.interceptor';
//import { NgxSpinnerModule } from 'ngx-spinner';
import { ExistingClaimComponent } from './existing-claim/existing-claim.component';
import { PdAndAttachmentComponent } from './existing-claim/pd-and-attachment/pd-and-attachment.component';
import { ConfirmationComponent } from './existing-claim/confirmation/confirmation.component';
//import { BnNgIdleService } from 'bn-ng-idle';
import { PersonalDetailsComponent } from './existing-claim/personal-details/personal-details.component';
import { DocumentAttachmentComponent } from './existing-claim/document-attachment/document-attachment.component';
import { AuthService } from './core/services/auth.service';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SidenavListComponent } from './core/components/sidenav-list/sidenav-list.component';
import { GetterSetterService } from './core/services/getterSetter.service';
import { environment } from '../environments/environment';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { CoreModule } from './core/core.module';
// import { NewClaimConfirmationComponent } from './add-new-claim/new-claim-confirmation/new-claim-confirmation.component';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { AddNewClaimModule } from './add-new-claim/add-new-claim.module';
import { MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter, NativeDateAdapter } from '@angular/material';
import { InActiveComponent } from './in-active/in-active.component';
import { AccessDeniedEnComponent } from './access-denied-en/access-denied-en.component';
//import { PdfViewerModule } from 'ng2-pdf-viewer';
//import { NgxMaskModule } from 'ngx-mask'
//export const options: Partial<IConfig> | (() => Partial<IConfig>);
//clearIfNotMatch:false
import { EventTypesResolve } from './add-new-claim/resolvers/event-types.resolve';
import { CountryResolve } from './add-new-claim/resolvers/country.resolver';
import { Title } from '@angular/platform-browser';
import { ErrorPageComponent } from './error-page/error-page.component';
import { DeviceDetectorService } from 'ngx-device-detector';
import { VersionCheckService } from './core/services/version-check.service';

@Injectable()
export class SettingService  {
 

  constructor(private http: HttpClient) {

  }


}



export class CustomDatePickerAdapter extends NativeDateAdapter {

  parse(value: any): Date | null {
    //console.log(value);
    if ((typeof value === 'string') && (value.indexOf('/') > -1)) {
      const str = value.split('/');
      const year = Number(str[2]);
      const month = Number(str[1]) - 1;
      const date = Number(str[0]);
   // console.log("year, month, date",year, month, date)
    //console.log("year, month, date",new Date(year, month, date))
    if(year>0 && month<12 && date>0 && date<=31){
      return new Date(year, month, date);
    }

    
    }
    const timestamp = typeof value === 'number' ? value : Date.parse(value);
    //console.log("timestamp",timestamp)
    return isNaN(timestamp) ? null : new Date(timestamp);
  }

  private _to2digit(n: number) {
    //console.log("_to2digit",('00' + n).slice(-2))
    return ('00' + n).slice(-2);
  }
  format(date: Date, displayFormat: string): string {
    //console.log(displayFormat," ------>",date,displayFormat )

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    //console.log("input",(this._to2digit(day) + '/' + this._to2digit(month) + '/' + year) )
    return this._to2digit(day) + '/' + this._to2digit(month) + '/' + year;

  }
}

@NgModule({
  entryComponents: [SidenavListComponent],
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    PageNotFoundComponent,
    LandingPageComponent,
    ErrorComponent,
    AccessDeniedComponent,
    SessionExpiredComponent,
    ExistingClaimComponent,
    PdAndAttachmentComponent,
    ConfirmationComponent,
    PersonalDetailsComponent, DocumentAttachmentComponent, SidenavListComponent, InActiveComponent,
    // NewClaimConfirmationComponent,
    AccessDeniedEnComponent,
    ErrorPageComponent],
  imports: [
    BrowserModule, FlexLayoutModule, CommonModule,
    FormsModule,BrowserAnimationsModule,
    ReactiveFormsModule, HttpClientModule,
    // NgxSpinnerModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
     // ,isolate: true
    }),
    AppRoutingModule,
    // NgbModule.forRoot(),
    NgIdleKeepaliveModule.forRoot(),
    FormsModule,
    // BrowserAnimationsModule,
    //NoopAnimationsModule,
    SharedModule,
    AddNewClaimModule,
    CoreModule,
    //NgxMaskModule.forRoot()
    //PdfViewerModule

  ],
  exports: [TranslateModule, TranslatePipe, CommonModule,
    FormsModule,
    ReactiveFormsModule, AddNewClaimModule],
  providers: [ TranslatePipe,SettingService, {
    'provide': APP_INITIALIZER,
    'useFactory': initTranslation,
    'deps': [TranslateService],
    'multi': true
  },
  { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true },
  {
    provide: DateAdapter,
    useClass: MomentDateAdapter,
    deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
  },

    {
      provide: DateAdapter,
      useClass: CustomDatePickerAdapter

    },
    // { provide: Window },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
    /*
  {
    'provide': APP_INITIALIZER,
    'useFactory':(authService: AuthService) => () => authService.tokenGeneration(),  
    'deps': [AuthService],
    'multi': true
  },*/
  AuthService,
    EventTypesResolve, CountryResolve, Title,DeviceDetectorService,VersionCheckService],
  bootstrap: [AppComponent]
})
export class AppModule { }


// AOT compilation support
export function initTranslation(translate: TranslateService, storage: GetterSetterService) {
  return () => {

    //  let defaultLang = storage.getSession('userData');
    // let defaultLang = JSON.parse(sessionStorage['userData']).defaultLanguage;

    translate.addLangs(['pl', 'pl_en', 'ro', 'ro_en']);

    //translate.use(defaultLang);
    return Promise.resolve();
  };
}
export function httpTranslateLoader(http: HttpClient) {
 //return new TranslateHttpLoader(http,'URL');
//const prefix = "http://127.0.0.1:8887/i18n/";
//const suffix = ".json"
return new TranslateHttpLoader(http, './assets/i18n/',('.json'+'?v='+new Date().getTime()));
//  return new TranslateHttpLoader(http);
}

