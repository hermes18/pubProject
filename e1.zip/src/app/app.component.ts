import { Component, ViewChild, ApplicationRef, HostListener, NgZone } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HeaderComponent, FooterComponent, PageNotFoundComponent } from './core/components';
// import { BnNgIdleService } from 'bn-ng-idle';
import { DialogService } from './shared/services/dialog.service';
import { SessionExpiredComponent } from './session-expired/session-expired.component';
import { AuthService } from './core/services/auth.service';
import { Router, NavigationStart } from '@angular/router';
import { DateAdapter } from '@angular/material';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToasterComponent } from './core/components/toaster/toaster.component';
import { GetterSetterService } from './core/services/getterSetter.service';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { Title } from "@angular/platform-browser";
import { NewClaimCommonService } from './core/services/add-new-claim-common.service';
import { PlatformLocation } from '@angular/common';
import { Observable, interval, of } from 'rxjs';
import { flatMap, takeUntil } from 'rxjs/operators';
import { VersionCheckService } from './core/services/version-check.service';
import { environment } from 'src/environments/environment';
import { HttpCommonService } from './shared/services/http-common.service';
import { HttpHeaders } from '@angular/common/http';


//import * as $ from 'jquery';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [NewClaimCommonService]
})
export class AppComponent {

  @ViewChild(HeaderComponent, { static: false }) headerRef: HeaderComponent;
  idleState = 'Not started.';
  timedOut = false;
  timedOutWarning = false;
  lastPing?: Date = null;
  title = 'eClaims';
  lang: string;
  showHead: boolean = true;
  footerDefaultLanguage;

  @HostListener('window:mousemove') refreshUserState() {
    // console.log('test')
    this.resetMobile();
  }
  constructor(private ngZone: NgZone,
    public translate: TranslateService, public dialog: DialogService, private authService: AuthService, private router: Router,
    public dateAdapter: DateAdapter<Date>, private _snackBar: MatSnackBar, private claimCommonService: NewClaimCommonService,
    public storage: GetterSetterService, private idle: Idle,
    private keepalive: Keepalive, private appRef: ApplicationRef, public titleService: Title,
    private pLocation: PlatformLocation, private versionCheckService: VersionCheckService,
    public httpCommonService: HttpCommonService,) {
    this.lang = sessionStorage.getItem('defaultLanguage');
    //console.log('this.lang',this.lang);
    let countryCodeParam = window['__env']['countryCode'];
    if (this.lang) {
      this.translate.setDefaultLang(this.lang);
      this.translate.use(this.lang);
    }
    else if (countryCodeParam == 'pl') {
      this.translate.setDefaultLang('pl_pl');
      translate.use('pl_pl');
    } else if (countryCodeParam == 'ro') {
      this.translate.setDefaultLang('ro_ro');
      translate.use('ro_ro');
    }

    this.setLanguageForConfirmation();
    // sets an idle timeout of 5 seconds, for testing purposes.
    this.lastAction = Date.now();
    clearInterval(this.timerIntervalCount);
    //this.check();
    this.initInterval();
    //this.initListener();
    //idle.setIdle(1);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    //need to get session time from constant
    // let sessionOut = ((window['__env']['sessionTimeoutInMinutes']) + 1) * 60;
    // idle.setTimeout(sessionOut);
    //idle.setTimeout(10);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    //idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    // idle.onIdleEnd.subscribe(() => {
    //   this.idleState = 'No longer idle.'

    //   if (this.headerRef) {
    //  //   this.headerRef.timeLeft = 0;
    //   }
    //   //console.log(this.idleState);
    //   this.timedOutWarning = false;
    //   this.timedOut = false;
    //   this.appRef.tick();
    //   this.reset();

    // });

    // idle.onTimeout.subscribe(() => {

    //   this.headerRef.timeLeft = 0;
    //   sessionStorage.removeItem('userToken');
    //   sessionStorage.removeItem('userData');
    //   //      console.log("ontimeout")
    //   this.dialog.openDialog(SessionExpiredComponent, {});

    //   this.idleState = 'Timed out!';
    //   this.timedOut = true;
    //   sessionStorage.clear();
    //   //console.log(this.idleState);
    //   //   this.router.navigate(['/']);
    // });

    // idle.onIdleStart.subscribe(() => {
    //   // this.idleState = 'You\'ve gone idle!'
    //   //console.log("idele starts");
    //   //this.childModal.show();
    // });

    // idle.onTimeoutWarning.subscribe((countdown, doCountdown) => {
    //   this.timedOutWarning = true;

    //   let countdownVal = countdown - 1;
    //   //    console.log("countdownVal",countdownVal);
    //   if (Math.floor((countdownVal) / 60) === 0 && this.headerRef) {
    //     this.headerRef.timeLeft = countdownVal;
    //     this.headerRef.secStarts = true;

    //   } else {
    //     this.headerRef.secStarts = false;
    //     this.headerRef.timeLeft = Math.floor(countdownVal / 60);
    //   }
    //   //  console.log("this.headerRef.timeLeft",this.headerRef.timeLeft);
    //   if (countdownVal === 0) {

    //     //sessionStorage.clear();
    //     /*        sessionStorage.removeItem('userData');
    //             sessionStorage.removeItem('userToken');
    //             sessionStorage.removeItem('tenantId');*/
    //     this.userName = '';
    //   }

    //   ////console.log(this.idleState);
    // });

    // sets the ping interval to 15 seconds
    // keepalive.interval(2);

    //keepalive.onPing.subscribe(() => this.lastPing = new Date());

    // this.reset();

    //10000 = 1sec refreshTokenInMinutes
    //(window['__env']['refreshTokenInMinutes'])






    this.authService.tokenGeneration('login').subscribe((token) => {

      this.callTokenInterval();



      if (document.getElementById('app_overLay')) {
        document.getElementById('app_overLay').remove();
      }

      this.authService.loginTo().subscribe((data) => {
        if (data) {

          let defaultLanguage = sessionStorage.getItem('defaultLanguage');
          // //console.log("deafult lang---",defaultLanguage);
          // this.switchLang(defaultLanguage);
          this.langChangeCalls(defaultLanguage);
          /*this.translate.setDefaultLang(defaultLanguage);
           this.translate.use(defaultLanguage);*/
          let userData = data;
          //let userData = this.storage.getSession('userData');
          this.footerDefaultLanguage = userData.defaultLanguage;
          if (userData && userData.userName) {
            this.userName = userData.userName;
          }
          if (userData.sourceOrigin) {
            this.sourceOfOrigin = userData.sourceOrigin;
          }
          this.router.navigate([`/${userData.landingPage}`]);
        }
        if (window['__env']) {
          //  delete window['__env'];
        }
      });
    });
    //this.openSnackBar();

  }


  ngOnInit() {

    // added for cache issue
    //if(environment.versionCheckURL){
    //}
    /*
    this.versionCheckService.getLangVersionChange().subscribe((data)=>{
      this.resetLanguage();
    });   
    this.versionCheckService.initVersionCheck('./assets/version.json',(1000*60));
      */

    //added for cache issue ends

  }

  callTokenInterval() {
    let intervalTime = window['__env']['refreshTokenInMinutes'] * 60 * 1000;
    this.tokenInterval = setInterval(() => {
      let userData = sessionStorage.getItem('userData');
      if (sessionStorage.getItem('userToken')) {
        // this.authService.tokenGeneration('refresh', data).subscribe((token) => {
        //   //  console.log(token);
        // });
        this.getRefreshTokenCall()
      } else {
        clearInterval(this.tokenInterval);
      }
    }, intervalTime);

  }

  getRefreshTokenCall() {
    let tokenCallParam = {
      "userName": "eclaims"
    };
    // headerOptions = {
    //   headers: new HttpHeaders({
    //     'accept-language': sessionStorage.getItem('defaultLanguage'),
    //     'x-tenant-id': sessionStorage.getItem('countryCode'),
    //     'x-system-id': 'ecustomer'
    //   })
    // };
    const token = sessionStorage.getItem('userToken');
    // let headers =
    //   new HttpHeaders({
    //     'accept-language': sessionStorage.getItem('defaultLanguage'),
    //     'x-tenant-id': sessionStorage.getItem('tenantId'),
    //     'content-type': 'application/json',
    //     'accept': 'application/json',
    //     'Authorization': `Bearer ${token}`

    //   });
    const baseUrl = environment.host + environment.tokenRefreshapi.url;

    this.httpCommonService[environment.tokenRefreshapi.method](baseUrl, tokenCallParam,{'loader':'true'}).subscribe((data) => {
    //  console.log(data);
      this.authService.tokenGeneration('refresh', data).subscribe((token) => {
        //  console.log(token);
      });
    });

  }
  tokenInterval: any;

  countDownMin: any = null;

  sourceOfOrigin: any = null;
  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOutWarning = false;
  }
  getPath() {
    //  console.log("this.pLocation",this.pLocation);
    return (this.pLocation as any).hash;
  }

  resetLanguage() {
    let translationLangs = Object.keys(this.translate.translations);
    let defaulltlang = sessionStorage.getItem('defaultLanguage');
    if(translationLangs && translationLangs.length>0){
    for (let i = 0; i < translationLangs.length; i++) {
      this.translate.resetLang(translationLangs[i]);
      //  this.translate.use(translationLangs[i]);
      //   this.translate.reloadLang(defaulltlang); 
      let timeStamp = new Date().getTime();
      this.httpCommonService['getData'](('./assets/i18n/' + translationLangs[i] + '.json?t=' + timeStamp),null,{'loader':'true'}).subscribe((response) => {
        this.translate.setTranslation(translationLangs[i], response);
        //this.translate.use(defaulltlang);
        this.switchLang(defaulltlang);
      });
      if (this.translate.translations.hasOwnProperty([translationLangs[i]])) {


      }
    }
  }
    //this.switchLang(defaulltlang);
  }

  languageJsonChange(language) {
    //this.translate.setTranslation(language,language);
    this.translate.setDefaultLang(language);

    this.translate.use(language);
    this.translate.onLangChange.subscribe((event) => {
      this.setLanguageForConfirmation();
    });


  }
  dateLanguageChange(language) {
    let dateTranslate = {
      'pl_en': 'en',
      'pl_pl': 'pl',
      'ro_ro': 'ro',
      'ro_en': 'en'
    }
    this.dateAdapter.setLocale(dateTranslate[language]);
  }
  titleLanguageChange(language) {
    let titleTranslate = {
      'pl_en': 'eClaims',
      'pl_pl': 'e-roszczenie',
      'ro_ro': 'e-Claim',
      'ro_en': 'e-Claim'
    }
    this.titleService.setTitle(titleTranslate[language]);
  }
  langChangeCalls(language) {
    this.languageJsonChange(language);

    this.dateLanguageChange(language);
    sessionStorage.setItem("defaultLanguage", language);
    this.lang = language;
    this.titleLanguageChange(language);
  }

  switchLang(language: string) {

    this.langChangeCalls(language);

    // on  landing page country list service should not download
    if (this.getPath().indexOf('/landing') === -1) {
      this.claimCommonService.getCountries();
    }


  }

  openSnackBar() {
    this._snackBar.openFromComponent(ToasterComponent, {
      //Duration to till toast open       duration: 10000,
    });
  }
  userName: any = null;
  private language_version = null;
  onRouteChange() {
    ////console.log("this.router",this.router); 
    this.languageVersionCheck();
    let userData = this.storage.getSession('userData');
    if (userData != '/in-active') {
      try {
        userData.landingPage = this.router.url;

      } catch (err) {
        console.log("err", err);
      }
      this.storage.setSession('userData', userData);

    }
    window.scroll(0, 0);

  }

  languageVersionCheck() {
    let timeStamp = new Date().getTime();
    this.httpCommonService['getData'](('./assets/i18n/lang_version.json?t=' + timeStamp),null,{'loader':'true'}).subscribe((response) => {
      if (this.language_version != response.version) {
    //    console.log(this.language_version, response.version);
      //  console.log(this.language_version != null && this.language_version != '');
        if (this.language_version != null && this.language_version != '') {
          console.log("reset lang");
          this.resetLanguage();
        }
        this.language_version = response.version;
      }
    });
  }

  setLanguageForConfirmation() {
    let lang = sessionStorage.getItem('defaultLanguage');
    this.claimCommonService.updateLanguageSelectionValue(lang);
  }
  initListener() {
    //this.ngZone.runOutsideAngular(() => {
    document.body.addEventListener('click', () => this.reset());
    //});
  }

  timerIntervalCount;
  lastAction;

  initInterval() {
    this.ngZone.runOutsideAngular(() => {
      this.timerIntervalCount = setInterval(() => {
        this.check();
      }, 1000);
    })
  }

  resetMobile() {
    this.lastAction = Date.now();
  }
  secondsCounter: number = 60;

  check() {
    const now = Date.now();
    const timeleft = this.lastAction + ((window['__env']['sessionTimeoutInMinutes']) + 1) * 60 * 1000;
    const diff = timeleft - now;
    const isTimeout = diff < 0;
    const countDownInMin = Math.floor(diff / 60);
    if (Math.floor((countDownInMin) / 1000) === 0 && this.headerRef) {
      this.secondsCounter = this.secondsCounter - 1;
      this.headerRef.secStarts = true;
      this.headerRef.timeLeft = this.secondsCounter;
    } else {
      this.headerRef.secStarts = false;
      this.headerRef.timeLeft = this.secondsCounter;
      let splittedVal = (countDownInMin / 1000).toString().split('.'),
        coundownVAl = parseInt(splittedVal[0]);
      this.headerRef.timeLeft = coundownVAl;
    }
    this.ngZone.run(() => {
      if (isTimeout) {
        // console.log(`timeout mobile`);
        sessionStorage.removeItem('userToken');
        sessionStorage.removeItem('userData');
        clearInterval(this.timerIntervalCount);
        this.dialog.openDialog(SessionExpiredComponent, {});
        sessionStorage.clear();
        setTimeout(() => {
          window.scrollTo(0, 0);
        });
      }
    });

    //}
  }
}
