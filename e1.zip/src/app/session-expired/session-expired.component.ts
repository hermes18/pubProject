import { Component, OnInit,ViewEncapsulation, } from '@angular/core';
import { Router } from '@angular/router';
import { DialogService } from '../shared/services/dialog.service';

@Component({
  selector: 'app-session-expired',
  templateUrl: './session-expired.component.html',
  styleUrls: ['./session-expired.component.scss'],
  encapsulation:ViewEncapsulation.None

})
export class SessionExpiredComponent implements OnInit {

  constructor(private router:Router, private dailogService: DialogService) { }

  ngOnInit() {
  }

  onRoute(){
    this.dailogService.closeDialog();
setTimeout(()=>{
  sessionStorage.clear();
  this.router.navigate(['/in-active']);
 
});    
//window.location.reload();
  }
}
