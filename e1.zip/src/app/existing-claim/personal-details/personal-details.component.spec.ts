import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { PersonalDetailsComponent } from './personal-details.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { ExistingClaimResolve } from '../existing-claim-resolve';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {  FormGroup, FormControl, Validators, FormArray, AbstractControl,FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { of } from 'rxjs';
import { NewClaimSharedService } from 'src/app/add-new-claim/add-new-claim.service';
import { DataService } from 'src/app/shared/services/data.service';
import { ActivatedRoute,Router } from "@angular/router";

describe('PersonalDetailsComponent', () => {
  let component: PersonalDetailsComponent;
  let fixture: ComponentFixture<PersonalDetailsComponent>;
  const fb: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientModule,
        HttpClientTestingModule,BrowserAnimationsModule, FormsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ PersonalDetailsComponent ],
      providers : [ HttpClient ,ExistingClaimResolve,
        HttpCommonService,NewClaimSharedService,DataService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }

    fixture = TestBed.createComponent(PersonalDetailsComponent);
    component = fixture.componentInstance;
    let attachClaimRules ={"ruleFileName":"Eclaims_PersonalDetailsAttachments.xls_PDA_FIELD_RENDER_DETAILS","sheetName":null,"partner":"metlife","sourceOfOrigin":"O","claimNumberSection":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"18","fieldminlength":"5","allowedDataType":"alphanumeric"},"personalDataName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-dot-space"},"personalDataSurName":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":"30","fieldminlength":"0","allowedDataType":"alphabets-every"},"contactDataCountry":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"fillInTheCountry":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"20","fieldminlength":"0","allowedDataType":","},"phoneNumber":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"15","fieldminlength":"0","allowedDataType":"numeric-plus"},"additionalComments":{"renderFlag":true,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"300","fieldminlength":"0","allowedDataType":","},"uploadedDocsAcceptanceCheck":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"personalDataCNP":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"11","fieldminlength":"0","allowedDataType":"numeric"},"uploadDocument":"ALL000_existing|ALL005_existing|ALL001_existing|ALL007_existing|ALL003_existing","countryCode":{"renderFlag":false,"mandatoryFlag":false,"subQuestionFlag":false,"fieldmaxlength":"3","fieldminlength":"0","allowedDataType":"numeric-plus"},"emailAddress":{"renderFlag":true,"mandatoryFlag":true,"subQuestionFlag":false,"fieldmaxlength":null,"fieldminlength":null,"allowedDataType":null},"ksession":null}    
    component.route.snapshot.data.existClaimData = attachClaimRules;
    
    component.existingClaim = fb.group(attachClaimRules);
  
    fixture.detectChanges();
 
 
  
 
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('httpCommonService.getData should return country list', () => {
    //this.httpCommonService.getData(countryListURL)
    let httpCommonService = TestBed.get(HttpCommonService);
    let newClaimService = TestBed.get(NewClaimSharedService);
    let countryList = [
      {"countryCode":"AF","countryName":" Afganistan"},
      {"countryCode":"AL","countryName":" Albania"},
      {"countryCode":"DZ","countryName":" Algieria"},
      {"countryCode":"AD","countryName":" Andora"},
      {"countryCode":"AO","countryName":" Angola"},
      {"countryCode":"AI","countryName":" Anguilla"},
      {"countryCode":"AQ","countryName":" Antarktyka"}
    ];
    spyOn(httpCommonService, 'getData').and.returnValue(of(countryList));
    spyOn(newClaimService, 'setCountryList').and.callThrough();
    
    component.ngOnInit();
    component.defaultLanguage = 'pl';
   
    expect(newClaimService.setCountryList).toHaveBeenCalledWith(countryList);
    component.contactCountryEnable = '';
    component.ngOnInit();
  });

  
  
 
  it('call blurPseiField should check valid pesel number', () => {
   let existingClaimResolve = TestBed.get(ExistingClaimResolve);
    spyOn(existingClaimResolve, 'getPseiValidation').and.returnValue(of({status:'failed'}));
   //component.fdEventValue('test');
   //component.existingClaim.controls.personalDataCNP = ''
   component.inValidSeriesNumber = false;
   component.blurPseiField();

    expect(component.inValidSeriesNumber).toEqual(false);

    component.existingClaim.controls.contactDataCountry.setValue('PL');
    component.existingClaim.controls.personalDataCNP.setValue('123456789');
    component.inValidSeriesNumber = false;
 //   component.blurPseiField();

   // expect(component.inValidSeriesNumber).toEqual(true);

   });
   
   


});
