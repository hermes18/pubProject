import { Component, OnInit,ViewEncapsulation, Output, EventEmitter, AfterViewInit, Input } from '@angular/core';
import { ActivatedRoute,Router } from "@angular/router";
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { DataService } from 'src/app/shared/services/data.service';
import { CreateFormService } from 'src/app/shared/services/create-form.service';
import { FileUpload } from 'src/app/core/models/file-upload';
import { environment } from 'src/environments/environment';
import { ScreenRenderReqModel } from 'src/app/add-new-claim/models/ScreenRenderReqModel';
import { HttpHeaders } from '@angular/common/http';
import { ExistingClaimResolve } from '../existing-claim-resolve';
import { UpdateClaimValidation } from 'src/app/core/models/UpdateClaimValidationModel';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { TranslateService } from '@ngx-translate/core';

import { NewClaimSharedService } from '../../add-new-claim/add-new-claim.service';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { ErrorDialogComponent } from 'src/app/shared/dialog/error-dialog/error-dialog.component';
@Component({
  selector: 'personal-details',
  templateUrl: './personal-details.component.html',
  styleUrls: ['./personal-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class PersonalDetailsComponent implements OnInit, AfterViewInit {

  @Output() isconfirmationTab: EventEmitter<boolean> = new EventEmitter();
  @Output() claimFormPersonalPage: EventEmitter<object> = new EventEmitter<object>();
  @Output() attachmentDetails: EventEmitter<object> = new EventEmitter<object>();

  showCountryLabel: boolean = false;

  @Input() set claimNumberData(event) {
    this.claimNumberFormControl = event;
    //console.log(this.claimNumberFormControl);
  }

  @Input() set existingClaimTabIndex(index) {
    this.showCountryLabel = false;
    this.fileUploadModel = [];
    this.dataService.setOption('uploadedFile', []);
    this.formInit(this.route.snapshot.data.existClaimData);
    // }
  }
  isconfirmFlag: boolean = false;
  existingClaimData: any;
  existingClaimRuleData;
  checkboxValid;
  uploadValid;
  claimNumberFormControl: FormGroup;
  addtionalCommentsShow = false;
  private fileUploadModel: Array<FileUpload> = [];
  updateClaimValidation: UpdateClaimValidation = new UpdateClaimValidation();
  countryCodes = {
    'RO': '+40',
    'PL': '+48'
  };

  selectedCountry: string;
  defaultConutry;
  CountryList = [];
  countryList = [];
  defaultLanguage: string;
  constructor(public route: ActivatedRoute, public httpCommonService: HttpCommonService, public dataService: DataService, public formService: CreateFormService, private fb: FormBuilder,
    private readonly existingClaimResolve: ExistingClaimResolve, public translate: TranslateService,
    private readonly newClaimService: NewClaimSharedService,public router: Router,
    public dialogService: DialogService) {

  }

  submitted = false;
  existingClaim: FormGroup;
  baseUrl = environment.host + environment.existingPersonalServiceConfig.url;
  headers = new HttpHeaders();
  screenRequestObj: ScreenRenderReqModel = new ScreenRenderReqModel();
  jsonObj = JSON.parse(sessionStorage.userData);
  sourceOfOrigin: string = this.jsonObj.sourceOrigin;
  partner: string = 'metlife';
  product: string = '';
  contactCountryEnable: string = '';
  toolTipEnableCountry: string = '';
  inValidSeriesNumber = false;

  //below service call can be made in route resolver and values can be taken here and for claim number attachment screen
  ngOnInit() {
   
    let countryListURL = environment.host + environment.getCountryListConfig.url;
    //   let countryListParam = "language=" + this.jsonObj.displayLanguages + "&country=" + this.jsonObj.defaultLanguage;
    //  countryListURL = countryListURL + countryListParam;
    //countryListURL = "http://localhost:4200/assets/mocks/countryList.json";
    this.httpCommonService.getData(countryListURL).subscribe((data) => {
     this.setCountryList(data);
    },(err) => {console.log(err)
        
      this.getCountriesFromLocal();
    });
    this.formInit(this.route.snapshot.data.existClaimData);

  }
  getCountriesFromLocal() {
    let envHost = environment.localhost;
    let language = sessionStorage.getItem('defaultLanguage');
    // let countryListURL = environment.host + environment.getCountryListLocalConfig.url +'_'+language+'.json';
    let countryListURL = envHost + environment.getCountryListLocalConfig.url +'_'+language+'.json';
    this.httpCommonService.getData(countryListURL).subscribe((data) => {
      this.setCountryList(data);
    });
}
setCountryList(data){
  this.CountryList = data;
  this.dataService.setOption("CountryList", data);
  this.dataService.setOption("countryList", data);
  this.newClaimService.setCountryList(data);
  if (this.contactCountryEnable.indexOf(this.defaultLanguage) != -1) {
    this.setDefaultMobileCode();
  } else {
    this.existingClaim.get('contactDataCountry').setValue(null);
  }

}
  ngAfterViewInit() {
  }
  personalFieldsrule: any;
  phoneNumberOtherMaxLength; any;
  formInit(datum?:any) {
    let data = datum?datum:{};
    this.addtionalCommentsShow = false;
    this.contactCountryEnable = eClaimsConstants.contactCountryEnable;
    this.toolTipEnableCountry = eClaimsConstants.toolTipEnableCountry;
    this.defaultLanguage = this.jsonObj.defaultLanguage.toUpperCase();
    this.phoneNumberOtherMaxLength = eClaimsConstants.phoneNumberOtherMaxLength;
   // this.existingClaimResolve.getRuleSheetDetails().subscribe((data) => {
      //console.log(data)
      this.personalFieldsrule = data;
      let formGroupObj: any = {};
      let rulesArr = [];
      formGroupObj = this.formService.generateForm(this.updateClaimValidation, data);
      this.existingClaim = this.formService.generateForm(this.updateClaimValidation, data);
      //console.log('this.existingClaim', this.existingClaim);
     // this.existingClaim.get('termsAndCondition').setValidators([Validators.required]);
     // this.existingClaim.get('termsAndCondition').updateValueAndValidity();

      if (this.contactCountryEnable.indexOf(this.defaultLanguage) != -1) {
        this.setDefaultMobileCode();
      } else {
        this.existingClaim.get('contactDataCountry').setValue(null);
      }

      this.newClaimService.getCountryList().subscribe((data) => {
        this.CountryList = data;

        setTimeout(() => {
          this.existingClaim.controls['contactDataCountry'].setValue(this.existingClaim.controls['contactDataCountry'].value);
        }, 0);
      });

      this.existingClaim.get('contactDataCountry').valueChanges.subscribe(val => {
        //console.log(val);
        this.inValidSeriesNumber = false;
        if (val === 'RO' || val === 'PL') {
          this.blurPseiField();
        }
      });

   // });




  }
  termsAndConditionChange(event) {
    //console.log(event, "event");
  }


  onSubmit(existForm) {
    this.uploadValid = false;
    this.checkboxValid = false;
    this.submitted = true;
    this.formService.markFormGroupTouched(this.existingClaim);
    this.formService.markFormGroupTouched(this.claimNumberFormControl);
    this.claimFormPersonalPage.emit(this.claimNumberFormControl);
    this.fileUploadModel = this.dataService.getOption('uploadedFile');
    if (this.fileUploadModel.length == 0) {
      if (!this.fileUploadModel || this.fileUploadModel.length == 0) {
        this.uploadValid = true;
      }
      return;

    }
    if (this.dataService.getOption('claimnumber') && 
    //this.existingClaim.get('termsAndCondition').value && 
    this.existingClaim.valid && (!this.showwEmailInValid) &&
    this.claimNumberFormControl.valid ) {
      const selectedFiles: File[] = [];
      let filesObject = new Map();
      for (var index in this.fileUploadModel) {
        selectedFiles.push(this.fileUploadModel[index].data);
        filesObject.set(index + "_" + this.fileUploadModel[index].name, this.fileUploadModel[index].data)
        // prints values: 10, 20, 30, 40
      }

      let updateClaimURL = environment.host + environment.updateClaimServiceConfig.url;

      let updateClaimDetails = this.getCountryName((this.existingClaim.value.contactDataCountry &&
         this.existingClaim.value.contactDataCountry.countryCode) ?
        this.existingClaim.value.contactDataCountry.countryCode : this.existingClaim.value.contactDataCountry);

      //updateClaimDetails["claimNumber"] = this.dataService.getOption('claimnumber');
      updateClaimDetails["uploadedDocumentList"] = [];
      const requestPayloadUpdateClaim = new FormData();
      // Array.from(selectedFiles).forEach((file) => requestPayloadUpdateClaim.append('files', file)),
      filesObject.forEach((value: File, key: string) => {
        //console.log(key);
        let newKey = key.split(/_(.+)/)[1];
        requestPayloadUpdateClaim.append('files', value, newKey)
      }),
        requestPayloadUpdateClaim.append('claimDetails', JSON.stringify(updateClaimDetails));
      //console.log(updateClaimDetails);
      if (!this.inValidSeriesNumber) {
        this.httpCommonService[environment.updateClaimServiceConfig.method](updateClaimURL, requestPayloadUpdateClaim, "").subscribe(data => {
          // //console.log(data[0]['claimNumber']);
          //console.log("ClaimattachmentID", data);
          //console.log("ClaimattachmentID", data[data.length - 1]['claimAttachmentsId']);
          this.dataService.setOption('fileValue', data[data.length - 1]['fileValue']);
          this.attachmentDetails.emit(data[data.length - 1]);
          this.isconfirmationTab.emit(false);
        },err => {console.log(err)
          this.dialogService.openDialog(ErrorDialogComponent, { 'heading': 'Error'});    
        //  this.router.navigate(['/errorPage']);
        });
      }
    }
  }
  getCountryName(value) {
    let existingPersonalVal = this.existingClaim.value,
      countryName = '';
      if(this.CountryList && this.CountryList.length>0){

        for (var i = 0; i < this.CountryList.length; i++) {
          if (this.CountryList[i].countryCode == value) {
            countryName = this.CountryList[i].countryName;
          }
        }
      }

    let countryCode = !this.showCountryLabel ? existingPersonalVal.countryCode : '';
    return {
      claimNumber: this.dataService.getOption('claimnumber'),
      name: existingPersonalVal.personalDataName,
      surName: existingPersonalVal.personalDataSurName,
      countryCode: this.showCountryLabel ? '' :((existingPersonalVal.contactDataCountry && existingPersonalVal.contactDataCountry.countryCode) ?
        existingPersonalVal.contactDataCountry.countryCode : existingPersonalVal.contactDataCountry) ,
      phoneNumber: `${(countryCode?countryCode:'')}${existingPersonalVal.phoneNumber}`,
      email:existingPersonalVal.emailAddress,
      psei: existingPersonalVal.personalDataCNP,
      personalDataCNP: existingPersonalVal.personalDataCNP,
      additionalComments: existingPersonalVal.additionalComments,
      otherCountry: existingPersonalVal.fillInTheCountry ? existingPersonalVal.fillInTheCountry : '',
      authorize: existingPersonalVal.personalDataSurName,
      otherCountryCode: this.showCountryLabel ? 'OTH' : '',
      language: existingPersonalVal.personalDataSurName,
      country: countryName
      // country: this.showCountryLabel ? existingPersonalVal.fillInTheCountry : existingPersonalVal.contactDataCountry
    }
  }
  showwEmailInValid =false;
  blurEmailField(event) {
    this.showwEmailInValid = false;
    //console.log("Email ID", this.corresspondenceAddressForm.controls.email.value)
    if (this.existingClaim.controls.emailAddress.value != '' && this.existingClaim.controls.emailAddress.value != null) {
      this.getEmailIdValue(this.existingClaim.controls.emailAddress.value).subscribe((data) => {
        //console.log("email", data)
        if (data == true) {
          this.showwEmailInValid = false;
          this.existingClaim.controls.emailAddress['invalidFlag'] = this.showwEmailInValid;
        } else {
          this.showwEmailInValid = true;
          this.existingClaim.controls.emailAddress['invalidFlag'] = this.showwEmailInValid;
        }

      });
    }
  }

  getEmailIdValue(emailID) {
    //console.log("emailID", emailID)
    let param = {
      "clientId": "",
      "email": emailID,
      "phoneNumber": "",
      "role": "",
      "userId": ""
    }
    const url = `${environment.host + environment.getEmailId.url}`;
    return this.httpCommonService[environment.getBankName.method](url,param,{'loader':'true'});
  }

  countryOnChange(event) {
    this.showCountryLabel = false;
    if ((this.contactCountryEnable.indexOf(this.defaultLanguage) != -1)
      && (event == this.defaultLanguage) && this.personalFieldsrule.countryCode.renderFlag) {
      this.existingClaim.controls.countryCode.setValue(this.countryCodes[this.defaultLanguage]);
      this.existingClaim.controls.countryCode.enable();
    } else {
      
      this.existingClaim.controls.countryCode.setValue('');
      this.existingClaim.controls.countryCode.disable();
    } 
    
    if (event == "OTHER") {
      this.showCountryLabel = true;
      this.existingClaim.controls.fillInTheCountry.enable();

    }else{
      this.showCountryLabel = false;
      this.existingClaim.controls.fillInTheCountry.setValue('');
      this.existingClaim.controls.fillInTheCountry.disable();
    }
    //console.log("personalFieldsrule", this.personalFieldsrule)

    this.existingClaim.controls.phoneNumber.reset();
    let maxLen = this.personalFieldsrule.phoneNumber.fieldmaxlength;
    if (this.existingClaim.get('contactDataCountry').value == this.defaultLanguage) {
      this.existingClaim.controls.phoneNumber['restrict'].maxlength = maxLen;
      this.existingClaim.controls.phoneNumber.setValidators([Validators.maxLength(maxLen)]);
    } else {
      this.existingClaim.controls.phoneNumber['restrict'].maxlength = this.phoneNumberOtherMaxLength;
      this.existingClaim.controls.phoneNumber.setValidators([Validators.maxLength(this.phoneNumberOtherMaxLength)]);
    }


  }

  setDefaultMobileCode() {
    // for (var i = 0; i < this.CountryList.length; i++) {
    //   if (this.CountryList[i].countryCode == this.defaultLanguage) {
    //     this.existingClaim.get('contactDataCountry').setValue({
    //       countryCode: this.CountryList[i].countryCode,
    //       countryName: this.CountryList[i].countryName
    //     });
    //   }
    // }
    setTimeout(() => {
      if(this.personalFieldsrule.contactDataCountry.renderFlag){
        this.existingClaim.get('contactDataCountry').setValue(this.defaultLanguage);
      }else{
        this.existingClaim.get('contactDataCountry').setValue('');
      }

      if(this.personalFieldsrule.countryCode.renderFlag){
        this.existingClaim.get('countryCode').setValue(this.countryCodes[this.defaultLanguage]);
      }else{
        this.existingClaim.get('countryCode').setValue('');
      }
    }, 10);
  }
  peselOldValue:any=null;
  blurPseiField() {
    if(this.peselOldValue != this.existingClaim.controls.personalDataCNP.value){

      let jsonObj = sessionStorage.getItem('tenantId');
      let countryCode = this.existingClaim.controls.contactDataCountry.value;
      if ((jsonObj === 'ro' && countryCode === 'RO' && this.existingClaim.controls.personalDataCNP.value) || (jsonObj === 'pl' && countryCode === 'PL' &&
        this.existingClaim.controls.personalDataCNP.value)) {
        this.existingClaimResolve.getPseiValidation(this.existingClaim.controls.personalDataCNP.value,
          countryCode.toLowerCase()).subscribe((data) => {
            //console.log(data);
            if (data.status.toLowerCase() === 'failed') {
              this.inValidSeriesNumber = true;
              this.existingClaim.get('personalDataCNP').updateValueAndValidity();
            } else {
              this.inValidSeriesNumber = false;
            }
          });
      } else {
        this.inValidSeriesNumber = false;
      }    
      this.peselOldValue = this.existingClaim.controls.personalDataCNP.value;
    
    }

  }

  inputChangeEvent(value) {
    //console.log(value)
    if (!value) {
      this.inValidSeriesNumber = false;
    }
  }
}
