import { Component, OnInit, ViewEncapsulation, ViewChild, HostListener } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from "@angular/router";
import { DialogService } from '../shared/services/dialog.service';
import { FilePreviewService } from '../shared/services/file-preview.service';
import { HttpCommonService } from '../shared/services/http-common.service';
import { PersonalDetailsComponent } from './personal-details/personal-details.component';
import { DocumentAttachmentComponent } from './document-attachment/document-attachment.component';
import { CanComponentDeactivate } from '../core/gaurds/can-deactivate-gaurd.service';
import { Observable } from 'rxjs';
import { BroadcasterService } from '../shared/services/broadcaster.service';
import { DataService } from '../shared/services/data.service';
import { AlertDialogComponent } from '../shared/dialog/alert-dialog/alert-dialog.component';
import { LocationStrategy } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'existing-claim',
  templateUrl: './existing-claim.component.html',
  styleUrls: ['./existing-claim.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ExistingClaimComponent implements OnInit {
  claimTabIndex = 0;
  disableConfirmation = true;
  claimNumberControl:any =null;
  claimPersonalSection : any = null;
  routingUrl:any=null;
  pressBackButton = false;
  attachmentNameDetails:any = null;
  @ViewChild(PersonalDetailsComponent, { static: false }) personalDetailComponent: PersonalDetailsComponent;
  @ViewChild(DocumentAttachmentComponent, { static: false }) attachDocument: DocumentAttachmentComponent;
  constructor(public dialogService: DialogService, public filePreviewService: FilePreviewService, public translate: TranslateService, public httpCommonService: HttpCommonService, private route: ActivatedRoute, private readonly shared: BroadcasterService, private readonly router: Router,
    public dataService: DataService, private readonly locationStrategy: LocationStrategy) {
  }

  ngOnInit() {

  }
  getConfirmationFlag($event) {
    // //console.log($event);
    this.disableConfirmation = $event;
    this.claimTabIndex = 1;
    window.scroll(0,0);
  }

  getClaimNumbercontrol(event) {
    // //console.log(event);
    this.claimNumberControl = event;
  }

  getclaimFormNumber(event) {
    this.claimPersonalSection = event;
  }

  onTabChanged(event) {
    this.claimTabIndex = event.index;
    if (event.index == 0) {
      this.disableConfirmation = true;
    }
    window.scroll(0,0);
  }

  getAttachmentDetail(event) {
    this.attachmentNameDetails = event;

  }

}


