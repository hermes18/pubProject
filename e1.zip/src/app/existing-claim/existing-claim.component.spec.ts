import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { ExistingClaimComponent } from './existing-claim.component';
import { PersonalDetailsComponent } from './personal-details/personal-details.component';
import { DocumentAttachmentComponent } from './document-attachment/document-attachment.component';
import { MatRippleModule, MatTabsModule } from '@angular/material';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { BroadcasterService } from '../shared/services/broadcaster.service';
import { ExistingClaimResolve } from './existing-claim-resolve';
import { DeviceDetectorService } from 'ngx-device-detector';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpCommonService } from '../shared/services/http-common.service';
import { of } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Component, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'personal-details',
  template: '<div></div>'
})
class MockChildComponent {
  @Output() isconfirmationTab: EventEmitter<boolean> = new EventEmitter();
  @Output() claimFormPersonalPage: EventEmitter<object> = new EventEmitter<object>();
  @Output() attachmentDetails: EventEmitter<object> = new EventEmitter<object>();

  showCountryLabel: boolean = false;

  @Input() set claimNumberData(event) {
   
    //console.log(this.claimNumberFormControl);
  }

  @Input() set existingClaimTabIndex(index) {
    this.showCountryLabel = false;
   
    // }
  }

}


describe('ExistingClaimComponent', () => {
  let component: ExistingClaimComponent;
  let fixture: ComponentFixture<ExistingClaimComponent>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      
      imports: [RouterTestingModule, ReactiveFormsModule,   BrowserAnimationsModule,MatRippleModule, HttpClientModule,  MatTabsModule,SharedModule,FormsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ ExistingClaimComponent,DocumentAttachmentComponent,
        ConfirmationComponent,MockChildComponent],
      //  schemas: [NO_ERRORS_SCHEMA],
        providers:[ HttpClient ,BroadcasterService,ExistingClaimResolve , DeviceDetectorService ]
    }).compileComponents();



  }));

  beforeEach(() => {
  
    let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    if(!(sessionStorage.getItem('userData'))){
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(ExistingClaimComponent);
    
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    //let httpCommonService = TestBed.get(HttpCommonService);
    //spyOn(httpCommonService, 'getData').and.returnValue( of([{"countryCode":"AF","countryName":" Afganistan"}]));
    expect(component).toBeTruthy();
  });
});


/*
fixture = TestBed.overrideComponent(PersonalDetailsComponent, {
  set: {
    template: '<span>{{message}}</span>'
  }})
  .createComponent(PersonalDetailsComponent);

fixture.detectChanges();
*/