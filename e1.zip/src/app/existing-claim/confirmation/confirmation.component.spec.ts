import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfirmationComponent } from './confirmation.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { MatDialogModule } from '@angular/material';
import { of } from 'rxjs';

describe('ConfirmationComponent', () => {
  let component: ConfirmationComponent;
  let fixture: ComponentFixture<ConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,HttpClientTestingModule,MatDialogModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ ConfirmationComponent ],
      providers:[ { provide: MatDialogModule },
        { provide: 'Window', useFactory: () => window }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    //if(!(sessionStorage.getItem('userData'))){
      let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
   
      sessionStorage.setItem('userData',JSON.stringify(userData));
    //}

    fixture = TestBed.createComponent(ConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('downloadForm should call getDownloadPDF', () => {
    
    spyOn(window, "confirm").and.returnValue(true);
    spyOn(component, 'getDownloadPDF').and.callThrough(); 
    spyOn(component, 'downloadFile').and.callThrough(); 
    spyOn(component.commonService, 'downloadPDF').and.returnValue(of('sample image')); 
    
    component.downloadForm();
  
     expect(component.getDownloadPDF).toHaveBeenCalled();
     
   });  
   
   it('gotoMetlife should call window.open ', () => {
    
    spyOn(component, 'gotoMetlife').and.callThrough();
    component.gotoMetlife();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.gotoMetlife();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.gotoMetlife();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.gotoMetlife();
    expect(component.gotoMetlife).toHaveBeenCalled();
  });
});
