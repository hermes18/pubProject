import { Component, OnInit, Input } from '@angular/core';
import { HttpCommonService } from "../../shared/services/http-common.service";
import { DataService } from 'src/app/shared/services/data.service';
import { environment } from 'src/environments/environment';
import { SecurityDialogComponent } from '../../shared/dialog/security-dialog/security-dialog.component';
import { DialogService } from '../../shared/services/dialog.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit {
  @Input() set claimAttachmnetInfo(event) {
    //console.log(event);
    this.attachmentDocumentName = event ? event.documentExt : '';
  }
  userData = JSON.parse(sessionStorage.userData);
  defaultLanguage: string = this.userData.defaultLanguage;
  constructor(public commonService: HttpCommonService,
    public dataService: DataService,
    public dialogService: DialogService,
    public translate: TranslateService) { }
  attachmentDocumentName;
  ngOnInit() {

  }

  getDownloadPDF() {

    //if(result=='yes'){
    let fileID = this.dataService.getOption('claimnumber');
    let docId = this.dataService.getOption('fileValue');

    let url = environment.host + environment.confirmationDownloadServiceConfig.url + docId;
    this.commonService.downloadPDF(url).subscribe((data) => {
      this.downloadFile(data);
    });

    //}

  }

  downloadForm() {
    // let docId = "";


    let confirmDownload = confirm(this.translate.instant('eClaims.existingClaim.confirmation.CacheWarning'));
    if (confirmDownload == true) {
      this.getDownloadPDF()
    }
    /*this.dialogService.openDialog(SecurityDialogComponent,
      { 'heading': this.translate.instant('eClaims.existingClaim.confirmationLabel'),
       'body': this.translate.instant('eClaims.existingClaim.confirmation.CacheWarning'), 
       'primaryButton': this.translate.instant('yesButton'),
       'tertiaryButton': this.translate.instant('noButton'),
       'thisRef':this,
      'callBack'  :this.getDownloadPDF
      })*/
  }
  downloadFile(data) {
    window.scroll(0,0);
    let blob = new Blob([data], { type: "application/pdf" });
    if (window.navigator.msSaveOrOpenBlob) {
      //IE11 & Edge
      window.navigator.msSaveOrOpenBlob(blob);
    } else {
      let url = window.URL.createObjectURL(blob);
      window.open(url);
    }
    // window.navigator.msSaveBlob(blob, `uiu.xlsx`);
    // let link = document.createElement('a');
    // link.href = "h";
    // link.target = '_blank';
    // // link.download = "help.pdf";
    // link.click();
  }
  gotoMetlife() {
    let redirectTo = "https://www.metropolitanlife.ro/";
    let language = sessionStorage.getItem("defaultLanguage");

    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/";
        break;
      case 'ro_ro': redirectTo = "https://www.metropolitanlife.ro/";
        break;
      case 'ro_en': redirectTo = "https://www.metropolitanlife.ro/";
        break;
    }
    window.open(redirectTo, "_blank");

  }
}