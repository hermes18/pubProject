import { Component, OnInit } from '@angular/core';
import {PersonalDetailsComponent} from '../personal-details/personal-details.component';
@Component({
  selector: 'pd-and-attachment',
  templateUrl: './pd-and-attachment.component.html',
  styleUrls: ['./pd-and-attachment.component.scss']
})
export class PdAndAttachmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
