import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot, ActivatedRoute } from "@angular/router";
import { Observable, of } from "rxjs";
import { HttpCommonService } from "../shared/services/http-common.service";
import { map, catchError,take } from 'rxjs/operators';
import { ScreenRenderReqModel } from '../add-new-claim/models/ScreenRenderReqModel';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class ExistingClaimResolve implements Resolve<any> {
  screenRequestObj: ScreenRenderReqModel = new ScreenRenderReqModel();
  partner: string = 'metlife';
  baseUrl = environment.host + environment.existingPersonalServiceConfig.url;
  headers = new HttpHeaders();
  ruleSheetDetails: any;
  constructor(private commonService: HttpCommonService,private route: ActivatedRoute) { }

  resolve(route: ActivatedRouteSnapshot) {
    //const url = "assets/mocks/rule.json";
    //console.log(this.commonService.getData(url), "this.commonService.getData(url)")
    return this.getRules();
  }
  getRules() {
    this.screenRequestObj.screenName = "ExistingClaim";
    let sourceOrigin = JSON.parse(sessionStorage.getItem("userData"));

    this.screenRequestObj.sourceOfOrigin = sourceOrigin.sourceOrigin;
    this.screenRequestObj.partner = this.partner;

    return this.commonService[environment.typeOfEventServiceConfig.method](this.baseUrl, this.screenRequestObj, this.headers).pipe(take(1),catchError(() => {
      return of({});
    }));
   
  }
  getRuleSheetDetails() {
    // let data =this.route.snapshot.data.existClaimData?this.route.snapshot.data.existClaimData:{};
    // return of(data);


    return this.commonService[environment.typeOfEventServiceConfig.method](this.baseUrl, this.screenRequestObj, this.headers).pipe(take(1),catchError(() => {
      return of({});
    }));

    // return this.route.snapshot.data.existClaimData;
    // (this.baseUrl,  this.screenRequestObj,this.headers).subscribe((data) => {
    //   return data;
    // });
  }

  getPseiValidation(nationalId, countryCode) {
    let encodeNationalId = encodeURIComponent(nationalId);
    let param = {
      "countryCode": countryCode,
      "nationalId": encodeNationalId
    }
    const url = `${environment.host + environment.getSeriesNumber.url}`;
    return this.commonService[environment.getSeriesNumber.method](
      url, param);

  }
} 