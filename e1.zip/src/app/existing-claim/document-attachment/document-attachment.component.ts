import { Component, OnInit, ViewEncapsulation, Output, EventEmitter, Input, ViewChild, HostListener } from '@angular/core';
import { FileUpload } from 'src/app/core/models/file-upload';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { FilePreviewService } from 'src/app/shared/services/file-preview.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { FilePreviewComponent } from 'src/app/shared/dialog/file-preview/file-preview.component';
import { ConfirmDialogComponent } from 'src/app/shared/dialog/confirm-dialog/confirm-dialog.component';
import { DataService } from 'src/app/shared/services/data.service';
import { UpdateClaimValidation } from 'src/app/core/models/UpdateClaimValidationModel';
import { ExistingClaimResolve } from './../existing-claim-resolve';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { CreateFormService } from 'src/app/shared/services/create-form.service';
import { TranslateService } from '@ngx-translate/core';
import { environment } from 'src/environments/environment';
import { eClaimsConstants } from 'src/app/core/constants/constant';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'document-attachment',
  templateUrl: './document-attachment.component.html',
  styleUrls: ['./document-attachment.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DocumentAttachmentComponent implements OnInit {
  @ViewChild('uploadpopover', { static: false }) uploadpopover;

  @HostListener('window:scroll', ['$event'])
  scrollHandler(event) {
    //this.uploadpopover.hide();
  }

  claimnumber: number;
  documentTypes = [];
  userInfo = JSON.parse(sessionStorage.userData);
  public fileUploadModel: Array<any>;
  allowedType = ['jpeg', 'jpg', 'tiff', 'pdf', 'gif', 'png', 'bmp', 'tif'];
  fileValidation_Messages = [];
  fileSizeObject = { filesSizeCalculation: 0 };
  claimFormGroup: FormGroup;
  claimFormNumberError = false;
  updateClaimValidation: UpdateClaimValidation = new UpdateClaimValidation();
  public file_count = 0;

  @Output() claimFormGroupControls: EventEmitter<object> = new EventEmitter<object>();
  @Input() set claimNumberFormGroup(event) {
    if (event) {
      // this.claimFormGroup.controls.claimNumberSection.markAsTouched();
      //console.log(event);
    }
  };

  @Input() set existingClaimTabIndex(index) {
    this.claimFormGroup ? this.claimFormGroup.reset() : '';
    this.fileValidation_Messages = [];
    this.fileSizeObject = { filesSizeCalculation: 0 };
    this.formInit();
  }

  constructor(public dialogService: DialogService, public dataService: DataService,
    private readonly existingclaimResolve: ExistingClaimResolve, public translate: TranslateService,
    private formService: CreateFormService,
    public filePreviewService: FilePreviewService, public httpCommonService: HttpCommonService,
    public deviceDetector:DeviceDetectorService,
    private route: ActivatedRoute) {
    this.dataService.setOption('uploadedFile', []);
  }
  claimNumberModel: ClaimNumberModel = new ClaimNumberModel();

  isMobile = this.deviceDetector.isMobile();
  @Output() uploadEvent: EventEmitter<boolean> = new EventEmitter();

  ngOnInit() {
   
   // this.existingclaimResolve.getRuleSheetDetails().subscribe((data) => {
     
   if(this.route.snapshot.data.existClaimData){

   let data = this.route.snapshot.data.existClaimData;
   //console.log(data);
      this.claimFormGroup = this.formService.generateForm(this.claimNumberModel, data);
      this.claimFormGroupControls.emit(this.claimFormGroup);
      // this.claimFormGroup = this.formService.generateForm(this.claimNumberModel, data);
      let documentTypesFromRule = data.uploadDocument.split("|");
      for (var docType of documentTypesFromRule) {
        //console.log("DocType", docType, documentTypesFromRule);
        //docType = docType.replace("_existing", "");
        this.documentTypes.push({ "id": docType, "name": docType });
      }
    }
  //  });
    this.formInit();
  }

  formInit() {
    this.claimnumber = null;
    this.fileUploadModel = [];
  }

  fileSelection(event, claimdoc: string, fileUploadData: HTMLInputElement) {
    let claimdocRemoveExistingKey = claimdoc.replace("_existing", "");
    let virusFileCheck = environment.host + environment.virusFileCheck.url;
    this.uploadEvent.emit(event);
    this.fileValidation_Messages = [];
    let isInValidFile = false;
    for (let index = 0; index < event.target.files.length; index++) {
      const file = event.target.files[index];
      const fileContentType = file.name.substring(file.name.lastIndexOf(".") + 1).toLocaleLowerCase();
      if (this.allowedType.indexOf(fileContentType) != -1) {
        const reqPayload = new FormData();
        reqPayload.append('file', file);
         this.httpCommonService[environment.virusFileCheck.method](virusFileCheck, reqPayload, "").subscribe(data => {
          if (data.statusCode == 200) {
        this.fileSizeObject.filesSizeCalculation = this.fileSizeObject.filesSizeCalculation + file.size;
        if (file.size < this.userInfo.minFilesize && this.fileSizeObject.filesSizeCalculation < this.userInfo.maxFilesize) {
          const reader = new FileReader();
          const filenameWithDocType = claimdocRemoveExistingKey + "_" + file.name;
          reader.onload = e => {
            const temp = reader.result as string;
            this.fileUploadModel.push({ data: file, state: claimdoc, path: temp, name: filenameWithDocType, contentType: fileContentType, fileName: file.name });
          }
          reader.readAsDataURL(file);
          fileUploadData.value = "";
        }
        else {
          isInValidFile = true;
          if (file.size > this.userInfo.minFilesize) {
            this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidSize' });
          }
          else if (this.fileSizeObject.filesSizeCalculation > this.userInfo.maxFilesize) {
            this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidSizeMax' });
          }
          this.fileSizeObject.filesSizeCalculation = this.fileSizeObject.filesSizeCalculation - file.size;

        }
           } else {
             this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.virusFile' });
           }
         });
      }
      else {
        this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidFormat' });
       // console.log('In Loop: ', this.fileValidation_Messages);
      }
      this.dataService.setOption('uploadedFile', this.fileUploadModel);
      this.dataService.setOption('claimnumber', this.claimFormGroup.value.claimNumberSection);
    }
  //  console.log('Outside loop: ', this.fileValidation_Messages);


  }

  onclaimNumber(event) {
    this.dataService.setOption('claimnumber', this.claimFormGroup.value.claimNumberSection);
  }
  hasNumber(myString) {
    return /\d/.test(myString);
  }
  onClaimInputChange(event) {
    
  }
  //e
  onBlurClaimNumber($event){
    let jsonObj = sessionStorage.getItem('tenantId');
    if (jsonObj == 'pl') {
     
if(this.hasNumber(this.claimFormGroup.value.claimNumberSection)){
  if (this.claimFormGroup.controls['claimNumberSection'].hasError('incorrect')) {
    delete this.claimFormGroup.controls['claimNumberSection'].errors['incorrect'];
    
  }
}else{
  this.claimFormGroup.controls['claimNumberSection'].setErrors({ 'incorrect': true});
}
     // this.claimFormGroup.get('claimNumberSection').updateValueAndValidity();
      this.dataService.setOption('claimnumber', this.claimFormGroup.value.claimNumberSection);
      this.claimFormGroupControls.emit(this.claimFormGroup);
    }
  }
  removeSelectedFile(index, file: FileUpload) {
    //console.log(this.fileUploadModel);
    const message = this.translate.instant("eClaims.existingClaim.attachment.confirmDeleteMessage") + ' ' + file.data.name
    this.dialogService.openDialog(ConfirmDialogComponent, { 'heading': this.translate.instant("eClaims.existingClaim.attachment.confirmDelete"), 'body': message, "index": index, "fileUploadModel": this.fileUploadModel, "fileSizeObject": this.fileSizeObject });
    this.fileValidation_Messages = [];
  }



  filePreview(filePath, contentType) {
    this.filePreviewService.openDialog(FilePreviewComponent, { 'filePath': filePath, 'type': contentType });
  }


  fileNameAlter(event, index) {
    let claimDocType = event.value.replace("_existing", "");
    this.fileUploadModel[index].name = claimDocType + "_" + this.fileUploadModel[index].data.name;
    this.dataService.setOption('uploadedFile', this.fileUploadModel);
  }
}

export class ClaimNumberModel {
  claimNumberSection: any = null;
}

export class fileCounter {
  public file_count = 0;
}