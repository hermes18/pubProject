import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DocumentAttachmentComponent } from './document-attachment.component';
import {SharedModule} from 'src/app/shared/shared.module';
import { ExistingClaimResolve } from './../existing-claim-resolve';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DeviceDetectorService } from 'ngx-device-detector';


describe('DocumentAttachmentComponent', () => {
  let component: DocumentAttachmentComponent;
  let fixture: ComponentFixture<DocumentAttachmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,
        FormsModule,HttpClientTestingModule,BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ DocumentAttachmentComponent ],
      providers:[ExistingClaimResolve,DeviceDetectorService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    if(!(sessionStorage.getItem('userData'))){
      let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
      sessionStorage.setItem('userData',JSON.stringify(userData));
    }
    fixture = TestBed.createComponent(DocumentAttachmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
