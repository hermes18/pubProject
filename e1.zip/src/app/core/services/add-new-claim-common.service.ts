
import { Injectable } from "@angular/core";
import { Observable,BehaviorSubject } from "rxjs";
import { HttpCommonService } from "../../shared/services/http-common.service";
import { map, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';


import { NewClaimSharedService } from '../../add-new-claim/add-new-claim.service';

@Injectable()
export class NewClaimCommonService {
    partner: string = 'metlife';
    baseUrl = environment.host + environment.existingPersonalServiceConfig.url;
    headers = new HttpHeaders();
    CountryList: any;
    public selectedLangSubject: BehaviorSubject<any>;

    constructor(private commonService: HttpCommonService,
        private newClaimService: NewClaimSharedService) { 
            this.selectedLangSubject = new BehaviorSubject(null);
        }



    getCountries() {

        let countryListURL = environment.host + environment.getCountryListConfig.url;
        this.commonService.getData(countryListURL).subscribe((data) => {
            this.newClaimService.setCountryList(data);
        },(err) => {console.log(err)
        
            this.getCountriesFromLocal();
          });
    }
    getCountriesFromLocal() {
        let envHost = environment.localhost;
        let language = sessionStorage.getItem('defaultLanguage');
        // let countryListURL = environment.host + environment.getCountryListLocalConfig.url +'_'+language+'.json';
        let countryListURL = envHost + environment.getCountryListLocalConfig.url +'_'+language+'.json';
        this.commonService.getData(countryListURL).subscribe((data) => {
            this.newClaimService.setCountryList(data);
        });
    }

    

    
    updateLanguageSelectionValue(lang) {
        this.selectedLangSubject.next(lang);
    }

    triggerLanguageSeletionValue(): Observable<any> {
        return this.selectedLangSubject.asObservable();
    }

}