import { Injectable, Output, EventEmitter, Inject } from '@angular/core';

import { HttpClient, HttpErrorResponse, HttpParams, HttpClientModule, HttpHeaders, HttpRequest } from '@angular/common/http';

import { Http } from '@angular/http';

import { Router, ActivatedRoute, Params } from '@angular/router';

import { Observable, throwError, of, timer } from 'rxjs';

import { map, catchError, retry, retryWhen, tap, delayWhen, take } from 'rxjs/operators';

import { GetterSetterService } from './getterSetter.service';

import { environment } from "src/environments/environment";

import { TranslateService } from '@ngx-translate/core';



@Injectable()

export class AuthService {



    redirectUrl: string;



    constructor(private http?: HttpClient, @Inject('Window')

    private window?: Window, public route?: ActivatedRoute,

        public router?: Router, public storage?: GetterSetterService, public translate?: TranslateService) {

        //super();

    }


    loginWindowURL: any = null;
    loadToken(): Promise<any> {

        const promise = this.http.get('/assets/app.config.json')
            .toPromise()
            .then(data => {
                Object.assign(this, data);
                return data;
            });

        return promise;
    }

    tokenGeneration(tokenDetails?: any, data?:any) {
        this.loginWindowURL = this.window.location.href;
        let defaultlang = { "pl": "pl_pl", "pl_en": "pl_en", "ro": "ro_ro", "ro_en": "ro_en" }

        //let httpParams = new HttpParams({ fromString: this.loginWindowURL.split('?')[1] });
        //  let countryCodeParam = httpParams.get('countryCode');
        let countryCodeParam = window['__env']['countryCode'];


        let isUserdata = JSON.parse(sessionStorage.getItem('userData'));


        if (isUserdata && countryCodeParam
            && (isUserdata.defaultLanguage === countryCodeParam)) {

        } else {
            if (defaultlang[countryCodeParam]) {

                sessionStorage.setItem("defaultLanguage", defaultlang[countryCodeParam]);

            }
            if (countryCodeParam) {
                sessionStorage.setItem("tenantId", countryCodeParam);
            }

        }
        // let istokenDetails = (tokenDetails ? tokenDetails : (isUserdata?isUserdata.type:null));
        //let tokenPass = istokenDetails ? istokenDetails : btoa("eclaims");
        let tokenPass = btoa("eclaims");
        let tokenConfig = {
            url: (environment.host + environment.tokenServiceConfig.url),
            reqParam: { "userName": "eclaims", "password": (data ? data : tokenPass), "type": tokenDetails }
        }
let options = (tokenDetails && tokenDetails==='refresh')?({'loader':'true'}):null;

        let headerOptions = {

            headers: new HttpHeaders({

                "Content-Type": "application/json"
            }),
            params: (options && options.loader == 'true') ? (new HttpParams().set('loader', 'true')) : (new HttpParams())
        }
        //"application/json"
        // 'text/plain; charset=utf-8'
        //,"responseType": "text"
        return this.http[environment.tokenServiceConfig.method]<any>(tokenConfig.url,
            JSON.stringify(tokenConfig.reqParam), headerOptions)
            .pipe(map((data: any) => {
                //    console.log(data);
                sessionStorage.setItem('userToken', data.token);

                return data.token;
            }), retryWhen(errors => {
                let countDown = 3;
                return errors
                    .pipe(
                        tap(errorStatus => {
                            //  console.log(errors);
                            // console.log(errorStatus);

                            if (errorStatus instanceof HttpErrorResponse) {
                                console.log("countdown", countDown);
                                if (countDown > 0) {
                                    console.log("retry");
                                } else {
                                    throw errorStatus;
                                }
                                --countDown;
                            } else {
                                throw errorStatus;
                            }
                        })
                        //,take(2)
                        //,retry(3)
                    )
                // Throw an exception to signal that the error needs to be propagated

            }
            ),

                catchError((err) => {

                    let defaultLanguage = sessionStorage.getItem("defaultLanguage");

                    this.router.navigate(['/errorPage']);
                    return throwError(err);

                }),

                catchError(this.handleError)

            );

    }


    loginTo() {

       // let reqData = { "sourceOrigin": "C", "identifierToken": "", "applicationType": "", "userName": "", "pesel": "", "requesterName": "", "requesterSurName": "", "requesterAddress": "", "requesterEmail": "", "requestFrom": "" };

        let config = { url: (environment.host + environment.authServiceConfig.url) }

        //let config = { url: (environment.authServiceConfig.url) }
        let windowURL = this.loginWindowURL;
        //let windowURL = this.window.location.href;
        let defaultlang = { "pl": "pl_pl", "pl_en": "pl_en", "ro": "ro_ro", "ro_en": "ro_en" }
        let httpParams = new HttpParams({ fromString: windowURL.split('?')[1] });

        let countryCode = window['__env']['countryCode'] ? window['__env']['countryCode'] : null;
        //   let countryCode = httpParams.get('countryCode') ? httpParams.get('countryCode') : null;

        // removed countryCode from param and put in env.js
        let isUserdata = JSON.parse(sessionStorage.getItem('userData'));

        let isDefaultLangSame = false;
        if (isUserdata && countryCode
            && (isUserdata.defaultLanguage === countryCode)) {
            isDefaultLangSame = true;
        }

        //session userdata default language is different from country code in env.js should trigger userdata service call
        if (!isUserdata || httpParams.has('identifierToken') ||
            httpParams.has('sourceOrigin') || httpParams.has('sourcekey') || !isDefaultLangSame
        ) {


            let identifierToken = httpParams.get('identifierToken') ? httpParams.get('identifierToken') : null;

            let sourceOrigin = httpParams.get('sourceOrigin') ? httpParams.get('sourceOrigin') : null;

            // let countryCodeParam = httpParams.get('countryCode') ? httpParams.get('countryCode') : null;

            let countryCodeParam = window['__env']['countryCode'] ? window['__env']['countryCode'] : null;

            let sourcekey = httpParams.get('sourcekey') ? httpParams.get('sourcekey') : null;
           //console.log("sourcekey",sourcekey);
            let params = {

                identifierToken: identifierToken,

                sourceOrigin: sourceOrigin,

                countryCode: countryCodeParam,

                encrytpedKeys: sourcekey



            }

            if (defaultlang[countryCodeParam]) {

                sessionStorage.setItem("defaultLanguage", defaultlang[countryCodeParam]);

            }
            if (countryCodeParam) {
                sessionStorage.setItem("tenantId", countryCodeParam);
            }


            //console.log("country--" + httpParams.get('countryCode'));

            //console.log("config----", config.url)
            let headerOptions = {

                headers: new HttpHeaders({

                    "Content-Type": "application/json"
                })
            }

            if (httpParams.has('identifierToken') || httpParams.has('sourceOrigin')
                || countryCodeParam || httpParams.has('sourcekey')) {

                return this.http[environment.authServiceConfig.method]<any>(config.url, JSON.stringify(params), headerOptions)
                    .pipe(map((data: any) => {
                        let userData = {};
                        if (data && data.landingPage) {
                            userData = data;
                            userData['originPage'] = data.landingPage;
                            sessionStorage.setItem('userData', JSON.stringify(userData));

                        }

                        return userData;

                    }),



                        //  catchError(this.handleError(Error,this))

                        catchError((err) => {

                            //console.log(err, this, "hell");

                            let defaultLanguage = sessionStorage.getItem("defaultLanguage");

                            //if there is no language while redirecting access denied page language should be English defect fix

                            if (!defaultLanguage) {

                                defaultLanguage = "ro_en";

                            }

                            this.translate.setDefaultLang(defaultLanguage);

                            this.translate.use(defaultLanguage);

                            this.router.navigate(['/access-denied']);



                            return throwError(err);

                        }),

                        catchError(this.handleError)

                    );

            } else {

                // //console.log(err,this,"hell");

                let defaultLanguage = sessionStorage.getItem("defaultLanguage");

                //if there is no language while redirecting access denied page language should be English defect fix

                if (!defaultLanguage) {

                    defaultLanguage = "ro_en";

                }

                this.translate.setDefaultLang(defaultLanguage);

                this.translate.use(defaultLanguage);

                this.router.navigate(['/access-denied']);

                return throwError('error')

                // return Observable.throw(null);

            }
        } else {
            let userData = JSON.parse(sessionStorage.getItem('userData'));
            return of(userData);
        }



    }

    initialRedirect() {

        return JSON.parse(sessionStorage.getItem('userData'))['landingPage'];

    }



    private handleError(error, self) {



        //if(!error || error.status == 404 || error.statusText== "Unknown Error"){



        // console.error('server error:', error);



        if (error.error instanceof Error) {

            const errMessage = error.error.message;

            return throwError(errMessage);

            // Use the following instead if using lite-server

            // return Observable.throw(err.text() || 'backend server error');

        }

        return throwError(error || 'Server error');

    }



}