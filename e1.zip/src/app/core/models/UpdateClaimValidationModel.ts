export class UpdateClaimValidation {
    // claimNumberSection: string = null;
    personalDataName: string = null;
    personalDataSurName: string = null;
    contactDataCountry: string = null;
    otherCountryName: string = null;
    fillInTheCountry: string = null;
    phoneNumber: any = null;
    emailAddress: any = null;
    uploadedDocsAcceptanceCheck: any = null;
    additionalComments: string = null;
    authorize: string = null;
    otherCountryCode: string = null;
    language: string = null;
    psei: string = null;
    countryCode: string = null;
    //termsAndCondition: boolean = null;
    personalDataCNP: string = null;
}