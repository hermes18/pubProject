export class FileUpload {
    data: File;
    state: string;
    path: string;
    name: string;
    contentType: string;
    fileName: string;

}
