import { Component, OnInit, Output, Input, EventEmitter, ViewEncapsulation } from '@angular/core';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { SessionExpiredComponent } from 'src/app/session-expired/session-expired.component';
import { Router } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None

})

export class HeaderComponent implements OnInit {
  @Input() lang: string;
  @Input() userName: string;
  @Input() sourceOfOrigin:string;
  country: string;
  timeLeft: any = null;
  secStarts: any = false;
  userData: any = null;
  constructor(private dailogService: DialogService, public router: Router) { }
  
  ngOnInit(): void {

    this.country = sessionStorage.getItem('tenantId');
    //console.log(this.country);
    this.lang = sessionStorage.getItem('defaultLanguage');
    //if there is no language while redirecting access denied page language should be English same condition in auth.services defect fix

    if (!this.lang) {
      this.lang = "ro_en";
    }
    this.userData = JSON.parse(sessionStorage.getItem('userData'));
    
  //this.sourceOfOrigin= this.userData.sourceOrigin;
  }
  @Output() langChange = new EventEmitter();
  @Output() public sidenavToggle = new EventEmitter();
  @Output() sidenavClose = new EventEmitter();

  public onToggleSidenav = () => {
    this.sidenavToggle.emit();
  }
  public onSidenavClose = () => {
    this.sidenavClose.emit();
  }

  langChanged(event) { // You can give any function name
    // //console.log("language---",this.lang);
    this.langChange.emit(this.lang);
  }

  contactUs() {
    let redirectTo = "https://www.metropolitanlife.ro/";
    let language = sessionStorage.getItem("defaultLanguage");

    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
        break;
      case 'ro_ro': redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/contact/";
        break;
      case 'ro_en': redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/contact/";
        break;
    }
    window.open(redirectTo, "_blank");

  }


  /*interval;
  startTime;
  startTimer() {
    this.startTime = true;
    this.interval = setInterval(() => {
    if(this.timeLeft > 1) {
    this.timeLeft--;
          }else {
    this.clearTimer();
    this.dailogService.openDialog(SessionExpiredComponent,{});
          }
        },(1000*60))
      }
    
    clearTimer() {
      this.startTime=false;
    clearInterval(this.interval);
    }
  */
 homePageRouting(){
   let userData = JSON.parse(sessionStorage.getItem('userData'));
 if(userData && userData.originPage){
  this.router.navigate([`/${userData.originPage}`]);
 }


 }

}
