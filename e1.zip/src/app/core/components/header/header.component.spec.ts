import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatIconModule,MatSelectModule,MatFormFieldModule,MatToolbarModule} from '@angular/material';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HeaderComponent } from './header.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { SessionExpiredComponent } from 'src/app/session-expired/session-expired.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,FormsModule,
        MatToolbarModule,MatIconModule,MatSelectModule,MatFormFieldModule,HttpClientModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ HeaderComponent ],
      providers:[{ provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
        { provide: MatDialog, useValue: {} },DialogService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    sessionStorage.setItem("defaultLanguage","pl_en");
    sessionStorage.setItem('tenantId','pl');
    let userData = {"sourceOrigin":"O","identifierToken":null,"userName":null,"authToken":null,"isAdminUser":null,"submittedBy":"Customer","defaultLanguage":"pl","displayLanguages":"pl","landingPage":"/newClaim","originPage":"/newClaim","minFilesize":"5242880","maxFilesize":"52428800","clientId":null,"tablet":false,"mobileDevice":false};
    
    sessionStorage.setItem('userData',JSON.stringify(userData));
 
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('ngOnInit should set country  and lang ', () => {
    spyOn(component, 'ngOnInit').and.callThrough();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.ngOnInit();
    expect(component.country ).toEqual('pl');
  });
  it('contactUs  should set country  and lang ', () => {
    spyOn(component, 'contactUs').and.callThrough();
    component.contactUs();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.contactUs();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.contactUs();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.contactUs();
    expect(component.contactUs ).toHaveBeenCalled();
  });
  it('langChanged  should call langChanged', () => {
    spyOn(component.langChange, 'emit').and.callThrough();
    component.langChanged('');
    expect(component.langChange.emit ).toHaveBeenCalled();
  });
  it('homePageRouting  should call langChanged', () => {
    spyOn(component.router, 'navigate').and.callThrough();
    component.homePageRouting();
    expect(component.router.navigate ).toHaveBeenCalled();
  });

});
