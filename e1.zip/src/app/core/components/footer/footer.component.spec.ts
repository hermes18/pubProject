import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { FooterComponent } from './footer.component';

describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ FooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
     sessionStorage.setItem("defaultLanguage","pl_pl");
     sessionStorage.setItem('tenantId','pl');
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit should set country ', () => {
    
     
    expect(component.country).toEqual('pl');
  });
  
  it('privacyPolicy should call privacyPolicy ', () => {
    
    spyOn(component, 'privacyPolicy').and.callThrough();
    component.privacyPolicy();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.privacyPolicy();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.privacyPolicy();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.privacyPolicy();
    expect(component.privacyPolicy).toHaveBeenCalled();
  });
  it('legalPolicy should call legalPolicy ', () => {
    
    spyOn(component, 'legalPolicy').and.callThrough();
    component.legalPolicy();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.legalPolicy();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.legalPolicy();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.legalPolicy();
    expect(component.legalPolicy).toHaveBeenCalled();
  });

  it('cookiePolicy should call cookiePolicy ', () => {
    
    spyOn(component, 'cookiePolicy').and.callThrough();
    component.cookiePolicy();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.cookiePolicy();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.cookiePolicy();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.cookiePolicy();
    expect(component.cookiePolicy).toHaveBeenCalled();
  });
  it('onKeyPress should call onKeyPress ', () => {
    
    spyOn(component, 'onKeyPress').and.callThrough();
    spyOn(component, 'cookiePolicy').and.callThrough();
    component.onKeyPress({keyCode:13},'cookiePolicy');
    expect(component.cookiePolicy).toHaveBeenCalled();
  });



});
