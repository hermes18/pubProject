import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { eClaimsConstants } from '../../constants/constant';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  @Input() footerDefaultLanguage;
  showToaster = true;
  country: string;
  FBIconEnableCountry = eClaimsConstants.FBIconEnableCountry;
  constructor(public router: Router) { }

  ngOnInit(): void {
    this.country = sessionStorage.getItem('tenantId');
  }

  privacyPolicy() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");


    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/content/dam/metlifecom/pl/pdf/ochrona-prywatnosci.pdf";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/content/dam/metlifecom/pl/pdf/ochrona-prywatnosci.pdf";
        break;
      case 'ro_ro': redirectTo = "assets/Politica%20de%20prelucrare%20date.pdf";
        break;
      case 'ro_en': redirectTo = "assets/Privacy%20Policy.pdf";
        break;
    }
    window.open(redirectTo, "_blank");




  }
  legalPolicy() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");


    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/prawne_regulaminy/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/prawne_regulaminy/";
        break;
      case 'ro_ro': redirectTo = "assets/Legal_Notice.pdf";
        break;
      case 'ro_en': redirectTo = "assets/Legal_Notice.pdf";
        break;
    }
    window.open(redirectTo, "_blank");




  }


  cookiePolicy() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");

    //  pl cookies https://www.metlife.pl/polityka_prywatnosci/
    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/cookies/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/cookies/";
        break;
      case 'ro_ro': redirectTo = "assets/Cookie_Policy.pdf";
        break;
      case 'ro_en': redirectTo = "assets/Cookie_Policy.pdf";
        break;
    }
    window.open(redirectTo, "_blank");
  }

  onKeyPress(event, calFunc) {
    // //console.log(event, "event");
    if (event.keyCode == 13) {
      this[calFunc]();
    }
  }

}
