import { Component, OnInit, Output, EventEmitter, Input, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-sidenav-list',
  templateUrl: './sidenav-list.component.html',
  styleUrls: ['./sidenav-list.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class SidenavListComponent implements OnInit {
  @Output() sidenavClose = new EventEmitter();
  @Input() lang:string;
  country:string;
  constructor() { }

  ngOnInit() {
    this.country=sessionStorage.getItem('tenantId');
   
    if(this.lang=='undefined' || this.lang==null){
      this.lang = sessionStorage.getItem('defaultLanguage');
    } 
  }
  showLanguages:any=false;


  @Output() langChange = new EventEmitter();

  public onSidenavClose = () => {
    this.sidenavClose.emit();
  }

  langChanged(event) { // You can give any function name
    // //console.log("language---",this.lang);
    this.langChange.emit(this.lang);
}
languageChanged(language){
  this.lang= language;
  this.langChanged(this.lang); 
  this.showLanguages = false;
}
selectBoxClick(){
  if(this.showLanguages){
    this.showLanguages=false;
  }else{
    this.showLanguages=true;
  }
}
contactUs(){
  let redirectTo = "https://www.metropolitanlife.ro/";
  let language = sessionStorage.getItem("defaultLanguage");
  
  switch(language){
        case 'pl_pl' : redirectTo = "https://www.metlife.pl/";
        break;
        case 'pl_en' : redirectTo = "https://www.metlife.pl/";
        break;
        case 'ro_ro' : redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/contact/";
        break;
        case 'ro_en' : redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/contact/";
        break;
      }
  window.open(redirectTo,"_blank");
      
  }

}
