import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {httpTranslateLoader} from 'src/app/app.module';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SidenavListComponent } from './sidenav-list.component';
import {SharedModule} from 'src/app/shared/shared.module';

describe('SidenavListComponent', () => {
  let component: SidenavListComponent;
  let fixture: ComponentFixture<SidenavListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule,SharedModule,HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        }) 
      ],
      declarations: [ SidenavListComponent ],
      providers:[ HttpClient ]
    }) 
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SidenavListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('call onSidenavClose should emit value', () => {
  
    spyOn(component.sidenavClose, 'emit').and.callThrough();
    component.onSidenavClose();
    
    expect(component.sidenavClose.emit).toHaveBeenCalled();
  
  });
  it('call langChanged should emit value', () => {
    component.lang = sessionStorage.getItem('defaultLanguage');
    spyOn(component.langChange, 'emit').and.callThrough();
    component.langChanged('');
    
    expect(component.langChange.emit).toHaveBeenCalled();
  
   });

  it('call languageChanged should call langChange', () => {
    component.lang = sessionStorage.getItem('defaultLanguage');
    spyOn(component, 'langChanged').and.callThrough();
    component.languageChanged(sessionStorage.getItem('defaultLanguage'));
    
    expect(component.langChanged).toHaveBeenCalled();
  
  });
  it('call selectBoxClick should toggle showLanguages', () => {
    component.showLanguages = false;
    let testDate = true;
  //  spyOn(component, 'langChanged').and.callThrough();
    component.selectBoxClick();
  //  expect(component.langChanged).toHaveBeenCalled();
  expect(component.showLanguages).toEqual(testDate);
  component.selectBoxClick();
  expect(component.showLanguages).toEqual(false);
  
  });
  

  it('call contactUs should call window.open', () => {
    sessionStorage.setItem("defaultLanguage",'pl_en');
    spyOn(window, 'open').and.callThrough();
    component.contactUs();
    
    expect(window.open).toHaveBeenCalledWith('https://www.metlife.pl/','_blank');
        sessionStorage.setItem("defaultLanguage",'pl_pl');
    component.contactUs();
    expect(window.open).toHaveBeenCalledWith('https://www.metlife.pl/','_blank');

    sessionStorage.setItem("defaultLanguage",'ro_en');
    component.contactUs();
    expect(window.open).toHaveBeenCalledWith('https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/contact/','_blank');

    sessionStorage.setItem("defaultLanguage",'ro_ro');
    component.contactUs();
    expect(window.open).toHaveBeenCalledWith('https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/contact/','_blank');
  });
 

});
