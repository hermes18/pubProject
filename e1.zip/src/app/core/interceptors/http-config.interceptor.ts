import { Injectable, Renderer2 } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError, finalize } from 'rxjs/operators';
// import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { ErrorDialogComponent } from 'src/app/shared/dialog/error-dialog/error-dialog.component';

@Injectable({ providedIn: 'root' })
export class HttpConfigInterceptor implements HttpInterceptor {
  constructor(public router: Router, public dialogService: DialogService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Get the auth header (fake value is shown here)
    //<ngx-spinner bdColor="grey"></ngx-spinner>
    let randomVal = (Math.floor((Math.random() * 100000000) + 1)) + '';
    //console.log(req);
    if (!req.params.has('loader')) {
      if (document.getElementById('app_component_starts')) {

        let overLay = document.createElement('div');
        overLay.setAttribute("class", 'overLay');
        overLay.setAttribute("id", randomVal);

        let spin = document.createElement('div');

        //spin.setAttribute("bdColor", "grey");

        spin.setAttribute("class", 'loader');
        overLay.appendChild(spin);
        document.getElementById('app_component_starts').appendChild(overLay);

        //      this.spinner.show(randomVal);
        //this.spinner.show();
      }
    }
    const authHeaderToken = '';
    //loader spin start
    let sessionToken = '';
    let bearerToken = '';
    if (req.url.indexOf('/token') === -1 || req.url.indexOf('/token/refresh') > -1) {
      sessionToken = sessionStorage.getItem('userToken') ? sessionStorage.getItem('userToken') : null;
      if (!sessionToken) {
        //setTimeout(()=>{
        let sessionTokenCheck = sessionStorage.getItem('userToken');
        //console.log("sessionTokenCheck", sessionTokenCheck);
        if ((!sessionTokenCheck || sessionTokenCheck == '') && req.method === 'POST') {
          if (req.url.indexOf('/token') === -1 || req.url.indexOf('/token/refresh') > -1) {
            this.router.navigate(['/in-active']);
          }

          if (document.getElementById(randomVal)) {
            //document.getElementById(randomVal).remove();
            document.getElementById(randomVal).parentElement.removeChild(document.getElementById(randomVal));
          }


        }

        //},2000);
      } else {
        bearerToken = 'Bearer ' + sessionToken;
      }


    }

    let sessionLanguage = sessionStorage.getItem('defaultLanguage') ? sessionStorage.getItem('defaultLanguage') : '';
    let sessionTenantId = sessionStorage.getItem('tenantId') ? sessionStorage.getItem('tenantId') : '';
    let headerParams;
    if (req.headers.has('loader')) {
      headerParams = req.headers.delete('loader');
    } else {
      headerParams = req.headers;
    }

    //console.log("req",req);
    const headerParamsDirect = {
      headers: headerParams.set('accept-language', sessionLanguage)
        .set('x-tenant-id', sessionTenantId)
        .set('x-system-id', 'eclaims')
        .set('authorization', bearerToken)
    }
    const httpReq = req.clone(headerParamsDirect);
    //console.log("httpReq",httpReq);
    return next.handle(httpReq).pipe(
      map((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {

        }
        return event;
      }),
      catchError((error: HttpErrorResponse) => {
        let data = {};
        data = {
          reason: error && error.error && error.error.reason ? error.error.reason : '',
          status: error.status
        };
        console.log(error, "eror");
        //this.dialogService.openDialog(ErrorDialogComponent, { 'heading': 'Error'}); 
        return throwError(error);
      }),
      finalize(() => {
        // this.spinner.hide(randomVal);

        if (document.getElementById('app_overLay')) {
          //document.getElementById(randomVal).remove();
          document.getElementById('app_overLay').parentElement.removeChild(document.getElementById('app_overLay'));
        }

        if (document.getElementById(randomVal)) {
          //document.getElementById(randomVal).remove();
          document.getElementById(randomVal).parentElement.removeChild(document.getElementById(randomVal));
        }
        // this.spinner.hide();
        //       console.log("randomVal",randomVal);
      }));

  }
}
