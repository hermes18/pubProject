import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { ContactDetailsComponent } from './contact-details.component';
import { MatFormFieldModule } from '@angular/material';


const routes: Routes = [
  {
    path: '', component: ContactDetailsComponent,
    canDeactivate: [NavigationGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes),MatFormFieldModule],
  exports: [RouterModule,MatFormFieldModule]
})
export class ContactDetailsRoutingModule { }
