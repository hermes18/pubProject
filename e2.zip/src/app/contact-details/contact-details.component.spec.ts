import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ContactDetailsModule } from './contact-details.module';
import { TranslateModule } from '@ngx-translate/core';

import { ContactDetailsComponent } from './contact-details.component';
import { ContactDetailsService } from './service/contact-details.service';
import { MatFormFieldControl, MatFormFieldModule, MatInputModule } from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';

describe('ContactDetailsComponent', () => {
  let component: ContactDetailsComponent;
  let fixture: ComponentFixture<ContactDetailsComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'getQuestionSet': host + '/api/v1/users/security-questions',
        'contractRetrieve': host + '/api/v1/users/contacts/',
        'validationConfig': host + '/api/v1/users/validate-phonenumber',
        'emailvalidation': host + '/api/v1/users/validate-email',
      }
    }
  };
  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({

  // }));

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, SharedModule, AppModule, MatFormFieldModule, ReactiveFormsModule, MatInputModule, TranslateModule.forRoot(), ContactDetailsModule, HttpClientTestingModule],

      declarations: [],

      providers: [TranslateService, ContactDetailsService, { provide: APP_BASE_HREF, useValue: '/' },
      ]

    })
      .compileComponents();
    fixture = TestBed.createComponent(ContactDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
