

export class SecurityQuestionModel {

    questionTypeCode: string = null;
    answer: string = null;
    questionTypeCode2: string = null;
    answer2: string = null;

}