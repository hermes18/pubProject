import { SecurityQuestionModel } from './SecurityQuestionModel';
import { FormGroup } from '@angular/forms';

export class CommonWorkFlowDataModel {

	firstName: string = null;
	userId: string = null;
	userName: string = null;
	lastName: string = null;
	currentEmail: string = null;
	updatedEmail: string = null;
	currentMobilePhone: string = null;
	updatedMobilePhone: string = null;
	validEmailCheckBox: boolean = false;
	validMobileCheckBox: boolean = false;
	consentContactCheckBox: boolean = false;
	consentElectronicServCheckBox: boolean = false;
	portalTermsCheckBox: boolean = false;
	renderportalTermsCheck: boolean = false;
	renderElectronicServicesCheck: boolean = false;
	renderContactConsentCheck: boolean = false;
	renderActivationInfo: boolean = false;
	clientId: string = null;
	pseConsentChecked: boolean = false;
	versionMarker: string = null;
	pseConsentStatus: string = null;
	renderSecurityQuestion: boolean = false;
	renderGatherConsentsPage: boolean = false;
	loginCounter: string = null;
	country: string = null;
	language: string = null;
	accountType: string = null;
	contactDataConsentsNavRoute: string = null;
	userRole: string = null;
	renderAcceptCookies: boolean = false;
	acceptCookiesCheckBox: boolean = false;
	renderAcceptTermsandConditions: boolean = false;
	acceptTermsandConditionsCheckBox: boolean = false;
	renderAcceptMarketingCheck: boolean = false;
	acceptMarketingCheckBox: boolean = false;
	consentsDispcounter: string = null;
	securityQuestionDTO: SecurityQuestionModel;
	renderContactAndConsentsScreen: boolean = false;
	hasInProgressOrders: boolean = false;
	contactDetail: FormGroup;
	settingroute: string = null;
	constructor() {
		this.renderContactAndConsentsScreen = true;
	}
}

