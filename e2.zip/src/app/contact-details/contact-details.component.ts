import { Component, OnInit, ViewChild } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpCommonService } from '../shared/services/http-common.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpHeaders } from '@angular/common/http';
import { CommonWorkFlowDataModel } from './model/CommonWorkFlowDataModel';
import { SecurityQuestionModel } from './model/SecurityQuestionModel';
import { AppConfig } from 'src/config/app.config';
import { Router } from '@angular/router';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { LoginComponent } from '../login/login.component';
import { AuthenticationService } from '../login/service/authentication.service';
import { BroadcasterService } from '../core/services/broadcaster.service';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UtilityService } from '../shared/utilities/utility.service';
export class CustomValidators {
  readonly betweenZeroHundred = [Validators.min(0), Validators.max(100)];
}
@Component({
  selector: 'contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.scss']
})
export class ContactDetailsComponent implements OnInit {
  questionSet: any;
  contactDetail: FormGroup;
  responseData: any;
  country: string = sessionStorage.getItem('countryCode');
  lang: string = sessionStorage.getItem('defaultLanguage');
  //userData: string = sessionStorage.get('userData');
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  displayPoOption: boolean = false;
  displayRoOption: boolean = false;
  loggedInCountryCheck: boolean;
  constructor(public commonService: HttpCommonService, private readonly router: Router, private readonly menuItemService: MenuItemsService,
    private readonly sharedService: SharedServiceService, public deviceDetector: DeviceDetectorService, private readonly broadCastService: BroadcasterService) { }
  contactUpdate = new CommonWorkFlowDataModel();
  screenName: string = null;
  routeFlag: boolean = false;
  clientId: string = '';
  questionSet2: any;
  questionSet1: any;
  @ViewChild(LoginComponent, { static: false }) loginComp: LoginComponent;

  isMobile = this.deviceDetector.isMobile();

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    this.loggedInCountryCheck = UtilityService.getCountry();
    if (this.loggedInCountryCheck)
      //if (this.country == 'pl')
      this.displayPoOption = true;
    else
      this.displayRoOption = true;
    this.submitFlag = false;
    this.invalidConsent = false;
    this.securityQuCheck = false;
    this.securityQuCheck2 = false;
    this.isEmailNotValid = false;
    this.isMobileNotValid = false;
    this.isActiveOrders = false;
    this.invalidContactConsent = false;
    this.invalidAcceptMarketingCheck = false;
    this.invalidAcceptTermsConditions = false;
    this.invalidAcceptCookiesCheckBox = false;
    this.contactDetail = new FormGroup({
      currentEmail: new FormControl('', [Validators.required]),
      currentmobileNO: new FormControl('', [Validators.required]),
      newEmail: new FormControl('', [Validators.required]),
      newmobileNO: new FormControl('', [Validators.required, Validators.pattern("^[0-9]*$")],),
      emailValid: new FormControl('', [Validators.required]),
      mobileValid: new FormControl('', [Validators.required]),
      acceptCookiesCheckBox: new FormControl('', [Validators.required]),
      contactConsent: new FormControl('', [Validators.required]),
      acceptTermsConditions: new FormControl('', [Validators.required]),
      acceptMarketingCheck: new FormControl('', [Validators.required]),
      question: new FormControl('', [Validators.required]),
      answer: new FormControl('', [Validators.required, Validators.minLength(3)]),
      question2: new FormControl('', [Validators.required]),
      answer2: new FormControl('', [Validators.required, Validators.minLength(3)])
    });
    let url = this.baseUrl.ecustomer.getQuestionSet;
    let head = new HttpHeaders();
    this.commonService['getDataValue'](url, head).subscribe(data => {
      this.questionSet = data;
      this.questionSet1 = data;
      this.questionSet2 = data
    })

    //(this.sharedService.getcontactConsentDetails());
    //  this.screenName = this.sharedService.getscreenName();
    this.screenName = sessionStorage.getItem('screenName');
    //this.commonService.getData(baseUrl).subscribe((response) => {
    //      this.consentLegalObj = response;

    //this.responseData = this.sharedService.getcontactConsentDetails();
    this.responseData = JSON.parse(sessionStorage.getItem('setcontactConsentDetails'));

    //Legal Consent call from add user account
    this.broadCastService.on<any>('addNewUser').subscribe((data) => {
      this.routeFlag = data.addNewUser;
      this.clientId = data.clientId;
    });
    if (this.routeFlag) {
      let url = this.baseUrl.ecustomer.addUserLegalContact + this.clientId;
      let head = new HttpHeaders();
      let reqParam = {
        clientId: this.clientId
      };
      this.commonService['postData'](this.baseUrl.ecustomer.contractRetrieve, reqParam, '').subscribe(data => {
        this.responseData = data
        // this.sharedService.setcontactConsentDetails(data);
        this.addNewUserData(this.responseData);
        //("this.responseData", data)
      })
    }
    // this.responseData = this.sharedService.getcontactConsentDetails();
    this.responseData = JSON.parse(sessionStorage.getItem('setcontactConsentDetails'));
    this.addNewUserData(this.responseData);

  }

  get f() { return this.contactDetail.controls; }
  isActiveOrders: boolean = false;
  activeOrders: boolean = false;
  invalidConsent: boolean = false;
  securityQuCheck: boolean = false;
  securityQuCheck2: boolean = false;
  invalidContactConsent: boolean = false;
  invalidAcceptMarketingCheck: boolean = false;
  invalidAcceptTermsConditions: boolean = false;
  invalidAcceptCookiesCheckBox: boolean = false;
  submitFlag: boolean = false;
  blankEmail: boolean = false;
  blankMobile: boolean = false;
  addNewUserData(data) {
    this.responseData = data

    if (this.responseData) {
      if (this.responseData.currentEmail) {
        this.contactDetail.get('currentEmail').setValue(this.responseData.currentEmail);
        this.contactDetail.get('currentEmail').disable();
      }
      if (this.responseData.currentMobilePhone) {
        this.contactDetail.get('currentmobileNO').setValue(this.responseData.currentMobilePhone);
        this.contactDetail.get('currentmobileNO').disable();
      }
      if (this.responseData.hasInProgressOrders) {
        this.isActiveOrders = true;
      } else {
        this.isActiveOrders = false;
      }
    }
  }
  blankInputs: boolean = false;
  sameAnswerFlag: boolean = false;
  submitContact() {
    this.submitFlag = true;
    this.blankEmail = false;
    this.blankMobile = false;
    if (this.responseData) {
      if (this.responseData.renderContactConsentCheck) {
        if (!this.contactDetail.value.contactConsent) {
          this.invalidConsent = true;
          this.invalidContactConsent = true;
        } else {
          this.invalidConsent = false;
          this.invalidContactConsent = false;
        }
      }
      if (this.responseData.renderElectronicServicesCheck) {
        if (!this.contactDetail.value.acceptMarketingCheck) {
          this.invalidConsent = true;
          this.invalidAcceptMarketingCheck = true
        } else {
          this.invalidConsent = false;
          this.invalidAcceptMarketingCheck = false
        }
      }
      if (this.responseData.renderportalTermsCheck || this.responseData.renderAcceptTermsandConditions) {
        if (!this.contactDetail.value.acceptTermsConditions) {
          this.invalidConsent = true;
          this.invalidAcceptTermsConditions = true
        } else {
          this.invalidConsent = false;
          this.invalidAcceptTermsConditions = false
        }
      }
      if (this.responseData.renderAcceptCookies) {
        if (!this.contactDetail.value.acceptCookiesCheckBox) {
          this.invalidConsent = true;
          this.invalidAcceptCookiesCheckBox = true
        } else {
          this.invalidConsent = false;
          this.invalidAcceptCookiesCheckBox = false
        }
      }

      if ((this.responseData.renderSecurityQuestion) && (this.contactDetail.value.question === "" ||
        this.contactDetail.value.question === "" || this.contactDetail.value.answer === "")) {
        this.securityQuCheck = true;
      } else {
        this.securityQuCheck = false;
      }
      if ((this.responseData.renderSecurityQuestion) && (this.contactDetail.value.question2 === "" ||
        this.contactDetail.value.question2 === "" || this.contactDetail.value.answer2 === "")) {
        this.securityQuCheck2 = true;
      } else {
        this.securityQuCheck2 = false;
      }
      if (this.contactDetail.value.newEmail === "" || this.contactDetail.value.newEmail === null) {
        this.isEmailNotValid = true;
      }
      if (this.contactDetail.value.newmobileNO === "" || this.contactDetail.value.newmobileNO === null) {
        this.isMobileNotValid = true;
      }

      if (this.isEmailNotValid || this.isMobileNotValid) {
        if ((this.contactDetail.value.newEmail === "" || this.contactDetail.value.newEmail === null) ||
          (this.contactDetail.value.newmobileNO === "" || this.contactDetail.value.newmobileNO === null)) {

          this.blankInputs = true;
          if ((this.contactDetail.value.newEmail === "" ||
            this.contactDetail.value.newEmail === null)) {
            this.blankEmail = true;
            this.isEmailNotValid = false;
          } else {
            this.blankEmail = false;
          }
          if (this.contactDetail.value.newmobileNO === "" ||
            this.contactDetail.value.newmobileNO === null) {
            this.isMobileNotValid = false;
            this.blankMobile = true;
          } else {
            this.blankMobile = false;
          }

        } else {
          this.blankInputs = false;
        }
      } else {
        this.blankInputs = false;
      }

      if ((!this.invalidConsent) && (!this.securityQuCheck) && (!this.securityQuCheck2) &&
        (!this.isEmailNotValid) && (!this.isMobileNotValid) && (!this.blankInputs) &&
        (!this.invalidContactConsent) && (!this.invalidAcceptMarketingCheck) && (!this.invalidAcceptTermsConditions)
        && (!this.invalidAcceptCookiesCheckBox)) {
        if (this.routeFlag) {
          this.routeSetting()
        } else {
          this.submitFlag = false;
          this.submit();
        }
      }
    }
  }
  minlengthError: boolean = false;
  submit() {
    let newEmail = this.contactDetail.get('newEmail').value;//this.contactDetail.value.newEmail; 
    let newMob = this.contactDetail.get('newmobileNO').value;//this.contactDetail.value.newmobileNO; 

    if (newEmail && newMob) {
      // let email = this.validateEmail(newEmail);
      // let mobile = this.validateMobile(newMob);
      // if ((!email) && (!mobile)) {
      if (this.responseData.renderSecurityQuestion) {
        if ((this.contactDetail.value.answer).toUpperCase() === (this.contactDetail.value.answer2).toUpperCase()) {
          this.sameAnswerFlag = true;

        } else {
          this.sameAnswerFlag = false;
        }
        if ((this.contactDetail.value.answer).length < 3 || (this.contactDetail.value.answer2).length < 3) {
          this.minlengthError = true;
        } else {
          this.minlengthError = false;
        }
      } else {
        this.minlengthError = false;
        this.sameAnswerFlag = false;
      }

      if (!this.sameAnswerFlag && !this.minlengthError) {

        let contactUpdateobj = new CommonWorkFlowDataModel();
        contactUpdateobj = this.dataPopulte();

        let head = new HttpHeaders();
        const baseUrl = this.baseUrl.ecustomer.updateContactServiceConfig;
        // const meth = environment.updateContactServiceConfig.method;
        this.commonService['putData'](baseUrl, contactUpdateobj).subscribe((response) => {

          //("---->contact update response", response);
          if (!response) {
            this.isActiveOrders = true
          } else {

          }
          if (this.screenName === "changepassword") {
            this.router.navigate(['/changepassword']);
          } else {
            this.getAnnouncemnetDetails().subscribe((data) => {
              if (data && data.length > 0) {
                this.sharedService.setDetail('announceMentDetail', data);
                this.router.navigate(['./announcement']);
              } else {
                this.getMenuDetails();
              }
            },
              (error: Error) => {
                this.getMenuDetails();
              });
          }
        })
      }
      // }
    }
  }

  getMenuDetails() {
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let clientID = loggedUser.clientId ? loggedUser.clientId : null;
    sessionStorage.setItem('loginOperationType', 'login');
    this.menuItemService.menuItemApi(clientID, 'login').subscribe((data) => {
      this.sharedService.setDetail('menuItemList', data);
      sessionStorage.setItem('menuItemList', JSON.stringify(data));
      this.menuItemService.navigationBasedOnRole(data);
    },
      (error: Error) => {
        // this.router.navigate(['./homepage']);
      });
  }
  dataPopulte() {
    //sessionStorage.getItem('defaultLanguage'),  
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const contactUpdateobj = new CommonWorkFlowDataModel();
    const securityObj = new SecurityQuestionModel();
    contactUpdateobj.renderGatherConsentsPage = false;
    contactUpdateobj.clientId = this.responseData.clientId;
    contactUpdateobj.loginCounter = this.responseData.loginCounter;
    contactUpdateobj.accountType = "new";
    contactUpdateobj.userId = loggedUser['userName']
    contactUpdateobj.userRole = "";
    contactUpdateobj.firstName = loggedUser['firstName']
    contactUpdateobj.lastName = loggedUser['lastName']
    contactUpdateobj.userName = loggedUser['userName']
    contactUpdateobj.currentEmail = (this.contactDetail.get('currentEmail').value).trim();
    contactUpdateobj.currentMobilePhone = (this.contactDetail.get('currentmobileNO').value).trim();
    contactUpdateobj.updatedEmail = this.contactDetail.get('newEmail').value; //this.contactDetail.value.newEmail;
    contactUpdateobj.updatedMobilePhone = this.contactDetail.get('newmobileNO').value; //this.contactDetail.value.newmobileNO;
    securityObj.answer = this.contactDetail.value.answer;
    securityObj.questionTypeCode = this.contactDetail.value.question;
    securityObj.answer2 = this.contactDetail.value.answer2;
    securityObj.questionTypeCode2 = this.contactDetail.value.question2;
    contactUpdateobj.securityQuestionDTO = securityObj;

    if (this.contactDetail.get('emailValid').value)
      contactUpdateobj.validEmailCheckBox = true;
    else
      contactUpdateobj.validEmailCheckBox = false;

    if (this.contactDetail.get('mobileValid').value)
      contactUpdateobj.validMobileCheckBox = true;
    else
      contactUpdateobj.validMobileCheckBox = false;

    if (this.contactDetail.value.contactConsent)
      contactUpdateobj.consentContactCheckBox = true;
    else
      contactUpdateobj.consentContactCheckBox = false;

    if (this.contactDetail.value.acceptMarketingCheck)
      contactUpdateobj.consentElectronicServCheckBox = true;
    else
      contactUpdateobj.consentElectronicServCheckBox = false;

    if (this.contactDetail.value.acceptTermsConditions)
      contactUpdateobj.portalTermsCheckBox = true;
    else
      contactUpdateobj.portalTermsCheckBox = false;

    contactUpdateobj.renderportalTermsCheck = this.responseData.renderportalTermsCheck;
    contactUpdateobj.renderElectronicServicesCheck = this.responseData.renderElectronicServicesCheck;
    contactUpdateobj.renderContactConsentCheck = this.responseData.renderContactConsentCheck;

    contactUpdateobj.renderActivationInfo = this.responseData.renderActivationInfo;
    contactUpdateobj.pseConsentChecked = this.responseData.pseConsentChecked;
    contactUpdateobj.versionMarker = this.responseData.versionMarker;
    contactUpdateobj.pseConsentStatus = this.responseData.pseConsentStatus;

    contactUpdateobj.renderSecurityQuestion = this.responseData.renderSecurityQuestion;
    contactUpdateobj.loginCounter = this.responseData.loginCounter;
    contactUpdateobj.country = this.country;
    contactUpdateobj.language = this.lang;

    contactUpdateobj.contactDataConsentsNavRoute = this.responseData.contactDataConsentsNavRoute;
    contactUpdateobj.renderAcceptCookies = this.responseData.renderAcceptCookies;
    if (this.contactDetail.value.acceptCookiesCheckBox)
      contactUpdateobj.acceptCookiesCheckBox = true;
    else
      contactUpdateobj.acceptCookiesCheckBox = false;

    contactUpdateobj.renderAcceptTermsandConditions = this.responseData.renderAcceptTermsandConditions;
    if (this.contactDetail.value.acceptTermsConditions)
      contactUpdateobj.acceptTermsandConditionsCheckBox = true;
    else
      contactUpdateobj.acceptTermsandConditionsCheckBox = false;
    contactUpdateobj.renderAcceptMarketingCheck = this.responseData.renderAcceptMarketingCheck;
    if (this.contactDetail.value.acceptMarketingCheck)
      contactUpdateobj.acceptMarketingCheckBox = true;
    else
      contactUpdateobj.acceptMarketingCheckBox = false;

    contactUpdateobj.consentsDispcounter = this.responseData.consentsDispcounter;

    return contactUpdateobj;
  }
  getAnnouncemnetDetails() {
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let url = `${this.baseUrl.ecustomer.retrieveAnnounceMent}/${loggedUser['userName']}`;
    return this.commonService['getData'](url);
  }
  onclickEmail() {
    //let emailText = document.getElementById('newEmaitextid') as HTMLInputElement;
    // let emailchkbx = document.getElementById('emailChkBx') as HTMLInputElement;
    let email = this.contactDetail.get('currentEmail').value;

    if (this.contactDetail.get('emailValid').value) {
      this.contactDetail.get('newEmail').setValue(email.trim());
      this.contactDetail.get('newEmail').disable();
      this.blankEmail = false;
      this.validateEmail(email);
    } else {
      this.blankEmail = true;
      this.contactDetail.get('newEmail').setValue(null);
      this.contactDetail.get('newEmail').enable();
    }

  }
  onclickMobile() {

    let newMobile = this.contactDetail.get('currentmobileNO').value;
    let mobile = this.contactDetail.get('newmobileNO').value;

    if (this.contactDetail.get('mobileValid').value) {
      this.blankMobile = false;
      this.contactDetail.get('newmobileNO').setValue(newMobile.trim());
      this.contactDetail.get('newmobileNO').disable();
      let loggedInCountryCheck = UtilityService.getCountry();
      if (loggedInCountryCheck) {
        // if (this.country === 'pl') {
        this.validateMobile(newMobile)
      }
      else if (this.country === 'ro') {
        //if (newMobile.length === 10) { 
        this.isMobileNotValid = false;
      }
      // else {
      //   this.isMobileNotValid = true; 
      //   if (this.contactDetail && this.contactDetail.controls.mobileValid.value) {
      //     this.contactDetail.get('mobileValid').setValue(false);
      //   }
      //   this.contactDetail.get('newmobileNO').enable();
      // }
      // } 
    } else {
      this.blankMobile = true;
      this.contactDetail.get('newmobileNO').setValue(null);
      this.contactDetail.get('newmobileNO').enable();
    }
  }
  validateMobileRo(evenet) {
    let newMobile = this.contactDetail.get('newmobileNO').value;

    if (newMobile) {
      this.isMobileNotValid = false;
      this.blankMobile = false;
    }
    else {
      this.isMobileNotValid = true;
      this.blankMobile = true;
    }
  }
  securityAns() {

    if (this.contactDetail.value.answer &&
      (this.contactDetail.value.question != "-1" && this.contactDetail.value.question !== "")) {
      this.securityQuCheck = false;
    } else {
      this.securityQuCheck = true;
    }


  }
  securityAns2() {
    if (this.contactDetail.value.answer2 &&
      (this.contactDetail.value.question2 != "-1" && this.contactDetail.value.question2 !== "")) {
      this.securityQuCheck2 = false;
    } else {
      this.securityQuCheck2 = true;
    }
  }
  securityQuestion2() {
    // this.contactDetail.get('answer2').setValue(null);
    // if (this.contactDetail.value.question2 !== "-1" && this.contactDetail.value.question2 !== "") {
    //   this.securityQuCheck2 = false;
    // }
  }
  securityQuestion() {
    // this.contactDetail.get('answer').setValue(null);
    // if (this.contactDetail.value.question !== "-1" && this.contactDetail.value.question !== "") {
    //   this.securityQuCheck = false;
    // }
  }
  consentsCheck() {

    // let cookies = this.contactDetail.value.acceptCookies;
    // let termsConditions = this.contactDetail.value.acceptTermsConditions;
    // let marketing = this.contactDetail.value.acceptMarketingCheck;
    if (this.responseData.renderContactConsentCheck) {
      if (this.submitFlag && !this.contactDetail.value.contactConsent) {
        // this.invalidConsent = true;
        this.invalidContactConsent = true;
      } else {
        // this.invalidConsent = false;
        this.invalidContactConsent = false;
      }
    }

    // if (cookies && termsConditions && marketing) {
    //   this.invalidConsent = false;
    // }
  }
  acceptCookiesCheckBox() {
    if (this.responseData.renderAcceptCookies) {
      if (this.submitFlag && !this.contactDetail.value.acceptCookiesCheckBox) {
        // this.invalidConsent = true;
        this.invalidAcceptCookiesCheckBox = true;
      } else {
        // this.invalidConsent = false;
        this.invalidAcceptCookiesCheckBox = false;
      }
    }
  }
  acceptMarketingCheck() {
    if (this.responseData.renderElectronicServicesCheck) {
      if (this.submitFlag && !this.contactDetail.value.acceptMarketingCheck) {
        // this.invalidConsent = true;
        this.invalidAcceptMarketingCheck = true;
      } else {
        // this.invalidConsent = false;
        this.invalidAcceptMarketingCheck = false;
      }
    } else if (this.responseData.renderAcceptMarketingCheck) {
      if (this.submitFlag && !this.contactDetail.value.acceptMarketingCheck) {
        // this.invalidConsent = true;
        this.invalidAcceptMarketingCheck = false;
      } else {
        // this.invalidConsent = false;
        this.invalidAcceptMarketingCheck = false;
      }
    }
  }
  acceptTermsConditions() {
    if (this.responseData.renderportalTermsCheck) {
      if (this.submitFlag && !this.contactDetail.value.acceptTermsConditions) {
        // this.invalidConsent = true;
        this.invalidAcceptTermsConditions = true;
      } else {
        // this.invalidConsent = false;
        this.invalidAcceptTermsConditions = false;
      }
    } else if (this.responseData.renderAcceptTermsandConditions) {
      if (this.submitFlag && !this.contactDetail.value.acceptTermsConditions) {
        // this.invalidConsent = true;
        this.invalidAcceptTermsConditions = true;
      } else {
        // this.invalidConsent = false;
        this.invalidAcceptTermsConditions = false;
      }
    }
  }

  isEmailNotValid: boolean;
  isMobileNotValid: boolean;
  validateEmail(email) {

    // let emailText = document.getElementById('newEmaitextid') as HTMLInputElement;
    // let emailchkbx = document.getElementById('emailChkBx') as HTMLInputElement;
    this.blankInputs = false;
    let emailValue = this.contactDetail.get('newEmail').value ? this.contactDetail.get('newEmail').value : ''

    if (this.country !== 'gr') {
      if (emailValue) {
        let headers = new HttpHeaders({});
        this.blankEmail = false;
        //const baseUrl = this.baseUrl.ecustomer.validationConfig + emailValue + "/validate";
        const param = {
          email: emailValue
        };
        this.commonService.postData(this.baseUrl.ecustomer.emailvalidation, param, '').subscribe((response) => {
          this.contactDetail.get('newEmail').setValue(emailValue.trim());
          if (response) {

            this.isEmailNotValid = false;
            // let old = this.contactDetail.get('currentEmail').value;
            // this.contactDetail.get('newEmail').setValue(old);

          }
          else {
            this.isEmailNotValid = true;
            //this.contactDetail.get('emailValid'). 
            if (this.contactDetail && this.contactDetail.controls.emailValid.value) {
              this.contactDetail.get('emailValid').setValue(false);
            }
            this.contactDetail.get('newEmail').enable();
          }

        })
      } else {
        this.isEmailNotValid = true;
        this.blankEmail = true;
      }
    }
  }


  validateMobile(mobile) {
    this.blankInputs = false;
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    // let mobiletxt = document.getElementById('newMobile') as HTMLInputElement;
    // let mobilechkbx = document.getElementById('mobileChkBx') as HTMLInputElement;
    let mobileValue = this.contactDetail.get('newmobileNO').value ? this.contactDetail.get('newmobileNO').value : ''
    let userId = loggedUser['userName'];
    if (this.country !== 'gr') {

      if (mobileValue) {
        let headers = new HttpHeaders({});
        this.blankMobile = false;
        const baseUrl = this.baseUrl.ecustomer.validationConfig + mobileValue + "/validate/" + userId;
        const param = {
          phoneNumber: mobileValue,
          userId: userId
        }
        this.commonService.postData(this.baseUrl.ecustomer.validationConfig, param, '').subscribe((response) => {
          this.contactDetail.get('newmobileNO').setValue(mobileValue.trim());
          if (response) {

            this.isMobileNotValid = false;
          }
          else {
            this.isMobileNotValid = true;
            // this.contactDetail.get('mobileValid').setValue(null);
            if (this.contactDetail && this.contactDetail.controls.mobileValid.value) {
              this.contactDetail.get('mobileValid').setValue(false);
            }
            this.contactDetail.get('newmobileNO').enable();
          }
        })
      } else {
        this.isMobileNotValid = true;
        this.blankMobile = true;
      }
    }
  }
  gotoContactForm() {


  }

  keyPress(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
      return false;

    return true;
  }

  routeSetting() {
    // let newEmail = this.contactDetail.value.newEmail;
    // let newMob = this.contactDetail.value.newmobileNO;
    let newEmail = this.contactDetail.get('newEmail').value;//this.contactDetail.value.newEmail; 
    let newMob = this.contactDetail.get('newmobileNO').value;//this.contactDetail.value.newmobileNO; 
    // let email = this.validateEmail(newEmail);
    // let mobile = this.validateMobile(newMob);
    if (newEmail && newMob) {
      let loggedUserData = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      // if ((email) && (mobile)) {
      let url = this.baseUrl.ecustomer.addUserLegalContact + this.clientId;
      let param = {
        "firstName": loggedUserData['firstName'],
        "lastName": loggedUserData['lastName'],
        "updatedEmail": this.contactDetail.get('newEmail').value,
        "updatedMobilePhone": this.contactDetail.get('newmobileNO').value,
        "clientId": this.clientId,
        "userId": loggedUserData['userName']
      }
      this.sharedService.setPramaValue('legalUpdateData', param)
      this.commonService['putData'](this.baseUrl.ecustomer.addUserLegalContact, param).subscribe();
      //("parama data ", param)
      this.sharedService.setPramaValue('addNewUserBack', false);
      this.broadCastService.broadcast('setttingroute', true);
      this.router.navigate(['./setting']);
      // }
    }
  }

  backToAddUser() {
    this.sharedService.setPramaValue('addNewUserBack', true);
    this.sharedService.setPramaValue('legalUpdateData', null)
    this.broadCastService.broadcast('setttingroute', true);
    this.router.navigate(['./setting']);

  }
  question1Change(value) {
    this.questionSet2 = [];
    this.questionSet2 = this.questionSet.filter(function (el) {
      return value.indexOf(el) < 0;
    });
    //  console.log(this.questionSet1)
  }

  question2DropdownChange(value) {
    this.questionSet1 = [];
    this.questionSet1 = this.questionSet.filter(function (el) {
      return value.indexOf(el) < 0;
    });
    //console.log(this.questionSet2);
  }
  termsConditions() {
    window.open('https://uat.ecustomer.metlife.pl/assets/mocks/Regulamin.pdf', null);
  }
  gotoHome() {

  }

}
