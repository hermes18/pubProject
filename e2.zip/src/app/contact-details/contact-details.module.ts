import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactDetailsRoutingModule } from './contact-details-routing.module';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { ContactDetailsService } from './service/contact-details.service';
import { ContactDetailsComponent } from './contact-details.component';
import {
  MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule, MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule,
  MatProgressSpinnerModule, MatExpansionModule, MatTabsModule, MatTooltipModule,
  MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatInputModule,
  MatSortModule, MatTableModule, MatPaginatorModule
} from '@angular/material';

const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule,];
  
@NgModule({
  declarations: [ContactDetailsComponent],
  imports: [
    CommonModule,
    ContactDetailsRoutingModule,
    // NgbModule.forRoot(),  
    ...materialModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule
  ],
  providers: [ContactDetailsService]
})
export class ContactDetailsModule { }
