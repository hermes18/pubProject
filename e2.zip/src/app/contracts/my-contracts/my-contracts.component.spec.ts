import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ContractsModule } from '../contracts.module';

import { MyContractsComponent } from './my-contracts.component';
import { SharedServiceService } from '../../shared-service/shared-service.service';
import { of } from 'rxjs';
describe('MyContractsComponent', () => {
  let component: MyContractsComponent;
  let fixture: ComponentFixture<MyContractsComponent>;
  let sharedService: SharedServiceService;
  let contractList;
  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    const countryCode = "ro";
    window.sessionStorage.setItem('countryCode', JSON.stringify(countryCode));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService, SharedServiceService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(MyContractsComponent);
    component = fixture.componentInstance;
    contractList = [{ "contractNumber": "21282475", "contractNumberList": null, "benefitType": "SuperKapitał S", "effectiveDate": "28.12.2009", "premiumType": "11", "premiumAmt": null, "premiumAmount": "", "premiumAmtType": null, "status": 21, "businessRoleList": ["insured", "owner"], "processingSystem": "OLAS", "insuredName": "INSURED_21282475", "premiumDueDate": null, "indexedPremiumAmount": null, "premiumPaymentMode": "11", "contractDetailsDTO": { "contractNumber": null, "insurer": "INSURER_21282475", "insured": "INSURED_21282475", "status": 21, "paymentMode": "11", "premiumDueDate": 1380319200000, "currentPremiumAmt": null, "bankAccount": "02 1030 1944 9000 0500 2128 2475", "debtStatus": "true", "indexationDocument": "-1", "lastPremiumAmt": 157.32, "indxPremiumAmt": 200, "indexedPremiumAmt": null, "coinsured1": null, "coinsured2": null, "coinsured3": null, "coinsured4": null, "coinsured5": null, "coinsured6": null, "coinsured7": null, "coinsured8": null, "coinsured9": null, "additionalBankAccount": null, "additionalBankAccountLabel": null, "additionalBankAccountTip": null, "policySearchDTOsList": [], "billGroup": null, "clientId": null, "billControl": null, "noOfPolicies": 0, "totalPremiumAmount": null, "suspendStatus": "FALSE", "suspendDate": null, "policyStatus": null, "frequency": null, "effectiveDate": "28.12.2009", "anniverseryDueDate": null, "indexRate1": null, "indexRate2": null, "indexedPremiumAmt2": null, "indexationEligible": 0 } }];
    component.sharedService.getDetail('menuItemList');
    spyOn(SharedServiceService.prototype, 'getDetail').withArgs('menuItemList').and.returnValue(of(contractList));

    fixture.detectChanges();
  });

  it('should create', inject([SharedServiceService], (sharedService: SharedServiceService) => {
    component.lang = "pl";

    expect(component).toBeTruthy();
  })
  );

  it('should call ', () => {
    const contract = {
      benefitType: "SuperKapitał S",
      businessRoleList: ["insured", "owner"],
      contractDetailsDTO: { contractNumber: null, insurer: "INSURER_21282475", insured: "INSURED_21282475", status: 21, paymentMode: "11" },
      contractNumber: "21282475",
      contractNumberList: null,
      effectiveDate: "28.12.2009",
      indexedPremiumAmount: null,
      insuredName: "INSURED_21282475",
      premiumAmount: "",
      premiumAmt: null,
      premiumAmtType: null,
      premiumDueDate: null,
      premiumPaymentMode: "11",
      premiumType: "11",
      processingSystem: "OLAS",
      status: 21
    };
    component.generalData(contract, '21282475');
  })
});
