import { Component, OnInit, Output, EventEmitter, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { AppConfig } from 'src/config/app.config';

import { MenuItemsService } from '../../shared-service/menu-items.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
@Component({
  selector: 'my-contracts',
  templateUrl: './my-contracts.component.html',
  styleUrls: ['./my-contracts.component.scss']
})
export class MyContractsComponent implements OnInit {
  @Output('userAccountValue') valueChange = new EventEmitter<any>();
  settingParamValue = {
    'generalData': false,
    'mycontracts': false,
  }
  showDetails: boolean = false;
  showDateTooltipBasic: boolean = false;
  constructor(public route: ActivatedRoute, private readonly router: Router,
    public fb: FormBuilder, public commonService: HttpCommonService, private menuItem: MenuItemsService,
    public sharedService: SharedServiceService, private cService: HttpCommonService) { }

  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  contractListData;
  flagtest = "assets/mocks/contractList.json";
  msg: any;
  ngOnInit() {
    this.msg = "test";
    let params = {
      // requesterEmail :  this.emailID
      clientId: "101583",
      userId: "ShabanaAdmin",
      requesterRole: "Admin"
    }

    //this.cService['postData'](this.baseUrl.ecustomer.contracts, JSON.stringify(params), "")
    // this.cService['getData'](this.flagtest)
    //   .subscribe(data => {
    //     //(data)
    //     this.contractListData = data;
    //     this.sharedService.setContractDetails(data);
    //   });

    this.sharedService.getDetail('menuItemList').subscribe((data) => {
      //(data);
      this.contractListData = data.contractList;

    });

    this.lang = UtilityService.getCountry();//sessionStorage.getItem('defaultLanguage');
    /*if (this.lang == "pl_en") {
      this.lang = "en";
    } else if (this.lang == "pl_pl") {
      this.lang = "pl";
    } else if (this.lang == "ro_en") {
      this.lang = "en";
    } else if (this.lang == "ro_ro") {
      this.lang = "ro";
    }*/
    this.countryCode = this.lang;
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.lang = data;
      }

    });

  }
  countryCode: any;
  lang: any;
  generalData(contract, contractNo) {

    this.sharedService.setPramaValue('individualContractDetails', contract);
    sessionStorage.setItem('contractDetails', JSON.stringify(contract));
    this.sharedService.setContractNo(contractNo);
    this.settingParamValue.generalData = true;
    this.settingParamValue.mycontracts = false;
    this.valueChange.emit(this.settingParamValue);
    this.getSubmenuList(contract);

    // this.router.navigate(['/contract-details'])
  }

  getSubmenuList(contract) {
    this.menuItem.getSubmenuList(contract);
  }

  gotoHome() {
    this.settingParamValue.generalData = false;
    this.settingParamValue.mycontracts = false;
    this.valueChange.emit(this.settingParamValue);
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItem.navigationBasedOnRole(menuItemList);
  }

  goIntoDetails() {
    if (!this.showDetails) {
      this.showDetails = true;
      this.showDateTooltipBasic = true;
      if (this.contractListData) {
        this.contractListData.forEach(element => {
          element.showDateTooltipBasic = true;
        })
      }
    }
    else {
      this.showDetails = false;
      this.showDateTooltipBasic = false;
      if (this.contractListData) {
        this.contractListData.forEach(element => {
          element.showDateTooltipBasic = false;
        })
      }
    }
  }
}
