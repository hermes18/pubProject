import { Component, OnInit } from '@angular/core';
import { SharedServiceService } from '../shared-service/shared-service.service';

@Component({
  selector: 'contracts',
  templateUrl: './contracts.component.html',
  styleUrls: ['./contracts.component.scss']
})

export class ContractsComponent implements OnInit {
  wardenData: any;
  showContract: boolean = false;
  showWardenContract: boolean = false;

  constructor(private readonly commonService: SharedServiceService) { }
  ngOnInit() {
    this.commonService.getDetail('menuItemList').subscribe((data) => {
      //("warden",data)
      this.wardenData = data;
      if (this.wardenData)
        if (this.wardenData.wardenRoleCheck) {
          this.showWardenContract = true;
        } else {
          this.showContract = true;
        }
    })

  }
}