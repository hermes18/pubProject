import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from 'src/app/app.module';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { ContractsModule } from '../contracts.module';

import { ContractWardenComponent } from './contract-warden.component';

fdescribe('ContractWardenComponent', () => {
  let component: ContractWardenComponent;
  let fixture: ComponentFixture<ContractWardenComponent>;


  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []

    })
      .compileComponents();
    fixture = TestBed.createComponent(ContractWardenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', inject([SharedServiceService], (sharedService: SharedServiceService) => {
    const bilinRecepient = {
      "menuItems": [{ "menuId": "3", "accessSpec": "RW", "menuName": "Change Password", "parentMenu": "Settings" }, { "menuId": "4", "accessSpec": "RW", "menuName": "Changing the Settings", "parentMenu": "Settings" }, { "menuId": "5", "accessSpec": "RW", "menuName": "My Contract", "parentMenu": "Main Menu" }, { "menuId": "6", "accessSpec": "RW", "menuName": "My Data", "parentMenu": "Main Menu" }, { "menuId": "7", "accessSpec": "RW", "menuName": "Offer", "parentMenu": "Main Menu" }, { "menuId": "8", "accessSpec": "RW", "menuName": "Review Of Orders", "parentMenu": "Main Menu" }, { "menuId": "9", "accessSpec": "RW", "menuName": "Claims", "parentMenu": "Main Menu" }, { "menuId": "11", "accessSpec": "RW", "menuName": "Individual Contract Details", "parentMenu": "My Contract" }, { "menuId": "12", "accessSpec": "RW", "menuName": "Individual Contract Benefits", "parentMenu": "My Contract" }, { "menuId": "13", "accessSpec": "RW", "menuName": "Individual Contract Beneficiaries", "parentMenu": "My Contract" }, { "menuId": "14", "accessSpec": "RW", "menuName": "Individual Contract Financial Info", "parentMenu": "My Contract" }, { "menuId": "15", "accessSpec": "RW", "menuName": "Invest Strategy Change", "parentMenu": "My Contract" }, { "menuId": "20", "accessSpec": "RW", "menuName": "Deposit As new Invest Account", "parentMenu": "My Contract" }, { "menuId": "21", "accessSpec": "RW", "menuName": "Order History Review", "parentMenu": "My Contract" }, { "menuId": "22", "accessSpec": "RW", "menuName": "Agent Details", "parentMenu": "My Contract" }, { "menuId": "23", "accessSpec": "RW", "menuName": "Invest Strategy Change menu", "parentMenu": "My Contract" }, { "menuId": "35", "accessSpec": "RW", "menuName": "Documents Presentation", "parentMenu": "Main Menu" }, { "menuId": "40", "accessSpec": "RW", "menuName": "My Company", "parentMenu": "My Contract" }], "renderMyContract": true, "renderOffers": false, "clientAdministration": false, "renderOrderReview": false, "renderMyData": false, "renderClaims": false, "renderUserAcctAdministration": false, "renderDocuments": false, "callRetrievePolicies": false, "callRetriveClientOffers": false, "callRetriveClientData": false, "renderMyCompany": true, "route": "Home", "contractList": null, "claimList": null, "personalInformationDTO": { "policyNumber": null, "dateOfBirth": null, "gender": null, "residenceTelephone": "", "mobile": null, "officeFax": null, "residenceFax": null, "firstName": null, "lastName": "FAMILY_NAME_10151", "identifier": null, "identifierType": null, "mobilePhone": "", "emailBasic": null, "emailSecondary": "shabana.shaikh@metlife.pl", "marketingConsentList": [{ "status": "DISAGREE", "type": "PSE", "recievedOn": null }, { "status": "NOINFO", "type": "EIB", "recievedOn": null }, { "status": "AGREE", "type": "PIN", "recievedOn": null }, { "status": "AGREE", "type": "RPH", "recievedOn": null }, { "status": "AGREE", "type": "RSM", "recievedOn": null }, { "status": "AGREE", "type": "REM", "recievedOn": null }, { "status": "AGREE", "type": "REC", "recievedOn": null }, { "status": "AGREE", "type": "RPHTF", "recievedOn": null }, { "status": "AGREE", "type": "RSMTF", "recievedOn": null }, { "status": "AGREE", "type": "REMTF", "recievedOn": null }, { "status": "AGREE", "type": "MMTM", "recievedOn": null }, { "status": "AGREE", "type": "NSURV", "recievedOn": null }, { "status": "AGREE", "type": "PHONE", "recievedOn": null }, { "status": "AGREE", "type": "DEPCO", "recievedOn": null }, { "status": "AGREE", "type": "MSE", "recievedOn": null }, { "status": "AGREE", "type": "MSEN", "recievedOn": null }, { "status": null, "type": null, "recievedOn": null }], "updatedmarketingConsentList": null, "addressDetailsDTO": { "existingAdressList": [{ "policyNumber": null, "policyName": null, "id": null, "clientId": null, "userId": null, "addressInstitution": "", "postOffice": "", "postBox": "", "addressLine1": null, "addressLine2": null, "state": null, "country": "PL", "city": "CITY_5613", "pinCode": null, "street": "STREET_5613", "flat": "", "house": "21T", "uploadFileList": [], "uploadFile": null, "addressId": null, "policyNumbersList": [], "policyNameAndNumbersList": [], "streetList": [], "citiesList": [], "postCodeList": [], "streetName": "STREET_5613", "cityName": null, "postCode": null, "countryName": null, "countryCode": "PL", "countriesResultList": [], "block": null, "entrance": null, "apartment": null, "sector": null, "mobile": null, "landline": null, "email": null }], "updatedaddressChangeDTO": null }, "updatedResidenceTelephone": null, "updatedMobile": null, "updatedEmailBasic": null, "updatedEmailSecondary": null, "clientId": null, "versionMarker": "2020 - 11 - 20T08: 17: 34.297 + 01: 00", "clientIdentifierList": [{ "identifierType": "PESEL", "identifierValue": "68092211074" }], "safePhone": "123456789", "updatedSafePhone": null, "accountType": "new ", "accountCreationWay": null, "flagOfCapabilityOfChangeData": "true" }, "orderHistory": null, "offerResponse": null, "fundPriceDetails": null, "renderFundPriceMonitoring": false, "documentsList": null, "billingRecipent": [{ "id": "0003", "billGroup": "BILGR003", "recipent": "10151" }], "activeContractDetails": [], "clientIdbillControlList": [], "clientIdList": [], "wardenRoleCheck": true,
      "searchFlag": true
    };
    sharedService.getDetail('menuItemList');
    spyOn(SharedServiceService.prototype, 'getDetail').and.returnValue(of(bilinRecepient));
    expect(component).toBeTruthy();
  }));
});
