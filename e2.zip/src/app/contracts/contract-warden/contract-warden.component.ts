import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DateAdapter, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { SelectionModel } from '@angular/cdk/collections';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { Router } from '@angular/router';
import { DeviceDetectorService } from 'ngx-device-detector';
import * as moment from 'moment';
export interface ContractWarden {
  lastName: string;
  contractNumber: number;
  premium: number;
  paidTo: Date;
  select;
  contractDetailsDTO: any;
  premiumAmt: any;
  premiumAmount: string;
}
@Component({
  selector: 'contract-warden',
  templateUrl: './contract-warden.component.html',
  styleUrls: ['./contract-warden.component.scss']
})
export class ContractWardenComponent implements OnInit {
  displayedColumns: string[] = ['insuredName', 'contractNumber', 'premiumAmount', 'premiumDueDate', 'select'];
  dataSource: MatTableDataSource<ContractWarden>;
  selection = new SelectionModel<ContractWarden>(true, []);
  private paginator: MatPaginator;
  private sort: MatSort;
  contractWardernRequest;
  recordFound: boolean = false;
  noContractSelected: boolean = false;
  searchValid: boolean = false;
  count: any;
  noSearchResultFound: boolean = false;
  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.dataSource)
      this.dataSource.paginator = this.paginator;
  }
  @ViewChild(MatSort, { static: false }) set matSort(mp: MatSort) {
    this.sort = mp;
    if (this.dataSource)
      this.dataSource.sort = this.sort;
  }
  user: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  contractListDataActive: any = [];
  billControlList;
  contractListData;
  total
  totalPolicy: any = [];
  constructor(public fb: FormBuilder, private dateAdapter: DateAdapter<Date>, public router: Router, private menuItem: MenuItemsService, public deviceDetector: DeviceDetectorService, public sharedService: SharedServiceService, public commonhttpService: HttpCommonService) { }
  contractWarden = this.fb.group({
    billControl: null,
    paidTo: null,
    lastName: null,
    contractNumber: null
  });
  noDataAvailable: boolean = false;
  lcode;
  ngAfterViewInit() {
    this.sharedService.getLangChange().subscribe((data) => {

      const lang = sessionStorage.getItem("defaultLanguage");
      // this.lcode = sessionStorage.getItem("defaultLanguage");
      this.lcode = sessionStorage.getItem('defaultLanguage');

      // console.log(this.lcode)
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_gr': 'el',
        'gr_en': 'en',
        'gr': 'el'
      }
      //("after lang change", data);
      const language = data ? data === 'gr' ? dateTranslate[lang] : data : dateTranslate[lang];
      this.dateAdapter.setLocale(language);
    })

    // if (this.dataSource)
    //   this.dataSource.sort = this.sort;
    // console.log(this.sort)
    // this.dataSource.paginator = this.paginator;
    // console.log(this.dataSource.paginator)
  }
  lang: any;

  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {

    this.InvalidDate = false;
    this.noContractSelected = false;
    this.noSearchResultFound = false;
    this.recordFound = false;
    this.initialDisplayAndReset();
    this.lang = sessionStorage.getItem('defaultLanguage');
    this.dateAdapter.setLocale(this.lang);

  }
  initialDisplayAndReset() {
    this.sharedService.getDetail('menuItemList').subscribe((data) => {
      //("wardendata", data);
      if (data) {
        this.billControlList = data.billingRecipent;
        if (this.billControlList && (this.billControlList.length == 0)) {
          this.noDataAvailable = true;
        }
        else {
          this.noDataAvailable = false;
        }
        if (this.billControlList && (this.billControlList.length == 1)) {
          this.contractWarden.get('billControl').setValue(this.billControlList[0].billGroup)

        }
        else {
          this.contractWarden.get('billControl').setValue('')
        }
        this.contractListData = data.activeContractDetails;
        //(this.contractListData);
        // this.dataSource = new MatTableDataSource<ContractWarden>();
        this.paginator = null;
        this.sort = null;
        if (this.contractListData) {
          this.dataSource = new MatTableDataSource(this.contractListData);
          //(this.dataSource)
          this.dataSource.data = this.contractListData
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.dataSource.sortingDataAccessor = (item, property) => {
            // console.log(property)
            switch (property) {
              case 'premiumAmount': {

                //  const a = item.premiumAmount;
                const str = item.premiumAmount;
                let a = str.split(" ");
                if (a.length > 1)
                  this.value = a[0];
                // console.log(this.value)
                // let val = a.toLocaleString();
                // let num = parseFloat(a.trim().replace(',', ''))
                var numeric = Number(this.value);
                // console.log(numeric);
                return numeric;

              }


              default: {

                return item[property];
              }
            }
          };

          if (this.contractListData.length != 0) {
            this.recordFound = true;
          } else {
            this.recordFound = false;
          }
        }
      }
    })

  }
  invalidDateStore: any = '';
  dateOnblur(val) {

    this.invalidDateStore = '';
    if (this.contractWarden.get('paidTo').value) {

    } else {
      this.invalidDateStore = val;
    }

  }
  paidDate
  InvalidDate: boolean = false
  dateChanged: boolean = false
  onChange(event: any) {
    // console.log("event", event.value);
    this.invalidDateStore = null;
    this.dateChanged = true;
  }
  searchOperation() {
    this.noDataAvailable = false;
    this.InvalidDate = false;
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
    this.noSearchResultFound = false;
    this.paidDate = moment(this.contractWarden.value.paidTo)
    //(this.Dob)

    //(this.dataChanged)
    if (this.invalidDateStore != null &&
      this.invalidDateStore != '' &&
      this.dateChanged && !this.paidDate.isValid()) {
      this.InvalidDate = true;
      this.dateChanged = true;
    }
    else {
      // if (this.contractWarden.value.billControl || this.contractWarden.value.paidTo || this.contractWarden.value.lastName || this.contractWarden.value.contractNumber) {
      //   this.searchValid = true;
      // }
      // else {
      //   this.searchValid = false;
      // }
      // if (this.searchValid) {
      this.recordFound = false;
      this.searchValid = false;
      this.dateChanged = false;
      let searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
      let loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      this.contractWardernRequest = {

        billControl: this.contractWarden.value.billControl ? (this.contractWarden.value.billControl).trim() : '',
        peselId: this.contractWarden.value.pesel ? (this.contractWarden.value.pesel).trim() : '',
        lastName: this.contractWarden.value.lastName ? (this.contractWarden.value.lastName).trim() : '',
        contractNumber: this.contractWarden.value.contractNumber ? (this.contractWarden.value.contractNumber).trim() : '',
        clientId: searchedClientDetails ? searchedClientDetails.customerId : '',
        requesterId: loggedInUserDetail ? loggedInUserDetail.requesterId : '',
        requesterRole: '3037',
        userId: loggedInUserDetail ? loggedInUserDetail.userName : '',
        // paidTo: this.contractWarden.value.paidTo,
        paidTo: (this.contractWarden.value.paidTo ? this.paidDate.format("DD/MM/YYYY") : null)
        // paidTo: (this.contractWarden.value.paidTo ? new Date(this.contractWarden.value.paidTo).toLocaleDateString() : null),
      }

      // }
      // console.log(this.contractWardernRequest)
      if ((this.contractWardernRequest.billControl == '') && (this.contractWardernRequest.paidTo == null) && (this.contractWardernRequest.lastName == '')
        && (this.contractWardernRequest.contractNumber == '')) {
        console.log("not valid search")

      } else {
        this.contractWardernList();
      }
    }
    // 
  }
  value;
  contractWardernList() {

    this.commonhttpService.postData(this.baseUrl.ecustomer.wardenSearch, this.contractWardernRequest, '').subscribe(data => {
      //("warden retrival data2", data)

      if (data && (data.activeContractDetails != null && data.activeContractDetails != '')) {
        this.contractListDataActive = [];

        if (data && data.activeContractDetails) {
          for (let i = 0; i < data.activeContractDetails.length; i++) {
            this.contractListDataActive.push(data.activeContractDetails[i]);
          }
        }

        if (this.contractListDataActive) {
          this.dataSource = new MatTableDataSource<ContractWarden>();
          this.paginator = null;
          this.user = this.contractListDataActive;
          //("user", this.user)
          this.dataSource = new MatTableDataSource(this.user);
          //("data", this.dataSource)
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          //           this.dataSource.sortingDataAccessor = (item, property) => {
          // console.log(property)
          //             switch (property) {
          //               case 'premiumAmount': {

          //                 //  const a = item.premiumAmount;
          //                 const str = item.premiumAmount;
          //                 let a = str.split(" ");
          //                 if (a.length > 1)
          //                   this.value = a[0];
          //                   console.log(this.value)
          //                 let val = a.toLocaleString();
          //                 // let num = parseFloat(a.trim().replace(',', ''))
          //                 // var numeric = Number(num);
          //                 // console.log(numeric);
          //                 // return numeric;

          //               }


          //               default: {

          //                 return item[property];
          //               }
          //             }
          //           };
          this.count = this.user.length;
        }

        if (this.contractListDataActive.length != 0) {
          this.recordFound = true;
        } else {
          this.recordFound = false;

        }
      }
      else { this.noSearchResultFound = true; }
    })
    if (this.isAllSelected()) {
      this.selection.clear()
    }
  }
  goToContractDetails(contract) {
    sessionStorage.setItem('contractDetails', JSON.stringify(contract));
    this.menuItem.getSubmenuList(contract);

  }


  clearOperation() {
    this.noSearchResultFound = false;
    this.noContractSelected = false;
    this.contractWarden.controls['paidTo'].reset()
    this.contractWarden.controls['lastName'].reset()
    this.contractWarden.controls['contractNumber'].reset()
    // this.contractWarden.reset();
    // this.checkedItems.forEach(child => {
    //   child.checked = false;
    // });
    this.selection.clear();
    this.initialDisplayAndReset();
    // this.isAllSelected() ?
    //   this.selection.clear() :
    //   this.dataSource.data.forEach(row => this.selection.select(row));
  }



  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  logSelection() {
    window.scrollTo(0, 0);
    //(this.selection.selected);

    //(this.selection.selected.length);
    if (this.selection.selected.length == 0) {
      this.noContractSelected = true;

    }
    else {
      const a = this.selection.selected;
      for (let i = 0; i < a.length; i++) {
        //(a[i])
        //(a[i].contractDetailsDTO.billGroup);
        this.totalPolicy.push({ "billGroup": a[i].contractDetailsDTO.billGroup, "premiumAmount": a[i].premiumAmt });
      }
      //(this.totalPolicy);
      this.sharedService.setTotalPolicy(this.totalPolicy);
      this.noContractSelected = false;
      this.router.navigate(['/wardenContract'])
    }

  }
  gotoHome() {
    this.router.navigate(['/wardenContract'])
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItem.navigationBasedOnRole(menuItemList);
  }
}


