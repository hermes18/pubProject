import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContractsComponent } from './contracts.component';
import { MatFormFieldModule } from '@angular/material';

import { MyContractsComponent } from './my-contracts/my-contracts.component';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { ContractWardenComponent } from './contract-warden/contract-warden.component';

const routes: Routes = [
  {
    path: '', component: ContractsComponent, canDeactivate: [NavigationGuard],
    children: [
      { path: '', component: MyContractsComponent, canDeactivate: [NavigationGuard] },
      { path: 'contract-warden', component: ContractWardenComponent, canDeactivate: [NavigationGuard] }
    ]
  }


];

@NgModule({
  imports: [RouterModule.forChild(routes), MatFormFieldModule],
  exports: [RouterModule, MatFormFieldModule]
})
export class ContractsRoutingModule { }
