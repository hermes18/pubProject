import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContractsRoutingModule } from './contracts-routing.module';
import { ContractsComponent } from './contracts.component';

import { MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule, MatSidenavModule, MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule, MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatInputModule, MatPaginatorModule, MatSortModule, MatTableModule, NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { NgxPaginationModule } from 'ngx-pagination';

import { MyContractsComponent } from './my-contracts/my-contracts.component';
import { ContractWardenComponent } from './contract-warden/contract-warden.component';
import { SharedModule } from '../shared/shared.module';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';


export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};

export class CustomDatePickerAdapter extends NativeDateAdapter {

  parse(value: any): Date | null {
    ////(value);
    if ((typeof value === 'string') && (value.indexOf('/') > -1)) {
      const str = value.split('/');
      const year = Number(str[2]);
      const month = Number(str[1]) - 1;
      const date = Number(str[0]);
      // //("year, month, date",year, month, date)
      ////("year, month, date",new Date(year, month, date))
      if (year > 0 && month < 12 && date > 0 && date <= 31) {
        return new Date(year, month, date);
      }


    }
    const timestamp = typeof value === 'number' ? value : Date.parse(value);
    ////("timestamp",timestamp)
    return isNaN(timestamp) ? null : new Date(timestamp);
  }

  private _to2digit(n: number) {
    ////("_to2digit",('00' + n).slice(-2))
    return ('00' + n).slice(-2);
  }
  format(date: Date, displayFormat: string): string {
    ////(displayFormat," ------>",date,displayFormat )

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    ////("input",(this._to2digit(day) + '/' + this._to2digit(month) + '/' + year) )
    return this._to2digit(day) + '/' + this._to2digit(month) + '/' + year;

  }
}

@NgModule({
  declarations: [ContractsComponent, ContractWardenComponent, MyContractsComponent],
  imports: [
    CommonModule,
    ContractsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule, SharedModule,
    NgxPaginationModule
  ],
  providers: [

    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {
      provide: DateAdapter,
      useClass: CustomDatePickerAdapter

    },


    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }

  ]
})
export class ContractsModule { }
