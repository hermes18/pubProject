import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpCommonService } from '../../shared/services/http-common.service';
// import { AccountSettingService } from './account-setting.service';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { TranslateService } from '@ngx-translate/core';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'account-setting',
  templateUrl: './account-setting.component.html',
  styleUrls: ['./account-setting.component.scss']
})
export class AccountSettingComponent implements OnInit {
  detail
  questionSet: any;
  securityDetail;
  country: string;
  lang: string;
  displayPoOption: boolean = false;
  displayRoOption: boolean = false;
  accountSettingForm: FormGroup;
  updateSecurity: FormGroup;

  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  settingFormValue;
  loginDetail: any;
  changeResponse: any;
  invaildSettingsForm: any;
  securityForm: boolean;
  invalidMail: boolean;
  userAuthenticated: boolean;
  inputPassword: string = "";
  securityQnssubmitted: boolean = false;
  passwordFormResponse: any;
  passwordFormsubmitted: boolean = false;
  currentPasswordFieldTextType: boolean = false;
  answerFlag: boolean = false;
  answersUpdatedFlag: boolean = false;
  questionSet2: any;
  questionSet1: any;
  userRole = this.menuItemService.getAllRoles();
  clientId: any;
  userdetail: any;
  securityQuCheck: boolean = false;
  securityQuCheck2: boolean = false;
  constructor(private route: ActivatedRoute, public fb: FormBuilder, public commonService: HttpCommonService, public dialogService: DialogService,
    private menuItemService: MenuItemsService,
    public deviceDetector: DeviceDetectorService,
    private translate: TranslateService,
    public dialog: DialogService,
    public router: Router,) { }

  // public accountService: AccountSettingService

  @Input() set settingsTabIndex(index) {
    this.passwordFormsubmitted = false;
    this.userAuthenticated = false;
    this.securityQnssubmitted = false;
    if (this.accountSettingForm || this.updateSecurity) {
      // this.updateSecurity ? this.updateSecurity.reset() : '';
      // this.accountSettingForm ? this.accountSettingForm.reset() : '';
      // // this.accountSettingForm.reset();
      // this.updateSecurity.reset();
      // this.updateSecurity ? this.updateSecurity.markAsUntouched() : '';
      // this.accountSettingForm ? this.accountSettingForm.markAsUntouched() : '';
      // this.updateSecurity.markAsTouched();

      this.changeResponse = '';
      this.invaildSettingsForm = false;
      this.invalidMail = false;
      this.securityForm = false;
      if (this.accountSettingForm) {
        if (this.displayRoOption) {
          this.accountSettingForm.get('updateMail').setValidators(null);
        } else {
          this.accountSettingForm.get('updateMail').setErrors(null);
          this.accountSettingForm.get('updateMail').clearValidators();
        }
        this.accountSettingForm.updateValueAndValidity();
        this.accountSettingForm.reset();
      }
      if (this.userRole == 'rClient' || this.userRole == 'rWarden') {
        this.updateSecurity.get('inputPassword').setErrors(null);
        this.updateSecurity.get('inputPassword').clearValidators();
        this.updateSecurity.get('question').setErrors(null);
        this.updateSecurity.get('question').clearValidators();
        this.updateSecurity.get('answer').setErrors(null);
        this.updateSecurity.get('answer').clearValidators();
        this.updateSecurity.get('question').setErrors(null);
        this.updateSecurity.get('question2').clearValidators();
        this.updateSecurity.get('answer2').setErrors(null);
        this.updateSecurity.get('answer2').clearValidators();
        this.updateSecurity.get('question').setValidators([Validators.required]);
        this.updateSecurity.get('answer').setValidators([Validators.required, Validators.minLength(3)]);
        this.updateSecurity.get('question2').setValidators([Validators.required]);
        this.updateSecurity.get('answer2').setValidators([Validators.required, Validators.minLength(3)]);
        this.updateSecurity.get('inputPassword').setValidators([Validators.required, Validators.maxLength(32)]);
        this.updateSecurity.updateValueAndValidity();
      }
      //this.callApi();
    }
  }

  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    //("country", this.country)

    this.lang = sessionStorage.getItem('defaultLanguage');
    //("lang", this.lang)
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }
    const userInfo = sessionStorage.getItem('loggedInUserInfo');
    this.userdetail = JSON.parse(userInfo);
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    const contractnumber = JSON.parse(sessionStorage.getItem('contract'));
    if (this.userRole === "rClient" || this.userRole === "rWarden") {
      this.clientId = this.userdetail.clientID;
    } else {
      this.clientId = customerId != null ? customerId.clientID : null;
    }

    this.accountSettingForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      //phoneNumber: [''],
      language: ['', Validators.required],
      updateMail: ['']

    });
    this.updateSecurity = this.fb.group({
      question: new FormControl('', [Validators.required]),
      answer: ['', [Validators.required, Validators.minLength(3)]],
      question2: new FormControl('', [Validators.required]),
      answer2: ['', [Validators.required, Validators.minLength(3)]],
      answerFlag: false,
      answersUpdatedFlag: false,
      inputPassword: ['', [Validators.maxLength(32), Validators.required]]

    })
    if (this.displayRoOption) {
      this.accountSettingForm.get('updateMail').setValidators(null);
    } else {
      this.accountSettingForm.get('updateMail').setErrors(null);
      this.accountSettingForm.get('updateMail').clearValidators();
    }
    this.accountSettingForm.updateValueAndValidity();
    if (this.userRole != "rClient" && this.userRole != "rWarden") {
      this.callApi();
    } else {
      this.patchSecurityFormValues();
    }
    //this.callApi();
  }

  callApi() {
    this.loginDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let url = `${this.baseUrl.ecustomer.accountSettingRetriev}${this.loginDetail ? this.loginDetail.userName ? this.loginDetail.userName : '' : ''}`,
      reqParam = {
        userId: this.loginDetail ? this.loginDetail.userName : ''
      };
    this.commonService['postData'](this.baseUrl.ecustomer.accountSettingRetriev, reqParam, '').subscribe(data => {
      //(data);
      this.settingFormValue = data;
      if (this.userRole != "rClient" && this.userRole != "rWarden") {
        this.patchFormValues(data)
      } else {
        this.patchSecurityFormValues();
      }
      // this.patchFormValues(data)
    });
  }


  get f1() { return this.accountSettingForm.controls; }

  patchFormValues(formValues) {
    const setFormValue = {
      firstName: formValues.firstName ? formValues.firstName : '',
      lastName: formValues.lastName ? formValues.lastName : '',
      email: formValues.emailId ? formValues.emailId : '',
      //phoneNumber: formValues.phoneNumber ? formValues.phoneNumber : '',
      language: formValues.locale ? formValues.locale : '',
      emailUpdate: ''
    };
    this.accountSettingForm.patchValue(setFormValue);
    this.accountSettingForm.updateValueAndValidity();
  }

  patchSecurityFormValues() {
    if (this.userRole == 'rClient' || this.userRole == 'rWarden') { //working condtion formValues.questionType != null && formValues.questionType2 != null
      this.updateSecurity.get('question').setValidators([Validators.required]);
      this.updateSecurity.get('answer').setValidators([Validators.required, Validators.minLength(3)]);
      this.updateSecurity.get('question').setValidators([Validators.required]);
      this.updateSecurity.get('answer2').setValidators([Validators.required, Validators.minLength(3)]);
      this.updateSecurity.get('inputPassword').setValidators([Validators.required, Validators.maxLength(32)]);
      // working condition if (this.settingFormValue && (this.settingFormValue.questionType != null || this.settingFormValue.questionType2 != null)) {
      let url = this.baseUrl.ecustomer.getQuestionSet;
      this.commonService['getDataValueHeaders'](url, '').subscribe(data => {
        this.questionSet = data;
        this.questionSet1 = data;
        this.questionSet2 = data;
        // if (formValues.questionType != null){
        //   this.question1Change(formValues.questionType);
        // }
        // if(formValues.questionType2 != null){
        //   this.question2DropdownChange(formValues.questionType2);
        // }
      })
      // }
    } else {
      this.userAuthenticated = true;
      this.updateSecurity.get('inputPassword').setErrors(null);
      this.updateSecurity.get('inputPassword').clearValidators();
      this.updateSecurity.get('question').setErrors(null);
      this.updateSecurity.get('question').clearValidators();
      this.updateSecurity.get('answer').setErrors(null);
      this.updateSecurity.get('answer').clearValidators();
      this.updateSecurity.get('question').setErrors(null);
      this.updateSecurity.get('question2').clearValidators();
      this.updateSecurity.get('answer2').setErrors(null);
      this.updateSecurity.get('answer2').clearValidators();
    }
    this.updateSecurity.updateValueAndValidity();
    // const setSecurityQnForm = {
    //   question: formValues.questionType,
    //   answer: formValues.answer,
    //   question2: formValues.questionType2,
    //   answer2: formValues.answer2
    // }
    // this.updateSecurity.patchValue(setSecurityQnForm);
    // this.updateSecurity.updateValueAndValidity();
  }

  updateAccountSetting() {
    if (this.accountSettingForm.valid && this.userRole != 'rClient' && this.userRole != 'rWarden') {
      this.invaildSettingsForm = false;
      this.invalidMail = false;
      this.securityForm = false;

      this.submitAccChanges();
    } else if (this.updateSecurity.valid && (this.userRole == 'rClient' || this.userRole == 'rWarden')) {
      this.invaildSettingsForm = false;
      this.invalidMail = false;
      this.securityForm = false;
      this.submitAccChanges();
    } else {
      if (this.userRole != 'rClient' && this.userRole != 'rWarden' && (!this.accountSettingForm.valid)) {
        if (!this.accountSettingForm.valid && this.accountSettingForm.get('email').value == "") {
          // setTimeout(() => {
          //   this.invalidMail = false;
          // }, 5000);
          this.invalidMail = false;
          this.invaildSettingsForm = true;
        } else if (!this.accountSettingForm.get('email').valid && this.accountSettingForm.get('email').value != "" && !this.accountSettingForm.valid) {
          // setTimeout(() => {
          //   this.invalidMail = false;
          // }, 5000);
          this.invalidMail = true;
          this.invaildSettingsForm = false;
        } else if (this.accountSettingForm.get('email').valid && this.accountSettingForm.get('email').value != "" && !this.accountSettingForm.valid) {
          // setTimeout(() => {
          //   this.invaildSettingsForm = false;
          // }, 5000);
          this.invaildSettingsForm = true;
          this.invalidMail = false;
        } else { }
      } else if ((this.userRole == 'rClient' || this.userRole == 'rWarden') && (!this.updateSecurity.valid)) {
        //   if (this.updateSecurity.value.question === "" ||
        //   this.updateSecurity.value.question === "" || this.updateSecurity.value.answer === "") {
        //   this.securityQuCheck = true;
        // } else {
        //   this.securityQuCheck = false;
        // }
        // if ((this.updateSecurity.value.question2 === "" ||
        //   this.updateSecurity.value.question2 === "" || this.updateSecurity.value.answer2 === "")) {
        //   this.securityQuCheck2 = true;
        // } else {
        //   this.securityQuCheck2 = false;
        // }
        // if(!this.securityQuCheck2 && !this.securityQuCheck)
        this.submitAccChanges();
      } else { }
    }
  }

  /*   updateSecurity = this.fb.group({
      question: ['', [Validators.required]],
      answer:['', [Validators.required,Validators.minLength(3)]],
      question2: ['', [Validators.required]],
      answer2: ['', [Validators.required,Validators.minLength(3)]],
      answerFlag: false,
      answersUpdatedFlag: false,
      inputPassword:['', [Validators.maxLength(32)]]
  
    }) */
  get f() { return this.updateSecurity.controls; }

  ngAfterViewInit() {
    // if ((this.loginDetail.roleInfo[0].name == 'rCustomer')) {

  }
  updateSecurityDetail() {
    // this.securityDetail = {
    //   securityQuestion: this.updateSecurity.value.question,
    //   answer: this.updateSecurity.value.answer
    // }
    // //(this.securityDetail)
    this.updateAccountSetting();
  }

  submitAccChanges() {
    this.changeResponse = '';
    this.passwordFormsubmitted = true;
    this.securityQnssubmitted = true;
    if (this.userRole == 'rClient' || this.userRole == 'rWarden') { //this.settingFormValue.questionType!= null

      Object.keys(this.updateSecurity.controls).forEach(key => {
        this.updateSecurity.controls['answerFlag'].setValue(false);
        // if (key !== 'question' && key !== 'question2' && key != 'answerFlag' && key != 'answersUpdatedFlag') {
        if (key == 'question') {
          if (this.updateSecurity.controls[key].value == '-1' || this.updateSecurity.controls[key].value == '') {
            this.updateSecurity.controls[key].setErrors({ 'required': true });
            this.updateSecurity.controls[key].setValue('');
            this.securityForm = true;
            this.securityQuCheck = true;
            //return;
          }
        }
        if (key == 'question2') {
          if (this.updateSecurity.controls[key].value == '-1' || this.updateSecurity.controls[key].value == '') {
            this.updateSecurity.controls[key].setErrors({ 'required': true });
            this.updateSecurity.controls[key].setValue('');
            this.securityForm = true;
            this.securityQuCheck2 = true;
            //return;
          }
        }
        if (key == 'answer') {
          if (this.updateSecurity.controls[key].value.trim() == '') {
            this.updateSecurity.controls[key].setErrors({ 'required': true });
            this.updateSecurity.controls[key].setValue('');
            this.securityForm = true;
            this.securityQuCheck = true;
            //return;
          }
        }
        if (key == 'answer2') {
          if (this.updateSecurity.controls[key].value.trim() == '') {
            this.updateSecurity.controls[key].setErrors({ 'required': true });
            this.updateSecurity.controls[key].setValue('');
            this.securityForm = true;
            this.securityQuCheck2 = true;
            //return;
          }
        }
        if (key == 'inputPassword') {
          if (this.updateSecurity.controls[key].value.trim() == '') {
            this.updateSecurity.controls[key].setErrors({ 'required': true });
            this.updateSecurity.controls[key].setValue('');
            this.userAuthenticated = false;
            this.securityForm = true;
          }
        }
      });
      this.updateSecurity.controls['answerFlag'].setValue(false);
      this.answerFlag = false;
      if (this.updateSecurity.controls['answer'].value != '' && this.updateSecurity.controls['answer2'].value != '' &&
        this.updateSecurity.controls['answer'].value.toUpperCase() === this.updateSecurity.controls['answer2'].value.toUpperCase()) {
        this.updateSecurity.controls['answerFlag'].setValue(true);
        this.answerFlag = true;
        this.answersUpdatedFlag = false;
        return;
      }
      if (this.updateSecurity.controls['question'].value == "" || this.updateSecurity.value.answer === "") {
        this.securityForm = true;
        this.securityQuCheck = true;
        return;
      } else {
        this.securityQuCheck = false;
      }
      if (this.updateSecurity.controls['question2'].value == "" || this.updateSecurity.value.answer2 === "") {
        this.securityForm = true;
        this.securityQuCheck2 = true;
        return;
      } else {
        this.securityQuCheck2 = false;
      }
      // if (this.updateSecurity.controls['answer'].value!= null && this.updateSecurity.controls['answer2'].value != null) {
      // this.updateSecurity.controls['answersUpdatedFlag'].setValue(false);
      // this.answersUpdatedFlag = false;
      // if ((this.updateSecurity.controls['answer'].value == this.settingFormValue.answer) && (this.updateSecurity.controls['answer2'].value == this.settingFormValue.answer2)) {
      //   this.updateSecurity.controls['answersUpdatedFlag'].setValue(true);
      //   this.answersUpdatedFlag = true;
      //   this.updateSecurity.controls['answerFlag'].setValue(false);
      //   this.answerFlag = false;
      //   return;
      // }
      //}
    }
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.accountSettingsSubmit;
    if ((this.updateSecurity.dirty && this.updateSecurity.valid && (this.userRole == 'rClient' || this.userRole == 'rWarden')
      && !this.securityQuCheck2 && !this.securityQuCheck && !this.securityForm) || (this.accountSettingForm.valid && (this.userRole != 'rClient' &&
        this.userRole != 'rWarden'))) {
      let request =
      {
        'password': btoa(encodeURIComponent(this.updateSecurity.value.inputPassword)),
        "userName": this.userdetail ? this.userdetail.userName : null,//"11110679",
        "answer": this.updateSecurity ? this.updateSecurity.value.answer : null,//"UpdatedCorrectAnswerRO2",
        "firstName": this.accountSettingForm ? this.accountSettingForm.value.firstName : null,//"SAIKATPoland",
        "lastName": this.accountSettingForm ? this.accountSettingForm.value.lastName : null,//"CHATTERJEE",
        "accountStatus": this.settingFormValue ? this.settingFormValue.accountStatus : null,//"ACTIVE",//this.accountSettingForm.value.accountStatus,
        "emailId": this.accountSettingForm ? this.accountSettingForm.value.email : null,//"Saikat1308PL@gmail.com",
        "locale": this.accountSettingForm ? this.accountSettingForm.value.language : null,
        "globalEmployeeId": "",
        "checkBoxBinding": this.accountSettingForm ? this.accountSettingForm.value.updateMail : false,
        "questionType": this.updateSecurity ? this.updateSecurity.value.question : null,
        "phoneNumber": "",//this.accountSettingForm.value.phoneNumber, //"QCODE_02"   // -> true Only For RO Flow, based on users selection whether he/she wants to update the email or not
        "questionType2": this.updateSecurity ? this.updateSecurity.value.question2 : null,
        "answer2": this.updateSecurity ? this.updateSecurity.value.answer2 : null
      }
      // this.dialogService.openDialog(AlertDialogComponent, { 'heading': '', 'body': this.translate.instant('mandatoryErrorMsg'), 'primaryButton': 'OK' });
      this.commonService['putReturnText'](url, request).subscribe(data => {
        //(data);
        this.changeResponse = data;
        // this.f.answers.setErrors({ 'minLength': false });
        // this.f.answer2.setErrors({ 'minLength': false });
        this.updateSecurity.controls['answerFlag'].setValue(false);
        this.updateSecurity.controls['answersUpdatedFlag'].setValue(false);
        this.answerFlag = false;
        this.answersUpdatedFlag = false;
        this.passwordFormsubmitted = false;
        if (data != null && this.changeResponse == "S01") {
          if (this.userRole != 'rClient' && this.userRole != 'rWarden') {
            //this.callApi();
          } else {

          }
          // this.accountSettingForm.reset();
          // this.updateSecurity.reset();
        } else if (data == 'LM500210' || data == 'SC500405' || data == 'S05') {
          this.navigateToLogoutPage();
        }
      });
    } else {
      if ((this.userRole == 'rWarden' || this.userRole == 'rClient') && !this.updateSecurity.valid) {
        this.securityForm = true;
      } else if (this.userRole != 'rClient' && this.userRole != 'rWarden' && !this.accountSettingForm.valid) {
        this.invaildSettingsForm = true;
      } else { }
    }
  }

  navigateToLogoutPage() {
    const userInfo = sessionStorage.getItem('loggedInUserInfo'),
      userdetail = JSON.parse(userInfo);

    let logoutRequest = {
      "userLogin": userdetail.userName,
      "systemType": "eCustomer",
      "processName": "LOGOUT",
      "logType ": "REASON_STANDARD_LOGOUT",
      "logMessage": "REASON_STANDARD_LOGOUT",
      "clientId ": ""
    }
    let logoutUrl = this.baseUrl.ecustomer.logoutUrl;
    this.commonService.postData(logoutUrl, logoutRequest, '')
      .subscribe(data => {

        // sessionStorage.clear();
        // this.router.navigate(['/logout']);
        this.clearSessionStorage();
      },
        (error: Error) => {
          this.clearSessionStorage();
        });
  }

  clearSessionStorage() {
    const countryCode = sessionStorage.getItem('countryCode'),
      defaultLangugae = sessionStorage.getItem('defaultLanguage');
    sessionStorage.clear();
    //this.sharedService.setDetail('menuItemList', null);
    //this.sharedService.setcurrentUserLoggedIn([]);
    sessionStorage.setItem("defaultLanguage", defaultLangugae);
    sessionStorage.setItem("countryCode", countryCode);
    //this.idle.stop();
    this.router.navigate(['/logout']);
  }

  onclickEmail() {

  }

  gotoHome() {
    this.changeResponse = '';
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

  toggleFieldTextType(textType) {
    this.currentPasswordFieldTextType = !textType;
  }

  authenticateUser() {
    this.passwordFormsubmitted = true;
    if (this.inputPassword != "") {
      let headers = new HttpHeaders();
      let url = this.baseUrl.ecustomer.authenticate;
      const userInfo = sessionStorage.getItem('loggedInUserInfo'),
        userdetail = JSON.parse(userInfo);

      let request = {
        'userName': userdetail.userName,
        'password': btoa(encodeURIComponent(this.inputPassword))
      }
      this.commonService['postData'](url, request, '').subscribe(data => {
        this.passwordFormResponse = data;
        if (data == true) {
          this.userAuthenticated = true;
        } else {
          this.userAuthenticated = false;
        }
      });
    } else {
      this.userAuthenticated = false;
    }
  }

  restrictPaste() {
    if (this.country === 'ro') {
      this.dialog.openDialog(AlertDialogComponent, { 'heading': 'Alert', 'body': this.translate.instant("eCustomer.loginData.copyPasteDisabled") });
      return false
    }
  }

  question1Change(value) {
    this.questionSet2 = [];
    this.questionSet2 = this.questionSet.filter(function (el) {
      return value.indexOf(el) < 0;
    });
  }

  question2DropdownChange(value) {
    this.questionSet1 = [];
    this.questionSet1 = this.questionSet.filter(function (el) {
      return value.indexOf(el) < 0;
    });
  }

  securityAns() {

    if (this.updateSecurity.value.answer.trim() != "" &&
      (this.updateSecurity.value.question != "-1" && this.updateSecurity.value.question != "0" && this.updateSecurity.value.question !== "")) {
      this.securityQuCheck = false;
      this.securityForm = false;
    } else {
      this.securityQuCheck = true;
      this.securityForm = true;
      if ((this.updateSecurity.value.question != "-1" && this.updateSecurity.value.question != "0" && this.updateSecurity.value.question !== "")) {
        this.updateSecurity.controls.answer.setErrors({ 'required': true });
        this.updateSecurity.controls.answer.setValue('');
      } else {
        this.updateSecurity.controls.question.setErrors({ 'required': true });
        this.updateSecurity.controls.question.setValue('');
      }
    }
    if (!this.securityQuCheck && !this.securityQuCheck2 && this.updateSecurity.value.inputPassword == "" || this.updateSecurity.value.inputPassword == null) {
      this.updateSecurity.controls.inputPassword.setErrors({ 'required': true });
      this.updateSecurity.controls.inputPassword.setValue('');
      this.userAuthenticated = false;
      this.securityForm = true;
    }


  }
  securityAns2() {
    if (this.updateSecurity.value.answer2.trim() != "" &&
      (this.updateSecurity.value.question2 != "-1" && this.updateSecurity.value.question2 != "0" && this.updateSecurity.value.question2 !== "")) {
      this.securityQuCheck2 = false;
      this.securityForm = false;
    } else {
      this.securityQuCheck2 = true;
      this.securityForm = true;
      if ((this.updateSecurity.value.question2 != "-1" && this.updateSecurity.value.question2 != "0" && this.updateSecurity.value.question2 !== "")) {
        this.updateSecurity.controls.answer2.setErrors({ 'required': true });
        this.updateSecurity.controls.answer2.setValue('');
      } else {
        this.updateSecurity.controls.question2.setErrors({ 'required': true });
        this.updateSecurity.controls.question2.setValue('');
      }
    }
    if (!this.securityQuCheck && !this.securityQuCheck2 && this.updateSecurity.value.inputPassword == "" || this.updateSecurity.value.inputPassword == null) {
      this.updateSecurity.controls.inputPassword.setErrors({ 'required': true });
      this.updateSecurity.controls.inputPassword.setValue('');
      this.userAuthenticated = false;
      this.securityForm = true;
    }
  }

  securityQn() {

    if (this.updateSecurity.value.answer &&
      (this.updateSecurity.value.question != "-1" && this.updateSecurity.value.question != "0" && this.updateSecurity.value.question !== "")) {
      this.securityQuCheck = false;
      this.securityForm = false;
    } else {
      this.securityQuCheck = true;
      this.securityForm = true;
    }
    if (!this.securityQuCheck && !this.securityQuCheck2 && this.updateSecurity.value.inputPassword.trim() == "" || this.updateSecurity.value.inputPassword == null) {
      this.updateSecurity.controls.inputPassword.setErrors({ 'required': true });
      this.updateSecurity.controls.inputPassword.setValue('');
      this.userAuthenticated = false;
      this.securityForm = true;
    }


  }
  securityQn2() {
    if (this.updateSecurity.value.answer2 &&
      (this.updateSecurity.value.question2 != "-1" && this.updateSecurity.value.question2 != "0" && this.updateSecurity.value.question2 !== "")) {
      this.securityQuCheck2 = false;
      this.securityForm = false;
    } else {
      this.securityQuCheck2 = true;
      this.securityForm = true;
    }
    if (this.updateSecurity.value.inputPassword == "" || this.updateSecurity.value.inputPassword == null) {
      this.updateSecurity.controls.inputPassword.setErrors({ 'required': true });
      this.updateSecurity.controls.inputPassword.setValue('');
      this.userAuthenticated = false;
      this.securityForm = true;
    }
  }

  passwordFieldInput() {
    if (this.changeResponse == 'Failure' && (this.userRole == 'rClient' || this.userRole == 'rWarden') && this.updateSecurity.value.inputPassword != "") {
      this.changeResponse = '';
    }
    if (this.updateSecurity.value.inputPassword == "" || this.updateSecurity.value.inputPassword == null) {
      this.updateSecurity.controls.inputPassword.setErrors({ 'required': true });
      this.updateSecurity.controls.inputPassword.setValue('');
      this.userAuthenticated = false;
      this.securityForm = true;
    }
  }

}