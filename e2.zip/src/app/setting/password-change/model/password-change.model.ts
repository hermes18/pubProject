import { FormGroup } from '@angular/forms';


export class PasswordChangeModel {
    PasswordChangeForm: FormGroup;
    submitted = false;
    successChangePassword: boolean;
    currentPasswordFieldTextType: boolean;
    newPasswordFieldTextType: boolean;
    confirmPasswordFieldTextType: boolean;
    errorCodeMessage: string;
    date: string;
    subscribeFlag: boolean;
    passwordFieldErr: boolean;
    confirmPasswordFieldErr: boolean;
    constructor() {
        this.date = '';
        this.successChangePassword = false;
        this.submitted = false;
        this.confirmPasswordFieldTextType = false;
        this.newPasswordFieldTextType = false;
        this.currentPasswordFieldTextType = false;
        this.subscribeFlag = true;
        this.passwordFieldErr = false;
        this.confirmPasswordFieldErr  = false;
    }

}