import { HttpHeaders } from '@angular/common/http';
import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NavigationEnd, Router, RouterEvent } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { PasswordChangeModel } from './model/password-change.model';
import { MenuItemsService } from '../../shared-service/menu-items.service';
import { filter, takeWhile } from 'rxjs/operators';


@Component({
  selector: 'password-change',
  templateUrl: './password-change.component.html',
  styleUrls: ['./password-change.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PasswordChangeComponent implements OnInit {

  passwordChangeModel: PasswordChangeModel;
  countryCode = sessionStorage.getItem('countryCode');
  message = "Password change is successfull";

  headers = new HttpHeaders();
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(private dailogService: DialogService,
    public commonService: SharedServiceService, private menuItemService: MenuItemsService,
    private cService: HttpCommonService, public translate: TranslateService, private route: Router,
    public router: Router, public dialog: DialogService) {
    this.passwordChangeModel = new PasswordChangeModel();
  }
  ngOnDestroy() {
    this.passwordChangeModel.subscribeFlag = false;
  }
  ngOnInit() {
    this.formInit();

  }

  formInit() {
    this.passwordChangeModel.PasswordChangeForm = new FormGroup({
      Password: new FormControl('', [Validators.required]),
      ConfirmPassword: new FormControl('', [Validators.required]),
      oldPassword: new FormControl('', [Validators.required])
    });

  }
  @Input() set passwordTabIndex(index) {
    if (this.passwordChangeModel.PasswordChangeForm) {
      this.passwordChangeModel.PasswordChangeForm ? this.passwordChangeModel.PasswordChangeForm.reset() : '';
      this.passwordChangeModel.PasswordChangeForm.markAsUntouched();
      this.passwordChangeModel.submitted = false
      this.passwordChangeModel.PasswordChangeForm.reset();
      this.passwordChangeModel.successChangePassword = false;
      this.passwordChangeModel.errorCodeMessage = '';
    }
  }

  toggleFieldTextType(textType) {
    this.passwordChangeModel[textType] = !this.passwordChangeModel[textType];
  }

  get fValue() { return this.passwordChangeModel.PasswordChangeForm.controls; }

  onSubmit() {
    this.passwordChangeModel.submitted = true;
    // this.checkPwd();
    let url = true
    const userInfo = sessionStorage.getItem('loggedInUserInfo'),
      userdetail = JSON.parse(userInfo);

    if (this.passwordChangeModel.PasswordChangeForm.controls['Password'].errors == null
      && this.passwordChangeModel.PasswordChangeForm.controls['ConfirmPassword'].errors == null
      && this.passwordChangeModel.PasswordChangeForm.controls['oldPassword'].errors == null) {

      let params = {
        oldPassword: btoa(encodeURIComponent(this.passwordChangeModel.PasswordChangeForm.get('oldPassword').value)),
        newPassword: btoa(encodeURIComponent(this.passwordChangeModel.PasswordChangeForm.get('Password').value)),
        reRetypedPassword: btoa(encodeURIComponent(this.passwordChangeModel.PasswordChangeForm.get('ConfirmPassword').value)),
        userId: userdetail.userName,
      }

      // let url = this.baseUrl.ecustomer.changePasswordConfig + '/' + params.userId + '/' + params.oldPassword + '/' + params.newPassword + '/' + params.confirmPassword + '/';
      let url = this.baseUrl.ecustomer.changePasswordConfig
      this.cService.postData(url, params, '')
        .subscribe(data => {


          if (data['errorCode'] != null && (data['errorCode'] == 'LM500408' || data['errorCode'] == 'E00')) {
            this.passwordChangeModel.successChangePassword = true;
            let userTokenParam = JSON.parse(sessionStorage.getItem('userToken'));
            userTokenParam.token = data.token;
            sessionStorage.setItem('userToken', JSON.stringify(userTokenParam));
          } else if (data['errorCode'] == 'LM500210' || data['errorCode'] == 'LM500405' || data['errorCode'] == 'E05') {
            this.navigateToLogoutPage();
          } else {
            this.passwordChangeModel.successChangePassword = false
            this.passwordChangeModel.errorCodeMessage = data['errorCode']
            
            if((this.passwordChangeModel.errorCodeMessage == 'LM500407' || this.passwordChangeModel.errorCodeMessage == 'E07' ||
            this. passwordChangeModel.errorCodeMessage == 'LM500401' || this.passwordChangeModel.errorCodeMessage == 'LM500413' ||
            this.passwordChangeModel.errorCodeMessage == 'LM500414' || this.passwordChangeModel.errorCodeMessage == 'LM500415' ||
            this.passwordChangeModel.errorCodeMessage == 'LM500416' || this.passwordChangeModel.errorCodeMessage == 'LM500417' || 
            this.passwordChangeModel.errorCodeMessage == 'E08' || this.passwordChangeModel.errorCodeMessage == 'LM500409' || 
            this.passwordChangeModel.errorCodeMessage == 'LM500410'|| this.passwordChangeModel.errorCodeMessage == 'LM500411'|| 
            this.passwordChangeModel.errorCodeMessage == 'LM500412'|| this.passwordChangeModel.errorCodeMessage == 'LM500499'
            ) || (this.passwordChangeModel.submitted && this.passwordChangeModel.PasswordChangeForm.controls['Password'].errors )){
              this.passwordChangeModel.passwordFieldErr = true;
            }else{
              this.passwordChangeModel.passwordFieldErr = false;
            }
            
            if((this.passwordChangeModel.errorCodeMessage == 'LM500407' || this.passwordChangeModel.errorCodeMessage == 'E07' ||
            this.passwordChangeModel.errorCodeMessage == 'LM500401' || this.passwordChangeModel.errorCodeMessage == 'LM500413' ||
              this.passwordChangeModel.errorCodeMessage == 'LM500414' || this.passwordChangeModel.errorCodeMessage == 'LM500415' ||
              this.passwordChangeModel.errorCodeMessage == 'LM500416' || this.passwordChangeModel.errorCodeMessage == 'LM500417' ||
              this.passwordChangeModel.errorCodeMessage == 'E08' || this.passwordChangeModel.errorCodeMessage == 'LM500409' ||
              this.passwordChangeModel.errorCodeMessage == 'LM500410' || this.passwordChangeModel.errorCodeMessage == 'LM500411' ||
              this.passwordChangeModel.errorCodeMessage == 'LM500412' || this.passwordChangeModel.errorCodeMessage == 'LM500499' )
              || (this.passwordChangeModel.submitted && this.passwordChangeModel.PasswordChangeForm.controls['ConfirmPassword'].errors)){
                this.passwordChangeModel.confirmPasswordFieldErr = true;
              }else{
                this.passwordChangeModel.confirmPasswordFieldErr = false;
              }
            // if (data['errorCode'] == 'LM500209') {
            //   this.passwordChangeModel.date = data['message'];
            // }
          }

          // }
        });


    }
  }

  restrictPaste() {
    if (this.countryCode === 'ro') {
      this.dialog.openDialog(AlertDialogComponent, { 'heading': this.translate.instant("eCustomer.loginData.Alert"), 'body': this.translate.instant("eCustomer.loginData.copyPasteDisabled") });
      return false
    }
  }

  onClickContact() {
    // this.commonService.getDetail('menuItemList').subscribe((data) => {
    this.passwordChangeModel.submitted = false;
    this.passwordChangeModel.errorCodeMessage = '';
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
    // },
    //   (error: Error) => {
    //     //this.router.navigate(['/homepage']);
    //   });

  }

  navigateToLogoutPage() {
    const userInfo = sessionStorage.getItem('loggedInUserInfo'),
      userdetail = JSON.parse(userInfo);
    let logoutRequest = {
      "userLogin": userdetail.userName,
      "systemType": "eCustomer",
      "processName": "LOGOUT",
      "logType ": "REASON_STANDARD_LOGOUT",
      "logMessage": "REASON_STANDARD_LOGOUT",
      "clientId ": ""
    }
    let logoutUrl = this.baseUrl.ecustomer.logoutUrl;
    this.cService.postData(logoutUrl, logoutRequest, '')
      .subscribe(data => {
        //('logout');
        // sessionStorage.clear();
        // this.router.navigate(['/logout']);
        this.clearSessionStorage();
      },
        (error: Error) => {
          this.clearSessionStorage();
        });
  }

  clearSessionStorage() {
    const countryCode = sessionStorage.getItem('countryCode'),
      defaultLangugae = sessionStorage.getItem('defaultLanguage');
    sessionStorage.clear();
    //this.sharedService.setDetail('menuItemList', null);
    // this.sharedService.setcurrentUserLoggedIn([]);
    sessionStorage.setItem("defaultLanguage", defaultLangugae);
    sessionStorage.setItem("countryCode", countryCode);
    // this.idle.stop();
    this.router.navigate(['/logout']);
  }

}
