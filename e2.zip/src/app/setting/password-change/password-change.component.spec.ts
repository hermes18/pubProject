import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { SettingModule } from '../setting.module';

import { PasswordChangeComponent } from './password-change.component';

describe('PasswordChangeComponent', () => {
  let component: PasswordChangeComponent;
  let fixture: ComponentFixture<PasswordChangeComponent>;

  // beforeEach(async(() => {

  // }));
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'changePasswordConfig': host + '/api/v1/users/change-password'
      }
    }
  };
  beforeEach(() => {
    const country = "ro";
    sessionStorage.setItem('countryCode', country);

    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, SettingModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService]
    })
      .compileComponents();
    fixture = TestBed.createComponent(PasswordChangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
 
  
  it('call clearSessionStorage', () => {
    spyOn(component , 'clearSessionStorage').and.callThrough();
    component.clearSessionStorage();
    expect(component.clearSessionStorage).toHaveBeenCalledWith();
  
  });
 
});
