import { FormGroup } from '@angular/forms';


export class AddNewUserModel {
    addnewaccount: FormGroup;
    subscribeFlag: boolean;
    submitted: boolean;
    saveSection: boolean;
    userrole: Array<any>;
    userrolePO: Array<any>;
    userroleRO: Array<any>;
    userroleCheckList: Array<any>;
    userTypeListPO;
    userTypeListRO;
    defaultUserTypeList;
    userroleList: Array<any>;
    checkedUserRole: boolean;
    userRoleArrayValue: Array<any>;
    showwEmailInValid: boolean;
    addNewAccountValue;
    errorCode;
    errorCodeConfirm;
    errorCodeConfig;
    renderConfirmMessagePage: boolean;
    renderConfigMessagePage: boolean;
    renderSavePage: boolean;
    errorFlag: boolean;
    userRoleError: boolean;
    validationErrorFlag: boolean;
    accountAlreadyExistError: boolean;
    userDataValue;
    accountConfigCorrupted: boolean;
    accountCreatedByOtherAppln: boolean;
    renderUserLinkedSuccessMsg: boolean
    renderUserRepairedSuccessMsg: boolean;
    boradCastData;
    userConfigData;
    noClientDataError: boolean;
    editUserNavigate: boolean;
    userWithEmailAlreadyExists: boolean;
    userRoleName: Array<any>;
    constructor() {
        this.showwEmailInValid = false;
        this.subscribeFlag = true;
        this.submitted = false;
        this.saveSection = true;
        this.checkedUserRole = false;
        this.renderUserLinkedSuccessMsg = false;
        this.renderUserRepairedSuccessMsg = false;
        this.renderConfirmMessagePage = false;
        this.renderConfigMessagePage = false;
        this.accountConfigCorrupted = false;
        this.accountCreatedByOtherAppln = false;
        this.renderSavePage = false;
        this.errorFlag = false;
        this.userRoleError = false;
        this.validationErrorFlag = false;
        this.accountAlreadyExistError = false;
        this.noClientDataError = false;
        this.editUserNavigate = false;
        this.userWithEmailAlreadyExists = false;
        this.userRoleArrayValue = []
        this.userRoleName = []
        this.userTypeListPO = [
            {
                key: "Employee",
                value: "Employee"
            },
            {
                key: "Customer",
                value: "Client"
            },
            /** {
                key: "Advisor",
                value: "Advisor"
            },*/
            {
                key: "Warden",
                value: "Warden"
            }
        ]
        this.userTypeListRO = [
            {
                key: "Employee",
                value: "Employee"
            },
            {
                key: "Customer",
                value: "Client"
            }
            // {
            //     key: "Advisor",
            //     value: "Advisor"
            // }
        ]

        this.defaultUserTypeList = [{
            key: "Customer",
            value: "Client"
        }]


        this.userrole = [{ name: 'Client', value: 'rClient', flag: true },
        { name: 'Standard User', value: 'rStandardUser', flag: true },
        { name: 'Super User', value: 'rSuperUser', flag: true },
        { name: 'System Administrator', value: 'rAdministrator', flag: true },
        { name: 'User Account Manager', value: 'rUserAccountManager', flag: true },
        /**  { name: 'Advisor', value: 'rAdvisor', flag: true }, */
        { name: 'Warden', value: 'rWarden', flag: true }
        ]


        this.userroleRO = [{ name: 'Client', value: 'rClient', flag: true },
        { name: 'Standard User', value: 'rStandardUser', flag: true },
        { name: 'Super User', value: 'rSuperUser', flag: true },
        { name: 'System Administrator', value: 'rAdministrator', flag: true }
            // { name: 'Advisor', value: 'rAdvisor', flag: true }
        ]


        this.userrolePO = [{ name: 'Client', value: 'rClient', flag: true },
        { name: 'Standard User', value: 'rStandardUser', flag: true },
        { name: 'Super User', value: 'rSuperUser', flag: true },
        { name: 'System Administrator', value: 'rAdministrator', flag: true },
        { name: 'User Account Manager', value: 'rUserAccountManager', flag: true },
        /**  { name: 'Advisor', value: 'rAdvisor', flag: true },*/
        { name: 'Warden', value: 'rWarden', flag: true }
        ]
    }

}