import { Component, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { eClaimsConstants } from 'src/app/core/constant/constant';
import { BroadcasterService } from 'src/app/core/services/broadcaster.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { AddNewUserModel } from './model/add-new-user.model';
import { DeviceDetectorService } from 'ngx-device-detector';
import { countryList, UtilityService } from 'src/app/shared/utilities/utility.service';
import * as lodash from "lodash";
import { AddNewUserUtility } from './add-new-user-utility/add-new-user-utility';

@Component({
  selector: 'add-new-user',
  templateUrl: './add-new-user.component.html',
  styleUrls: ['./add-new-user.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AddNewUserComponent implements OnInit {
  detail: any;
  addNewUserModel: AddNewUserModel;
  country = sessionStorage.getItem('countryCode');

  addNewUserEnableCountry = eClaimsConstants.addNewUserEnableCountry;
  enablePolandCountry = countryList.enablePolandCountry;
  enableGreeceCountry = countryList.enableGreeceCountry;

  //enableGreeceCountry;

  //country: string;
  lang: string;
  displayPoOption: boolean = false;
  displayRoOption: boolean = false;
  @Output('userAccountValue') valueChange = new EventEmitter<any>();
  @Output('userIdValue') userValue = new EventEmitter<any>();
  settingParamValue = {
    'userAccount': false,
    'addNewUser': false,
    'editUser': false
  }
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(public fb: FormBuilder, public commonService: HttpCommonService, public router: Router,
    private sharedService: SharedServiceService, public deviceDetector: DeviceDetectorService, private readonly broadCastService: BroadcasterService, private addnewUtility: AddNewUserUtility) {
    this.addNewUserModel = new AddNewUserModel();
  }
  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    if (this.country === 'gr') {
      this.addNewUserModel.userTypeListPO = lodash.filter(this.addNewUserModel.userTypeListPO, (o) => {
        if (o.key !== 'Warden') {
          return o;
        }
      });
      const hrRoleValue = {
        key: "HR",
        value: "HR"
      };
      this.addNewUserModel.userTypeListPO.push(hrRoleValue);
      // const roleListForHR =
      //   { name: 'HR', value: 'rHR', flag: true }

      // this.addNewUserModel.userrole.push(roleListForHR);
      let systemRole = this.addnewUtility.getSystemRoleList();
      this.addNewUserModel.userrole = systemRole;

    }
    this.addNewUserModel.addnewaccount = this.fb.group({
      userType: ['', [Validators.required]],
      firstName: ['', [Validators.required]],
      userName: ['', [Validators.required]],
      customerId: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      emailID: ['', [Validators.required]],
      language: ['', [Validators.required]],
      userrole: this.createCheckList(this.addNewUserModel.userrole)

    });

    this.lang = sessionStorage.getItem('defaultLanguage');
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      // if (this.country.toLowerCase() == 'pl') {
      this.displayPoOption = true;
      this.addNewUserModel.addnewaccount.addControl('globalEmpID', new FormControl('', [Validators.required]));
      this.addNewUserModel.addnewaccount.addControl('mobile', new FormControl('', [Validators.required]));
      this.addNewUserModel.userrole = this.addNewUserModel.userrolePO
    }
    else {
      this.displayRoOption = true;
      this.addNewUserModel.userrole = this.addNewUserModel.userroleRO
    }
    if (this.country === 'gr') {
      // this.addNewUserModel.userrolePO = lodash.filter(this.addNewUserModel.userrolePO, (o) => {
      //   if (o.name !== 'Warden') {
      //     return o;
      //   }
      // });
      // this.addNewUserModel.userrole = this.addNewUserModel.userrolePO
      // const roleListForHR =
      //   { name: 'HR', value: 'rHR', flag: true }

      // this.addNewUserModel.userrole.push(roleListForHR);
      let systemRole = this.addnewUtility.getSystemRoleList();
      this.addNewUserModel.userrole = systemRole;
    }


    const loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    if (this.sharedService.boradcastData) {
      this.patchData();
      if (loggedInUserDetail.roleInfo.length == 1 && loggedInUserDetail.roleInfo[0].name === 'rUserAccountManager') {
        // this.addNewUserModel.addnewaccount.controls.userType.setValue('Client');
        // this.addNewUserModel.userTypeListRO = this.addNewUserModel.defaultUserTypeList;
        this.addNewUserModel.userTypeListPO = this.addNewUserModel.defaultUserTypeList;
      }
    } else {
      this.setDefaultValue();
    }

  }

  setDefaultValue() {
    const loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));

    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      // if (this.country.toLowerCase() == 'pl') {
      //this.addNewUserModel.addnewaccount.controls.language.setValue('pl');
      this.addNewUserModel.addnewaccount.controls.language.setValue(this.country.toLowerCase());
    }
    else {
      this.addNewUserModel.addnewaccount.controls.language.setValue('ro');
    }

    if (loggedInUserDetail.roleInfo.length == 1 && loggedInUserDetail.roleInfo[0].name === 'rUserAccountManager') {
      this.addNewUserModel.addnewaccount.controls.userType.setValue('Client');
      // this.addNewUserModel.userTypeListRO = this.addNewUserModel.defaultUserTypeList;
      this.addNewUserModel.userTypeListPO = this.addNewUserModel.defaultUserTypeList;

    } else {
      this.addNewUserModel.addnewaccount.controls.userType.setValue('Employee');
    }


    this.addNewUserValue();
  }
  createCheckList(checkList) {

    // let country = JSON.parse(sessionStorage.getItem('userData')).country;
    let country = sessionStorage.getItem('countryCode');
    const arr = this.addnewUtility.countryBaseRoleList(checkList)
    console.log(arr)
    // const arr = checkList.map(purpose => {
    //   if (!((purpose.value == 'rWarden' || purpose.value == 'rUserAccountManager') && country.toLowerCase() == 'ro') && !((purpose.value == 'rWarden') && country.toLowerCase() == 'gr'))
    //     return new FormControl('');
    // });
    this.addNewUserModel.userroleCheckList = arr.filter(item => item !== undefined)
    const arrList = this.addnewUtility.getUserRoleList(checkList);
    // console.log(test);
    // const arrList = checkList.map(purpose => {
    //   if (!((purpose.value == 'rWarden' || purpose.value == 'rUserAccountManager') && country.toLowerCase() == 'ro') && !((purpose.value == 'rWarden') && country.toLowerCase() == 'gr'))
    //     return purpose;
    // });
    this.addNewUserModel.userroleList = arrList.filter(item => item !== undefined)

    return new FormArray(this.addNewUserModel.userroleCheckList, [Validators.required]);
  }

  onCheckboxChange(data: string, isChecked: boolean, indexValue: string) {


    if (isChecked) {
      this.addNewUserModel.userRoleArrayValue.push(data)
      this.addNewUserModel.userrole[indexValue].flag = true;
      let value = this.addNewUserModel.userrole[indexValue].name
      this.addNewUserModel.userRoleName.push(value)
      // roleArray.push(new FormControl(data));
    } else {

      // let index = this.addNewUserModel.userRoleArrayValue.findIndex(x => x.value == data)
      const index = this.addNewUserModel.userRoleArrayValue.indexOf(data);
      if (index > -1) {
        this.addNewUserModel.userRoleArrayValue.splice(index, 1);
        // this.addNewUserModel.userRoleName.splice(index, 1);
      }
      let value = this.addNewUserModel.userrole[indexValue].name
      const index1 = this.addNewUserModel.userRoleName.indexOf(value);
      if (index1 > -1) {
        this.addNewUserModel.userRoleName.splice(index1, 1);
        // this.addNewUserModel.userRoleName.splice(index, 1);
      }

      // let index = parseInt(indexValue);
      // this.addNewUserModel.userRoleArrayValue.splice(index);
      // this.addNewUserModel.userRoleName.splice(index);
      this.addNewUserModel.userrole[indexValue].flag = false;
    }
    // this.addNewUserModel.userRoleName = this.addNewUserModel.userRoleArrayValue
    if (this.addNewUserModel.userRoleName) {

      this.addNewUserModel.userRoleName.sort();
    }

  }
  clearValue() {
    this.addNewUserModel.userConfigData = {
      userName: '',
      accountConfigCorrupted: '',
      accountCreatedByOtherAppln: '',
      ldap_fName: '',
      ldap_LName: '',
      ldap_mail: '',
      ldap_phone: '',
      ldap_preferredLanguage: '',
      ldap_globalEmployeeId: '',
      clientId: '',
      userRoles: '',
      userType: '',
      authorizedApplicationCode: '',
      partialconfiguration: '',
    }
    this.addNewUserModel.addNewAccountValue = {
      userType: '',
      firstName: '',
      lastName: '',
      userName: '',
      email: '',
      globalEmployeeId: '',
      clientId: '',
      mobile: '',
      language: '',
      userRoles: '',
      roleInfo: '',
    }
  }
  submit() {
    this.addNewUserModel.submitted = true;
    const detail = this.addNewUserModel.addnewaccount.value;

    this.clearValue();
    const loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));


    if (this.addNewUserModel.addnewaccount.valid && this.addNewUserModel.userRoleArrayValue.length != 0) {
      if (this.addNewUserModel.addnewaccount.controls.userType.value === 'Client'
        || this.addNewUserModel.addnewaccount.controls.userType.value === 'HR' || this.addNewUserModel.addnewaccount.controls.userType.value === 'Warden') {

        this.addNewUserModel.addNewAccountValue = {
          userType: this.addNewUserModel.addnewaccount.get('userType').value,
          firstName: '',
          lastName: '',
          userName: this.country.toLowerCase() == 'ro' ? this.addNewUserModel.addnewaccount.get('userName').value : '',
          email: '',
          globalEmployeeId: '',
          clientId: this.addNewUserModel.addnewaccount.get('customerId').value,
          mobile: '',
          language: this.addNewUserModel.addnewaccount.get('language').value,
          userRoles: this.addNewUserModel.userRoleArrayValue,
          roleInfo: loggedInUserDetail.roleInfo,
        }
        let url = this.baseUrl.ecustomer.clientdata;
        this.commonService.postData(url, this.addNewUserModel.addNewAccountValue, '').subscribe(data => {

          this.addNewUserModel.userDataValue = data;
          this.addNewUserModel.addNewAccountValue = {
            userType: data.userType,
            firstName: data.firstName != null && data.firstName != '' ? data.firstName : '',
            lastName: data.lastName != null && data.lastName != '' ? data.lastName : '',
            userName: data.userName != null && data.userName != '' ? data.userName : '',
            email: data.email != null && data.email != '' ? data.email : '',
            globalEmployeeId: data.globalEmployeeId != null && data.globalEmployeeId != '' ? data.globalEmployeeId : '',
            clientId: data.clientId != null && data.clientId != '' ? data.clientId : '',
            mobile: data.mobile != null && data.mobile != '' ? data.mobile : '',
            language: data.language != null && data.language != '' ? data.language : '',
            userRoles: data.userRoles,
          }
          this.ldapDataConfig(data);
          // this.addNewUserModel.addnewaccount.controls.mobile.setValue(data.mobile != null && data.mobile != '' ? data.mobile : '');
          // this.addNewUserModel.addnewaccount.controls.emailID.setValue(data.email != null && data.email != '' ? data.email : '');
          this.addNewUserModel.addnewaccount.controls.firstName.setValue(data.firstName != null && data.firstName != '' ? data.firstName : '');
          this.addNewUserModel.addnewaccount.controls.lastName.setValue(data.lastName != null && data.lastName != '' ? data.lastName : '');
          if (this.country.toLowerCase() != 'ro') {
            this.addNewUserModel.addnewaccount.controls.userName.setValue(data.userName != null && data.userName != '' ? data.userName : '');
          }
          this.addNewUserModel.renderConfirmMessagePage = data.renderConfirmMessagePage
          this.addNewUserModel.renderConfigMessagePage = data.renderConfigMessagePage
          this.addNewUserModel.saveSection = data.renderSavePage
          this.addNewUserModel.errorFlag = data.errorFlag
          this.addNewUserModel.userRoleError = data.userRoleError
          this.addNewUserModel.validationErrorFlag = data.validationErrorFlag
          this.addNewUserModel.accountAlreadyExistError = data.accountAlreadyExistError
          this.addNewUserModel.accountConfigCorrupted = data.accountConfigCorrupted
          this.addNewUserModel.accountCreatedByOtherAppln = data.accountCreatedByOtherAppln
          this.addNewUserModel.noClientDataError = data.noClientDataError
          this.addNewUserModel.userWithEmailAlreadyExists = data.userWithEmailAlreadyExists
          this.sharedService.setPramaValue('boradcastData', this.addNewUserModel.userDataValue);
          this.sharedService.setPramaValue('addNewAccountFormData', this.addNewUserModel.addNewAccountValue);
          this.sharedService.setPramaValue('userRoleData', this.addNewUserModel.userRoleName)
          if (!data.renderSavePage && !data.noClientDataError && !data.userWithEmailAlreadyExists) {

            this.addNewUserModel.boradCastData = {
              addNewUser: true,
              clientId: this.addNewUserModel.addnewaccount.get('customerId').value,
            }
            this.broadCastService.broadcast('addNewUser', this.addNewUserModel.boradCastData);
            this.router.navigate(['./contactdetail']);
          }
          if (data.noClientDataError || data.userWithEmailAlreadyExists) {
            this.addNewUserModel.saveSection = true;
            this.addNewUserModel.renderConfirmMessagePage = false
            this.addNewUserModel.renderConfigMessagePage = false
          }
        });

      } else if (this.addNewUserModel.addnewaccount.controls.userType.value === 'Advisor') {
        this.addNewUserModel.addNewAccountValue = {
          userType: this.addNewUserModel.addnewaccount.get('userType').value,
          firstName: '',
          lastName: '',
          userName: this.addNewUserModel.addnewaccount.get('userName').value,
          email: this.addNewUserModel.addnewaccount.get('emailID').value,
          globalEmployeeId: '',
          clientId: this.addNewUserModel.addnewaccount.get('customerId').value,
          mobile: '',
          language: this.addNewUserModel.addnewaccount.get('language').value,
          userRoles: this.addNewUserModel.userRoleArrayValue,
          roleInfo: loggedInUserDetail.roleInfo,
        }
        let url = this.baseUrl.ecustomer.clientdata;
        this.commonService.postData(url, this.addNewUserModel.addNewAccountValue, '').subscribe(data => {

          this.addNewUserModel.userDataValue = data;
          this.addNewUserModel.addNewAccountValue = {
            userType: data.userType,
            firstName: data.firstName != null && data.firstName != '' ? data.firstName : '',
            lastName: data.lastName != null && data.lastName != '' ? data.lastName : '',
            userName: data.userName != null && data.userName != '' ? data.userName : '',
            email: data.email != null && data.email != '' ? data.email : '',
            globalEmployeeId: data.globalEmployeeId != null && data.globalEmployeeId != '' ? data.globalEmployeeId : '',
            clientId: data.clientId != null && data.clientId != '' ? data.clientId : '',
            mobile: data.mobile != null && data.mobile != '' ? data.mobile : '',
            language: data.language != null && data.language != '' ? data.language : '',
            userRoles: data.userRoles,
          }
          this.ldapDataConfig(data);
          if (this.addNewUserModel.addnewaccount.controls.mobile) {
            this.addNewUserModel.addnewaccount.controls.mobile.setValue(data.mobile != null && data.mobile != '' ? data.mobile : '');
          }
          this.addNewUserModel.addnewaccount.controls.emailID.setValue(data.email != null && data.email != '' ? data.email : '');
          this.addNewUserModel.addnewaccount.controls.firstName.setValue(data.firstName != null && data.firstName != '' ? data.firstName : '');
          this.addNewUserModel.addnewaccount.controls.lastName.setValue(data.lastName != null && data.lastName != '' ? data.lastName : '');
          this.addNewUserModel.addnewaccount.controls.userName.setValue(data.userName != null && data.userName != '' ? data.userName : '');
          this.addNewUserModel.renderConfirmMessagePage = data.renderConfirmMessagePage
          this.addNewUserModel.renderConfigMessagePage = data.renderConfigMessagePage
          this.addNewUserModel.saveSection = data.renderSavePage
          this.addNewUserModel.errorFlag = data.errorFlag
          this.addNewUserModel.userRoleError = data.userRoleError
          this.addNewUserModel.validationErrorFlag = data.validationErrorFlag
          this.addNewUserModel.accountAlreadyExistError = data.accountAlreadyExistError
          this.addNewUserModel.accountConfigCorrupted = data.accountConfigCorrupted
          this.addNewUserModel.accountCreatedByOtherAppln = data.accountCreatedByOtherAppln
          this.addNewUserModel.noClientDataError = data.noClientDataError
          this.addNewUserModel.userWithEmailAlreadyExists = data.userWithEmailAlreadyExists
          if (data.userWithEmailAlreadyExists || data.noClientDataError) {
            this.addNewUserModel.saveSection = true;
            this.addNewUserModel.renderConfirmMessagePage = false
            this.addNewUserModel.renderConfigMessagePage = false
          }
        });

      } else {
        this.addNewUserModel.addNewAccountValue = {
          userType: this.addNewUserModel.addnewaccount.get('userType').value,
          firstName: this.addNewUserModel.addnewaccount.get('firstName').value,
          lastName: this.addNewUserModel.addnewaccount.get('lastName').value,
          userName: this.addNewUserModel.addnewaccount.get('userName').value,
          email: this.addNewUserModel.addnewaccount.get('emailID').value,
          globalEmployeeId: this.addNewUserModel.addnewaccount.controls.globalEmpID ? this.addNewUserModel.addnewaccount.get('globalEmpID').value : '',
          clientId: '',
          mobile: '',
          language: this.addNewUserModel.addnewaccount.get('language').value,
          userRoles: this.addNewUserModel.userRoleArrayValue,
          roleInfo: loggedInUserDetail.roleInfo,
        }
        let url = this.baseUrl.ecustomer.clientdata;
        this.commonService.postData(url, this.addNewUserModel.addNewAccountValue, '').subscribe(data => {

          this.addNewUserModel.userDataValue = data;
          this.addNewUserModel.addNewAccountValue = {
            userType: data.userType,
            firstName: data.firstName != null && data.firstName != '' ? data.firstName : '',
            lastName: data.lastName != null && data.lastName != '' ? data.lastName : '',
            userName: data.userName != null && data.userName != '' ? data.userName : '',
            email: data.email != null && data.email != '' ? data.email : '',
            globalEmployeeId: data.globalEmployeeId != null && data.globalEmployeeId != '' ? data.globalEmployeeId : '',
            clientId: data.clientId != null && data.clientId != '' ? data.clientId : '',
            mobile: data.mobile != null && data.mobile != '' ? data.mobile : '',
            language: data.language != null && data.language != '' ? data.language : '',
            userRoles: data.userRoles,
          }
          this.ldapDataConfig(data);


          this.addNewUserModel.renderConfirmMessagePage = data.renderConfirmMessagePage
          this.addNewUserModel.renderConfigMessagePage = data.renderConfigMessagePage
          this.addNewUserModel.saveSection = data.renderSavePage
          this.addNewUserModel.errorFlag = data.errorFlag
          this.addNewUserModel.userRoleError = data.userRoleError
          this.addNewUserModel.validationErrorFlag = data.validationErrorFlag
          this.addNewUserModel.accountAlreadyExistError = data.accountAlreadyExistError
          this.addNewUserModel.accountConfigCorrupted = data.accountConfigCorrupted
          this.addNewUserModel.accountCreatedByOtherAppln = data.accountCreatedByOtherAppln
          this.addNewUserModel.noClientDataError = data.noClientDataError
          this.addNewUserModel.userWithEmailAlreadyExists = data.userWithEmailAlreadyExists
          if (data.userWithEmailAlreadyExists) {
            this.addNewUserModel.saveSection = true;
            this.addNewUserModel.renderConfirmMessagePage = false
            this.addNewUserModel.renderConfigMessagePage = false
          }
        });

      }
    }
    window.scrollTo(0, 0);
  }

  ldapDataConfig(data) {
    this.addNewUserModel.userConfigData = {
      userName: data.userName != null && data.userName != '' ? data.userName : '',
      accountConfigCorrupted: data.accountConfigCorrupted,
      accountCreatedByOtherAppln: data.accountCreatedByOtherAppln,
      ldap_fName: data.ldap_fName != null && data.ldap_fName != '' ? data.ldap_fName : '',
      ldap_LName: data.ldap_LName != null && data.ldap_LName != '' ? data.ldap_LName : '',
      ldap_mail: data.ldap_mail != null && data.ldap_mail != '' ? data.ldap_mail : '',
      ldap_phone: data.ldap_phone != null && data.ldap_phone != '' ? data.ldap_phone : '',
      ldap_preferredLanguage: data.ldap_preferredLanguage != null && data.ldap_preferredLanguage != '' ? data.ldap_preferredLanguage : '',
      ldap_globalEmployeeId: data.ldap_globalEmployeeId != null && data.ldap_globalEmployeeId != '' ? data.ldap_globalEmployeeId : '',
      clientId: data.clientId != null && data.clientId != '' ? data.clientId : '',
      userRoles: data.userRoles,
      userType: data.userType,
      partialconfiguration: data.partialconfiguration,
      authorizedApplicationCode: data.authorizedApplicationCode != null && data.authorizedApplicationCode != '' ? data.authorizedApplicationCode : '',
    }
    this.sharedService.setPramaValue('addNewUserLdapData', this.addNewUserModel.userConfigData);
  }

  changecheckbox() {
    const userTypeValue = this.addNewUserModel.addnewaccount.controls.userType.value;
    const langValue = this.addNewUserModel.addnewaccount.controls.language.value
    // this.addNewUserModel.addnewaccount.reset();
    this.addNewUserModel.addnewaccount.controls.userrole.reset();
    this.addNewUserModel.addnewaccount.addControl('userrole', this.createCheckList(this.addNewUserModel.userrole));
    this.addNewUserModel.addnewaccount.get('firstName').setValue('');
    this.addNewUserModel.addnewaccount.get('lastName').setValue('');
    this.addNewUserModel.addnewaccount.get('userName').setValue('');
    this.addNewUserModel.addnewaccount.get('emailID').setValue('');
    this.addNewUserModel.addnewaccount.get('customerId').setValue('');
    if (this.addNewUserModel.addnewaccount.controls.globalEmpID) {
      this.addNewUserModel.addnewaccount.get('globalEmpID').setValue('');
    }
    if (this.addNewUserModel.addnewaccount.controls.mobile) {
      this.addNewUserModel.addnewaccount.get('mobile').setValue('');
    }
    this.addNewUserModel.userRoleArrayValue = [];
    this.addNewUserModel.addnewaccount.controls.userType.setValue(userTypeValue);
    this.addNewUserModel.addnewaccount.controls.language.setValue(langValue);
    this.addNewUserModel.showwEmailInValid = false;
    this.addNewUserModel.submitted = false;
    this.addNewUserModel.userWithEmailAlreadyExists = false;
    this.addNewUserModel.noClientDataError = false;
    this.addNewUserModel.userRoleName = []
    for (let index = 0; index < this.addNewUserModel.userrole.length; index++) {
      this.addNewUserModel.userrole[index].flag = true;

    }
    this.addNewUserValue();
  }

  addNewUserValue() {

    this.addNewUserModel.checkedUserRole = false;
    switch (this.addNewUserModel.addnewaccount.controls.userType.value) {
      case 'Employee': {
        this.addNewUserModel.addnewaccount.controls.firstName.enable();
        this.addNewUserModel.addnewaccount.controls.userName.enable();
        this.addNewUserModel.addnewaccount.controls.lastName.enable();
        this.addNewUserModel.addnewaccount.controls.emailID.enable();

        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.globalEmpID.enable();
        }
        this.addNewUserModel.addnewaccount.controls.customerId.disable();
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.mobile.disable();
        }
        let valueList = ['rStandardUser', 'rSuperUser', 'rAdministrator', 'rUserAccountManager'];
        if (this.country == 'gr') {
          valueList = ['rGroupAdmin', 'rSuperUser', 'rIndividualAdmin'];

        }
        this.disableCheckbox(valueList);
        this.addNewUserModel.checkedUserRole = false;
        break;
      }
      case 'Client': {

        this.addNewUserModel.addnewaccount.controls.customerId.enable();

        this.addNewUserModel.addnewaccount.controls.firstName.disable();

        this.addNewUserModel.addnewaccount.controls.lastName.disable();
        this.addNewUserModel.addnewaccount.controls.emailID.disable();
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.userName.disable();
        } else {
          this.addNewUserModel.addnewaccount.controls.userName.enable();
        }
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.globalEmpID.disable();
        }
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.mobile.disable();
        }
        let valueList = ['rClient']
        this.disableCheckbox(valueList);
        this.addNewUserModel.checkedUserRole = true;
        this.disableCheckboxValue(valueList);
        this.addNewUserModel.userRoleArrayValue.push('rClient')
        this.addNewUserModel.userRoleName.push('Client')
        break;
      }
      case 'Advisor': {

        this.addNewUserModel.addnewaccount.controls.customerId.enable();

        this.addNewUserModel.addnewaccount.controls.userName.enable();
        this.addNewUserModel.addnewaccount.controls.emailID.enable();


        this.addNewUserModel.addnewaccount.controls.firstName.disable();
        this.addNewUserModel.addnewaccount.controls.lastName.disable();
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.globalEmpID.disable();
        }
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.mobile.disable();
        }
        let valueList = ['rAdvisor']
        this.disableCheckbox(valueList);
        this.addNewUserModel.checkedUserRole = true;
        this.disableCheckboxValue(valueList);
        this.addNewUserModel.userRoleArrayValue.push('rAdvisor')
        this.addNewUserModel.userRoleName.push('Advisor')
        break;
      }
      case 'Warden': {
        this.addNewUserModel.addnewaccount.controls.customerId.enable();

        this.addNewUserModel.addnewaccount.controls.firstName.disable();
        this.addNewUserModel.addnewaccount.controls.userName.disable();
        this.addNewUserModel.addnewaccount.controls.lastName.disable();
        this.addNewUserModel.addnewaccount.controls.emailID.disable();

        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.globalEmpID.disable();
        }
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.mobile.disable();
        }
        let valueList = ['rWarden']
        this.disableCheckbox(valueList);
        this.addNewUserModel.checkedUserRole = true;
        this.disableCheckboxValue(valueList);
        this.addNewUserModel.userRoleArrayValue.push('rWarden')
        this.addNewUserModel.userRoleName.push('Warden')
        break;
      }
      case 'HR': {

        this.addNewUserModel.addnewaccount.controls.customerId.enable();

        this.addNewUserModel.addnewaccount.controls.firstName.disable();

        this.addNewUserModel.addnewaccount.controls.lastName.disable();
        this.addNewUserModel.addnewaccount.controls.emailID.disable();
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.userName.disable();
        } else {
          this.addNewUserModel.addnewaccount.controls.userName.enable();
        }
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.globalEmpID.disable();
        }
        if (this.addNewUserEnableCountry.indexOf(this.country) != -1) {
          this.addNewUserModel.addnewaccount.controls.mobile.disable();
        }
        let valueList = ['rHR']
        this.disableCheckbox(valueList);
        this.addNewUserModel.checkedUserRole = true;
        this.disableCheckboxValue(valueList);
        this.addNewUserModel.userRoleArrayValue.push('rHR')
        this.addNewUserModel.userRoleName.push('HR')
        break;
      }
    }
  }

  disableCheckbox(valueList) {
    let value = valueList;
    const control = this.addNewUserModel.addnewaccount.controls.userrole as FormArray;
    // if (valueList.length > 0) {
    for (let i = 0; i < valueList.length; i++) {

      for (let j = 0; j < this.addNewUserModel.userroleList.length; j++) {
        if (this.addNewUserModel.userroleList[j].value == valueList[i]) {
          control.at(j).enable();

        } else {
          if (valueList.indexOf(this.addNewUserModel.userroleList[j].value) < 0) {
            control.at(j).disable();
            control.at(j).setValidators([Validators.nullValidator]);
          }

        }
      }
    }
    // } else {
    //   for (let j = 0; j < this.addNewUserModel.userroleList.length; j++) {
    //     control.at(j).disable();
    //   }
    // }


  }

  disableCheckboxValue(valueList) {
    const control = this.addNewUserModel.addnewaccount.controls.userrole as FormArray;
    // if (valueList.length > 0) {
    for (let i = 0; i < valueList.length; i++) {

      for (let j = 0; j < this.addNewUserModel.userroleList.length; j++) {
        if (this.addNewUserModel.userroleList[j].value == valueList[i]) {

          control.at(j).disable();
          control.at(j).setValidators([Validators.nullValidator]);
        }

      }
    }
  }

  emailValidation() {
    if (this.country.toLowerCase() !== 'gr') {
      this.addNewUserModel.showwEmailInValid = false;
      // let url = this.baseUrl.ecustomer.getQuestionSet;
      let emailID = this.addNewUserModel.addnewaccount.controls.emailID.value;
      if (this.addNewUserModel.addnewaccount.controls.emailID.value != '' && this.addNewUserModel.addnewaccount.controls.emailID.value != null) {
        // let url = this.baseUrl.ecustomer.emailvalidation + '/' + emailID + '/' + 'validate';
        let url = this.baseUrl.ecustomer.emailvalidation,
          param = {
            email: emailID
          };
        this.commonService['postData'](url, param, '').subscribe(data => {

          if (data == true) {
            this.addNewUserModel.showwEmailInValid = false;
          } else {
            this.addNewUserModel.showwEmailInValid = true;
          }

        });
      }
    }

  }


  backSearchUser() {
    this.settingParamValue.addNewUser = false;
    this.settingParamValue.editUser = false;
    this.settingParamValue.userAccount = true;
    this.sharedService.setPramaValue('boradcastData', null);
    this.sharedService.setPramaValue('addNewAccountFormData', null);
    this.sharedService.setPramaValue('userRoleData', null)
    this.addNewUserModel.editUserNavigate = false;
    this.valueChange.emit(this.settingParamValue);
    this.addNewUserModel.errorCodeConfirm = '';
  }

  createUser() {
    const loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let url = this.baseUrl.ecustomer.addUser;
    let param = {
      userType: this.addNewUserModel.addNewAccountValue.userType != null && this.addNewUserModel.addNewAccountValue.userType != '' ? this.addNewUserModel.addNewAccountValue.userType : null,
      firstName: this.addNewUserModel.addNewAccountValue.firstName != null && this.addNewUserModel.addNewAccountValue.firstName != '' ? this.addNewUserModel.addNewAccountValue.firstName : '',
      lastName: this.addNewUserModel.addNewAccountValue.lastName != null && this.addNewUserModel.addNewAccountValue.lastName != '' ? this.addNewUserModel.addNewAccountValue.lastName : '',
      userName: this.addNewUserModel.addNewAccountValue.userName != null && this.addNewUserModel.addNewAccountValue.userName != '' ? this.addNewUserModel.addNewAccountValue.userName : null,
      email: this.addNewUserModel.addNewAccountValue.email != null && this.addNewUserModel.addNewAccountValue.email != '' ? this.addNewUserModel.addNewAccountValue.email : '',
      globalEmployeeId: this.addNewUserModel.addNewAccountValue.globalEmployeeId != null && this.addNewUserModel.addNewAccountValue.globalEmployeeId != '' ? this.addNewUserModel.addNewAccountValue.globalEmployeeId : null,
      clientId: this.addNewUserModel.addNewAccountValue.clientId != null && this.addNewUserModel.addNewAccountValue.clientId != '' ? this.addNewUserModel.addNewAccountValue.clientId : null,
      mobile: this.addNewUserModel.addNewAccountValue.mobile != null && this.addNewUserModel.addNewAccountValue.mobile != '' ? this.addNewUserModel.addNewAccountValue.mobile : null,
      language: this.addNewUserModel.addNewAccountValue.language != null && this.addNewUserModel.addNewAccountValue.language != '' ? this.addNewUserModel.addNewAccountValue.language : null,
      userRoles: this.addNewUserModel.addNewAccountValue.userRoles,
      roleInfo: loggedInUserDetail.roleInfo,
    }
    this.commonService.postData(url, param, '').subscribe(data => {

      if (data.response == 'Success') {
        this.addNewUserModel.editUserNavigate = true;
        this.addNewUserModel.renderConfirmMessagePage = false;
        this.addNewUserModel.renderConfigMessagePage = false;
        this.addNewUserModel.saveSection = true;
        this.addNewUserModel.errorCode = 'accountcreated';
        this.addNewUserModel.addnewaccount.disable();
        this.addNewUserModel.checkedUserRole = true;
        this.addNewUserModel.submitted = false;
      } else {
        this.addNewUserModel.errorCodeConfirm = data.errorCode;
      }

    });
  }
  accountRepairRelink() {
    const loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let url = this.baseUrl.ecustomer.accountRepairRelink;
    let param = {
      userName: this.addNewUserModel.userConfigData.userName != null && this.addNewUserModel.userConfigData.userName != '' ? this.addNewUserModel.userConfigData.userName : null,
      accountConfigCorrupted: this.addNewUserModel.userConfigData.accountConfigCorrupted,
      accountCreatedByOtherAppln: this.addNewUserModel.userConfigData.accountCreatedByOtherAppln,
      ldap_fName: this.addNewUserModel.userConfigData.ldap_fName != null && this.addNewUserModel.userConfigData.ldap_fName != '' ? this.addNewUserModel.userConfigData.ldap_fName : null,
      ldap_LName: this.addNewUserModel.userConfigData.ldap_LName != null && this.addNewUserModel.userConfigData.ldap_LName != '' ? this.addNewUserModel.userConfigData.ldap_LName : null,
      ldap_mail: this.addNewUserModel.userConfigData.ldap_mail != null && this.addNewUserModel.userConfigData.ldap_mail != '' ? this.addNewUserModel.userConfigData.ldap_mail : null,
      ldap_phone: this.addNewUserModel.userConfigData.ldap_phone != null && this.addNewUserModel.userConfigData.ldap_phone != '' ? this.addNewUserModel.userConfigData.ldap_phone : null,
      ldap_preferredLanguage: this.addNewUserModel.userConfigData.ldap_preferredLanguage != null && this.addNewUserModel.userConfigData.ldap_preferredLanguage != '' ? this.addNewUserModel.userConfigData.ldap_preferredLanguage : null,
      ldap_globalEmployeeId: this.addNewUserModel.userConfigData.ldap_globalEmployeeId != null && this.addNewUserModel.userConfigData.ldap_globalEmployeeId != '' ? this.addNewUserModel.userConfigData.ldap_globalEmployeeId : null,
      clientId: this.addNewUserModel.userConfigData.clientId != null && this.addNewUserModel.userConfigData.clientId != '' ? this.addNewUserModel.userConfigData.clientId : null,
      userRoles: this.addNewUserModel.userConfigData.userRoles,
      userType: this.addNewUserModel.userConfigData.userType,
      partialconfiguration: this.addNewUserModel.userConfigData.partialconfiguration,
      authorizedApplicationCode: this.addNewUserModel.userConfigData.authorizedApplicationCode != null && this.addNewUserModel.userConfigData.authorizedApplicationCode != '' ? this.addNewUserModel.userConfigData.authorizedApplicationCode : null,
      roleInfo: loggedInUserDetail.roleInfo,
    }
    this.commonService.postData(url, param, '').subscribe(data => {

      if (data.renderSavePage) {
        this.addNewUserModel.editUserNavigate = true;
        this.addNewUserModel.renderConfirmMessagePage = false;
        this.addNewUserModel.renderConfigMessagePage = false;
        this.addNewUserModel.saveSection = true;
        this.addNewUserModel.addnewaccount.disable();
        this.addNewUserModel.checkedUserRole = true;
        this.addNewUserModel.submitted = false;
        this.addNewUserModel.renderUserLinkedSuccessMsg = data.renderUserLinkedSuccessMsg;
        this.addNewUserModel.renderUserRepairedSuccessMsg = data.renderUserRepairedSuccessMsg;
        if (this.addNewUserModel.addnewaccount.controls.globalEmpID) {
          this.addNewUserModel.addnewaccount.controls.globalEmpID.setValue(this.addNewUserModel.userConfigData.ldap_globalEmployeeId);
        }
        this.addNewUserModel.addnewaccount.controls.emailID.setValue(this.addNewUserModel.userConfigData.ldap_mail);
        if (this.addNewUserModel.addnewaccount.controls.mobile) {
          this.addNewUserModel.addnewaccount.controls.mobile.setValue(this.addNewUserModel.userConfigData.ldap_phone);
        }
        this.addNewUserModel.addnewaccount.controls.firstName.setValue(this.addNewUserModel.userConfigData.ldap_fName);
        this.addNewUserModel.addnewaccount.controls.lastName.setValue(this.addNewUserModel.userConfigData.ldap_LName);
        this.addNewUserModel.addnewaccount.controls.language.setValue(this.addNewUserModel.userConfigData.ldap_preferredLanguage)
        this.addNewUserModel.addnewaccount.controls.userType.setValue(this.addNewUserModel.userConfigData.userType)
        this.addNewUserModel.addnewaccount.controls.userName.setValue(this.addNewUserModel.userConfigData.userName)
        this.addNewUserModel.addnewaccount.controls.customerId.setValue(this.addNewUserModel.userConfigData.clientId)
      } else {
        this.addNewUserModel.errorCode = data.errorCode;
      }

    });
  }

  backToAddUser() {
    this.addNewUserModel.renderConfirmMessagePage = false;
    this.addNewUserModel.renderConfigMessagePage = false;
    this.addNewUserModel.saveSection = true;
    this.addNewUserModel.checkedUserRole = true;
    this.addNewUserModel.submitted = false;
    this.addNewUserModel.errorCodeConfirm = '';
    this.sharedService.setPramaValue('addNewUserBack', false);
  }
  navigateEditUserAccount() {
    this.settingParamValue.addNewUser = false;
    this.settingParamValue.editUser = true;
    this.settingParamValue.userAccount = false;
    this.sharedService.setPramaValue('boradcastData', null);
    this.sharedService.setPramaValue('addNewAccountFormData', null);
    this.sharedService.setPramaValue('addNewUserLdapData', null);
    this.sharedService.setPramaValue('userRoleData', null)
    this.valueChange.emit(this.settingParamValue);
    this.userValue.emit(this.addNewUserModel.addnewaccount.controls.userName.value);
  }
  patchData() {
    this.addNewUserModel.addnewaccount.controls.userType.setValue(this.sharedService.boradcastData.userType);
    this.addNewUserModel.addnewaccount.controls.language.setValue(this.sharedService.boradcastData.language);
    this.addNewUserValue();
    this.addNewUserModel.addnewaccount.controls.customerId.setValue(this.sharedService.boradcastData.clientId);
    this.addNewUserModel.addnewaccount.controls.firstName.setValue(this.sharedService.boradcastData.firstName);
    this.addNewUserModel.addnewaccount.controls.lastName.setValue(this.sharedService.boradcastData.lastName);
    this.addNewUserModel.addnewaccount.controls.userName.setValue(this.sharedService.boradcastData.userName);
    this.addNewUserModel.renderConfirmMessagePage = this.sharedService.boradcastData.renderConfirmMessagePage;
    this.addNewUserModel.renderConfigMessagePage = this.sharedService.boradcastData.renderConfigMessagePage;
    this.addNewUserModel.saveSection = this.sharedService.boradcastData.renderSavePage;
    this.addNewUserModel.accountConfigCorrupted = this.sharedService.boradcastData.accountConfigCorrupted;
    this.addNewUserModel.accountCreatedByOtherAppln = this.sharedService.boradcastData.accountCreatedByOtherAppln;
    this.addNewUserModel.addNewAccountValue = this.sharedService.addNewAccountFormData;
    this.addNewUserModel.userConfigData = this.sharedService.addNewUserLdapData;
    if (this.sharedService.legalUpdateData != null) {
      this.addNewUserModel.addnewaccount.controls.emailID.setValue(this.sharedService.legalUpdateData.updatedEmail);
      if (this.addNewUserModel.addnewaccount.controls.mobile) {
        this.addNewUserModel.addnewaccount.controls.mobile.setValue(this.sharedService.legalUpdateData.updatedMobilePhone);
      }
      this.addNewUserModel.addNewAccountValue.email = this.sharedService.legalUpdateData.updatedEmail;
      this.addNewUserModel.addNewAccountValue.mobile = this.sharedService.legalUpdateData.updatedMobilePhone;
      if (this.addNewUserModel.userConfigData.ldap_mail == null || this.addNewUserModel.userConfigData.ldap_mail === '') {
        this.addNewUserModel.userConfigData.ldap_mail = this.sharedService.legalUpdateData.updatedEmail;
      }
    }
    this.addNewUserModel.userRoleName = this.sharedService.userRoleData;
    let backUserValue = this.sharedService.addNewUserBack;
    if (backUserValue) {
      this.backToAddUser()
    }
  }

}
