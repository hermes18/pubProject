import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';

import { RouterTestingModule } from '@angular/router/testing';

import { AppModule } from '../../app.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { AddNewUserComponent } from './add-new-user.component';
import { SettingModule } from '../setting.module';

describe('AddNewUserComponent', () => {
  let component: AddNewUserComponent;
  let fixture: ComponentFixture<AddNewUserComponent>;
  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    const countryCode = "pl";
    window.sessionStorage.setItem('countryCode', countryCode);
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, SettingModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService]
    })
      .compileComponents();
    fixture = TestBed.createComponent(AddNewUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.country = "pl";
    expect(component).toBeTruthy();
  });
});
