import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';

@Injectable({
    providedIn: 'root'
})
export class AddNewUserUtility {

    countryBaseRoleList(checkList) {
        let array;
        let country = sessionStorage.getItem('countryCode');
        switch (country) {
            case 'ro':
                array = checkList.map(purpose => {
                    if (!((purpose.value == 'rWarden' || purpose.value == 'rUserAccountManager') && country.toLowerCase() == 'ro'))
                        return new FormControl('');
                });
                return array;

            case 'gr':
                array = checkList.map(purpose => {
                    if (!((purpose.value == 'rWarden') && country.toLowerCase() == 'gr'))
                        return new FormControl('');
                });
                return array;

            case 'pl':
                array = checkList.map(purpose => {

                    return new FormControl('');
                });
                return array;
        }

    }

    getUserRoleList(checkList) {
        let arrayList;
        let country = sessionStorage.getItem('countryCode');
        switch (country) {
            case 'ro':
                arrayList = checkList.map(purpose => {
                    if (!((purpose.value == 'rWarden' || purpose.value == 'rUserAccountManager') && country.toLowerCase() == 'ro'))
                        return purpose;
                });
                return arrayList;

            case 'gr':
                arrayList = checkList.map(purpose => {
                    if (!(purpose.value == 'rWarden'))
                        return purpose;
                });
                return arrayList;
            case 'pl':
                arrayList = checkList.map(purpose => {
                    return purpose;
                });
                return arrayList;
        }

    }

    getSystemRoleList() {
        let country = sessionStorage.getItem('countryCode');
        const systemRole = [{ name: 'Client', value: 'rClient', flag: true },
        { name: 'Group Admin', value: 'rGroupAdmin', flag: true },
        { name: 'Super User', value: 'rSuperUser', flag: true },
        { name: 'Individual Admin', value: 'rIndividualAdmin', flag: true },
        { name: 'HR', value: 'rHR', flag: true }
        ];

        switch (country) {
            case 'gr':
                return systemRole;

        }
    }
}