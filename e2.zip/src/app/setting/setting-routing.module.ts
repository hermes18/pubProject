import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SettingComponent } from './setting.component';
import { MatFormFieldModule } from '@angular/material';
import { NavigationGuard } from '../core/gaurds/navigation-guard';


const routes: Routes = [
  { path: '', component: SettingComponent, canDeactivate: [NavigationGuard] },
  //{ path: '/account-setting', component: SettingComponent, canDeactivate: [NavigationGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(routes), MatFormFieldModule],
  exports: [RouterModule, MatFormFieldModule]
})
export class SettingRoutingModule { }
