import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchSendInvitationComponent } from './search-send-invitation.component';

describe('SearchSendInvitationComponent', () => {
  let component: SearchSendInvitationComponent;
  let fixture: ComponentFixture<SearchSendInvitationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchSendInvitationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchSendInvitationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
