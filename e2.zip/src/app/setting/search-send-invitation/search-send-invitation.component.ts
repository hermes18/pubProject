import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { AppConfig } from 'src/config/app.config';
import { Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { takeWhile } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { SharedServiceService } from '../../shared-service/shared-service.service';
import { HttpCommonService } from '../../shared/services/http-common.service';
import { MenuItemsService } from '../../shared-service/menu-items.service'
import { AlertDialogComponent } from '../../shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from '../../shared/services/dialog.service';
import { UtilityService } from '.././../shared/utilities/utility.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ConfirmDialogComponent } from 'src/app/shared/dialog/confirm-dialog/confirm-dialog.component';
import { FilePreviewComponent } from 'src/app/shared/dialog/file-preview/file-preview.component';
import { FilePreviewService } from 'src/app/shared/services/file-preview.service';
import { FileUpload } from 'src/app/core/models/file-upload';
import { RemoveFileDialogComponentComponent } from 'src/app/shared/dialog/remove-file-dialog-component/remove-file-dialog-component.component';
import { HttpHeaders } from '@angular/common/http';

export interface clientData {
  clientId: String;
  firstName: String;
  lastName: String;
  emailID: String;
  status: String;
}

@Component({
  selector: 'search-send-invitation',
  templateUrl: './search-send-invitation.component.html',
  styleUrls: ['./search-send-invitation.component.scss']
})
export class SearchSendInvitationComponent implements OnInit {
  uploadedFile: any;
    displayedColumnsSearchBlock: String[] = [
    'clientId', 'firstName',
    'lastName', 'emailId', 'notificationStatus'
  ];
  displayedColumnsSearchBlockMob: String[] = [
    'clientId', 'firstName',
    'lastName', 'emailId', 'notificationStatus'
  ];
  allowedType = '.csv';
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  public fileUploadModel: Array<any>;
  fileValidation_Messages: any[];
  fileSizeObject = { filesSizeCalculation: 0 };
  dataSourceSearchedDetails = new MatTableDataSource<clientData>();
  sendinvitationClicked: boolean;
  reqPayload: FormData;
  sendInvitationResponse: any;
  fileScanSuccess: boolean = false;
  country: string;
  lang: string;
  displayPoland: boolean;
  user: any;
  searchedRecordsFound: boolean;
  searchedMaxRecord: boolean;
  searchedZeroRecordFound: boolean;
  searchCount: any;
  private searchPaginator: MatPaginator;
  private searchSort: MatSort;
  showFileUploadSuccess: boolean;
  showSearchBlock: boolean = false;
  showSendInviteBlock: any;
  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.searchPaginator = mp;    
    if (this.dataSourceSearchedDetails)
      this.dataSourceSearchedDetails.paginator = this.searchPaginator;
  }
  isMobile = this.deviceDetector.isMobile();
  userSearchForm = this.formBuilder.group({
    clientId: null,
    emailId: null
  });
  constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, public filePreviewService: FilePreviewService,
    private route: ActivatedRoute, public deviceDetector: DeviceDetectorService, public dialogService: DialogService,
    public commonService: SharedServiceService, public httpService: HttpCommonService, private readonly menuItemService: MenuItemsService, public dialog: DialogService, private translate: TranslateService) {
  }

  ngOnInit() {
    this.fileUploadModel = [];
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      // if (this.country == 'pl') {
      this.displayPoland = true;
    }
    else {
      this.displayPoland = false;
    }
    this.searchedZeroRecordFound = false;
    this.searchedMaxRecord = false;
    this.searchedRecordsFound = false;
    //this.dataSource.sort = this.sort;
    this.userSearchForm.reset();
    this.showFileUploadSuccess = false;
    this.fileScanSuccess = false;
  }
  headers = new HttpHeaders();

  searchBtnClick() {
    const loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
      userrole = this.menuItemService.getAllRoles();
    this.searchedZeroRecordFound = false;
    this.searchedMaxRecord = false;
    this.searchedRecordsFound = false;
    let screenRequestObj = new SearchSectionReqModel();
    screenRequestObj.loginId = (loggedInUserDetail.userName ? (loggedInUserDetail.userName).trim() : 'tets');
    screenRequestObj.clientId = (this.userSearchForm.value.clientId ? (this.userSearchForm.value.clientId).trim() : '');
    screenRequestObj.email = (this.userSearchForm.value.emailId ? (this.userSearchForm.value.emailId).trim() : '');
    let url = this.baseUrl.ecustomer.sendInvitationSearch;
    this.httpService['postData'](url, screenRequestObj, this.headers).subscribe(data => {
      this.dataSourceSearchedDetails = new MatTableDataSource<clientData>();
      this.searchPaginator = null;
      this.searchSort = null;
      this.user = data;
      if (this.user.maxRecordSizeExceed)
        this.searchedMaxRecord = true;
      else
        this.searchedMaxRecord = false;

      if (screenRequestObj.loginId == '' && screenRequestObj.clientId == '' && screenRequestObj.email == '') {
        this.dataSourceSearchedDetails = new MatTableDataSource(this.user.groupInvitationDTOs);
      }
      else {
        this.dataSourceSearchedDetails = new MatTableDataSource(this.user.groupInvitationDTOs);
      }

      this.dataSourceSearchedDetails.paginator = this.searchPaginator;
      this.dataSourceSearchedDetails.sort = this.searchSort;
      if (this.user.groupInvitationDTOs) {
        this.searchCount = this.user.groupInvitationDTOs.length;
      }
      if (this.searchCount > 0) {
        this.searchedRecordsFound = true;
      } else {
        this.searchedZeroRecordFound = true;
      }
    })
  }

  openSearchBlock() {
    if (!this.showSearchBlock) {
      this.showSearchBlock = true;
      this.showSendInviteBlock = false;
    } else {
      this.showSearchBlock = false;
      this.showSendInviteBlock = false;
    }
  }

  openSendInvitehBlock() {
    if (!this.showSendInviteBlock) {
      this.showSendInviteBlock = true;
      this.showSearchBlock = false;
    } else {
      this.showSendInviteBlock = false;
      this.showSearchBlock = false;
    }
  }

}

export class SearchSectionReqModel {
  loginId: string = null;
  clientId: string = null;
  email: string = null;
}

