import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { AppConfig } from 'src/config/app.config';
import { Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { takeWhile } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { SharedServiceService } from '../../shared-service/shared-service.service';
import { HttpCommonService } from '../../shared/services/http-common.service';
import { MenuItemsService } from '../../shared-service/menu-items.service'
import { AlertDialogComponent } from '../../shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from '../../shared/services/dialog.service';
import { UtilityService } from '.././../shared/utilities/utility.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ConfirmDialogComponent } from 'src/app/shared/dialog/confirm-dialog/confirm-dialog.component';
import { FilePreviewComponent } from 'src/app/shared/dialog/file-preview/file-preview.component';
import { FilePreviewService } from 'src/app/shared/services/file-preview.service';
import { FileUpload } from 'src/app/core/models/file-upload';
import { RemoveFileDialogComponentComponent } from 'src/app/shared/dialog/remove-file-dialog-component/remove-file-dialog-component.component';
import { HttpHeaders } from '@angular/common/http';

export interface clientData {
  clientId: String;
  firstName: String;
  lastName: String;
  emailID: String;
  status: String;
}

export interface sendInviteReaponseData {
  clientId: String;
  firstName: String;
  lastName: String;
  emailID: String;
  reason: String;
}
// const ELEMENT_DATA: clientData[] = [
//   { clientId: '1aa', firstName: 'Hydrogen', lastName: '1.0079', emailID: 'abc@hgg.com', status: 'Failed' },
//   { clientId: '2bb', firstName: 'Helium', lastName: '4.0026', emailID: 'abcd@hgg.com', status: 'Failed' },
//   { clientId: '3cc', firstName: 'Lithium', lastName: '6.941', emailID: 'awebc@hgg.com', status: 'Failed' },
//   { clientId: '4dd', firstName: 'Beryllium', lastName: '9.0122', emailID: 'asabc@hgg.com', status: 'Failed' },
// ]

@Component({
  selector: 'send-invitation',
  templateUrl: './send-invitation.component.html',
  styleUrls: ['./send-invitation.component.scss']
})
export class SendInvitationComponent implements OnInit {
  uploadedFile: any;
  displayedColumnsBfre: String[] = [
    'clientId', 'firstName',
    'lastName', 'emailId', 'reason'
  ];
  displayedColumnsBfreMob: String[] = [
    'clientId', 'firstName',
    'lastName', 'emailId', 'reason'
  ];
  displayedColumnsSearchBlock: String[] = [
    'clientId', 'firstName',
    'lastName', 'emailId', 'notificationStatus'
  ];
  displayedColumnsSearchBlockMob: String[] = [
    'clientId', 'firstName',
    'lastName', 'emailId', 'notificationStatus'
  ];
  allowedType = '.csv';
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  public fileUploadModel: Array<any>;
  fileValidation_Messages: any[];
  fileSizeObject = { filesSizeCalculation: 0 };
  dataSourceDetails = new MatTableDataSource<sendInviteReaponseData>();
  dataSourceSearchedDetails = new MatTableDataSource<clientData>();
  private paginator: MatPaginator;
  private sort: MatSort;
  sendinvitationClicked: boolean;
  maxRecord: boolean = false;
  reqPayload: FormData;
  zeroRecordFound: boolean;
  RecordsFound: boolean;
  sendInvitationResponse: any;
  count: any;
  fileScanSuccess: boolean = false;
  country: string;
  lang: string;
  displayPoland: boolean;
  user: any;
  searchedRecordsFound: boolean;
  searchedMaxRecord: boolean;
  searchedZeroRecordFound: boolean;
  searchCount: any;
  private searchPaginator: MatPaginator;
  private searchSort: MatSort;
  showFileUploadSuccess: boolean;
  showSearchBlock: boolean = false;
  showSendInviteBlock: any;
  fileRemoved: any;
  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.dataSourceDetails)
      this.dataSourceDetails.paginator = this.paginator;
  }
  // @ViewChild(MatPaginator, { static: false }) set matPaginator2(mp2: MatPaginator) {
  //   this.searchPaginator = mp2;    
  //   if (this.dataSourceSearchedDetails)
  //     this.dataSourceSearchedDetails.paginator = this.searchPaginator;
  // }
  isMobile = this.deviceDetector.isMobile();
  userSearchForm = this.formBuilder.group({
    clientId: null,
    emailId: null
  });
  constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, public filePreviewService: FilePreviewService,
    private route: ActivatedRoute, public deviceDetector: DeviceDetectorService, public dialogService: DialogService,
    public commonService: SharedServiceService, public httpService: HttpCommonService, private readonly menuItemService: MenuItemsService, public dialog: DialogService, private translate: TranslateService) {
  }

  ngOnInit() {
    this.fileUploadModel = [];
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      // if (this.country == 'pl') {
      this.displayPoland = true;
    }
    else {
      this.displayPoland = false;
    }
    this.maxRecord = false;
    this.RecordsFound = false;
    this.zeroRecordFound = false;
    this.searchedZeroRecordFound = false;
    this.searchedMaxRecord = false;
    this.searchedRecordsFound = false;
    //this.dataSource.sort = this.sort;
    this.userSearchForm.reset();
    this.showFileUploadSuccess = false;
    this.fileScanSuccess = false;
  }
  headers = new HttpHeaders();

  @Input() set sendInvitationTabIndex(index) {
    this.fileUploadModel = [];
    this.fileScanSuccess = false;
    this.RecordsFound = false;
    this.fileValidation_Messages = [];
    this.searchedZeroRecordFound = false;
    this.searchedMaxRecord = false;
    this.searchedRecordsFound = false;
    this.showFileUploadSuccess = false;
  }

  fileSelection(event, claimdoc: string, fileUploadData: HTMLInputElement) {
    this.RecordsFound = false;
    this.showFileUploadSuccess = false;
    //let claimdocRemoveExistingKey = claimdoc.replace("_existing", "");
    let virusFileCheck = this.baseUrl.ecustomer.virusFileCheck;
    //this.uploadEvent.emit(event);
    this.fileValidation_Messages = [];
    let isInValidFile = false;
    this.fileUploadModel = [];
    for (let index = 0; index < event.target.files.length; index++) {
      const file = event.target.files[index];
      this.uploadedFile = file.name;
      const fileContentType = file.name.substring(file.name.lastIndexOf(".") + 1).toLocaleLowerCase();
      if (this.allowedType.indexOf(fileContentType) != -1) {
        this.reqPayload = new FormData();
        this.reqPayload.append('file', file)
        const reader = new FileReader();
        const filenameWithDocType = file.name;////claimdocRemoveExistingKey + "_" + file.name;
        reader.onload = e => {
          const temp = reader.result as string;
          // this.fileUploadModel.push({ data: file, state: claimdoc, path: temp, name: filenameWithDocType, contentType: fileContentType, fileName: file.name });
        }
        reader.readAsDataURL(file);
        fileUploadData.value = "";
        this.httpService['postDataFileUpload'](virusFileCheck, this.reqPayload, '').subscribe(data => {
          if (data.statusCode == "200") {
            this.fileScanSuccess = true;
            this.showFileUploadSuccess = true;
            this.fileSizeObject.filesSizeCalculation = this.fileSizeObject.filesSizeCalculation + file.size;
            // if (file.size < this.userInfo.minFilesize && this.fileSizeObject.filesSizeCalculation < this.userInfo.maxFilesize) {
            const reader = new FileReader();
            const filenameWithDocType = file.name;////claimdocRemoveExistingKey + "_" + file.name;
            reader.onload = e => {
              const temp = reader.result as string;
              this.fileUploadModel.push({ data: file, state: claimdoc, path: temp, name: filenameWithDocType, contentType: fileContentType, fileName: file.name });
            }
            reader.readAsDataURL(file);
            fileUploadData.value = "";
            // }
            // else {
            //   isInValidFile = true;
            /* if (file.size > this.userInfo.minFilesize) {
              this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidSize' });
            }
            else if (this.fileSizeObject.filesSizeCalculation > this.userInfo.maxFilesize) {
              this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidSizeMax' });
            }
            th is.fileSizeObject.filesSizeCalculation = this.fileSizeObject.filesSizeCalculation - file.size;
  */
            //}
          } else {
            this.fileScanSuccess = false;
            this.showFileUploadSuccess = false;
            this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.virusFile' });
          }
        });
      }
      else {
        this.fileScanSuccess = false;
        this.showFileUploadSuccess = false;
        this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidFormat' });
      }
    }
  }

  removeSelectedFile(index, file: FileUpload) {
    //console.log(this.fileUploadModel);
    const message = this.translate.instant("Are you sure you want to remove") + ' ' + file.data.name
    this.dialogService.openDialog(RemoveFileDialogComponentComponent, { 'heading': this.translate.instant("Confirm deleting"), 'body': message, "index": index, "fileUploadModel": this.fileUploadModel, "fileSizeObject": this.fileSizeObject });
    // this.fileRemoved = this.commonService.geFileRemovedStatus(); 
    if (this.fileRemoved) {
      this.fileValidation_Messages = [];
      this.fileScanSuccess = false;
      this.showFileUploadSuccess = false;
      this.RecordsFound = false;
    }
  }

  templateDownload() {
    window.open("/assets/mocks/send_invite_template.csv");
  }

  sendInvitationBtnClick() {
    this.showFileUploadSuccess = false;
    this.searchPaginator = null;
    this.zeroRecordFound = false;
    this.maxRecord = false;
    this.RecordsFound = false;
    let sendInvitation = this.baseUrl.ecustomer.sendInvitation;
    this.httpService['postDataFileUpload'](sendInvitation, this.reqPayload, "").subscribe(data => {
      //if (data.statusCode == 200) {
      // this.sendinvitationClicked = true;      
      this.dataSourceDetails = new MatTableDataSource<sendInviteReaponseData>();
      this.paginator = null;
      this.sort = null;
      this.sendInvitationResponse = data;
      if (this.sendInvitationResponse.maxRecordSizeExceed)
        this.maxRecord = true;
      else
        this.maxRecord = false;
      this.dataSourceDetails = new MatTableDataSource(this.sendInvitationResponse.sendInvitationDto);
      this.dataSourceDetails.paginator = this.paginator;
      this.dataSourceDetails.sort = this.sort;
      if (this.sendInvitationResponse.sendInvitationDto) {
        this.count = this.sendInvitationResponse.sendInvitationDto.length;
      }
      //("---------------------", this.count);
      if (this.count > 0) {
        this.RecordsFound = true;
      } else {
        this.zeroRecordFound = true;
      }
      // } else {
      //   this.sendinvitationClicked = false;
      // }   
    });
  }

  /* searchBtnClick() {
    this.paginator = null;
    const loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
      userrole = this.menuItemService.getAllRoles();
    this.searchedZeroRecordFound = false;
    this.searchedMaxRecord = false;
    this.searchedRecordsFound = false;
    let screenRequestObj = new SearchSectionReqModel();
    screenRequestObj.loginId = (loggedInUserDetail.userName ? (loggedInUserDetail.userName).trim() : 'tets');
    screenRequestObj.clientId = (this.userSearchForm.value.clientId ? (this.userSearchForm.value.clientId).trim() : '');
    screenRequestObj.email = (this.userSearchForm.value.emailId ? (this.userSearchForm.value.emailId).trim() : '');
    let url = this.baseUrl.ecustomer.sendInvitationSearch;
    this.httpService['postData'](url, screenRequestObj, this.headers).subscribe(data => {
      this.dataSourceSearchedDetails = new MatTableDataSource<clientData>();
      this.searchPaginator = null;
      this.searchSort = null;
      this.user = data;
      if (this.user.maxRecordSizeExceed)
        this.searchedMaxRecord = true;
      else
        this.searchedMaxRecord = false;

      if (screenRequestObj.loginId == '' && screenRequestObj.clientId == '' && screenRequestObj.email == '') {
        this.dataSourceSearchedDetails = new MatTableDataSource(this.user.groupInvitationDTOs);
      }
      else {
        this.dataSourceSearchedDetails = new MatTableDataSource(this.user.groupInvitationDTOs);
      }

      this.dataSourceSearchedDetails.paginator = this.searchPaginator;
      this.dataSourceSearchedDetails.sort = this.searchSort;
      if (this.user.groupInvitationDTOs) {
        this.searchCount = this.user.groupInvitationDTOs.length;
      }
      if (this.searchCount > 0) {
        this.searchedRecordsFound = true;
      } else {
        this.searchedZeroRecordFound = true;
      }
    })
  } */

  openSearchBlock() {
    if (!this.showSearchBlock) {
      this.showSearchBlock = true;
      this.showSendInviteBlock = false;
      this.fileUploadModel = [];
      this.fileScanSuccess = false;
      this.RecordsFound = false;
      this.fileValidation_Messages = [];
    } else {
      this.showSearchBlock = false;
      this.showSendInviteBlock = false;
    }
  }
  openSendInviteBlock() {
    if (!this.showSendInviteBlock) {
      this.showSendInviteBlock = true;
      this.showSearchBlock = false;
    } else {
      this.showSendInviteBlock = false;
      this.showSearchBlock = false;
    }
  }

}

export class SearchSectionReqModel {
  loginId: string = null;
  clientId: string = null;
  email: string = null;
}
