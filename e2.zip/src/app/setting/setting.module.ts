import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SettingRoutingModule } from './setting-routing.module';
import { SettingComponent } from './setting.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import {
  MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule, MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule,
  MatNativeDateModule, MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule, MatRadioModule
} from '@angular/material';
import { AddNewUserComponent } from './add-new-user/add-new-user.component';
import { UserAccountComponent } from './user-account/user-account.component';
import { EditUserAccountComponent } from './edit-user-account/edit-user-account.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { PasswordChangeComponent } from './password-change/password-change.component';
import { SharedModule } from './../shared/shared.module';
import { AccountSettingComponent } from './account-setting/account-setting.component';
import { SendInvitationComponent } from './send-invitation/send-invitation.component';
import { CreateBulkUsersComponent } from './create-bulk-users/create-bulk-users.component';
import { SearchSendInvitationComponent } from './search-send-invitation/search-send-invitation.component';


const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule, MatRadioModule];

@NgModule({
  declarations: [SettingComponent, AddNewUserComponent, UserAccountComponent, EditUserAccountComponent, PasswordChangeComponent, AccountSettingComponent, SendInvitationComponent,
    CreateBulkUsersComponent, SearchSendInvitationComponent],
  imports: [
    CommonModule,
    SettingRoutingModule,
    // NgbModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    ...materialModule,
    NgxPaginationModule,
    SharedModule
  ]
})
export class SettingModule { }
