import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { AppConfig } from 'src/config/app.config';
import { Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { takeWhile } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { SharedServiceService } from '../../shared-service/shared-service.service';
import { HttpCommonService } from '../../shared/services/http-common.service';
import { MenuItemsService } from '../../shared-service/menu-items.service'
import { AlertDialogComponent } from '../../shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from '../../shared/services/dialog.service';
import { UtilityService } from '.././../shared/utilities/utility.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ConfirmDialogComponent } from 'src/app/shared/dialog/confirm-dialog/confirm-dialog.component';
import { FilePreviewComponent } from 'src/app/shared/dialog/file-preview/file-preview.component';
import { FilePreviewService } from 'src/app/shared/services/file-preview.service';
import { FileUpload } from 'src/app/core/models/file-upload';
import { RemoveFileDialogComponentComponent } from 'src/app/shared/dialog/remove-file-dialog-component/remove-file-dialog-component.component';
import { HttpHeaders } from '@angular/common/http';

export interface clientData {
  clientId: String;
  firstName: String;
  lastName: String;
  emailID: String;
  status: String;
}

@Component({
  selector: 'create-bulk-users',
  templateUrl: './create-bulk-users.component.html',
  styleUrls: ['./create-bulk-users.component.scss']
})
export class CreateBulkUsersComponent implements OnInit {
  uploadedFile: any;
  displayedColumnsBfre: String[] = [
    'clientId', 'firstName',
    'lastName', 'emailId', 'status'
  ];
  displayedColumnsBfreMob: String[] = [
    'clientId', 'firstName',
    'lastName', 'emailId', 'status'
  ];
  allowedType = '.csv';
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  public fileUploadModel: Array<any>;
  fileValidation_Messages: any[];
  fileSizeObject = { filesSizeCalculation: 0 };
  dataSourceDetails = new MatTableDataSource<clientData>();
  private paginator: MatPaginator;
  private sort: MatSort;
  sendinvitationClicked: boolean;
  maxRecord: boolean = false;
  reqPayload: FormData;
  zeroRecordFound: boolean;
  RecordsFound: boolean;
  sendInvitationResponse: any;
  count: any;
  fileScanSuccess: boolean = false;
  showFileUploadSuccess: boolean;
  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.dataSourceDetails)
      this.dataSourceDetails.paginator = this.paginator;
  }
  @ViewChild(MatSort, { static: false }) set matSort(mp: MatSort) {
    this.sort = mp;
    if (this.dataSourceDetails)
      this.dataSourceDetails.sort = this.sort;
  }
  isMobile = this.deviceDetector.isMobile();
  clientSearch = this.formBuilder.group({
    clientId: null,
    emailId: null,
  });
  constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, public filePreviewService: FilePreviewService,
    private route: ActivatedRoute, public deviceDetector: DeviceDetectorService, public dialogService: DialogService,
    public commonService: SharedServiceService, public httpService: HttpCommonService, private readonly menuItemService: MenuItemsService, public dialog: DialogService, private translate: TranslateService) {
  }

  ngOnInit() {
    this.fileUploadModel = [];

  }

  @Input() set sendInvitationTabIndex(index) {
    this.fileUploadModel = [];
    this.fileScanSuccess = false;
    this.RecordsFound = false;
    this.fileValidation_Messages = [];
    this.sendInvitationResponse = null;
    this.showFileUploadSuccess = false;
  }

  fileSelection(event, claimdoc: string, fileUploadData: HTMLInputElement) {
    this.sendInvitationResponse = null;
    this.showFileUploadSuccess = false;
    //let claimdocRemoveExistingKey = claimdoc.replace("_existing", "");
    let virusFileCheck = this.baseUrl.ecustomer.virusFileCheck;
    //this.uploadEvent.emit(event);
    this.fileValidation_Messages = [];
    let isInValidFile = false;
    this.fileUploadModel = [];
    for (let index = 0; index < event.target.files.length; index++) {
      const file = event.target.files[index];
      this.uploadedFile = file.name;
      const fileContentType = file.name.substring(file.name.lastIndexOf(".") + 1).toLocaleLowerCase();
      if (this.allowedType.indexOf(fileContentType) != -1) {
        this.reqPayload = new FormData();
        this.reqPayload.append('file', file)
        const reader = new FileReader();
        const filenameWithDocType = file.name;////claimdocRemoveExistingKey + "_" + file.name;
        reader.onload = e => {
          const temp = reader.result as string;
          // this.fileUploadModel.push({ data: file, state: claimdoc, path: temp, name: filenameWithDocType, contentType: fileContentType, fileName: file.name });
        }
        reader.readAsDataURL(file);
        fileUploadData.value = "";
        this.httpService['postDataFileUpload'](virusFileCheck, this.reqPayload, '').subscribe(data => {
          if (data.statusCode == "200") {
            this.fileScanSuccess = true;
            this.showFileUploadSuccess = true;
            this.fileSizeObject.filesSizeCalculation = this.fileSizeObject.filesSizeCalculation + file.size;
            // if (file.size < this.userInfo.minFilesize && this.fileSizeObject.filesSizeCalculation < this.userInfo.maxFilesize) {
            const reader = new FileReader();
            const filenameWithDocType = file.name;////claimdocRemoveExistingKey + "_" + file.name;
            reader.onload = e => {
              const temp = reader.result as string;
              this.fileUploadModel.push({ data: file, state: claimdoc, path: temp, name: filenameWithDocType, contentType: fileContentType, fileName: file.name });
            }
            reader.readAsDataURL(file);
            fileUploadData.value = "";
            // }
            // else {
            //   isInValidFile = true;
            /* if (file.size > this.userInfo.minFilesize) {
              this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidSize' });
            }
            else if (this.fileSizeObject.filesSizeCalculation > this.userInfo.maxFilesize) {
              this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidSizeMax' });
            }
            th is.fileSizeObject.filesSizeCalculation = this.fileSizeObject.filesSizeCalculation - file.size;
  */
            //}
          } else {
            this.fileScanSuccess = false;
            this.showFileUploadSuccess = false;
            this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.virusFile' });
          }
        });
      }
      else {
        this.fileScanSuccess = false;
        this.showFileUploadSuccess = false;
        this.fileValidation_Messages.push({ "name": file.name, "errorMessage": 'errors.attachment.invalidFormat' });
      }
    }
  }

  removeSelectedFile(index, file: FileUpload) {
    //console.log(this.fileUploadModel);
    const message = this.translate.instant("Are you sure you want to remove") + ' ' + file.data.name
    this.dialogService.openDialog(RemoveFileDialogComponentComponent, { 'heading': this.translate.instant("Confirm deleting"), 'body': message, "index": index, "fileUploadModel": this.fileUploadModel, "fileSizeObject": this.fileSizeObject });
    this.fileValidation_Messages = [];
    this.fileScanSuccess = false;
    this.showFileUploadSuccess = false;
    this.sendInvitationResponse =null;
  }

  templateDownload() {
    window.open("/assets/mocks/create_bulk_user_template.csv");
  }

  createUserBtnClick() {
    this.showFileUploadSuccess = false;
    let uploadNewAccountData = this.baseUrl.ecustomer.uploadNewAccountData;
    this.httpService['postDataFileUpload'](uploadNewAccountData, this.reqPayload, "").subscribe(data => {
      this.sendInvitationResponse = data;      
    });
  }

}
