import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateBulkUsersComponent } from './create-bulk-users.component';

describe('CreateBulkUsersComponent', () => {
  let component: CreateBulkUsersComponent;
  let fixture: ComponentFixture<CreateBulkUsersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateBulkUsersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateBulkUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
