import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from '../app.module';
import { SharedServiceService } from '../shared-service/shared-service.service';

import { SettingComponent } from './setting.component';
import { SettingModule } from './setting.module';

describe('SettingComponent', () => {
  let component: SettingComponent;
  let fixture: ComponentFixture<SettingComponent>;
  let sharedService: SharedServiceService;
  const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
  const menuItemList2 = JSON.parse(sessionStorage.getItem('menuItemList'));
  const loggedUserInfo = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, SettingModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: []

    })
      .compileComponents();
    //const data = JSON.parse(sessionStorage.getItem('menuItemList'));
    fixture = TestBed.createComponent(SettingComponent);
    sharedService = TestBed.get(SharedServiceService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', inject([SharedServiceService], (sharedService: SharedServiceService) => {
    const menuItemList = { "menuItems": [{ "menuId": "2", "accessSpec": "RW", "menuName": "Clients Administration", "parentMenu": "Administration" }, { "menuId": "3", "accessSpec": "RW", "menuName": "Change Password", "parentMenu": "Settings" }, { "menuId": "5", "accessSpec": "RW", "menuName": "My Contract", "parentMenu": "Main Menu" }, { "menuId": "6", "accessSpec": "R", "menuName": "My Data", "parentMenu": "Main Menu" }, { "menuId": "7", "accessSpec": "RW", "menuName": "Offer", "parentMenu": "Main Menu" }, { "menuId": "8", "accessSpec": "RW", "menuName": "Review Of Orders", "parentMenu": "Main Menu" }, { "menuId": "9", "accessSpec": "RW", "menuName": "Claims", "parentMenu": "Main Menu" }, { "menuId": "11", "accessSpec": "RW", "menuName": "Individual Contract Details", "parentMenu": "My Contract" }, { "menuId": "12", "accessSpec": "RW", "menuName": "Individual Contract Benefits", "parentMenu": "My Contract" }, { "menuId": "13", "accessSpec": "RW", "menuName": "Individual Contract Beneficiaries", "parentMenu": "My Contract" }, { "menuId": "14", "accessSpec": "RW", "menuName": "Individual Contract Financial Info", "parentMenu": "My Contract" }, { "menuId": "15", "accessSpec": "RW", "menuName": "Invest Strategy Change", "parentMenu": "My Contract" }, { "menuId": "16", "accessSpec": "R", "menuName": "Allocation Change", "parentMenu": "My Contract" }, { "menuId": "17", "accessSpec": "R", "menuName": "Fund Transfer", "parentMenu": "My Contract" }, { "menuId": "18", "accessSpec": "RW", "menuName": "Deposits Menu", "parentMenu": "My Contract" }, { "menuId": "19", "accessSpec": "R", "menuName": "Deposit to existing invest account", "parentMenu": "My Contract" }, { "menuId": "20", "accessSpec": "R", "menuName": "Deposit As new Invest Account", "parentMenu": "My Contract" }, { "menuId": "21", "accessSpec": "RW", "menuName": "Order History Review", "parentMenu": "My Contract" }, { "menuId": "22", "accessSpec": "RW", "menuName": "Agent Details", "parentMenu": "My Contract" }, { "menuId": "23", "accessSpec": "RW", "menuName": "Invest Strategy Change menu", "parentMenu": "My Contract" }, { "menuId": "24", "accessSpec": "RW", "menuName": "User Account Administration", "parentMenu": "Settings" }, { "menuId": "31", "accessSpec": "RW", "menuName": "Orders Report", "parentMenu": "Administration" }, { "menuId": "32", "accessSpec": "RW", "menuName": "Users", "parentMenu": "Administration" }, { "menuId": "33", "accessSpec": "RW", "menuName": "Customers", "parentMenu": "Administration" }, { "menuId": "35", "accessSpec": "RW", "menuName": "Documents Presentation", "parentMenu": "Main Menu" }, { "menuId": "36", "accessSpec": "RW", "menuName": "New Account Errors", "parentMenu": "Administration" }, { "menuId": "40", "accessSpec": "RW", "menuName": "My Company", "parentMenu": "My Contract" }], "renderMyContract": false, "renderOffers": false, "clientAdministration": true, "renderOrderReview": false, "renderMyData": false, "renderClaims": false, "renderUserAcctAdministration": true, "renderDocuments": false, "callRetrievePolicies": false, "callRetriveClientOffers": false, "callRetriveClientData": false, "renderMyCompany": false, "route": "DisplayClientSearch", "contractList": null, "claimList": null, "personalInformationDTO": null, "orderHistory": null, "offerResponse": null, "fundPriceDetails": null, "renderFundPriceMonitoring": false, "documentsList": null, "billingRecipent": null, "activeContractDetails": null, "clientIdbillControlList": [], "clientIdList": [], "wardenRoleCheck": false, "searchFlag": false, "ccDBAddressDTO": { "ccdbFullAddress": "https://10.112.202.48/ccdb-web/", "ccdbAddressPart1": "https://10.112.202.48/ccdb-web/ClientData.faces?eCustomerId=", "ccdbAddressPart2": "" }, "eClaimsURL": "https://qa.eclaim.metlife.pl?countryCode=pl&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d3ac40013934387411a890f1f92293e6961ccd91c419c3efe9642d615c7d69b2a7", "clientLoginId": null, "clientRoleIds": "3032|3033|3034|3036", "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator|rUserAccountManager", clientId: "" }
    //sharedService.getDetail('menuItemList');
    spyOn(sharedService, 'getDetail').and.returnValue(of(menuItemList));
    expect(component).toBeTruthy();
  })
  );
});
