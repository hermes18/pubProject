import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormArray, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { eClaimsConstants } from 'src/app/core/constant/constant';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { EditUserModel } from './model/edit-user-account.model';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import * as lodash from "lodash";
import { EditUserUtility } from './utility/edit-user-utility';

@Component({
  selector: 'edit-user-account',
  templateUrl: './edit-user-account.component.html',
  styleUrls: ['./edit-user-account.component.scss']
})
export class EditUserAccountComponent implements OnInit {

  detail: any;
  editUserModel: EditUserModel;
  addNewUserEnableCountry = eClaimsConstants.addNewUserEnableCountry;
  editUserAccountEnableCounry = eClaimsConstants.editUserAccountEnableCounry;
  country: string;
  lang: string;
  displayPoOption: boolean = false;
  displayRoOption: boolean = false;
  @Output('userAccountValue') valueChange = new EventEmitter<any>();
  @Input() userName: any;
  settingParamValue = {
    'userAccount': false,
    'addNewUser': false,
    'editUser': false
  }
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  loggedInCountryCheck: any;
  constructor(public fb: FormBuilder, public commonService: HttpCommonService, public router: Router,
    private sharedService: SharedServiceService,
    private editUserUtility: EditUserUtility, public deviceDetector: DeviceDetectorService, private menuItemService: MenuItemsService,) {
    this.editUserModel = new EditUserModel();
  }
  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');

    if (this.country === 'gr') {
      this.editUserModel.userTypeListPO = lodash.filter(this.editUserModel.userTypeListPO, (o) => {
        if (o.key !== 'Warden') {
          return o;
        }
      });
      const hrRoleValue = {
        key: "HR",
        value: "HR"
      };
      this.editUserModel.userTypeListPO.push(hrRoleValue);
      // const roleListForHR =
      //   { name: 'HR', value: 'rHR', flag: true }

      // this.addNewUserModel.userrole.push(roleListForHR);
      let systemRole = this.editUserUtility.getSystemRoleList();
      this.editUserModel.userrole = systemRole;

    }
    this.editUserModel.editUserAccountForm = this.fb.group({
      userType: ['', [Validators.required]],
      firstName: ['', [Validators.required]],
      userName: ['', [Validators.required]],
      customerId: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      emailID: ['', [Validators.required]],
      language: ['', [Validators.required]],
      accountStatus: ['', [Validators.required]],
      userrole: this.createCheckList(this.editUserModel.userrole)

    });
    //("country", this.country)
    // this.country = JSON.parse(sessionStorage.getItem('userData')).country;
    // //(this.country)

    this.lang = sessionStorage.getItem('defaultLanguage');
    //("lang", this.lang)
    //if (this.country.toLowerCase() == 'pl') {
    this.loggedInCountryCheck = UtilityService.getCountry();
    if (this.loggedInCountryCheck) {
      this.displayPoOption = true;
      this.editUserModel.editUserAccountForm.addControl('globalEmpID', new FormControl('', [Validators.required]));
      this.editUserModel.editUserAccountForm.addControl('mobile', new FormControl('', [Validators.required]));
      this.editUserModel.userrole = this.editUserModel.userrolePO
    }
    else {
      this.displayRoOption = true;
      this.editUserModel.editUserAccountForm.addControl('updateEmail', new FormControl(''));
      this.editUserModel.editUserAccountForm.get('updateEmail').setValue(false);
      this.editUserModel.userrole = this.editUserModel.userroleRO

      this.editUserModel.editUserAccountForm.controls.emailID.disable()
    }
    // this.setDefaultValue();
    if (this.country === 'gr') {
      // this.addNewUserModel.userrolePO = lodash.filter(this.addNewUserModel.userrolePO, (o) => {
      //   if (o.name !== 'Warden') {
      //     return o;
      //   }
      // });
      // this.addNewUserModel.userrole = this.addNewUserModel.userrolePO
      // const roleListForHR =
      //   { name: 'HR', value: 'rHR', flag: true }

      // this.addNewUserModel.userrole.push(roleListForHR);
      let systemRole = this.editUserUtility.getSystemRoleList();
      this.editUserModel.userrole = systemRole;
    }
    let url = this.baseUrl.ecustomer.editUserDetail;
    let param = {
      userName: this.userName
    };
    this.commonService['postData'](url, param, '').subscribe(data => {
      //("edituser", data)
      this.setAccountValues(data);
    })

    //("userName", this.userName)
  }

  setAccountValues(data) {

    this.editUserModel.editUserAccountForm.controls.userType.setValue(data.userType != null && data.userType != '' ? data.userType : '');
    this.editUserModel.editUserAccountForm.controls.firstName.setValue(data.firstName != null && data.firstName != '' ? data.firstName : '');
    this.editUserModel.editUserAccountForm.controls.lastName.setValue(data.lastName != null && data.lastName != '' ? data.lastName : '');
    this.editUserModel.editUserAccountForm.controls.userName.setValue(data.userName != null && data.userName != '' ? data.userName : '');
    this.editUserModel.editUserAccountForm.controls.emailID.setValue(data.emailId != null && data.emailId != '' ? data.emailId : '');
    // this.editUserModel.editUserAccountForm.controls.mobile.setValue(data.phoneNumber != null && data.phoneNumber != '' ? data.phoneNumber : '');
    this.editUserModel.editUserAccountForm.controls.language.setValue(data.locale != null && data.locale != '' ? data.locale : '');
    this.editUserModel.editUserAccountForm.controls.customerId.setValue(data.clientId != null && data.clientId != '' ? data.clientId : '');

    if (this.editUserModel.editUserAccountForm.controls.globalEmpID) {
      this.editUserModel.editUserAccountForm.controls.globalEmpID.setValue(data.globalEmployeeId != null && data.globalEmployeeId != '' ? data.globalEmployeeId : '');
      this.editUserModel.editUserAccountForm.controls.globalEmpID.disable();
    }
    if (this.editUserModel.editUserAccountForm.controls.mobile) {
      this.editUserModel.editUserAccountForm.controls.mobile.setValue(data.phoneNumber != null && data.phoneNumber != '' ? data.phoneNumber : '');
      if (data.disablePhone) {
        this.editUserModel.editUserAccountForm.controls.mobile.disable()
      }
    }
    // this.editUserModel.editUserAccountForm.controls.temporaryLockDate.setValue(data.temporaryLockDate != null && data.temporaryLockDate != '' ? data.temporaryLockDate : '');
    this.editUserModel.editUserAccountForm.controls.accountStatus.setValue(data.accountStatus != null && data.accountStatus != '' ? data.accountStatus.toLowerCase() : '');
    this.editUserModel.temporaryLockDate = data.temporaryLockDate;
    this.editUserModel.accountType = data.accountType;
    this.editUserModel.editUserAccountForm.controls.userName.disable();
    this.editUserModel.editUserAccountForm.controls.userType.disable();
    if (this.editUserModel.editUserAccountForm.controls.userType.value == '') {
      this.editUserModel.editUserAccountForm.controls.userType.enable();
    } else {
      this.editUserModel.editUserAccountForm.controls.userType.disable();
    }
    this.editUserModel.editUserAccountForm.controls.customerId.disable();
    if (data.disableEmail) {
      this.editUserModel.editUserAccountForm.controls.emailID.disable()
    }
    this.editUserModel.userRoleArrayValue = data.userRoles ? data.userRoles : '';
    this.checkboxUserrole(this.editUserModel.userRoleArrayValue);
    this.addNewUserValue();
  }

  checkboxUserrole(data) {
    //("user role", data)
    if (data != null && data != '') {
      for (let i = 0; i < data.length; i++) {

        for (let j = 0; j < this.editUserModel.userrole.length; j++) {
          if (this.editUserModel.userrole[j].value == data[i]) {

            this.editUserModel.userrole[j].flag = true;
          }

        }
      }
    }
  }

  createCheckList(checkList) {
    // let country = JSON.parse(sessionStorage.getItem('userData')).country;
    // let country = sessionStorage.getItem('countryCode');
    // const arr = checkList.map(purpose => {
    //   if (!((purpose.value == 'rWarden' || purpose.value == 'rUserAccountManager') && country.toLowerCase() == 'ro'))
    //     return new FormControl('');
    // });
    // this.editUserModel.userroleCheckList = arr.filter(item => item !== undefined)
    // const arrList = checkList.map(purpose => {
    //   if (!((purpose.value == 'rWarden' || purpose.value == 'rUserAccountManager') && country.toLowerCase() == 'ro'))
    //     return purpose;
    // });
    // this.editUserModel.userroleList = arrList.filter(item => item !== undefined)

    // return new FormArray(this.editUserModel.userroleCheckList, [Validators.required]);

    // let country = JSON.parse(sessionStorage.getItem('userData')).country;
    let country = sessionStorage.getItem('countryCode');
    const arr = this.editUserUtility.countryBaseRoleList(checkList)
    console.log(arr)

    this.editUserModel.userroleCheckList = arr.filter(item => item !== undefined)
    const arrList = this.editUserUtility.getUserRoleList(checkList);

    this.editUserModel.userroleList = arrList.filter(item => item !== undefined)

    return new FormArray(this.editUserModel.userroleCheckList, [Validators.required]);
  }

  onCheckboxChange(data: string, isChecked: boolean, indexValue: string) {
    // //(e)
    // const roleArray: FormArray = this.editUserModel.editUserAccountForm.get('roleArray') as FormArray

    if (isChecked) {
      this.editUserModel.userRoleArrayValue.push(data)
      this.editUserModel.userrole[indexValue].flag = true
      // roleArray.push(new FormControl(data));
    } else {

      // let index = this.editUserModel.userRoleArrayValue.findIndex(x => x.value == data)
      // this.editUserModel.userRoleArrayValue.splice(index);
      const index = this.editUserModel.userRoleArrayValue.indexOf(data);
      if (index > -1) {
        this.editUserModel.userRoleArrayValue.splice(index, 1);
      }
      this.editUserModel.userrole[indexValue].flag = false;
    }
    //("array value user role", this.editUserModel.userRoleArrayValue)
  }
  submit() {
    this.editUserModel.submitted = true;
    this.editUserModel.saveSection = false;
    const detail = this.editUserModel.editUserAccountForm.value;
    //(detail)
    this.editUserModel.editUserValue = {
      userType: this.editUserModel.editUserAccountForm.get('userType').value,
      firstName: this.editUserModel.editUserAccountForm.get('firstName').value,
      lastName: this.editUserModel.editUserAccountForm.get('lastName').value,
      userName: this.editUserModel.editUserAccountForm.get('userName').value,
      emailId: this.editUserModel.editUserAccountForm.get('emailID').value,
      globalEmployeeId: this.editUserModel.editUserAccountForm.controls.globalEmpID ? this.editUserModel.editUserAccountForm.get('globalEmpID').value : null,
      clientId: this.editUserModel.editUserAccountForm.get('customerId').value,
      phoneNumber: this.editUserModel.editUserAccountForm.controls.mobile ? this.editUserModel.editUserAccountForm.get('mobile').value : null,
      locale: this.editUserModel.editUserAccountForm.get('language').value,
      userRoles: this.editUserModel.userRoleArrayValue,
      checkBoxBinding: this.editUserModel.editUserAccountForm.controls.updateEmail && this.editUserModel.editUserAccountForm.controls.updateEmail.value != '' && this.editUserModel.editUserAccountForm.controls.updateEmail.value !== 'false' ? this.editUserModel.editUserAccountForm.get('updateEmail').value : false,
      temporaryLockDate: this.editUserModel.temporaryLockDate,
      accountType: this.editUserModel.accountType,
      accountStatus: this.editUserModel.editUserAccountForm.get('accountStatus').value,
    }

    if (this.editUserModel.editUserAccountForm.valid && this.editUserModel.userRoleArrayValue.length != 0) {

      let url = this.baseUrl.ecustomer.editUserUpdate;
      this.commonService['putData'](url, this.editUserModel.editUserValue).subscribe(data => {
        //(data)
        this.editUserModel.renderConfirmPage = data['renderConfirmPage'];
        // //("renderConfirmPage", data['renderConfirmPage'])
        if (data['renderConfirmPage']) {
          this.editUserModel.saveSection = true;
          this.editUserModel.submitted = false;
        } else {
          this.editUserModel.validPhoneNumberErr = data['validPhoneNumberErr']
          this.editUserModel.emailValidationErr = data['emailValidationErr']
          this.editUserModel.inputParametersErr = data['inputParametersErr']
          this.editUserModel.renderCannotReadData = data['renderCannotReadData']
          this.editUserModel.renderMinimumOneActiveOrder = data['renderMinimumOneActiveOrder']
          this.editUserModel.renderUpdateDataError = data['renderUpdateDataError']
          this.editUserModel.systemParametersErr = data['systemParametersErr']
          this.editUserModel.orderNotSent = data['orderNotSent']
          this.editUserModel.orderNotRegistered = data['orderNotRegistered']
          this.editUserModel.UserWithEmailAlreadyExists = data['userWithEmailAlreadyExists']
          this.editUserModel.saveSection = false;
        }
      });
    } else {
      this.editUserModel.saveSection = false
    }

  }

  changecheckbox() {
    // const userTypeValue = this.editUserModel.editUserAccountForm.controls.userType.value;
    // const langValue = this.editUserModel.editUserAccountForm.controls.language.value
    // this.editUserModel.editUserAccountForm.reset();
    // this.editUserModel.editUserAccountForm.controls.userType.setValue(userTypeValue);
    // this.editUserModel.editUserAccountForm.controls.language.setValue(langValue);
    // this.addNewUserValue();
  }

  addNewUserValue() {
    //(this.editUserModel.editUserAccountForm.controls.userType.value)
    this.editUserModel.checkedUserRole = false;
    switch (this.editUserModel.editUserAccountForm.controls.userType.value) {
      case 'Employee': {

        let valueList = ['rStandardUser', 'rSuperUser', 'rAdministrator', 'rUserAccountManager'];
        if (this.country == 'gr') {
          valueList = ['rGroupAdmin', 'rSuperUser', 'rIndividualAdmin'];

        }
        this.disableCheckbox(valueList);
        this.editUserModel.checkedUserRole = false;
        break;
      }
      case 'Client': {

        let valueList = ['rClient']
        this.disableCheckbox(valueList);
        this.editUserModel.checkedUserRole = true;
        this.disableCheckboxValue(valueList);
        // this.editUserModel.userRoleArrayValue.push('rClient')
        break;
      }
      case 'Advisor': {

        let valueList = ['rAdvisor']
        this.disableCheckbox(valueList);
        this.editUserModel.checkedUserRole = true;
        this.disableCheckboxValue(valueList);
        // this.editUserModel.userRoleArrayValue.push('rAdvisor')
        break;
      }
      case 'Warden': {

        let valueList = ['rWarden']
        this.disableCheckbox(valueList);
        this.editUserModel.checkedUserRole = true;
        this.disableCheckboxValue(valueList);
        // this.editUserModel.userRoleArrayValue.push('rWarden')
        break;
      }
      case 'HR': {

        let valueList = ['rHR']
        this.disableCheckbox(valueList);
        this.editUserModel.checkedUserRole = true;
        this.disableCheckboxValue(valueList);
        // this.editUserModel.userRoleArrayValue.push('rClient')
        break;
      }
    }

  }

  disableCheckbox(valueList) {
    let value = valueList;
    const control = this.editUserModel.editUserAccountForm.controls.userrole as FormArray;
    // if (valueList.length > 0) {
    for (let i = 0; i < valueList.length; i++) {

      for (let j = 0; j < this.editUserModel.userroleList.length; j++) {
        if (this.editUserModel.userroleList[j].value == valueList[i]) {
          control.at(j).enable();
          //  ////("if:",this.eventInsurance[j].data,'-',this.eventSecondaryValue[i])
        } else {
          if (valueList.indexOf(this.editUserModel.userroleList[j].value) < 0) {
            control.at(j).disable();
            control.at(j).setValidators([Validators.nullValidator]);
          }

        }
      }
    }
    // } else {
    //   for (let j = 0; j < this.editUserModel.userroleList.length; j++) {
    //     control.at(j).disable();
    //   }
    // }


  }

  disableCheckboxValue(valueList) {
    const control = this.editUserModel.editUserAccountForm.controls.userrole as FormArray;
    // if (valueList.length > 0) {
    for (let i = 0; i < valueList.length; i++) {

      for (let j = 0; j < this.editUserModel.userroleList.length; j++) {
        if (this.editUserModel.userroleList[j].value == valueList[i]) {

          control.at(j).disable();
          control.at(j).setValidators([Validators.nullValidator]);
        }

      }
    }
  }


  backSearchUser() {
    this.settingParamValue.addNewUser = false;
    this.settingParamValue.editUser = false;
    this.settingParamValue.userAccount = true;
    this.valueChange.emit(this.settingParamValue);
  }

  onClickNavigate() {
    // this.router.navigate(['./homepage']);
    //this.sharedService.getDetail('menuItemList').subscribe((data) => {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
    this.settingParamValue.addNewUser = false;
    this.settingParamValue.editUser = false;
    this.settingParamValue.userAccount = true;
    this.valueChange.emit(this.settingParamValue);
    // },
    //   (error: Error) => {
    //     //this.router.navigate(['/homepage']);
    //   });

  }

  emailUpdate(isChecked: boolean) {
    if (isChecked) {
      this.editUserModel.editUserAccountForm.controls.emailID.enable()
    } else {
      this.editUserModel.editUserAccountForm.controls.emailID.disable()
    }
  }



}
