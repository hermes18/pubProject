import { FormGroup } from '@angular/forms';


export class EditUserModel {
    editUserAccountForm: FormGroup;
    subscribeFlag: boolean;
    submitted: boolean;
    saveSection: boolean;
    userrole: Array<any>;
    userrolePO: Array<any>;
    userroleRO: Array<any>;
    userroleCheckList: Array<any> = [];
    userTypeListPO;
    userTypeListRO;
    userroleList: Array<any>;
    checkedUserRole: boolean;
    userRoleArrayValue: Array<any>;
    showwEmailInValid: boolean;
    statusList;
    temporaryLockDate;
    accountType;
    disablePhone: boolean;
    disableEmail: boolean;
    editUserValue;
    validPhoneNumberErr: boolean;
    emailValidationErr: boolean;
    inputParametersErr: boolean;
    renderCannotReadData: boolean;
    renderMinimumOneActiveOrder: boolean;
    renderUpdateDataError: boolean;
    systemParametersErr: boolean;
    orderNotSent: boolean;
    orderNotRegistered: boolean;
    renderSavePage: boolean;
    renderConfirmPage: boolean;
    UserWithEmailAlreadyExists: boolean;
    constructor() {
        this.UserWithEmailAlreadyExists = false;
        this.renderCannotReadData = false;
        this.validPhoneNumberErr = false;
        this.emailValidationErr = false;
        this.inputParametersErr = false;
        this.renderMinimumOneActiveOrder = false;
        this.renderUpdateDataError = false;
        this.systemParametersErr = false;
        this.orderNotSent = false;
        this.orderNotRegistered = false;
        this.renderSavePage = false;
        this.renderConfirmPage = false;
        this.disablePhone = false;
        this.showwEmailInValid = false;
        this.subscribeFlag = true;
        this.submitted = false;
        this.saveSection = false;
        this.checkedUserRole = false;
        this.userRoleArrayValue = []
        this.userTypeListPO = [
            {
                key: "Employee",
                value: "Employee"
            },
            {
                key: "Customer",
                value: "Client"
            },
            // {
            //     key: "Advisor",
            //     value: "Advisor"
            // },
            {
                key: "Warden",
                value: "Warden"
            }
        ]
        this.userTypeListRO = [
            {
                key: "Employee",
                value: "Employee"
            },
            {
                key: "Customer",
                value: "Client"
            }
            // ,
            // {
            //     key: "Advisor",
            //     value: "Advisor"
            // }
        ]

        this.statusList = [
            {
                key: "Active",
                value: "active"
            },
            {
                key: "Locked",
                value: "locked"
            },
            {
                key: "Closed",
                value: "closed"
            }

        ]


        this.userrole = [{ name: 'Client', value: 'rClient', flag: false },
        { name: 'Standard User', value: 'rStandardUser', flag: false },
        { name: 'Super User', value: 'rSuperUser', flag: false },
        { name: 'System Administrator', value: 'rAdministrator', flag: false },
        { name: 'User Account Manager', value: 'rUserAccountManager', flag: false },
        // { name: 'Advisor', value: 'rAdvisor', flag: false },
        { name: 'Warden', value: 'rWarden', flag: false }
        ]

        this.userroleRO = [{ name: 'Client', value: 'rClient', flag: false },
        { name: 'Standard User', value: 'rStandardUser', flag: false },
        { name: 'Super User', value: 'rSuperUser', flag: false },
        { name: 'System Administrator', value: 'rAdministrator', flag: false }
            // { name: 'Advisor', value: 'rAdvisor', flag: false }
        ]


        this.userrolePO = [{ name: 'Client', value: 'rClient', flag: false },
        { name: 'Standard User', value: 'rStandardUser', flag: false },
        { name: 'Super User', value: 'rSuperUser', flag: false },
        { name: 'System Administrator', value: 'rAdministrator', flag: false },
        { name: 'User Account Manager', value: 'rUserAccountManager', flag: false },
        // { name: 'Advisor', value: 'rAdvisor', flag: false },
        { name: 'Warden', value: 'rWarden', flag: false }
        ]
    }

}