import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { UserAccountComponent } from './user-account/user-account.component';
import * as utils from 'lodash';
import { NavigationEnd, NavigationStart, Router, RouterEvent } from '@angular/router';
import { filter, pairwise, takeWhile } from 'rxjs/operators';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { BroadcasterService } from '../core/services/broadcaster.service';

@Component({
  selector: 'setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.scss']
})
export class SettingComponent implements OnInit {
  @ViewChild(UserAccountComponent, { static: false }) userAccountComp: UserAccountComponent;
  navLinks;
  settingParamValue = {
    'userAccount': false,
    'addNewUser': false,
    'editUser': false
  }
  settingTabIndex;
  settingTabList = {
    'userAccountAdmin': false,
    'ChnagePassword': false,
    'changingSetting': false,
    // 'sendInvitation': false,
    // 'createBulkUsers': false
  };
  // sendInvitationTabIndex;
  // createBulkUsersTabIndex;
  subscribeFlag = true;
  userName: any;
  routeFlag: boolean = false;
  routeFlagFrmHome: boolean = false;
  userRole: string;
  constructor(public commonService: SharedServiceService, private route: Router,
    private readonly menuItemService: MenuItemsService, public readonly broadCastService: BroadcasterService,
    private readonly sharedService: SharedServiceService) { }
  @ViewChild('tabRef', { static: false }) tabRef;
  @ViewChild("accountSetting", { static: false }) accountSetting;
  @ViewChild("changePassword", { static: false }) changePassword;
  // @ViewChild("sendInvitation", { static: false }) sendInvitation;
  // @ViewChild("createBulkUsers", { static: false }) createBulkUsers;

  ngOnInit() {
    this.route.events.pipe(filter((event: RouterEvent) => event instanceof NavigationEnd),
      takeWhile(() => this.subscribeFlag)
    ).subscribe(() => {
      // this.fetchData();
      this.menuListRender();
      // this.fetchData();
    });
    this.menuListRender();
    // this.fetchData();
    this.broadCastService.on<any>('setttingroute').subscribe((data) => {
      this.routeFlag = data;
      if (data) {
        this.settingParamValue.addNewUser = true;
        this.settingParamValue.editUser = false;
        this.settingParamValue.userAccount = false;
      }
      setTimeout(() => {
        if (window.location.href.indexOf('/account-setting') != -1) {
          // this.matSelectedTabIndex = 3;
          this.accountSetting.nativeElement.click();

        }
      })

    });
    // this.routeFlag = this.sharedService.boradcastData.addNewUser;
    // //("route flah", this.routeFlag)
    // if (this.routeFlag) {
    //   this.settingParamValue.addNewUser = true;
    //   this.settingParamValue.editUser = false;
    //   this.settingParamValue.userAccount = false;
    // } else {
    //   this.fetchData();
    // }

    // this.broadCastService.on<any>('fromHomePage').subscribe((data) => {
    //   if (data) {
    //     //('fromhome', data);
    //     this.routeFlagFrmHome = data;
    //     this.tabRef.selectedIndex = 1;
    //   }
    // });
    this.routeFlagFrmHome = this.commonService.getterData('fromHomePage');

    //this.routeFlagFrmHome=sessionStorage.getItem('fromHomePage');

  }


  ngOnDestroy() {
    this.subscribeFlag = false;
  }
  menuListRender() {
    // window.location.reload();
    // //("menu", sessionStorage.getItem('menuItemList'))
    // this.commonService.getDetail('menuItemList').subscribe((data) =>
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let clientID = loggedUser.clientId ? loggedUser.clientId : null;
    if (loggedUser.roleInfo.length == 1 && loggedUser.roleInfo[0].name === 'rAdvisor') {
      this.userRole = "rAdvisor";
    } else {
      this.userRole = '';
    }
    //this.menuItemService.menuItemApi(clientID, 'login').subscribe((data) => {

    this.commonService.getDetail('menuItemList').subscribe((list) => {
      const data = JSON.parse(sessionStorage.getItem('menuItemList'));
      const menuListInAdminn = utils.filter(data.menuItems, obj => {
        if (obj.parentMenu && obj.parentMenu == "Settings") return obj;
      });
      menuListInAdminn.forEach(menu => {
        if (menu.menuName === "User Account Administration") {

          this.settingTabList.userAccountAdmin = true;
          if (!this.routeFlagFrmHome && this.tabRef) {
            this.tabRef.selectedIndex = 0;
          }
        }
        if (menu.menuName === 'Change Password') {
          this.settingTabList.ChnagePassword = true;
          setTimeout(() => {
            if (window.location.href.indexOf('/change-password') != -1) {
              // this.matSelectedTabIndex = 3;
              this.changePassword.nativeElement.click();

            }
          })
        }

        if (menu.menuName === 'Changing the Settings') {
          this.settingTabList.changingSetting = true;
          setTimeout(() => {
            if (window.location.href.indexOf('/account-setting') != -1) {
              // this.matSelectedTabIndex = 3;
              this.accountSetting.nativeElement.click();

            }
          })
        }

        /* if (menu.menuName === 'Send Invitation') {
          this.settingTabList.sendInvitation = true;
          setTimeout(() => {
            if (window.location.href.indexOf('/send-invitation') != -1) {
              // this.matSelectedTabIndex = 3;
              this.accountSetting.nativeElement.click();

            }
          })
        } */

      });
      if (this.routeFlagFrmHome && this.settingTabList.ChnagePassword && this.settingTabList.userAccountAdmin) {
        this.tabRef.selectedIndex = 1;
      } else if (this.routeFlagFrmHome && !this.settingTabList.userAccountAdmin && this.settingTabList.ChnagePassword) {
        this.tabRef.selectedIndex = 0;

      }
    });

    if (!this.routeFlag) {
      this.settingParamValue.addNewUser = false;
      this.settingParamValue.editUser = false;
      this.settingParamValue.userAccount = true;
      // this.broadCastService.broadcast('setttingroute', false);
    }



  }
  fetchData() {

    this.settingParamValue.addNewUser = false;
    this.settingParamValue.editUser = false;
    this.settingParamValue.userAccount = true;

  }

  displayArray(theArray) {
    this.settingParamValue.addNewUser = theArray.addNewUser;
    this.settingParamValue.editUser = theArray.editUser;
    this.settingParamValue.userAccount = theArray.userAccount;

  }

  onTabClick() {
    ////("matSelectedTabIndex",this.matSelectedTabIndex);
    // this.route.navigate(['setting']);
    //this.ngOnInit();

    // this.sharedService.setcontactConsentDetails(null);
    this.settingParamValue.addNewUser = false;
    this.settingParamValue.editUser = false;
    this.settingParamValue.userAccount = true;
    this.onTabChanged('');

  }

  onTabChanged(event) {
    if (this.routeFlag) {
      this.settingParamValue.addNewUser = true;
      this.settingParamValue.editUser = false;
      this.settingParamValue.userAccount = false;
      this.broadCastService.broadcast('setttingroute', false);
    } else {
      this.sharedService.setPramaValue('boradcastData', null);
      this.sharedService.setPramaValue('addNewAccountFormData', null);
      this.sharedService.setPramaValue('legalUpdateData', null)
      this.sharedService.setPramaValue('addNewUserLdapData', null);
      this.sharedService.setPramaValue('userRoleData', null)
      // this.sharedService.setcontactConsentDetails(null);
      this.settingParamValue.addNewUser = false;
      this.settingParamValue.editUser = false;
      this.settingParamValue.userAccount = true;
    }
    // this.settingParamValue.addNewUser = true;
    // this.settingParamValue.editUser = false;
    // this.settingParamValue.userAccount = false;
    this.settingTabIndex = event;
    // this.sendInvitationTabIndex = event;
    // this.createBulkUsersTabIndex = event;
    if (this.userAccountComp)
      this.userAccountComp.ngOnInit();
  }

  editUserValue(event) {
    this.userName = event;
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

}