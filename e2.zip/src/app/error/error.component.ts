import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { HttpCommonService } from '../shared/services/http-common.service';
import { NgForm } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { DialogService } from '../shared/services/dialog.service';
import { TranslateService } from '@ngx-translate/core';
import { UtilityService } from '../shared/utilities/utility.service';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss'],
})
export class ErrorComponent implements OnInit {
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  OKBtn;
  constructor(private cService: HttpCommonService, public translate: TranslateService, private dailogService: DialogService) {

  }

  ngOnInit() {
    this.OKBtn = `${this.translate.instant("OkBtn")}`
    this.country = sessionStorage.getItem('countryCode');
    //("country", this.country)

    this.lang = sessionStorage.getItem('defaultLanguage');
    //("lang", this.lang)
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }
  }
  onRoute() {
    this.dailogService.closeDialog();

  }

  closeDialog() {
    this.dailogService.closeDialog();
  }

}
