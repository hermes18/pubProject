import { Component, ViewChild, ApplicationRef, HostListener, NgZone } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HeaderComponent, FooterComponent, PageNotFoundComponent } from './core/components';
import { BnNgIdleService } from 'bn-ng-idle';
import { DialogService } from './shared/services/dialog.service';
import { AlertDialogComponent } from './shared/dialog/alert-dialog/alert-dialog.component';
import { AuthService } from './core/services/auth.service';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { DateAdapter } from '@angular/material';
import { GetterSetterService } from './core/services/getter-setter.service';
import { HttpCommonService } from '../app/shared/services/http-common.service';
import { Idle, DEFAULT_INTERRUPTSOURCES, DocumentInterruptSource } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { HttpHeaders } from '@angular/common/http';

import { SessionExpiredComponent } from './session-expired/session-expired.component';
import { SharedServiceService } from '../app/shared-service/shared-service.service';
import { LocationStrategy } from '@angular/common';
import { interval, Subject } from 'rxjs';
import { flatMap, takeUntil, startWith, switchMap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { VersionCheckService } from './core/services/version-check.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import * as utils from 'lodash';
import { IdleExpiry, LocalStorageExpiry, SimpleExpiry } from '@ng-idle/core';
import { AppConfig } from 'src/config/app.config';


//import * as $ from 'jquery';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
  //changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent {
  @ViewChild(HeaderComponent, { static: true }) headerRef: HeaderComponent;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  lang: string;
  idleState = 'Not started.';
  timedOut = false;
  timedOutWarning = false;
  countDownMin;
  userName: any = null;
  observableRef: any;
  headers = new HttpHeaders();
  stopTimer$: Subject<any> = new Subject();
  isMobile = this.deviceDetector.isMobile();
  @HostListener('document:click', ['$event'])
  @HostListener('mousemove', ['$event'])
  @HostListener('keypress ', ['$event'])
  documentFocus(event) {
    //console.log('called hostlistener');

    // this.headerRef.idleSecondsCounter = 0;
    //this.checkPageFocus();
    //this.stopTimer$.next();
    // this.callTimerForMobile();
    // this.stopTimer$.next();  
  }

  @HostListener('window:mousemove') refreshUserState() {
    // console.log('test')
    this.resetMobile();
  }
  constructor(private ngZone: NgZone,
    public translate: TranslateService, private bnIdle: BnNgIdleService, private location: LocationStrategy,
    public dialog: DialogService, private authService: AuthService, public router: Router,
    public dateAdapter: DateAdapter<Date>, private getterSetterService: GetterSetterService,
    private idle: Idle, private cService: HttpCommonService,
    private keepalive: Keepalive, private appRef: ApplicationRef, public deviceDetector: DeviceDetectorService,
    private readonly commonService: SharedServiceService, private idelExiry: IdleExpiry,
    private versionCheckService: VersionCheckService, private localExpiry: LocalStorageExpiry) {
    this.lang = "pl_pl";

    this.authService.loginTo().subscribe((data) => {
      if (data) {

        let defaultLanguage = sessionStorage.getItem('defaultLanguage');
        // //("deafult lang---", defaultLanguage);
        this.translate.setDefaultLang(defaultLanguage);
        this.translate.use(defaultLanguage);
        // //(this.router)
        //this.router.navigate([`/login`]);
      }
    });
    // if (window['__env']) {
    //   delete window['__env'];
    // }

    this.location.onPopState(() => {
      // set isBackButtonClicked to true.
      this.commonService.setterData('isBackButtonCliked', true);
      return false;
    });
    //this.commonService.getcurrentUserLoggedIn().subscribe((data) => {
    //this.CallTokenRefresh();
    // });
    //}

    // this.observableRef = interval((intervalTime))
    //   .pipe(
    //     flatMap(() =>
    //       this.authService.refreshUserToken())
    //   )
    //   .subscribe(data => console.log(intervalTime, data));
    // let reqParams = JSON.parse(sessionStorage.getItem('loginFormDetails'));
    // let userToken = JSON.parse(sessionStorage.getItem('userToken')),
    //   userInfo = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));

    // let intervalTime = window['__env']['refreshTokenInMinutes'] * 60 * 1000;
    // this.tokenInterval = setInterval(() => {
    //   if (reqParams && userToken && userInfo) {
    //     // this.authService.refreshUserToken().subscribe((token) => {
    //     //   console.log(token);
    //     //});
    //   } else {
    //     clearInterval(this.tokenInterval);
    //   }
    // }, intervalTime);


  }
  tokenInterval: any = null;

  title = 'eCustomer';
  getRefreshTokenCall() {
    let userName = JSON.parse(sessionStorage.getItem('loginFormDetails')),
      tokenCallParam = {
        "userName": userName.userName
      };
    // headerOptions = {
    //   headers: new HttpHeaders({
    //     'accept-language': sessionStorage.getItem('defaultLanguage'),
    //     'x-tenant-id': sessionStorage.getItem('countryCode'),
    //     'x-system-id': 'ecustomer'
    //   })
    // };
    const token = JSON.parse(sessionStorage.getItem('userToken'));
    let headers =
      new HttpHeaders({
        'accept-language': sessionStorage.getItem('defaultLanguage'),
        'x-tenant-id': sessionStorage.getItem('countryCode'),
        'content-type': 'application/json',
        'accept': 'application/json',
        'x-system-id': 'ecustomer',
        'Authorization': `Bearer ${token.token}`

      })
    this.cService['postDataResponseText'](
      this.baseUrl.ecustomer.tokenRefreshUrl, tokenCallParam, headers, { 'loader': 'true' }).subscribe((data) => {
        //  console.log(data);
        this.authService.refreshUserToken(data).subscribe((token) => {

        });
      });

  }

  CallTokenRefresh() {
    //10000 = 1sec refreshTokenInMinutes
    //(window['__env']['refreshTokenInMinutes'])
    let intervalTime = window['__env']['refreshTokenInMinutes'] * 60 * 1000;
    // callTokenInterval(){
    this.tokenInterval = setInterval(() => {
      if (sessionStorage.getItem('userTokenForTimer') && sessionStorage.getItem('logedUSerForTimer')) {
        this.getRefreshTokenCall();
      } else {
        //this.tokenInterval = null;
        clearInterval(this.tokenInterval);
        this.tokenInterval = null;
      }
    }, intervalTime);
  }
  switchLang(language: string) {
    this.translate.use(language);
    let dateTranslate = {
      'pl_en': 'en',
      'pl_pl': 'pl',
      'ro_ro': 'ro',
      'ro_en': 'en',
      "gr_gr": "gr",
      "gr_en": "en"
    }
    this.dateAdapter.setLocale(dateTranslate[language]);
    sessionStorage.setItem("defaultLanguage", language);
    this.commonService.setLangChange(dateTranslate[language]);

    this.lang = language;
  }




  reset() {
    //this.idle.setTimeout(false);
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOutWarning = false;
  }

  currentUser;
  loggedUser;
  menuItems: any = [];
  clientSearchData: any;
  clientUserRole: boolean = false;
  userAccountManagerRole: boolean = false;

  ngOnDestroy() {
    //  this.observableRef.unsubscribe();
  }

  ngOnInit() {
    // added for cache issue
    //if(environment.versionCheckURL){

    // this.versionCheckService.initVersionCheck('./assets/version.json');
    // }
    //added for cache issue ends
    if (!sessionStorage.getItem('userToken')) {
      this.router.navigate(['/login']);
    }

    this.commonService.getCurrentUserToken().subscribe((data) => {
      this.currentUser = data;
    });
    this.commonService.getcurrentUserLoggedIn().subscribe((data) => {
      this.loggedUser = data;
      this.loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      if (!utils.isEmpty(this.loggedUser)) {
        this.callIdleTimer();
      }
    });
    this.commonService.getDetail('menuItemList').subscribe((data) => {
      this.clientUserRole = false;
      this.userAccountManagerRole = false;
      const role = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      if (role) {
        role.roleInfo.find((data) => {
          if (data.name === 'rClient') {
            this.clientUserRole = true;
          }
          if (role.length == 1 && data.name === 'rUserAccountManager') {
            this.userAccountManagerRole = true;
          }
        });
      }
      const clientSearch =
        JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
      this.clientSearchData = clientSearch ? JSON.parse(sessionStorage.getItem('menuListFromClientSearch')) : null;
      // this.clientSearchData = utils.filter(clientSearch.menuItems, obj => {
      //   if (obj.parentMenu && obj.parentMenu == "Main Menu") return obj;
      // });
      this.menuItems = data;
      this.dateLanguageChange(this.lang);
      //this.callIdleTimer();
    });
  }
  dateLanguageChange(language) {
    let dateTranslate = {
      'pl_en': 'en',
      'pl_pl': 'pl',
      'ro_ro': 'ro',
      'ro_en': 'en',
      'gr_gr': 'el',
      'gr_en': 'en'
    }
    this.dateAdapter.setLocale(dateTranslate[language]);
  }

  showUserName: boolean = false;
  isEnterTimeOutSection: boolean = false;
  // idleSecondsCounter: number = 0;
  // IDLE_TIMEOUT = 60;
  // idleSecondsTimer = null;
  // checkPageFocus() {
  //   this.headerRef.idleSecondsCounter++;
  //   if (this.headerRef.idleSecondsCounter >= this.headerRef.IDLE_TIMEOUT) {
  //     // this.headerRef.idleSecondsTimer.unsubscribe();
  //     console.log("Time expired!");
  //     let reqParams = {};
  //     sessionStorage.setItem('loginFormDetails', JSON.stringify(reqParams));
  //     this.isEnterTimeOutSection = true;
  //     this.headerRef.timeLeft = 0;
  //     this.timedOutWarning = false;
  //     this.headerRef.userData = null;
  //     this.userName = '';
  //     this.timedOut = true;
  //     //this.observableRef.unsubscribe();
  //     this.idle.stop();
  //     this.headerRef.idleSecondsTimer.unsubscribe();
  //     window.clearInterval(this.idleSecondsTimer);
  //     this.dialog.openDialog(SessionExpiredComponent, {});
  //     // this.stopTimer$.next();
  //   } else {
  //     let sessionOut = ((window['__env']['sessionTimeoutInMinutes']) + 1) * 60;

  //     let countdownVal = this.headerRef.idleSecondsCounter - 1;
  //     if (Math.floor((countdownVal) / 60) === 0 && this.headerRef) {
  //       //  this.headerRef.timeLeft = countdownVal;
  //       this.headerRef.idleSecondsCounter = countdownVal;
  //       // this.headerRef.secStarts = true;

  //     } else {
  //       // this.headerRef.secStarts = false;
  //       // this.headerRef.timeLeft = Math.floor(countdownVal / 60);
  //       this.headerRef.idleSecondsCounter = Math.floor(countdownVal / 60);

  //     }

  //     if (countdownVal === 0) {
  //       // sessionStorage.clear();

  //     }
  //   }
  //   //console.log(this.idleSecondsCounter)
  //   //  if (document.hasFocus()) {
  //   //   console.log('tab active')
  //   // } else {
  //   //   console.log('tab inactive', document.hasFocus())
  //   // }
  // }

  idleSecondsTimer;


  // callTimerForMobile() {
  //   // if (this.isMobile) {
  //   this.idleSecondsTimer = setInterval(() => {
  //     this.checkPageFocus();
  //   }, 1000);
  //   // this.headerRef.idleSecondsTimer = interval(1000).pipe(takeUntil(this.stopTimer$)).subscribe(x => {
  //   //   this.checkPageFocus(x);
  //   // });
  // }

  initListener() {
    //this.ngZone.runOutsideAngular(() => {
    document.body.addEventListener('click', () => this.reset());
    //});
  }

  timerIntervalCount;
  initInterval() {
    this.ngZone.runOutsideAngular(() => {
      this.timerIntervalCount = setInterval(() => {
        if (sessionStorage.getItem('loggedInUserInfo') && sessionStorage.getItem('userToken')) {
          this.check();
        } else {
          clearInterval(this.timerIntervalCount);
          this.secondsCounter = 60;
        }
      }, 1000);
    })
  }

  resetMobile() {
    this.lastAction = Date.now();
    this.secondsCounter = 60;
  }
  mobileTimeLimit = ((window['__env']['sessionTimeoutInMinutes']) + 1) * 60;
  mobileTimeLeft: number = 60;
  lastAction;
  secondsCounter: number = 60;
  check() {
    const now = Date.now();
    const timeleft = this.lastAction + ((window['__env']['sessionTimeoutInMinutes']) + 1) * 60 * 1000;
    const diff = timeleft - now;
    const isTimeout = diff < 0;
    const countDownInMin = Math.floor(diff / 60);
    if (Math.floor((countDownInMin) / 1000) === 0 && this.headerRef) {
      this.secondsCounter = this.secondsCounter - 1;
      this.headerRef.timeLeft = this.secondsCounter;
      this.headerRef.secStarts = true;
    } else {
      this.headerRef.secStarts = false;
      let splittedVal = (countDownInMin / 1000).toString().split('.'),
        coundownVAl = parseInt(splittedVal[0]);
      this.headerRef.timeLeft = coundownVAl;
    }
    this.ngZone.run(() => {
      if (isTimeout) {
        // console.log(`timeout mobile`);
        sessionStorage.removeItem('userTokenForTimer');
        sessionStorage.removeItem('logedUSerForTimer');
        clearInterval(this.timerIntervalCount);
        this.secondsCounter = 60;
        this.dialog.openDialog(SessionExpiredComponent, {});
        setTimeout(() => {
          window.scrollTo(0, 0);
        });
      }
    });

  }
  callIdleTimer() {
    this.headerRef.userData = this.loggedUser;
    this.showUserName = true;
    if (this.tokenInterval == null) {
      this.CallTokenRefresh();
    }
    const loggedInUserDetails = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    if (this.loggedUser || loggedInUserDetails) {
      this.lastAction = Date.now();
      clearInterval(this.timerIntervalCount);
      this.check();
      //this.initListener();
      this.initInterval();
      // sets an idle timeout of 5 seconds, for testing purposes.
      // this.idle.setIdle(1);
      // let sessionOut = ((window['__env']['sessionTimeoutInMinutes']) + 1) * 60;

      // this.idleSecondsTimer = setInterval(() => {
      //   this.checkPageFocus();
      // }, 1000);

      //this.callTimerForMobile();
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      // this.idle.setTimeout(sessionOut);

      //const interuptsources = new DocumentInterruptSource("click keydown mousemove pointermove");
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      // this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
      // this.idle.onIdleEnd.subscribe(() => {
      //   this.idleState = 'No longer idle.';
      //   if (this.headerRef) {
      //     this.headerRef.timeLeft = window['__env']['sessionTimeoutInMinutes'];

      //     // this.headerRef.timeLeft = 0;
      //   }
      //   // //(this.idleState);
      //   this.timedOutWarning = false;
      //   this.timedOut = false;
      //   this.appRef.tick();
      //   this.reset();

      // });

      // this.idle.onTimeout.subscribe(() => {
      //   //if (this.headerRef.timeLeft === 0) {
      //   let reqParams = {};
      //   sessionStorage.setItem('loginFormDetails', JSON.stringify(reqParams));
      //   //this.isEnterTimeOutSection = true;
      //   this.headerRef.timeLeft = 0;
      //   this.timedOutWarning = false;
      //   ////   this.headerRef.userData = null;
      //   //his.userName = '';
      //   this.timedOut = true;
      //   //   this.observableRef.unsubscribe();
      //   //  this.idle.stop();
      //   //this.dialog.openDialog(SessionExpiredComponent, {});
      //   this.idleState = 'Timed out!';


      //}
      // else {
      //   this.idleState = 'No longer idle.'
      //   this.isEnterTimeOutSection = false;
      //   this.headerRef.timeLeft = 0;
      //   // //(this.idleState);
      //   this.timedOutWarning = false;
      //   this.timedOut = false;
      //   this.appRef.tick();
      //   this.reset();
      // }
      //   setTimeout(() => {
      //     window.scrollTo(0, 0);
      //   });

      //   //   this.router.navigate(['/']);
      // });

      // this.idle.onIdleStart.subscribe(() => {

      //   // if (this.isMobile) {
      //   // this.idleSecondsCounter = 0;
      //   // setInterval(this.checkPageFocus, 3000)
      //   // }
      //   // this.idleState = 'You\'ve gone idle!'
      //   //this.childModal.show();
      // });

      // this.idle.onTimeoutWarning.subscribe((countdown, doCountdown) => {
      //   this.timedOutWarning = true;
      //   // if ((countdown - 1) % 60 === 0) {
      //   //   this.headerRef.timeLeft = Math.floor(countdown / 60);
      //   // }
      //   let countdownVal = countdown - 1;
      //   //  console.log(this.idle['countdown'])
      //   console.log(countdown)
      //   if (Math.floor((countdownVal) / 60) === 0 && this.headerRef) {
      //     this.headerRef.timeLeft = countdownVal;
      //     this.headerRef.secStarts = true;

      //   } else {

      //     this.headerRef.secStarts = false;
      //     this.headerRef.timeLeft = Math.floor(countdownVal / 60);
      //   }
      //   console.log('timeleft', this.headerRef.timeLeft);
      //   this.appRef.tick();
      //   // if (this.headerRef.timeLeft == 5) {
      //   //  // this.idle['countdown'] = countdownVal;
      //   //  this.idle.watch();
      //   // }

      //   // if (countdownVal === 0) {
      //   //   // sessionStorage.clear();
      //   //   this.userName = '';
      //   // }
      // });

      // sets the ping interval to 15 seconds
      // this.keepalive.interval(5);
      // let intervalTime = window['__env']['refreshTokenInMinutes'] * 60 * 1000;

      // this.keepalive.onPing.subscribe(() => {
      //   console.log('alive')
      // });


      //   // this.observableRef = interval((intervalTime))
      //   //   .pipe(
      //   //     flatMap(() =>
      //   //       this.authService.refreshUserToken())
      //   //   )
      //   //   .subscribe(data => console.log(data)),
      //   console.log(new Date()));

      // this.reset();

    } else {
      // this.idle.stop();
    }
  }

  onRouteChange() {
    window.scroll(0, 0);
    this.languageVersionCheck();
    // console.log(window.location.hostname)
    // this.router.events.subscribe((ev) => {
    //   if (ev instanceof NavigationStart) {
    //     console.log(this.router.config)
    //   }
    // });
  }
  language_version;
  languageVersionCheck() {
    let timeStamp = new Date().getTime();
    const token = JSON.parse(sessionStorage.getItem('userToken'));
    if (token) {
      this.cService['getData'](('./assets/i18n/lang_version.json?t=' + timeStamp), null, { 'loader': 'true' }).subscribe((response) => {
        if (this.language_version != response.version) {
          console.log(this.language_version, response.version);
          console.log(this.language_version != null && this.language_version != '');
          if (this.language_version != null && this.language_version != '') {
            console.log("reset lang");
            this.resetLanguage();
          }
          this.language_version = response.version;
          // setTimeout(() => {
          //  this.changeDetector.detectChanges();

          // }, 1000);
        }
      });
    }
  }


  resetLanguage() {
    let translationLangs = Object.keys(this.translate.translations);
    let defaulltlang = sessionStorage.getItem('defaultLanguage');
    for (let i = 0; i < translationLangs.length; i++) {
      this.translate.resetLang(translationLangs[i]);
      // //  this.translate.use(translationLangs[i]);
      // this.translate.reloadLang(defaulltlang);
      let timeStamp = new Date().getTime();
      this.cService['getData'](('./assets/i18n/' + translationLangs[i] + '.json?t=' + timeStamp)).subscribe((response) => {
        this.translate.setTranslation(translationLangs[i], response);
        // this.translate.use(defaulltlang);
      });

      if (this.translate.translations.hasOwnProperty([translationLangs[i]])) {
        // delete this.translate.translations[translationLangs[i]];

      }
    }


    // this.translate.reloadLang(defaulltlang);
    // this.switchLang('pl_pl');
    this.switchLang(defaulltlang);
    // setTimeout(() => {
    // this.appRef.tick()

    // }, 1000);
  }





}
