import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TranslateLoader, TranslateModule, TranslateService, TranslatePipe } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HeaderComponent, FooterComponent, PageNotFoundComponent } from './core/components';
import { MenuComponent } from './core/components';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { LandingPageComponent } from './landing-page/landing-page.component';
// import { OrderComponent } from './order/order.component';
// import { PolicyComponent } from './policy/policy.component';
import { ErrorComponent } from './error/error.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { SessionExpiredComponent } from './session-expired/session-expired.component';
import { SidenavListComponent } from './core/components/sidenav-list/sidenav-list.component';
import { SharedModule } from './shared/shared.module';
import { HttpConfigInterceptor } from './core/interceptors/http-config.interceptor';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BnNgIdleService } from 'bn-ng-idle';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter, MatDatepickerModule, MatNativeDateModule, MatDatepickerIntl } from '@angular/material';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { AuthService } from './core/services/auth.service';
import { LogoutComponent } from './logout/logout.component';
import { ForgotLoginComponent } from './forgot-login/forgot-login.component';
import { NoDataComponent } from './no-data/no-data.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { DeviceDetectorService } from 'ngx-device-detector';
import { VersionCheckService } from './core/services/version-check.service';
import { IdleExpiry, LocalStorageExpiry, SimpleExpiry } from '@ng-idle/core';
// import { MyClaimComponent } from './my-claim/my-claim.component';
//import { MyContractsComponent } from './contracts/my-contracts/my-contracts.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MenuComponent,
    PageNotFoundComponent,
    //LandingPageComponent,
    ErrorComponent,
    AccessDeniedComponent,
    SessionExpiredComponent,
    // PolicyComponent,
    // OrderComponent,
    SidenavListComponent,
    ForgotPasswordComponent, ChangePasswordComponent, LogoutComponent,
    // /MyContractsComponent,
    ForgotLoginComponent,
    NoDataComponent,
    ErrorPageComponent
  ],
  imports: [
    BrowserModule, FlexLayoutModule, CommonModule,
    FormsModule,
    ReactiveFormsModule, HttpClientModule, NgxSpinnerModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
    AppRoutingModule,
    // NgbModule.forRoot(),
    FormsModule,
    NgIdleKeepaliveModule.forRoot(),
    BrowserAnimationsModule,
    SharedModule.forRoot(),
    MatDatepickerModule, MatNativeDateModule

  ],
  exports: [TranslateModule, TranslatePipe, CommonModule,
    FormsModule,
    ReactiveFormsModule],
  providers: [VersionCheckService, BnNgIdleService, AuthService, TranslatePipe, {
    'provide': APP_INITIALIZER,
    'useFactory': initTranslation,
    'deps': [TranslateService],
    'multi': true
  },
    { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true },
    LocalStorageExpiry,
    {
      provide: IdleExpiry,
      useClass: SimpleExpiry
    },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
    DeviceDetectorService

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
// AOT compilation support
export function initTranslation(translate: TranslateService) {
  return () => {

    //  let defaultLang = storage.getSession('userData');
    // let defaultLang = JSON.parse(sessionStorage['userData']).defaultLanguage;

    translate.addLangs(['pl', 'pl_en', 'ro', 'ro_en', 'gr', 'gr_en']);

    // translate.setDefaultLang('pl_pl');
    // translate.use('pl_pl');
    return Promise.resolve();
  };
}
export function httpTranslateLoader(http: HttpClient) {
  //return new TranslateHttpLoader(http,'URL');
  //const prefix = "http://127.0.0.1:8887/i18n/";
  //const suffix = ".json"
  let timeStamp = new Date().getTime();
  return new TranslateHttpLoader(http, './assets/i18n/', '.json?t=' + timeStamp);

  //return new TranslateHttpLoader(http);
}