export const eClaimsConstants = {


    addNewUserEnableCountry: "pl|PL|gr|Gr",
    editUserAccountEnableCounry: "ro|RO",
    errorPageStatusCode: 404

}