import { Injectable, Output, EventEmitter, Inject } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';

import { Observable, of, throwError } from 'rxjs';
import { map, catchError, retryWhen, tap } from 'rxjs/operators';
import { GetterSetterService } from './getter-setter.service';
import { environment } from 'src/environments/environment';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { Router } from '@angular/router';

@Injectable()
export class AuthService {

    redirectUrl: string;
    appConfig: AppConfig = AppConfig.getConfig();
    baseUrl = this.appConfig['api'];
    //  @Output() authChanged: EventEmitter<boolean> = new EventEmitter<boolean>();

    constructor(private http: HttpClient, private cService: HttpCommonService,
        private readonly menuItemService: MenuItemsService,
        public sharedService: SharedServiceService, @Inject('Window') private window: Window, private getterSetterService: GetterSetterService, public router: Router) { }



    loginTo() {
        let reqData = "";
        let host: "'http://'+window.location.host+'/'";

        //let config = { url: (environment.hosts + environment.authServiceConfig.url) };
        let windowURL = this.window.location.href;
        //const httpParams = new HttpParams({ fromString: windowURL.split('?')[1] });
        // let params = {
        //     // identifierToken: httpParams.get('identifierToken'),
        //     // sourceOrigin: httpParams.get('sourceOrigin'),
        //     countryCode: httpParams.get('countryCode'),
        //     language: httpParams.get('language')


        // }
        ////("params", params)
        let countryCodeParam = window['__env']['countryCode'];
        //('env', window['__env']['countryCode']);
        //('auth service country param', countryCodeParam);
        let defaultlang = { "pl": "pl_pl", "pl_en": "pl_en", "ro": "ro_ro", "ro_en": "ro_en", "gr": "gr_gr", "gr_en": "gr_en" };
        let landStoreInSession = {
            "pl_pl": "pl_pl", "pl_en": "pl_en", "ro_ro": "ro_ro", "ro_en": "ro_en",
            "gr_gr": "gr_gr", "gr_en": "gr_en"
        }
        const langInSession = sessionStorage.getItem("defaultLanguage");
        // sessionStorage.setItem("countryCode",defaultlang[httpParams.get('countryCode')])
        if (defaultlang[countryCodeParam]) {
            langInSession ? sessionStorage.setItem("defaultLanguage", landStoreInSession[langInSession]) : sessionStorage.setItem("defaultLanguage", defaultlang[countryCodeParam]);
            sessionStorage.setItem("countryCode", countryCodeParam);
            // this.getterSetterService.setSession("defaultLanguage", defaultlang[httpParams.get('countryCode')]);
        }
        // return this.http.get<any>(config.url)
        //     .pipe(map(data => {
        //         // login successful if there's a jwt token in the response
        //         //(data, "data");
        //         if (data && data.landingPage) {
        //             sessionStorage.setItem('userData', JSON.stringify(data));
        //             // this.getterSetterService.setSession('defaultLanguage', JSON.stringify(data));

        //         }

        //        return data.landingPage;
        //     }),
        this.triggerMenuCallOnRefresh();
        return of('login');
        // catchError(this.handleError)
        //     );
    }


    private handleError(error: HttpErrorResponse) {
        console.error('server error:', error);
        if (error.error instanceof Error) {
            const errMessage = error.error.message;
            return Observable.throw(errMessage);
            // Use the following instead if using lite-server
            // return Observable.throw(err.text() || 'backend server error');
        }
        return Observable.throw(error || 'Server error');
    }


    triggerMenuCallOnRefresh() {
        const clientId = JSON.parse(sessionStorage.getItem('searcClientID'));
        const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
        let LoginClientID = loggedUser ? loggedUser.clientId ? loggedUser.clientId : null : null;

        if (clientId) {
            this.menuItemService.menuItemApi(clientId.clientID, 'search').subscribe((data) => {
                sessionStorage.setItem('menuListFromClientSearch', JSON.stringify(data));
                this.sharedService.setDetail('menuItemList', data);
                //this.menuItemService.navigationBasedOnRole(data);
            });
        } else if (LoginClientID) {
            this.menuItemService.menuItemApi(LoginClientID, 'login').subscribe((data) => {
                this.sharedService.setDetail('menuItemList', data);
                sessionStorage.setItem('menuItemList', JSON.stringify(data));
                //this.menuItemService.navigationBasedOnRole(data);
            });
        }
    }




    refreshUserToken(data) {
        let reqParams = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
        let userToken = JSON.parse(sessionStorage.getItem('userToken')),
            userName = JSON.parse(sessionStorage.getItem('loginFormDetails')),
            userInfo = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
        if (reqParams && userName && userToken && userInfo) {
            let tokenCallParam = {
                "userName": userName.userName,
                "password": data,
                "type": "refresh"
            };
            const token = JSON.parse(sessionStorage.getItem('userToken'));
            let headers =
                new HttpHeaders({
                    'accept-language': sessionStorage.getItem('defaultLanguage'),
                    'x-tenant-id': sessionStorage.getItem('countryCode'),
                    'content-type': 'application/json',
                    'accept': 'application/json',
                    'x-system-id': 'ecustomer',
                    'Authorization': `Bearer ${token.token}`

                })
            //  this.cService['postDataWithHeader'](
            //     this.baseUrl.ecustomer.loginUrl, reqParams, headerOptions);

            return this.cService['postDataWithHeader'](
                this.baseUrl.ecustomer.loginUrl, tokenCallParam, headers, { 'loader': 'true' })

                .pipe(map((data: any) => {
                    //    console.log(data);
                    sessionStorage.setItem('userToken', JSON.stringify(data));
                    return data.token;
                }), retryWhen(errors => {
                    let countDown = 3;
                    return errors
                        .pipe(
                            tap(errorStatus => {
                                //  console.log(errors);
                                // console.log(errorStatus);

                                if (errorStatus instanceof HttpErrorResponse) {
                                    console.log("countdown", countDown);
                                    if (countDown > 0) {
                                        console.log("retry");
                                    } else {
                                        throw errorStatus;
                                    }
                                    --countDown;
                                } else {
                                    throw errorStatus;
                                }
                            })
                            //,take(2)
                            //,retry(3)
                        )
                    // Throw an exception to signal that the error needs to be propagated

                }
                ),
                    catchError((err) => {
                        let defaultLanguage = sessionStorage.getItem("defaultLanguage");
                        this.router.navigate(['/errorPage']);
                        return throwError(err);

                    })
                );
        }
    }
}