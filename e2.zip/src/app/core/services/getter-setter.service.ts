import { Injectable, Output, EventEmitter, Inject } from '@angular/core';
import { HttpClient, HttpErrorResponse,HttpParams,HttpClientModule } from '@angular/common/http';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable({providedIn:'root'})
export class GetterSetterService {

    constructor(private http: HttpClient, @Inject('Window') private window: Window,private route: ActivatedRoute,private router: Router) { }

getSession(key){
    /*let val  
    if(objKey){
    val =(JSON.parse(sessionStorage.getItem(objKey)))[key]; 
    }
    else{
        val =JSON.parse(sessionStorage.getItem(key)); 
    }*/
return JSON.parse(sessionStorage.getItem(key));

}
setSession(key,data){
if(typeof(data)!= 'string' ){
data = JSON.stringify(data);
}
    sessionStorage.setItem(key,data);
}

}