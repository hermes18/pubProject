import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { SharedServiceService } from '../../shared-service/shared-service.service';

@Injectable({ providedIn: 'root' })
export class CanActivateGuard implements CanActivate {
    currentUser;
    constructor(
        private router: Router,
        private authenticationService: SharedServiceService
    ) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        this.authenticationService.getCurrentUserToken().subscribe(data => {
            this.currentUser = data;
        });

        const requiresLogin = route.data.requiresLogin || false;
        if (this.currentUser && requiresLogin) {
            return true;
        }

        // not logged in so redirect to login page with the return url
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
        return false;
    }
}