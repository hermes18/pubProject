import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

import { SharedServiceService } from '../../shared-service/shared-service.service';

@Injectable({ providedIn: 'root' })

export class NavigationGuard implements CanDeactivate<any> {
    constructor(private sharedService: SharedServiceService) { }

    canDeactivate(component: any, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState?: RouterStateSnapshot) {
        if (this.sharedService.getterData('isBackButtonCliked')) {
            this.sharedService.setterData('isBackButtonCliked', false);
            // push current state again to prevent further attempts.
            history.pushState(null, null, location.href);
            return false;
        }
        return true;
        //throw new Error('Method not implemented.');
    }
}