export { FooterComponent } from './footer/footer.component';
export { HeaderComponent } from './header/header.component';
export { PageNotFoundComponent } from './page-not-found/page-not-found.component';
export { MenuComponent } from './menu/menu.component';