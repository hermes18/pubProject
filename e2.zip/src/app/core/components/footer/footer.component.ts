import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  showToaster = true;
  country: string;
  lang: any;
  displayPoOption: boolean;
  displayRoOption: boolean;
  loggedInCountryCheck: boolean;
  constructor(public router: Router) { }

  ngOnInit(): void {
    this.country = sessionStorage.getItem('tenantId');
    this.country = sessionStorage.getItem('countryCode');
    //("country", this.country)

    this.lang = sessionStorage.getItem('defaultLanguage');
    //("lang", this.lang)
    this.loggedInCountryCheck = UtilityService.getCountry();
    if (this.loggedInCountryCheck)
      //   if (this.country == 'pl')
      this.displayPoOption = true;
    else
      this.displayRoOption = true;
  }

  addresseOffices() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/pl/individual/obsuga-klienta/znajdz-placowke/index.html";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/pl/individual/obsuga-klienta/znajdz-placowke/index.html";
        break;
      case 'ro_ro': redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/gaseste-un-consultant/";
        break;
      case 'ro_en': redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/gaseste-un-consultant/";
        break;
    }
    window.open(redirectTo, "_blank");
  }

  termsOfService() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");
    //console.log("clicked")
    switch (language) {
      case 'pl_pl': window.open("/assets/mocks/Regulamin.pdf");
        break;
      case 'pl_en': window.open("/assets/mocks/Regulamin.pdf");
        break;
      case 'ro_ro': window.open("/assets/mocks/Terms_condition_Ro_ro.pdf");
        break;
      case 'ro_en': window.open("/assets/mocks/Terms_condition_Ro_en.pdf");
        break;
    }
  }
  siteSecurity() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");

    switch (language) {
      case 'pl_pl': window.open("/assets/mocks/Ochrona_prywatnosci.pdf");
        break;
      case 'pl_en': window.open("/assets/mocks/Ochrona_prywatnosci.pdf");
        break;
      case "ro_ro": window.open("/assets/mocks/MetLife_Politica_de_prelucrare_date_clienti_Life_si_NonLife_aug2019.pdf");
        break;
      case "ro_en": window.open("/assets/mocks/MetLife_Politica_de_prelucrare_date_clienti_Life_si_NonLife_aug2019.pdf");
        break;
    }
  }


  privacyPolicyManual() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'ro_ro': window.open("/assets/mocks/Afla aici detalii despre eCustomer.pdf");
        break;
      case 'ro_en': window.open("/assets/mocks/Afla aici detalii despre eCustomer.pdf");
        break;

    }
  }



  userManual() {


    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'pl_pl': window.open("/assets/mocks/Pomocnik w użytkowaniu portalu e-klient.pdf");
        break;
      case 'pl_en': window.open("/assets/mocks/Pomocnik w użytkowaniu portalu e-klient.pdf");
        break;

    }
  }

  //link need to be updated

  //both
  contact() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
        break;
      case 'ro_ro': redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/contact/";
        break;
      case 'ro_en': redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/contact/";
        break;
      // case 'ro_ro': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
      //   break;
      // case 'ro_en': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
      //   break;
    }
    window.open(redirectTo, "_blank");
  }
  //only romania

  keyInformation() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'ro_ro': redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/Informatii-utile/Informatii-esentiale/";
        break;
      case 'ro_en': redirectTo = "https://www.metropolitanlife.ro/ai-nevoie-de-ajutor/Informatii-utile/Informatii-esentiale/";
        break;
    }
    window.open(redirectTo, "_blank");
  }

  cookiePolicy() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/cookies/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/cookies/";
        break;
      case 'ro_ro': redirectTo = "https://10.112.204.4:999/eClaims/faces/xAdvisorWeb/bundles/eclaimsRomania/pdf/Cookie_Policy.pdf";
        break;
      case 'ro_en': redirectTo = "https://10.112.204.4:999/eClaims/faces/xAdvisorWeb/bundles/eclaimsRomania/pdf/Cookie_Policy.pdf";
        break;
    }
    window.open(redirectTo, "_blank");

  }
  privacyPolicy() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/polityka_prywatnosci/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.com/about-us/privacy-policy/online-privacy-policy/";
        break;
      case 'ro_ro': redirectTo = "https://www.metlife.com/about-us/privacy-policy/online-privacy-policy/";
        break;
      case 'ro_en': redirectTo = "https://www.metlife.com/about-us/privacy-policy/online-privacy-policy/";
        break;
    }
    window.open(redirectTo, "_blank");
  }

  legalPolicy() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/prawne_regulaminy/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.com/about-us/terms-and-conditions/";
        break;
      case 'ro_ro': redirectTo = "https://www.metlife.com/about-us/terms-and-conditions/";
        break;
      case 'ro_en': redirectTo = "https://www.metlife.com/about-us/terms-and-conditions/";
        break;

        window.open(redirectTo, "_blank");

    }
  }
  //link need to be updated
}
