import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';

import { FooterComponent } from './footer.component';

describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;


  beforeEach(() => {
    sessionStorage.setItem("defaultLanguage","pl_pl");
    sessionStorage.setItem('tenantId','pl');
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: [],
      providers: [TranslateService]
    })
      .compileComponents();
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  // it('ngOnInit should set country ', () => {
    
     
  //   expect(component.country).toEqual('ro');
  // });
  it('privacyPolicy should call privacyPolicy ', () => {
    
    spyOn(component, 'privacyPolicy').and.callThrough();
    component.privacyPolicy();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.privacyPolicy();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.privacyPolicy();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.privacyPolicy();
    expect(component.privacyPolicy).toHaveBeenCalled();
  });
  it('addresseOffices should call addresseOffices ', () => {
    
    spyOn(component, 'addresseOffices').and.callThrough();
    component.addresseOffices();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.addresseOffices();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.addresseOffices();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.addresseOffices();
    expect(component.addresseOffices).toHaveBeenCalled();
  });
  it('termsOfService should call termsOfService ', () => {
    
    spyOn(component, 'termsOfService').and.callThrough();
    component.termsOfService();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.termsOfService();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.termsOfService();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.termsOfService();
    expect(component.termsOfService).toHaveBeenCalled();
  });
  it('siteSecurity should call siteSecurity ', () => {
    
    spyOn(component, 'siteSecurity').and.callThrough();
    component.siteSecurity();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.siteSecurity();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.siteSecurity();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.siteSecurity();
    expect(component.siteSecurity).toHaveBeenCalled();
  });
  it('privacyPolicyManual should call privacyPolicyManual ', () => {
    
    spyOn(component, 'privacyPolicyManual').and.callThrough();
  
    component.privacyPolicyManual();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.privacyPolicyManual();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.privacyPolicyManual();
    expect(component.privacyPolicyManual).toHaveBeenCalled();
  });
  it('userManual should call userManual ', () => {
    
    spyOn(component, 'userManual').and.callThrough();
    component.userManual();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.userManual();
    sessionStorage.setItem("defaultLanguage","pl_pl");
   
    component.userManual();
    expect(component.userManual).toHaveBeenCalled();
  });
  it('contact should call contact ', () => {
    
    spyOn(component, 'contact').and.callThrough();
    component.contact();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.contact();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.contact();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.contact();
    expect(component.contact).toHaveBeenCalled();
  });
  it('keyInformation should call keyInformation ', () => {
    
    spyOn(component, 'keyInformation').and.callThrough();
    
    component.keyInformation();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.keyInformation();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.keyInformation();
    expect(component.keyInformation).toHaveBeenCalled();
  });
  it('cookiePolicy should call cookiePolicy ', () => {
    
    spyOn(component, 'cookiePolicy').and.callThrough();
    component.cookiePolicy();
    sessionStorage.setItem("defaultLanguage","pl_en");
    component.cookiePolicy();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.cookiePolicy();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.cookiePolicy();
    expect(component.cookiePolicy).toHaveBeenCalled();
  });
  //  it('legalPolicy should call legalPolicy ', () => {
    
  //   spyOn(component, 'legalPolicy').and.callThrough();
  //   component.legalPolicy();
  //   sessionStorage.setItem("defaultLanguage","pl_en");
  //   component.legalPolicy();
  //   sessionStorage.setItem("defaultLanguage","ro_ro");
  //   component.legalPolicy();
  //   sessionStorage.setItem("defaultLanguage","ro_en");
  //   component.legalPolicy();
  //   expect(component.legalPolicy).toHaveBeenCalled();
  // });

});
