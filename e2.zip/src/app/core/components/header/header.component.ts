import { Component, OnInit, Output, Input, EventEmitter, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

import { LogoutDialogComponent } from '../../../shared/dialog/logout-dialog/logout-dialog.component';
import { DialogService } from '../../../shared/services/dialog.service';
import { BroadcasterService } from '../../services/broadcaster.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  @Input() lang: string;
  country: string;
  searchedClientDetails: any = null;
  cnpFieldMask: any;
  displayPoOption: boolean = false;
  displayRoOption: boolean = false;
  displayEclaimROAdmin: boolean;
  constructor(public router: Router, public dialog: DialogService, public commonService: SharedServiceService,
    public readonly broadCastService: BroadcasterService, private menuItemService: MenuItemsService,
    public translate: TranslateService) { }

  adminstration: boolean = false;
  timeLeft: any = null;
  secStarts: any = false;
  userData: any = null;
  showUserName: boolean = false;
  loggedUser;
  showPeselFieldValue: boolean = false;
  idleSecondsCounter: number = ((window['__env']['sessionTimeoutInMinutes']));
  IDLE_TIMEOUT = 60;
  idleSecondsTimer = null;
  displayGrOption = false;
  ngOnInit(): void {
    this.displayEclaimROAdmin = false;
    // console.log("1",this.displayEclaimROAdmin)
    this.country = sessionStorage.getItem('countryCode');
    // this.country = "pl"
    //(this.country, "", sessionStorage.getItem('defaultLanguage'));
    this.lang = sessionStorage.getItem('defaultLanguage');
    let loggedInCountryCheck = UtilityService.getCountry();
    console.log("Country",this.country)
    if (loggedInCountryCheck) {
      //  if (this.country == 'pl') {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }

    if(this.country == 'gr'){
      this.displayGrOption = true;
    }
    // this.lang = "pl_pl";
    //if there is no language while redirecting access denied page language should be English same condition in auth.services defect fix

    if (!this.lang) {
      this.lang = "pl_pl";
    }
    this.enableMenuItem();
    this.commonService.getcurrentUserLoggedIn().subscribe((data) => {
      const loggedInUserDetails = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      this.loggedUser = loggedInUserDetails;
      const role = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      //  console.log(role)

      if (this.displayRoOption) {
        // if (role) {
        //   role.roleInfo.find((data) => {
        //     // {roleId: "3034", name: "rAdministrator",
        //     if (data.roleId == "3032" || data.roleId == "3033" || data.roleId == "3034" ||data.roleId == "3036"
        //     || data.name === 'rAdministrator') {
        //       this.displayEclaimROAdmin = true;
        //     }
        //   });
        // }
        if (role) {
          if (role.requesterRole == "3032" || role.requesterRole == "3033" || role.requesterRole == "3034"
            || role.requesterRole == "3036") {
            this.displayEclaimROAdmin = true;

          }
          else {
            this.displayEclaimROAdmin = false;
          }
          //  console.log("2",this.displayEclaimROAdmin)
        }
      }
    });
    this.commonService.getDetail('menuItemList').subscribe((data) => {
      //(data)
      const menuListFromClientSearch = JSON.parse(sessionStorage.getItem('menuListFromClientSearch')),
        menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
      data = menuListFromClientSearch;
      if (data && data.clientLoginId !== null) {
        this.clientLoginID = menuListFromClientSearch.clientLoginId;
        // data.clientLoginId ? data.clientLoginId : menuListFromClientSearch.clientLoginId;
      }
      else {
        this.clientLoginID = null;
      }
      this.searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
      this.cutomerIdLink = `${menuItemList ? menuItemList.ccDBAddressDTO.ccdbAddressPart1 : ''}${this.searchedClientDetails ? this.searchedClientDetails.customerId : ''}`;

      this.cnpFieldMask = this.searchedClientDetails ? this.searchedClientDetails.id ? this.searchedClientDetails.id.split('') : [] : [];
      this.showPeselFieldValue = true;
    });
  }
  clientLoginID = null;
  cutomerIdLink: string;
  toggleFieldTextType() {
    this.showPeselFieldValue = !this.showPeselFieldValue;
  }
  @Output() langChange = new EventEmitter();
  @Output() public sidenavToggle = new EventEmitter();
  @Output() sidenavClose = new EventEmitter();

  public onToggleSidenav = () => {
    this.sidenavToggle.emit();
  }
  public onSidenavClose = () => {
    this.sidenavClose.emit();
  }

  langChanged(event) { // You can give any function name
    //  //("language---",this.lang);
    this.langChange.emit(this.lang);
  }

  contactUs() {
    let redirectTo = "https://www.metropolitanlife.ro/";
    let language = sessionStorage.getItem("defaultLanguage");

    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/";
        break;
      case 'ro_ro': redirectTo = "https://www.metropolitanlife.ro/";
        break;
      case 'ro_en': redirectTo = "https://www.metropolitanlife.ro/";
        break;
    }
    window.open(redirectTo, "_blank");

  }


  onLogoutClickHandler() {
    this.translate.instant("eCustomer.logout.logOutDialogText1")
    // let message1 = `${this.translate.instant("eCustomer.logout.logOutDialogText1")}
    // ${this.translate.instant("eCustomer.logout.logOutDialogText2")}`;
    let message1 = `${this.translate.instant("eCustomer.logout.logOutDialogText")}`
    this.dialog.openDialog(LogoutDialogComponent, {
      'heading': this.translate.instant("eCustomer.logout.header"), 'body': message1
    });
  }


  onClickContact() {
    this.router.navigate(['/contact-form']);

  }


  onClickSetting() {
    this.broadCastService.broadcast('setttingroute', false);
    this.router.navigate(['/setting']);

  }
  onClickAdministration() {
    sessionStorage.setItem('activeTabInAdminBackButton', null);
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    this.commonService.setDetail('contractDetailsOnClick', mobileContractView);

    this.router.navigate(['/administartion']);
  }

  menuList: any = [];
  enableMenuItem() {
    this.commonService.getDetail('menuItemList').subscribe((data) => {
      //(data);
      this.menuList = data;
    });

  }

  showLanguages: any = false;
  languageChanged(language) {
    this.lang = language;
    this.langChanged(this.lang);
    this.showLanguages = false;
  }
  selectBoxClick() {
    if (this.showLanguages) {
      this.showLanguages = false;
    } else {
      this.showLanguages = true;
    }
  }

  onClickEclaim() {
    let redirect = '';
    let menuRedirect = '';
    // this.commonService.getDetail('menuItemList').subscribe((data) => {
    //   // //("eclaims", data.eClaimsURL)

    // });

    let data = JSON.parse(sessionStorage.getItem('menuItemList'));
    let dataMenu = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    redirect = data.eClaimsURL;
    menuRedirect = dataMenu ? dataMenu.eClaimsURL : '';
    if (menuRedirect != null && menuRedirect != '') {
      window.open(menuRedirect, "_blank");
    } else {
      window.open(redirect, "_blank");
    }
  }
  goToHomePagePoland() {
    // console.log("homepage")
    this.router.navigate(['/homepage'])
  }
  goToHomePageRomania() {
    // console.log("homepage")
    this.router.navigate(['/homepage'])
  }

  goToLandingPage() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    if (menuItemList) {
      this.menuItemService.navigationBasedOnRole(menuItemList);
    }

  }
}
