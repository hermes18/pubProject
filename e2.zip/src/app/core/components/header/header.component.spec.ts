import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';

import { HeaderComponent } from './header.component';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;



  beforeEach(() => {
    sessionStorage.setItem("defaultLanguage", "pl_en");
    sessionStorage.setItem('tenantId', 'pl');
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: [],
      providers: [TranslateService]

    })
      .compileComponents();
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('contactUs  should set country  and lang ', () => {
    spyOn(component, 'contactUs').and.callThrough();
    component.contactUs();
    sessionStorage.setItem("defaultLanguage", "pl_en");
    component.contactUs();
    sessionStorage.setItem("defaultLanguage", "ro_en");
    component.contactUs();
    sessionStorage.setItem("defaultLanguage", "ro_ro");
    component.contactUs();
    expect(component.contactUs).toHaveBeenCalled();
  });
  it('call selectBoxClick should toggle showLanguages', () => {
    component.showLanguages = false;
    let testDate = true;
    component.selectBoxClick();
    expect(component.showLanguages).toEqual(testDate);
    component.selectBoxClick();
    expect(component.showLanguages).toEqual(false);

  });
  it('call languageChanged should call langChange', () => {
    component.lang = sessionStorage.getItem('defaultLanguage');
    spyOn(component, 'langChanged').and.callThrough();
    component.languageChanged(sessionStorage.getItem('defaultLanguage'));

    expect(component.langChanged).toHaveBeenCalled();

  });
  it('call toggleFieldTextType ', () => {

    component.showPeselFieldValue = false;

    component.toggleFieldTextType();
    expect(component.showPeselFieldValue).toEqual(true);
    component.toggleFieldTextType();
    expect(component.showPeselFieldValue).toEqual(false);
  });
  it('ngOnInit should set country  and lang ', () => {
    spyOn(component, 'ngOnInit').and.callThrough();
    sessionStorage.setItem("defaultLanguage", "ro_en");
    component.ngOnInit();
    ///expect(component.country ).toEqual("ro");
  });
  it('goToHomePageRomania  should call', () => {
    spyOn(component.router, 'navigate').and.callThrough();
    component.goToHomePageRomania();
    expect(component.router.navigate).toHaveBeenCalled();
  });
  it('call onLogoutClickHandler', () => {
    spyOn(component, 'onLogoutClickHandler').and.callThrough();
    component.onLogoutClickHandler();
    expect(component.onLogoutClickHandler).toHaveBeenCalledWith();

  });
  it('goToHomePagePoland  should call', () => {
    spyOn(component.router, 'navigate').and.callThrough();
    component.goToHomePagePoland();
    expect(component.router.navigate).toHaveBeenCalled();
  });
  it('call onClickAdministration', () => {
    spyOn(component, 'onClickAdministration').and.callThrough();
    component.onClickAdministration();
    expect(component.onClickAdministration).toHaveBeenCalledWith();

  });
  it('call goToLandingPage', () => {
    spyOn(component, 'goToLandingPage').and.callThrough();
    component.goToLandingPage();
    expect(component.goToLandingPage).toHaveBeenCalledWith();

  });
});
