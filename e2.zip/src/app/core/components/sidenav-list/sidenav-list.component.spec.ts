import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { SharedModule } from 'src/app/shared/shared.module';

import { SidenavListComponent } from './sidenav-list.component';

describe('SidenavListComponent', () => {
  let component: SidenavListComponent;
  let fixture: ComponentFixture<SidenavListComponent>;



  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, SharedModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService]

    })
      .compileComponents();
    fixture = TestBed.createComponent(SidenavListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('call selectBoxClick should toggle showLanguages', () => {
    component.showLanguages = false;
    let testDate = true;
    component.selectBoxClick();
    expect(component.showLanguages).toEqual(testDate);
    component.selectBoxClick();
    expect(component.showLanguages).toEqual(false);

  });
  it('call languageChanged should call langChange', () => {
    component.lang = sessionStorage.getItem('defaultLanguage');
    spyOn(component, 'langChanged').and.callThrough();
    component.languageChanged(sessionStorage.getItem('defaultLanguage'));

    expect(component.langChanged).toHaveBeenCalled();

  });
  it('call contactUs should call window.open', () => {
    sessionStorage.setItem("defaultLanguage", 'pl_en');
    spyOn(window, 'open').and.callThrough();
    component.contactUs();

    expect(window.open).toHaveBeenCalledWith('https://www.metlife.pl/', '_blank');
    sessionStorage.setItem("defaultLanguage", 'pl_pl');
    component.contactUs();
    expect(window.open).toHaveBeenCalledWith('https://www.metlife.pl/', '_blank');

    sessionStorage.setItem("defaultLanguage", 'ro_en');
    component.contactUs();
    expect(window.open).toHaveBeenCalledWith('https://www.metropolitanlife.ro/', '_blank');

    sessionStorage.setItem("defaultLanguage", 'ro_ro');
    component.contactUs();
    expect(window.open).toHaveBeenCalledWith('https://www.metropolitanlife.ro/', '_blank');
  });
  it('call onSidenavClose should emit value', () => {

    spyOn(component.sidenavClose, 'emit').and.callThrough();
    component.onSidenavClose();

    expect(component.sidenavClose.emit).toHaveBeenCalled();

  });
});
