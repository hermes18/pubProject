import { Component, OnInit, Output, EventEmitter, Input, ViewChild, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { LogoutDialogComponent } from 'src/app/shared/dialog/logout-dialog/logout-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { BroadcasterService } from '../../services/broadcaster.service';

@Component({
  selector: 'app-sidenav-list',
  templateUrl: './sidenav-list.component.html',
  styleUrls: ['./sidenav-list.component.scss']
})
export class SidenavListComponent implements OnInit {
  @Output() sidenavClose = new EventEmitter();
  @Input() lang: string;
  country: string;
  menuList: any;
  loggedUser: any;
  @ViewChild('languageList', { static: false }) languageList;
  menuItems: any;
  clientUserRole: boolean = false;
  userAccountManagerRole: boolean = false;
  clientSearchData: any;

  constructor(public translate: TranslateService, public dialog: DialogService, public readonly broadCastService: BroadcasterService,
    public router: Router, public commonService: SharedServiceService,) { }
  // @HostListener('blur', ['$event'])
  // blur($event) {
  //   // this.languageList.close();
  //   //(this.languageList)
  //   //  this.showLanguages = false;

  //   if (this.languageList && this.showLanguages) {
  //     //this.isClickOutside = true;
  //     this.showLanguages = false;
  //   }

  //   // Click outside of the menu was detected
  // }
  // isClickOutside: boolean = false;
  onClickOfContract: boolean = false;
  displayGrOption:boolean = false
  blurLanguage() {
    if (this.languageList && this.showLanguages) {
      //this.isClickOutside = true;
      this.showLanguages = false;
    }
  }
  contractSubMenuList: any;
  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    // this.country = "pl"
    //(this.country, "", sessionStorage.getItem('defaultLanguage'));
    this.lang = sessionStorage.getItem('defaultLanguage');
    // this.lang = "pl_pl";
    //if there is no language while redirecting access denied page language should be English same condition in auth.services defect fix
if(this.country = 'gr'){
  this.displayGrOption= true;
}
    if (!this.lang) {
      this.lang = "pl_pl";
    }
    this.commonService.getcurrentUserLoggedIn().subscribe((data) => {
      const loggedInUserDetails = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      this.loggedUser = loggedInUserDetails;

    });
    this.commonService.getDetail('contractDetailsOnClick').subscribe((data) => {
      data = JSON.parse(sessionStorage.getItem('contractDetailsOnClick'));
      if (data && data.showSubMenu) {
        console.log(this.onClickOfContract)
        this.onClickOfContract = true;
        const subMenuList = JSON.parse(sessionStorage.getItem('contratSubMenuList'));
        if (subMenuList) {
          this.contractSubMenuList = subMenuList;
        }
      } else {
        this.onClickOfContract = false;
      }
    });
    this.commonService.getDetail('menuItemList').subscribe((data) => {
      //(data);
      this.menuItems = data;
    });
    this.commonService.getDetail('menuItemList').subscribe((data) => {
      this.clientUserRole = false;
      this.userAccountManagerRole = false;
      const role = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      if (role) {
        role.roleInfo.find((data) => {
          if (data.name === 'rClient') {
            this.clientUserRole = true;
          }
          if (role.length == 1 && data.name === 'rUserAccountManager') {
            this.userAccountManagerRole = true;
          }
        });
      }
      const clientSearch =
        JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
      this.clientSearchData = clientSearch ? JSON.parse(sessionStorage.getItem('menuListFromClientSearch')) : null;
    });
    this.enableMenuItem();
  }
  @Output() langChange = new EventEmitter();

  public onSidenavClose = () => {
    this.sidenavClose.emit();
  }

  langChanged(event) { // You can give any function name
    // //("language---",this.lang);
    this.langChange.emit(this.lang);
  }

  contactUs() {
    let redirectTo = "https://www.metropolitanlife.ro/";
    let language = sessionStorage.getItem("defaultLanguage");

    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/";
        break;
      case 'ro_ro': redirectTo = "https://www.metropolitanlife.ro/";
        break;
      case 'ro_en': redirectTo = "https://www.metropolitanlife.ro/";
        break;
    }
    window.open(redirectTo, "_blank");

  }


  onLogoutClickHandler() {
    //this.translate.instant("eCustomer.logout.logOutDialogText1")
    let message1 = `${this.translate.instant("eCustomer.logout.logOutDialogText")}`;
    this.dialog.openDialog(LogoutDialogComponent, {
      'heading': this.translate.instant("eCustomer.logout.header"), 'body': message1
    });
    this.onSidenavClose();
  }


  onClickContact() {
    this.clearMAinMenuHighlight();
    this.router.navigate(['/contact-form']);
    this.sidenavClose.emit();

  }


  onClickSetting() {
    this.clearMAinMenuHighlight();
    this.broadCastService.broadcast('setttingroute', false);
    this.router.navigate(['/setting']);
    this.sidenavClose.emit();

  }

  clearMAinMenuHighlight() {
    sessionStorage.setItem('activeTabInAdminBackButton', null);
    const mobileContractView = {
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    this.commonService.setDetail('contractDetailsOnClick', mobileContractView);
  }
  onClickAdministration() {
    this.clearMAinMenuHighlight()
    this.router.navigate(['/administartion']);
    this.sidenavClose.emit();
  }

  enableMenuItem() {
    this.commonService.getDetail('menuItemList').subscribe((data) => {
      //(data);
      this.menuList = data;
    });
  }
  showLanguages: any = false;
  languageChanged(language) {
    this.lang = language;
    this.langChanged(this.lang);
    this.showLanguages = false;
  }
  selectBoxClick() {
    if (this.showLanguages) {
      this.showLanguages = false;
    } else {
      this.showLanguages = true;
    }
  }

  onClickEclaim() {
    let redirect = '';
    // this.commonService.getDetail('menuItemList').subscribe((data) => {
    //   // //("eclaims", data.eClaimsURL)

    // });

    let data = JSON.parse(sessionStorage.getItem('menuItemList'));
    redirect = data.eClaimsURL;
    if (redirect) {
      window.open(redirect, "_blank");
    }
  }

  mainMenuItem(menuItem, event?) {
    if (event) {
      sessionStorage.setItem('menuSelectedItem', event.target.id);
      if (event && event.target.id !== 'contractMenu') {
        const mobileContractView = {
          //'contractDetails': contractDetailsValues.contractDetails,
          'showSubMenu': false
        }
        sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
        this.commonService.setDetail('contractDetailsOnClick', mobileContractView);
      }
    }
    switch (menuItem) {
      // case 'home': {
      //   this.router.navigate(['/setting']);
      // }
      //   break;
      // case :
      //   this.router.navigate(['/administartion']);
      //   break;
      case 'home':
        this.router.navigate(['/homepage']);
        this.onSidenavClose();
        break;
      case 'contract':
        this.commonService.setDetail('submenuSelectedIndex', 0);
        this.router.navigate(['/MyContracts']);
        this.onSidenavClose();
        break;
      case 'generalData':
        // this.router.navigate(['myOffers/offerlist']);

        //  this.router.navigate(['contract-details/generalData']);

        this.commonService.setDetail('submenuSelectedIndex', 0);
        this.onSidenavClose();
        break;
      case 'renderContractDetails':
        this.commonService.setDetail('submenuSelectedIndex', 1);
        // this.router.navigate(['contract-details/contractData']);
        this.onSidenavClose();
        break;
      case 'renderContractValue':
        this.commonService.setDetail('submenuSelectedIndex', 2);
        //this.router.navigate(['/contract-details/contractValue']);
        this.onSidenavClose();
        break;
      case 'renderOrders':
        this.commonService.setDetail('submenuSelectedIndex', 3);
        //this.router.navigate(['/contract-details/orderInvest']);
        this.onSidenavClose();
        break;
      case 'renderHistortyOfContractOrders':
        this.commonService.setDetail('submenuSelectedIndex', 4);
        //this.router.navigate(['/orderHistory']);
        this.onSidenavClose();
        break;
      case 'renderIndexationBenefits':
        this.commonService.setDetail('submenuSelectedIndex', 5);
        // this.router.navigate(['/contract-details/indexationOption']);
        this.onSidenavClose();
        break;
      case 'offerList':
        this.router.navigate(['/myOffers']);
        this.onSidenavClose();
        break;
      case 'document':
        this.router.navigate(['/document']);
        this.onSidenavClose();
        break;
      case 'personlaData':
        this.router.navigate(['/personalInfo']);
        this.onSidenavClose();
        break;
      case 'orders':
        this.router.navigate(['/orderHistory']);
        this.onSidenavClose();
        break;
      case 'myClaim':
        this.router.navigate(['/myClaim']);
        this.onSidenavClose();
        break;
      case 'mycompany':
        this.router.navigate(['/mycompany']);
        this.onSidenavClose();
        break;
      case 'fundPriceMonitoring':
        this.router.navigate(['/fundPriceMonitoring']);
        this.onSidenavClose();
        break;
      // case (menuItems.renderOrderReview && menuItems.route == 'ServiceRequestDetailsView'):
      //     this.router.navigate(['/order']);
      //     break;
    }
  }

}
