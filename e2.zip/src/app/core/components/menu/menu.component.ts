import { Component, OnInit } from '@angular/core';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';

import { environment } from 'src/environments/environment';
import { HttpCommonService } from '../../../shared/services/http-common.service';
@Component({
  selector: 'menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {

  constructor(private cService: HttpCommonService, public commonService: SharedServiceService) { }
  menuList;
  navLinks;
  menuItems;
  addActiveClass: boolean = false;
  ngOnInit() {
    this.commonService.getDetail('menuItemList').subscribe((data) => {
      //(data);
      this.menuItems = data;
    });
    this.commonService.getDetail('contractDetailsOnClick').subscribe((data) => {
      data = JSON.parse(sessionStorage.getItem('contractDetailsOnClick'));
      const activeMenu = sessionStorage.getItem('menuSelectedItem');
      if (data && data.showSubMenu && activeMenu && (activeMenu === 'contractMenu' || activeMenu === 'homeMenu')) {
        this.addActiveClass = true;
      } else {
        this.addActiveClass = false;
      }

    });

    // const test = [
    //   {
    //     label: 'homepage',
    //     link: './homepage',
    //     index: 0,
    //     render: true
    //   }
    //   , {
    //     label: 'order',
    //     link: './order',
    //     index: 3,
    //     render: false
    //   }
    // ];
    // this.navLinks = [];
    // test.forEach(element => {
    //   this.navLinks.push(
    //     {
    //       label: element.label,
    //       link: `./${element.label}`,
    //       index: element.index,
    //       render: element.render

    //     }
    //   );

    // });
    // //(this.navLinks)
    // this.menuList = [
    //   {
    //     label: 'Home Page',
    //     link: '',
    //     index: 0
    //   },
    //   {
    //     label: 'My Contracts',
    //     link: '',
    //     index: 0
    //   },
    //   {
    //     label: 'My Offers',
    //     link: '',
    //     index: 0
    //   },
    //   {
    //     label: 'Personal data',
    //     link: '',
    //     index: 0
    //   },
    //   {
    //     label: 'My Orders',
    //     link: '',
    //     index: 0
    //   },
    //   {
    //     label: 'My Claims',
    //     link: '',
    //     index: 0
    //   },
    //   {
    //     label: 'My documents',
    //     link: '',
    //     index: 0
    //   },
    //   {
    //     label: 'My Contracts',
    //     link: '',
    //     index: 0
    //   }

    // ];

  }
  setAccMonitorFlag() {
    this.commonService.setMenuClicked(true);
  }
  onTabChanged(ev) {
    sessionStorage.setItem('menuSelectedItem', ev.target.id);
    if (ev && ev.target.id !== 'contractMenu') {
      const mobileContractView = {
        //'contractDetails': contractDetailsValues.contractDetails,
        'showSubMenu': false
      }
      sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
      this.commonService.setDetail('contractDetailsOnClick', mobileContractView);
    }


  }
}
