import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError, finalize } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { eClaimsConstants } from '../constant/constant';

import { SnackBarComponent } from '../../shared/dialog/snack-bar/snack-bar.component';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { ErrorComponent } from 'src/app/error/error.component';

@Injectable({ providedIn: 'root' })
export class HttpConfigInterceptor implements HttpInterceptor {
  constructor(private spinner: NgxSpinnerService, public snackBar: MatSnackBar,
    private router: Router, public dialog: DialogService,) { }
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    // Get the auth header (fake value is shown here)
    //this.spinner.show();
    let randomVal = (Math.floor((Math.random() * 100000000) + 1)) + '';
    if (!req.params.has('loader')) {
      if (document.getElementById('app_component_starts')) {

        let overLay = document.createElement('div');
        overLay.setAttribute("class", 'overLay');
        overLay.setAttribute("id", randomVal);

        let spin = document.createElement('div');

        //spin.setAttribute("bdColor", "grey");

        spin.setAttribute("class", 'loader');
        overLay.appendChild(spin);
        document.getElementById('app_component_starts').appendChild(overLay);
      }
    }
    const authHeaderToken = '';
    //loader spin start
    let httpReq = req.clone({
      // url: (envUrl + req.url),
      headers: req.headers.set('accept-language', sessionStorage.getItem('defaultLanguage'))
        .set('x-tenant-id', sessionStorage.getItem('countryCode'))
        //.set('content-type', 'application/json')
      // added for cache issue
      //.set('Cache-Control', 'no-cache, no-store, must-revalidate')
      //.set('Pragma', 'no-cache')
      //.set('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT')
      //.set('If-Modified-Since', '0')
      // added for cache issue ends
    });

    return next.handle(httpReq).pipe(
      map((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {

        }
        return event;
      }),
      catchError((error: HttpErrorResponse) => {
        let data = {};
        data = {
          reason: error && error.error && error.error.reason ? error.error.reason : '',
          status: error.status
        };
        if (error.status == eClaimsConstants.errorPageStatusCode) {
          this.router.navigate(['/error']);
        }
        if (error.status === 500 || error.status === 417 || error.status === 401) {
          if (error.error && error.error.errorCode !== 414 && error.error.errorCode !== 415 && error.error.errorCode !== 503 && error.error.errorCode !== 500 && error.error.errorCode !== 501) {
            // const message = `Something went wrong.\n
            // Please Contact System Administrator`
            // this.openSnackBar(message, 'pizza-party');
            this.dialog.openDialog(ErrorComponent, {});
            // this.router.navigate(['/errorPage']);
          } else if (error.error == null && error.url.split('users')[1] !== '/logout') {
            // const message = `Something went wrong.\n
            // Please Contact System Administrator`
            // this.openSnackBar(message, 'pizza-party');
            this.dialog.openDialog(ErrorComponent, {})
            //this.router.navigate(['/errorPage']);
          }
        }
        return throwError(error);
      }),
      finalize(() => {
        // this.spinner.hide()
        if (document.getElementById(randomVal)) {
          //document.getElementById(randomVal).remove();
          document.getElementById(randomVal).parentElement.removeChild(document.getElementById(randomVal));
        }
      }));

  }


  openSnackBar(message: string, panelClass: string) {
    this.snackBar.openFromComponent(SnackBarComponent, {
      data: message,
      panelClass: 'my-custom-snackbar',
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition
    });
  }

}
