import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { AppModule } from '../app.module';
import { HomeOfferListService } from './home-offer-list/service/home-offer-list.service';

import { HomePageComponent } from './home-page.component';
import { HomePageModule } from './home-page.module';
//import { HomeOfferListComponent } from './home-offer-list/home-offer-list.component';

describe('HomePageComponent', () => {
  let component: HomePageComponent;
  let fixture: ComponentFixture<HomePageComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        "notificationService": host + '/api/v1/users/notifications'
      }
    }
  };
  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    const test = {
      "menuItems": [{ "menuId": "1", "accessSpec": "RW", "menuName": "Account Management", "parentMenu": "Settings" }, { "menuId": "3", "accessSpec": "RW", "menuName": "Change Password", "parentMenu": "Settings" }, { "menuId": "4", "accessSpec": "RW", "menuName": "Changing the Settings", "parentMenu": "Settings" }, { "menuId": "5", "accessSpec": "RW", "menuName": "My Contract", "parentMenu": "Main Menu" }, { "menuId": "6", "accessSpec": "RW", "menuName": "My Data", "parentMenu": "Main Menu" }, { "menuId": "7", "accessSpec": "RW", "menuName": "Offer", "parentMenu": "Main Menu" }, { "menuId": "8", "accessSpec": "RW", "menuName": "Review Of Orders", "parentMenu": "Main Menu" }, { "menuId": "9", "accessSpec": "RW", "menuName": "Claims", "parentMenu": "Main Menu" }, { "menuId": "11", "accessSpec": "RW", "menuName": "Individual Contract Details", "parentMenu": "My Contract" }, { "menuId": "12", "accessSpec": "RW", "menuName": "Individual Contract Benefits", "parentMenu": "My Contract" }, { "menuId": "13", "accessSpec": "RW", "menuName": "Individual Contract Beneficiaries", "parentMenu": "My Contract" }, { "menuId": "14", "accessSpec": "RW", "menuName": "Individual Contract Financial Info", "parentMenu": "My Contract" }, { "menuId": "15", "accessSpec": "RW", "menuName": "Invest Strategy Change", "parentMenu": "My Contract" }, { "menuId": "16", "accessSpec": "RW", "menuName": "Allocation Change", "parentMenu": "My Contract" }, { "menuId": "17", "accessSpec": "RW", "menuName": "Fund Transfer", "parentMenu": "My Contract" }],
      "activeContractDetails": null,
      "billingRecipent": null,
      "callRetrievePolicies": false,
      "callRetriveClientData": false,
      "callRetriveClientOffers": false,
      "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
      "claimList": null,
      "clientAdministration": true,
      clientId: "2323",
      "clientIdList": [],
      "clientIdbillControlList": [],
      "clientLoginId": null,
      "clientRoleIds": "3032|3033|3034",
      "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
      "contractList": [{
        "benefitType": "SuperKapitał",
        "businessRoleList": ["insured", "owner"],
        "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
        "contractNumber": "21223250",
        "contractNumberList": null,
        "effectiveDate": "28.11.2007",
        "indexedPremiumAmount": null,
        "insuredName": "INSURED_21223250",
        "premiumAmount": null,
        "premiumAmt": null,
        "premiumAmtType": "17",
        "premiumDueDate": null,
        "premiumPaymentMode": null,
        "premiumType": "17",
        "processingSystem": "OLAS",
        "status": 22
      }],
      "personalInformationDTO": {
        "dateOfBirth": null,
        "emailBasic": "cosmin.misici@gmail.com",
        "emailSecondary": null,
        "firstName": "COSMIN ADRIAN",
        "flagOfCapabilityOfChangeData": "true",
        "gender": null,
        "identifier": null,
        "identifierType": null,
        "lastName": "MISICI",
        "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
        "mobile": null,
        "mobilePhone": "0723347690",
        "officeFax": null,
        "policyNumber": null,
        "postalCode": null,
        "residenceFax": null,
        "residenceTelephone": "",
        "safePhone": null,
        "updatedEmailBasic": null,
        "updatedEmailSecondary": null,
        "updatedMobile": null,
        "updatedResidenceTelephone": null,
        "updatedSafePhone": null,
        "updatedmarketingConsentList": null,
        "versionMarker": "2020-12-22T12:13:17.867"
      },
      "documentsList": null,
      "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
      "fundPriceDetails": null,
      "offerResponse": null,
      "orderHistory": null,
      "renderClaims": false,
      "renderDocuments": false,
      "renderFundPriceMonitoring": false,
      "renderMyCompany": false,
      "renderMyContract": false,
      "renderMyData": false,
      "renderOffers": false,
      "renderOrderReview": false,
      "renderUserAcctAdministration": true,
      "route": "DisplayClientSearch",
      "searchFlag": false,
      "wardenRoleCheck": false
    };
    window.sessionStorage.setItem('menuListFromClientSearch', JSON.stringify(test));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HomePageModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: [],
      providers: []

    })
      .compileComponents();
    fixture = TestBed.createComponent(HomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(HomePageComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 7000;
    expect(component).toBeTruthy();
  });
});
