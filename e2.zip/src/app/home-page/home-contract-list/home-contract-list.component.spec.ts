import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from 'src/app/app.module';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { HomePageModule } from '../home-page.module';

import { HomeContractListComponent } from './home-contract-list.component';

describe('HomeContractListComponent', () => {
  let component: HomeContractListComponent;
  let fixture: ComponentFixture<HomeContractListComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        "lastOrderDetailsUrl": host + '/api/v1/users/orderhistory'
      }
    }
  };
  // beforeEach(async(() => {
  const userImfo =
    { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" }
  // }));
  let router = {
    navigate: jasmine.createSpy('navigate')
  };
  beforeEach(() => {
    const test = {
      "menuItems": [{ "menuId": "1", "accessSpec": "RW", "menuName": "Account Management", "parentMenu": "Settings" }, { "menuId": "3", "accessSpec": "RW", "menuName": "Change Password", "parentMenu": "Settings" }, { "menuId": "4", "accessSpec": "RW", "menuName": "Changing the Settings", "parentMenu": "Settings" }, { "menuId": "5", "accessSpec": "RW", "menuName": "My Contract", "parentMenu": "Main Menu" }, { "menuId": "6", "accessSpec": "RW", "menuName": "My Data", "parentMenu": "Main Menu" }, { "menuId": "7", "accessSpec": "RW", "menuName": "Offer", "parentMenu": "Main Menu" }, { "menuId": "8", "accessSpec": "RW", "menuName": "Review Of Orders", "parentMenu": "Main Menu" }, { "menuId": "9", "accessSpec": "RW", "menuName": "Claims", "parentMenu": "Main Menu" }, { "menuId": "11", "accessSpec": "RW", "menuName": "Individual Contract Details", "parentMenu": "My Contract" }, { "menuId": "12", "accessSpec": "RW", "menuName": "Individual Contract Benefits", "parentMenu": "My Contract" }, { "menuId": "13", "accessSpec": "RW", "menuName": "Individual Contract Beneficiaries", "parentMenu": "My Contract" }, { "menuId": "14", "accessSpec": "RW", "menuName": "Individual Contract Financial Info", "parentMenu": "My Contract" }, { "menuId": "15", "accessSpec": "RW", "menuName": "Invest Strategy Change", "parentMenu": "My Contract" }, { "menuId": "16", "accessSpec": "RW", "menuName": "Allocation Change", "parentMenu": "My Contract" }, { "menuId": "17", "accessSpec": "RW", "menuName": "Fund Transfer", "parentMenu": "My Contract" }],
      "activeContractDetails": null,
      "billingRecipent": null,
      "callRetrievePolicies": false,
      "callRetriveClientData": false,
      "callRetriveClientOffers": false,
      "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
      "claimList": null,
      "clientAdministration": true,
      "clientId": "",
      "clientIdList": [],
      "clientIdbillControlList": [],
      "clientLoginId": null,
      "clientRoleIds": "3032|3033|3034",
      "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
      "contractList": [{
        "benefitType": "SuperKapitał",
        "businessRoleList": ["insured", "owner"],
        "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
        "contractNumber": "21223250",
        "contractNumberList": null,
        "effectiveDate": "28.11.2007",
        "indexedPremiumAmount": null,
        "insuredName": "INSURED_21223250",
        "premiumAmount": null,
        "premiumAmt": null,
        "premiumAmtType": "17",
        "premiumDueDate": null,
        "premiumPaymentMode": null,
        "premiumType": "17",
        "processingSystem": "OLAS",
        "status": 22
      }],
      "personalInformationDTO": {
        "dateOfBirth": null,
        "emailBasic": "cosmin.misici@gmail.com",
        "emailSecondary": null,
        "firstName": "COSMIN ADRIAN",
        "flagOfCapabilityOfChangeData": "true",
        "gender": null,
        "identifier": null,
        "identifierType": null,
        "lastName": "MISICI",
        "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
        "mobile": null,
        "mobilePhone": "0723347690",
        "officeFax": null,
        "policyNumber": null,
        "postalCode": null,
        "residenceFax": null,
        "residenceTelephone": "",
        "safePhone": null,
        "updatedEmailBasic": null,
        "updatedEmailSecondary": null,
        "updatedMobile": null,
        "updatedResidenceTelephone": null,
        "updatedSafePhone": null,
        "updatedmarketingConsentList": null,
        "versionMarker": "2020-12-22T12:13:17.867"
      },
      "documentsList": null,
      "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
      "fundPriceDetails": null,
      "offerResponse": null,
      "orderHistory": null,
      "renderClaims": false,
      "renderDocuments": false,
      "renderFundPriceMonitoring": false,
      "renderMyCompany": false,
      "renderMyContract": false,
      "renderMyData": false,
      "renderOffers": false,
      "renderOrderReview": false,
      "renderUserAcctAdministration": true,
      "route": "DisplayClientSearch",
      "searchFlag": false,
      "wardenRoleCheck": false
    };
    window.sessionStorage.setItem('menuListFromClientSearch', JSON.stringify(test));
    window['__env'].environmentConstURLs = environmentConstURL;
    const userImfo =
      { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": 121212, "requesterId": "-1", "requesterRole": "3033" }
    const serachClient =
      { "clientID": 1234, "opeType": "search" }
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HomePageModule, HttpClientTestingModule, TranslateModule.forRoot()],

      declarations: [],
      providers: [TranslateService, SharedServiceService, HttpCommonService, { provide: Router, useValue: router }
      ]
    })
      .compileComponents();

    let store = {};
    const mockSessionStorage = {
      getItem: (key: string): string => {
        return key in store ? store[key] : null;
      },
      setItem: (key: string, value: string) => {
        store[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      }
    };
    spyOn(sessionStorage, 'getItem')
      .and.callFake(mockSessionStorage.getItem);
    spyOn(sessionStorage, 'setItem')
      .and.callFake(mockSessionStorage.setItem);
    spyOn(sessionStorage, 'removeItem')
      .and.callFake(mockSessionStorage.removeItem);
    spyOn(sessionStorage, 'clear')
      .and.callFake(mockSessionStorage.clear);
    fixture = TestBed.createComponent(HomeContractListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

  });

  // it('should return stored token from localStorage', () => {
  //   debugger
  //   sessionStorage.setItem('searcClientID', 'userImfo');
  // });
  // it('should store the token in localStorage', () => {
  //   //  sessionStorage.setAccessToken('sometoken');
  //   expect(sessionStorage.getItem('searcClientID')).toEqual('userImfo');
  // });

  it('should create', () => {
    component.getLastOrderDetails();
    component.getContractOrderDetails();
    expect(component).toBeTruthy();
  });

  it('should call getContractOrderDetails', inject([SharedServiceService], (sharedService: SharedServiceService) => {
    let shareServices: SharedServiceService = TestBed.get(SharedServiceService);
    const contractList = [{
      "contractNumber": "21282475", "contractNumberList": null, "benefitType": "SuperKapitał S", "effectiveDate": "28.12.2009", "premiumType": "11", "premiumAmt": null, "premiumAmount": "", "premiumAmtType": null, "status": 21, "businessRoleList": ["insured", "owner"], "processingSystem": "OLAS", "insuredName": "INSURED_21282475", "premiumDueDate": null, "indexedPremiumAmount": null, "premiumPaymentMode": "11", "contractDetailsDTO": {
        "contractNumber": null, "insurer": "INSURER_21282475", "insured": "INSURED_21282475", "status": 21, "paymentMode": "11", "premiumDueDate": 1380319200000, "currentPremiumAmt": null, "bankAccount": "02 1030 1944 9000 0500 2128 2475", "debtStatus": "true", "indexationDocument": "-1", "lastPremiumAmt": 157.32, "indxPremiumAmt": 200, "indexedPremiumAmt": null, "coinsured1": null, "coinsured2": null, "coinsured3": null, "coinsured4": null, "coinsured5": null, "coinsured6": null, "coinsured7": null, "coinsured8": null, "coinsured9": null, "additionalBankAccount": null, "additionalBankAccountLabel": null, "additionalBankAccountTip": null, "policySearchDTOsList": [], "contractList": [{
          "benefitType": "SuperKapitał",
          "businessRoleList": ["insured", "owner"],
          "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
          "contractNumber": "21223250",
          "contractNumberList": null,
          "effectiveDate": "28.11.2007",
          "indexedPremiumAmount": null,
          "insuredName": "INSURED_21223250",
          "premiumAmount": null,
          "premiumAmt": null,
          "premiumAmtType": "17",
          "premiumDueDate": null,
          "premiumPaymentMode": null,
          "premiumType": "17",
          "processingSystem": "OLAS",
          "status": 22
        }], "billGroup": null, "clientId": null, "billControl": null, "noOfPolicies": 0,
        "totalPremiumAmount": null, "suspendStatus": "FALSE", "suspendDate": null, "policyStatus": null, "frequency": null, "effectiveDate": "28.12.2009", "anniverseryDueDate": null, "indexRate1": null, "indexRate2": null, "indexedPremiumAmt2": null, "indexationEligible": 0
      }
    }];
    spyOn(shareServices, 'getDetail').and.returnValue(of(contractList));
    component.getContractOrderDetails();
  }));

  it('should call getLastOrderDetails', () => {
    const response = [{ "orderDate": 1611734762327, "login": "SenthilQABackupNew", "orderType": "46", "contract": "32386578", "status": "Registered", "orderNumber": "00001488", "orderTypeId": "46", "serviceTypeId": "Fund_Transfer", "createDateUI": "27.01.2021 09: 06" }];
    spyOn(HttpCommonService.prototype, 'postData').and.returnValue(of(response));
    component.getOrderHistoryList(response);
  });

  it('should call goToOrderPage', () => {
    const row = {
      orderTypeId: '44',
      orderNumber: '12121'
    }
    window.sessionStorage.setItem('personalDataOrderId', row.orderNumber);
    component.goToOrderPage(row);
    // expect(router.navigate).toHaveBeenCalledWith(['/orderHistory/singlePremiumSave']);

  });

  it('should call goToOrderPage', () => {
    const row = {
      orderTypeId: '47',
      orderNumber: '12121'
    }
    window.sessionStorage.setItem('personalDataOrderId', row.orderNumber);
    component.goToOrderPage(row);
    // expect(router.navigate).toHaveBeenCalledWith(['/orderHistory/singlePremiumSave']);

  });

  it('should call goToOrderPage', () => {
    const row = {
      orderTypeId: '45',
      orderNumber: '12121'
    }
    window.sessionStorage.setItem('personalDataOrderId', row.orderNumber);
    component.goToOrderPage(row);
    // expect(router.navigate).toHaveBeenCalledWith(['/orderHistory/singlePremiumSave']);

  });

  it('should call goToOrderPage', () => {
    const row = {
      orderTypeId: '51',
      orderNumber: '12121'
    }
    window.sessionStorage.setItem('personalDataOrderId', row.orderNumber);
    component.goToOrderPage(row);
    // expect(router.navigate).toHaveBeenCalledWith(['/orderHistory/singlePremiumSave']);

  });

  it('should call goToOrderPage', () => {
    const row = {
      orderTypeId: '48',
      orderNumber: '12121'
    }
    window.sessionStorage.setItem('personalDataOrderId', row.orderNumber);
    component.goToOrderPage(row);
    // expect(router.navigate).toHaveBeenCalledWith(['/orderHistory/singlePremiumSave']);

  });

  it('should call goToOrderPage', () => {
    const row = {
      orderTypeId: '46',
      orderNumber: '12121'
    }
    window.sessionStorage.setItem('personalDataOrderId', row.orderNumber);
    component.goToOrderPage(row);
    // expect(router.navigate).toHaveBeenCalledWith(['/orderHistory/singlePremiumSave']);

  });

  it('should call goToContactMainPage', () => {
    component.goToContactMainPage();
    expect(router.navigate).toHaveBeenCalledWith(['/MyContracts']);

  });

  it('should call goToOrderHistory', () => {
    component.goToOrderHistory();
    //expect(router.navigate).toHaveBeenCalledWith(['/orderHistory']);

  });
  it('it should call goToContractDetails', () => {
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    const contract = {
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    };
    component.goToContractDetails(contract);
  });
});
