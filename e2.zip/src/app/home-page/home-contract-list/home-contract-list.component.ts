import { Component, OnInit } from '@angular/core';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import * as moment from 'moment';

import { AppConfig } from '../../../config/app.config';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { Router } from '@angular/router';

import { MenuItemsService } from '../../shared-service/menu-items.service';

@Component({
  selector: 'home-contract-list',
  templateUrl: './home-contract-list.component.html',
  styleUrls: ['./home-contract-list.component.scss']
})
export class HomeContractListComponent implements OnInit {

  flagtestdata;
  contractListData;
  displayedColumns: string[] = ['benefitType', 'contractNumber'];
  displayedColumnsInOrder: string[] = ['orderCreateDate', 'serviceTypeId', 'policyNumber', 'status'];

  appConfig: AppConfig = AppConfig.getConfig();
  orderHistoryDetails = [];

  constructor(private cService: HttpCommonService, public sharedService: SharedServiceService,
    private readonly router: Router, private readonly commonService: SharedServiceService,
    private menuItem: MenuItemsService) { }
  baseUrl = this.appConfig['api'];
  ngOnInit() {
    this.getContractOrderDetails();
    this.getLastOrderDetails();

  }
  ngAfterViewInit() {

  }


  getLastOrderDetails() {
    let clientID;
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID')),
      loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    if (customerId && customerId.opeType == 'search') {
      clientID = (customerId && customerId.clientID) ? customerId.clientID : '';
    } else {
      clientID = (loggedInUserDetail && loggedInUserDetail.clientId) ? loggedInUserDetail.clientId : null;
    }
    const url = this.baseUrl.ecustomer.lastOrderDetailsUrl,
      reqParam = {
        "clientId": clientID
      }
      ;
    this.cService['postData'](url, reqParam, '').subscribe(data => {
      if (data) {
        this.getOrderHistoryList(data);
      } else {
        this.orderHistoryDetails = [];
      }
    })
  }

  getContractOrderDetails() {
    this.commonService.getDetail('menuItemList').subscribe((data) => {
      //(data)
      if (data && data.contractList) {
        this.contractListData = data.contractList;
      } else {
        this.contractListData = [];
      }

    });
  }

  getOrderHistoryList(data) {
    //const orderHistory = data.orderHistory;
    data.forEach(orderList => {
      const dateFromat = this.dateConversion(orderList.createDate)
      this.orderHistoryDetails.push({
        orderCreateDate: orderList.createDateUI,
        serviceTypeId: orderList.serviceTypeId,
        status: orderList.status,
        policyNumber: orderList.contract,
        orderNumber: orderList.orderNumber,
        orderTypeId: orderList.orderTypeId
      });
    });
  }

  dateConversion(date) {
    if (date) {
      // const localDateString = new Date(date).toLocaleDateString(),
      //   repalecDate = localDateString.replace('\/\g', '.');
      // const time = new Date(date).toLocaleTimeString();
      //  const timeDateFormat = moment(1602437849480).format("DD.MM.YYYY HH:MM");
      const timeDateFormat = moment(date).format("DD.MM.YYYY HH:MM");
      return timeDateFormat;
    } else {
      return '';
    }
  }
  goToOrderPage(row) {
    sessionStorage.setItem('personalDataOrderId', row.orderNumber);
    sessionStorage.setItem('orderData', JSON.stringify(row));
    switch (row.orderTypeId) {
      case '44':
        this.router.navigate(['/orderHistory/singlePremiumSave']);
        break;
      case '47':
        this.router.navigate(['/orderHistory/allocationChange']);
        break;
      case '45':
        this.router.navigate(['/orderHistory/additionalContributionSave']);
        break;
      case '51':
        this.router.navigate(['/orderHistory/indexationorderhistory']);
        break;
      case '48':
        sessionStorage.setItem('personalDataOrderId', row.orderNumber);
        this.router.navigate(['/orderHistory/clientDataChange']);
        break;
      case '46':
        this.router.navigate(['/orderHistory/fundtransfer']);
        break;
    }

  }

  goToContactMainPage() {
    this.router.navigate(['/MyContracts']);
  }

  goToContractDetails(contract) {
    const mobileContractView = {
      'contractDetails': contract,
      'showSubMenu': true
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    sessionStorage.setItem('menuSelectedItem', 'homeMenu');
    this.sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    sessionStorage.setItem('contractDetails', JSON.stringify(contract));
    this.menuItem.getSubmenuList(contract);

  }
  goToOrderHistory(): any {
    //("called order");
    this.router.navigate(['/orderHistory']);
  }
}