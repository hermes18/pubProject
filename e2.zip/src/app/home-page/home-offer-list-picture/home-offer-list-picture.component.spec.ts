import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HomePageModule } from '../home-page.module';
import { interval, of, throwError } from 'rxjs';

import { HomeOfferListPictureComponent } from './home-offer-list-picture.component';
import { Router } from '@angular/router';
import { BrowserModule, DomSanitizer } from '@angular/platform-browser';

describe('HomeOfferListPictureComponent', () => {
  let component: HomeOfferListPictureComponent;
  let fixture: ComponentFixture<HomeOfferListPictureComponent>;
  let sharedService: SharedServiceService;
  const serachClient =
    { "clientId": 1234, "opeType": "search" };
  // beforeEach(async(() => {

  // }));
  let router = {
    navigate: jasmine.createSpy('navigate')
  };
  beforeEach(() => {
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HomePageModule, HttpClientTestingModule, TranslateModule.forRoot()],

      declarations: [],
      providers: [TranslateService, { provide: Router, useValue: router }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(HomeOfferListPictureComponent);
    component = fixture.componentInstance;
    sharedService = TestBed.get(SharedServiceService);
    fixture.detectChanges();
  });

  it('should create', () => {
    const test = {
      "menuItems": [{ "menuId": "1", "accessSpec": "RW", "menuName": "Account Management", "parentMenu": "Settings" }, { "menuId": "3", "accessSpec": "RW", "menuName": "Change Password", "parentMenu": "Settings" }, { "menuId": "4", "accessSpec": "RW", "menuName": "Changing the Settings", "parentMenu": "Settings" }, { "menuId": "5", "accessSpec": "RW", "menuName": "My Contract", "parentMenu": "Main Menu" }],
      "offerResponse": {
        'clientOffersList': [{
          'clientId': "101583",
          contractNumber: '67879',
          offerDetailsText: "Pobyt w szpitalu w wyniku wypadku to spore nieprzewidziane koszty. W tym czasie Twoje dochody ulegają znacznemu zmniejszeniu. <BR><BR>Dodatkowy zastrzyk gotówki po wyjściu ze szpitala sprawi, że w razie potrzeby możesz przeznaczyć pieniądze na dostęp do lekarzy specjalistów, nowoczesne leczenie, rehabilitację lub dowolnie wybrany cel. <BR><BR>Mając Świadczenie Szpitalne otrzymasz: <BR><BR>- Dzienne świadczenie  za każdy dzień pobytu w szpitalu, wskutek nieszczęśliwego wypadku, pod warunkiem, że hospitalizacja trwała co najmniej 4 dni <BR><BR>- Dzienne świadczenie szpitalne wypłacane jest aż za maksymalnie 180 dni pobytu w szpitalu, wskutek nieszczęśliwego wypadku, w każdym roku trwania umowy dodatkowej Świadczenie Szpitalne to: <BR><BR>- świadczenie uzupełniające dochód w przypadku pobytu w szpitalu, <BR><BR>- wypłata świadczenia za pobyt w szpitalu wskutek nieszczęśliwego wypadku, <BR><BR>- ochronę, która działa na całym świecie. <BR><BR>Przykład: <BR><BR>Rodzina Pana Jacka długo planowała wakacje w Zakopanem. Wspinaczka wysokogórska była jego pasją.  Pierwsze dwa dni upłynęły szybko na pieszych wycieczkach. Trzeciego dnia Pan Jacek postanowił wspiąć się trochę wyżej, niestety podczas górskiej wycieczki potknął się i upadł poważnie raniąc się w głowę. Obrażenie było na tyle poważne, że jeszcze tego samego dnia trafił do szpitala. Lekarze nie mieli dla niego dobrych wieści - musiał zostać przez kolejnych 5 dni na obserwacji. <BR><BR>Pan Jacek nie był zadowolony z konieczności zmiany planów. Niemniej jednak miał świadomość, że po powrocie do domu otrzyma świadczenie szpitalne, które zrekompensuje mu czas spędzony w szpitalu. Tak też się stało, dzięki czemu Pan Jacek może spokojnie planować przyszłe wakacje.",
          offerDueDate: 1400104800000,
          offerGenerationDate: 1388530800000,
          offerId: "63D020I16",
          offerMainImage: "/9j/4AAQSkZJRgABAQEAYABgAAD/4RtKRXhpZgAATU0AKgAAAA",
          offerMarketingName: "Świadczenie Szpitalne - ochrona dla Ciebie",
          offerMiniatureImage: "/9j/4AAQSkZJRgABAQEBLAEsAAD/4RJQRXhpZgAATU0AKgAAAA",
          offerName: "MM16_Świadczenie Szpitalne",
          offerPremium: 5555.55,
          offerSort: 1,
          offerSummaryText: "Świadczenie Szpitalne – to ubezpieczenie – to ubezpieczenie na wypadek pobytu"
        }]
      }
    }
    spyOn(sharedService, 'getDetail').and.returnValue(of(test));
    expect(component).toBeTruthy();
  });


  it('should call menuitem error method', () => {
    const error = {
      error: {
        date: 1618914539459,
        errorCode: 500,
        errorDetails: "server Error",
        message: "Server Error"
      }
    };
    spyOn(sharedService, 'getDetail').and.returnValue(throwError(error));
    component.ngOnInit();
  })
  it('should call goToOfferList', () => {
    component.goToOfferList();
    expect(router.navigate).toHaveBeenCalledWith(['/myOffers']);
  });
  it('should call getOfferList', () => {
    const test = {
      "offerResponse": {
        'clientOffersList': [{
          'clientId': "101583",
          contractNumber: '67879',
          offerDetailsText: "Pobyt w szpitalu w wyniku wypadku to spore nieprzewidziane koszty. W tym czasie Twoje dochody ulegają znacznemu zmniejszeniu. <BR><BR>Dodatkowy zastrzyk gotówki po wyjściu ze szpitala sprawi, że w razie potrzeby możesz przeznaczyć pieniądze na dostęp do lekarzy specjalistów, nowoczesne leczenie, rehabilitację lub dowolnie wybrany cel. <BR><BR>Mając Świadczenie Szpitalne otrzymasz: <BR><BR>- Dzienne świadczenie  za każdy dzień pobytu w szpitalu, wskutek nieszczęśliwego wypadku, pod warunkiem, że hospitalizacja trwała co najmniej 4 dni <BR><BR>- Dzienne świadczenie szpitalne wypłacane jest aż za maksymalnie 180 dni pobytu w szpitalu, wskutek nieszczęśliwego wypadku, w każdym roku trwania umowy dodatkowej Świadczenie Szpitalne to: <BR><BR>- świadczenie uzupełniające dochód w przypadku pobytu w szpitalu, <BR><BR>- wypłata świadczenia za pobyt w szpitalu wskutek nieszczęśliwego wypadku, <BR><BR>- ochronę, która działa na całym świecie. <BR><BR>Przykład: <BR><BR>Rodzina Pana Jacka długo planowała wakacje w Zakopanem. Wspinaczka wysokogórska była jego pasją.  Pierwsze dwa dni upłynęły szybko na pieszych wycieczkach. Trzeciego dnia Pan Jacek postanowił wspiąć się trochę wyżej, niestety podczas górskiej wycieczki potknął się i upadł poważnie raniąc się w głowę. Obrażenie było na tyle poważne, że jeszcze tego samego dnia trafił do szpitala. Lekarze nie mieli dla niego dobrych wieści - musiał zostać przez kolejnych 5 dni na obserwacji. <BR><BR>Pan Jacek nie był zadowolony z konieczności zmiany planów. Niemniej jednak miał świadomość, że po powrocie do domu otrzyma świadczenie szpitalne, które zrekompensuje mu czas spędzony w szpitalu. Tak też się stało, dzięki czemu Pan Jacek może spokojnie planować przyszłe wakacje.",
          offerDueDate: 1400104800000,
          offerGenerationDate: 1388530800000,
          offerId: "63D020I16",
          offerMainImage: "/9j/4AAQSkZJRgABAQEAYABgAAD/4RtKRXhpZgAATU0AKgAAAA",
          offerMarketingName: "Świadczenie Szpitalne - ochrona dla Ciebie",
          offerMiniatureImage: "/9j/4AAQSkZJRgABAQEBLAEsAAD/4RJQRXhpZgAATU0AKgAAAA",
          offerName: "MM16_Świadczenie Szpitalne",
          offerPremium: 5555.55,
          offerSort: 1,
          offerSummaryText: "Świadczenie Szpitalne – to ubezpieczenie – to ubezpieczenie na wypadek pobytu"
        }]
      }
    };
    let offerList = test.offerResponse.clientOffersList;
    component.getOfferList(offerList);
  });

  it('should call goToIndividualOffer', () => {
    const offerList = {
      offerMainImage: "/9j/4AAQSkZJRgABAQEAYABgAAD/4RtKRXhpZgAATU0AKgAAAA",
      offerSort: 1,
      'clientId': "101583",
      contractNumber: '67879',
      offerId: "63D020I16",
      offerMarketingName: "Świadczenie Szpitalne - ochrona dla Ciebie",
      offerSummaryText: "Świadczenie Szpitalne – to ubezpieczenie – to ubezpieczenie na wypadek pobytu"
    }
    component.goToIndividualOffer(offerList);
  });

  it('should call goToPersonlaData', () => {
    component.goToPersonlaData();
    expect(router.navigate).toHaveBeenCalledWith(['/personalInfo']);
  });

  it('should call goToChangePassword', () => {
    component.goToChangePassword();
  });


});
