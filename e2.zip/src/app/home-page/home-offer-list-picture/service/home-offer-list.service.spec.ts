import { APP_BASE_HREF } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppModule } from 'src/app/app.module';
import { HomePageModule } from '../../home-page.module';

import { HomeOfferListService } from './home-offer-list.service';

describe('HomeOfferListService', () => {
  let service: HomeOfferListService

  beforeEach(() => {

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HomePageModule],
      providers: [HomeOfferListService, { provide: APP_BASE_HREF, useValue: '/' }],
    })
    service = TestBed.get(HomeOfferListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call gteNotificationList', () => {
    const customerId = {
      clientID: "11088615",
      opeType: "search"
    },
      userRole = "rStandardUser|rSuperUser|rAdministrator",
      userImfo =
        { userName: "Finson_Admin2", firstName: "Finson", lastName: "Francis", email: "finson.francis1@metlife.com", preferredLanguage: "en", creationDate: "Mon Nov 09 14:20:54 CET 2020", passwordType: "STANDARD", customerPasswordExprationCode: "1", passwordStatusCode: "ACTIVE", securityPolicyId: "12345", tokenExpirationDate: "Mon Nov 09 14:20:54 CET 2020", employeeNumber: "3470451", pwdExpirationDate: "Wed Jan 20 14:20:54 CET 2021", failedLoginCounts: "0", authorizedApplicationCode: "eCustomer", temporaryLockDate: null, route: "Home", pwdExpired: "Active", daysSincePwdNotChanged: null, pwdChangeDate: null, roleInfo: [{ roleId: "3033", name: "rSuperUser", description: "RSuperUser" }, { roleId: "3034", name: "rAdministrator", description: "SystemAdministrator" }, { "roleId": "3036", name: "rUserAccountManager", description: "RUserAccountManager" }], clientId: null, requesterId: "-1", requesterRole: "3033" };
    service.gteNotificationList(userImfo, customerId, userRole);
  });
});
