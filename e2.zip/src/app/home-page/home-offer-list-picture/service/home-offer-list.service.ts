import { Injectable } from '@angular/core';

import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';

@Injectable()

export class HomeOfferListService {
  //http://localhost:9087/api/v1/users/notifications/shaban_101583/Admin
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  canChangeDataflag :boolean = false;
  constructor(private cService: HttpCommonService) { }


  gteNotificationList(data, customerId, userrole) {  
    let clientID;
    let contractList =[];
    let multipleRole = encodeURIComponent(userrole);
    if (customerId && customerId.opeType == 'search') {
      clientID = customerId.clientID ? customerId.clientID : '';
    } else {
      clientID = data.clientId ? data.clientId : null;
    }
    let loginOpeType = sessionStorage.getItem('loginOperationType');
    const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    const menuItemList2 = JSON.parse(sessionStorage.getItem('menuItemList'));
    let homeContractList = menuItemList?menuItemList.contractList:(menuItemList2?menuItemList2.contractList:[]);
    for (let i = 0; i < homeContractList.length; i++) {
      let contract ={};
     //contract['contractNumber'] = homeContractList[i].contractNumber;
     //contract['benefitType'] = homeContractList[i].benefitType;
     contractList.push(homeContractList[i].contractNumber);
    }
    const loggedUserInfo = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));

    let clientLoginId ="";
    let clientRole ="";
    if(menuItemList){
      clientLoginId =  menuItemList.clientLoginId ? menuItemList.clientLoginId :'';
      clientRole = menuItemList.clientRoleIds ?  menuItemList.clientRoleIds :'';
      this.canChangeDataflag = menuItemList.personalInformationDTO.flagOfCapabilityOfChangeData=== 'true' ? true:false;
    }else if(menuItemList2){
      
      let username = loggedUserInfo? loggedUserInfo.userName :'';
      let clientuserrole = loggedUserInfo? loggedUserInfo.requesterRole :'';
      clientLoginId =  menuItemList2.clientLoginId ? menuItemList2.clientLoginId :username;
      clientRole = menuItemList2.clientRoleIds ?  menuItemList2.clientRoleIds :clientuserrole;
      this.canChangeDataflag = menuItemList2.personalInformationDTO.flagOfCapabilityOfChangeData=== 'true' ? true:false;
    }
  
    const reqParam = {
      userId: data.userName,
      canChangeData:this.canChangeDataflag,
      role: userrole,
      pwdExpirationDelay: loggedUserInfo ? (loggedUserInfo.pwdExpirationDelay? loggedUserInfo.pwdExpirationDelay: ''):'' ,
      clientId: clientID,
      clientLoginId: clientLoginId, 
      clientRoleIds: clientRole,
      requesterID: data.requesterId,
      requesterRole: data.requesterRole,
      "contractNoList": contractList? contractList.toString() :"",
      creationDate: loggedUserInfo.creationDate,
      pwdExpirationDate: loggedUserInfo.pwdExpirationDate,
      customerPasswordExprationCode:loggedUserInfo.customerPasswordExprationCode, 
      userDn : loggedUserInfo.userDn,
      ldapUserName : loggedUserInfo.userName,
      "opeType": (customerId && customerId.opeType) ? customerId.opeType : loginOpeType,
    };
    //let url = `${this.baseUrl.ecustomer.notificationService}${data.userName}/${clientID}/${userrole}`;
    return this.cService['postData'](this.baseUrl.ecustomer.notificationService, reqParam, '');
  }
}
