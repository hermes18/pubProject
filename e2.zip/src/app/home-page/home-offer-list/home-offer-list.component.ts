import { Component, OnInit } from '@angular/core';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { environment } from 'src/environments/environment';

import { DomSanitizer } from '@angular/platform-browser';

import { HomeOfferListModel } from './Model/home-offer-list.model';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { Router } from '@angular/router';
import { BroadcasterService } from 'src/app/core/services/broadcaster.service';
import { HomeOfferListService } from './service/home-offer-list.service';
import { takeWhile } from 'rxjs/operators';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';

import * as utils from 'lodash';

@Component({
  selector: 'home-offer-list',
  templateUrl: './home-offer-list.component.html',
  styleUrls: ['./home-offer-list.component.scss'],
  providers: [HomeOfferListService]
})
export class HomeOfferListComponent implements OnInit {
  homeOfferListModel: HomeOfferListModel;
  offferList;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  url;
  debtPolicyList = [];
  notificationList;
  investAccNumList = [];
  suspendedPoliciesList = [];
  userDetails: any;
  clientId: any;
  defaultOffer: any;
  country: any;
  constructor(private cService: HttpCommonService, private sanitize: DomSanitizer,
    private readonly commonService: SharedServiceService, private readonly router: Router,
    private homeOfferService: HomeOfferListService, private readonly menuItemService: MenuItemsService,
    private readonly broadCastService: BroadcasterService) {
    this.homeOfferListModel = new HomeOfferListModel();
    this.commonService.getcurrentUserLoggedIn().subscribe((data) => {
      this.userDetails = data;
    });
  }

  ngOnDestroy() {
    this.homeOfferListModel.subscribeFlag = false;
  }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    // sessionStorage.setItem('countryCode', country);

    this.clientId = this.commonService.getClientId() != null ? this.commonService.getClientId() : '';
    let url = this.baseUrl.ecustomer.homeOfferList;
    // let userId = '101584';
    // this.cService['getDataValue'](url + '/' + userId + '/', '')
    this.commonService.getDetail('menuItemList').pipe(takeWhile(() => this.homeOfferListModel.subscribeFlag))
      .subscribe((data) => {
        if (data && data.offerResponse && data.offerResponse.clientOffersList) {

          const offersList = data.offerResponse.clientOffersList;

          const uniqueOffersList = Array.from(new Set(offersList.map(a => a.offerId)))
            .map(offer => {
              return offersList.find(a => a.offerId === offer)
            })
          //("===>" ,uniqueOffersList);
          //const offerList = data.offerResponse.clientOffersList;
          if (uniqueOffersList) {
            const offerList = uniqueOffersList;
            this.getOfferList(offerList);
          }
        } else {
          // let url = this.baseUrl.ecustomer.myOfferDetails + '?' + 'offerId=' + '' + '&' + 'clentId=' + this.clientId + '&' + 'policyNo=' + '' + '&' + 'userRole=' + this.userDetails.roleInfo[0].name;
          // this.cService['getData'](url).subscribe(data => {
          //   //  this.defaultOffer = data;
          //   this.defaultOffer = utils.cloneDeep(data);
          //   this.defaultOffer.offerConfigurationDto.imageBase64 = '';
          //   this.defaultOffer.offerConfigurationDto.imageBase64 = "data:image/png;base64," + this.defaultOffer.offerConfigurationDto.offerMainImage;
          //   this.defaultOffer.offerConfigurationDto.imageBase64 = this.sanitize.bypassSecurityTrustUrl(this.defaultOffer.offerConfigurationDto.imageBase64);
          // });
          this.homeOfferListModel.offerMainList = [];
        }
      },
        (error: Error) => {
          this.homeOfferListModel.offerMainList = [];
        });
    //const flagtest = "assets/mocks/notification.json";
    // this.cService['getData'](flagtest)
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID')),
      loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
      userrole = this.menuItemService.getAllRoles();
    //(userrole);

    this.homeOfferService.gteNotificationList(loggedInUserDetail, customerId, userrole).pipe(takeWhile(() => this.homeOfferListModel.subscribeFlag))
      .subscribe(data => {
        //(data);
        this.getNotificationList(data);
      });
  }

  getNotificationList(data) {
    if (data.investAccNumList.length > 0 || data.debtPoliciesList.length > 0 || data.suspendedPoliciesList.length > 0 || data.renderAddressChange || data.renderPasswordChange) {
      this.notificationList = data;
      //(this.notificationList)
      // for (const policy in this.notificationList) {
      //   //(policy)
      // }
      this.notificationList.debtPoliciesList.forEach(policy => {
        if (policy) {
          this.debtPolicyList.push({
            contractNumber: policy.policyNo,
            status: policy.status ? policy.status : '',
            benefitType: policy.benefitType
          });
        } else {
          this.debtPolicyList = [];
        }
      });
      this.getInvestmentList();
      this.getSuspendedPolicy();
    } else {
      this.notificationList = null;
    }

  }

  getInvestmentList() {
    if (this.notificationList && this.notificationList.investAccNumList) {
      this.notificationList.investAccNumList.forEach(policy => {
        if (policy) {
          this.investAccNumList.push({
            contractNumber: policy.investAccNumber,
            fundCode: policy.fundCode ? policy.fundCode : '',
            status: policy.status ? policy.status : '',
            benefitType: policy.benefitType
          });
        }
      });
    } else {
      this.investAccNumList = [];
    }
    //(this.investAccNumList)

  }

  getSuspendedPolicy() {
    if (this.notificationList && this.notificationList.suspendedPoliciesList) {
      this.notificationList.suspendedPoliciesList.forEach(policy => {
        if (policy.policyNo) {
          this.suspendedPoliciesList.push({
            contractNumber: policy.policyNo,
            status: policy.status ? policy.status : '',
            benefitType: policy.benefitType
          });
        } else {
          this.suspendedPoliciesList = [];
        }
      });
    }
  }


  getOfferList(offerList) {
    offerList.forEach(list => {
      const base64 = "data:image/png;base64," + list.offerMainImage,
        base64Url = this.sanitize.bypassSecurityTrustUrl(base64);
      this.homeOfferListModel.offerMainList.push({
        offerMainImage: list.offerMainImage ? base64Url : '',
        offerSort: list.offerSort,
        offerMarketingName: list.offerMarketingName,
        offerSummaryText: list.offerSummaryText,
        clientId: list.clientId,
        offerId: list.offerId,
        contractNumber: list.contractNumber
      });
    });
  }

  goToOfferList() {
    this.router.navigate(['/myOffers'])
  }

  goToIndividualOffer(offerList) {
    //(offerList)
    this.router.navigate(['myOffers/offerlist']);
    this.commonService.setterData('offerList', offerList);
  }

  goToPersonlaData() {
    const customerOrderId = JSON.parse(sessionStorage.getItem('searcClientID'));
    sessionStorage.setItem('personalDataOrderId', customerOrderId);
    this.router.navigate(['/personalInfo']);
  }

  goToChangePassword() {
    // this.broadCastService.broadcast('fromHomePage', true);
    this.commonService.setterData('fromHomePage', true);
    this.router.navigate(['/setting']);
  }

  navigateToContractDetails(contract) {
    sessionStorage.setItem('contractDetails', JSON.stringify(contract));
    this.menuItemService.getSubmenuList(contract);
  }
}
