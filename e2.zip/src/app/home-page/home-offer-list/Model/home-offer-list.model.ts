

export class HomeOfferListModel {
    subscribeFlag: boolean;
    offerMainList;
    constructor() {
        this.subscribeFlag = true;
        this.offerMainList = [];

    }

}