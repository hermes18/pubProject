import { APP_BASE_HREF } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppModule } from 'src/app/app.module';
import { HomePageModule } from '../../home-page.module';

import { HomeOfferListService } from './home-offer-list.service';

describe('HomeOfferListService', () => {
  let service: HomeOfferListService;
  const menuClinetList = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": null,
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "personalInformationDTO": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  }
  const menulist = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  }
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        "notificationService": host + '/api/v1/users/notifications'
      }
    }
  };
  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    window.sessionStorage.setItem('menuListFromClientSearch', JSON.stringify(menulist));
    window.sessionStorage.setItem('menuItemList', JSON.stringify(menuClinetList));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HomePageModule],
      providers: [HomeOfferListService, { provide: APP_BASE_HREF, useValue: '/' }],
    });
    service = TestBed.get(HomeOfferListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call gteNotificationList', () => {
    const customerId = {
      clientID: "11088615",
      opeType: "search"
    },
      userRole = "rStandardUser|rSuperUser|rAdministrator",
      userImfo =
        { userName: "Finson_Admin2", firstName: "Finson", lastName: "Francis", email: "finson.francis1@metlife.com", preferredLanguage: "en", creationDate: "Mon Nov 09 14:20:54 CET 2020", passwordType: "STANDARD", customerPasswordExprationCode: "1", passwordStatusCode: "ACTIVE", securityPolicyId: "12345", tokenExpirationDate: "Mon Nov 09 14:20:54 CET 2020", employeeNumber: "3470451", pwdExpirationDate: "Wed Jan 20 14:20:54 CET 2021", failedLoginCounts: "0", authorizedApplicationCode: "eCustomer", temporaryLockDate: null, route: "Home", pwdExpired: "Active", daysSincePwdNotChanged: null, pwdChangeDate: null, roleInfo: [{ roleId: "3033", name: "rSuperUser", description: "RSuperUser" }, { roleId: "3034", name: "rAdministrator", description: "SystemAdministrator" }, { "roleId": "3036", name: "rUserAccountManager", description: "RUserAccountManager" }], clientId: null, requesterId: "-1", requesterRole: "3033" };
    service.gteNotificationList(userImfo, customerId, userRole);
  });
});
