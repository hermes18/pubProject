

export class HomePageWardenModel {
    subscribeFlag: boolean;
    offerMainList;
    constructor() {
        this.subscribeFlag = true;
        this.offerMainList = [];

    }

} 