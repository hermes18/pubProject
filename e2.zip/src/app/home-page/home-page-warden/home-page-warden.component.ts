import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { takeWhile } from 'rxjs/operators';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { HomePageWardenModel } from './Model/home-page-warden.model';
import { HomePageWardenService } from './service/home-page-warden.service';
import { DeviceDetectorService } from 'ngx-device-detector';

export interface contractData {
  benefitType: string;
  contractNumber: string;
  status: string;
}

@Component({
  selector: 'home-page-warden',
  templateUrl: './home-page-warden.component.html',
  styleUrls: ['./home-page-warden.component.scss'],
  providers: [HomePageWardenService]
})
export class HomePageWardenComponent implements OnInit {
  clientSearchForm: FormGroup;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  contractListData;
  contractListDataActive: any = [];
  contractListDataInactive: any = [];
  displayedColumns: string[] = ['benefitType', 'contractNumber'];
  user: any;
  dataSource: MatTableDataSource<contractData>;
  count: number;
  private paginator: MatPaginator;
  user1: any;
  dataSource1: MatTableDataSource<contractData>;
  count1: number;
  private paginator1: MatPaginator;
  searchclick: boolean = false;
  RecordsFound: boolean;
  debtPolicyList = [];
  notificationList;
  investAccNumList = [];
  suspendedPoliciesList = [];
  billGroupList = [];
  searchResultFlag: boolean = false;
  homePageWardenModel: HomePageWardenModel;
  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {

    this.paginator = mp;
    this.paginator1 = mp;
    if (this.dataSource)
      this.dataSource.paginator = this.paginator;

    if (this.dataSource1)
      this.dataSource1.paginator = this.paginator1;
  }
  constructor(public fb: FormBuilder, private readonly commonService: SharedServiceService,
    private menuItem: MenuItemsService, private readonly router: Router, private readonly menuItemService: MenuItemsService,
    private homePageService: HomePageWardenService,public deviceDetector:DeviceDetectorService,  public commonhttpService: HttpCommonService) {
    this.homePageWardenModel = new HomePageWardenModel();
  }
  clientId: any = null;
  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.clientSearchForm = this.fb.group({
      billcontrol: null,
      pesel: null,
      lastName: null,
      contractNo: null,
      //customerId: [null, Validators.pattern("^[0-9]*$")],

    });

    const customerId = JSON.parse(sessionStorage.getItem('searcClientID')),
      loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
      userrole = this.menuItemService.getAllRoles();

    this.homePageService.gteNotificationList(loggedInUserDetail, customerId, userrole).pipe(takeWhile(() => this.homePageWardenModel.subscribeFlag))
      .subscribe(data => {
        this.getNotificationList(data);
      });

    this.RecordsFound = false;
    this.getContractOrderDetails();


    if (loggedInUserDetail) {
      this.clientId = loggedInUserDetail.clientId ? loggedInUserDetail.clientId : '';
    }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    }

  }

  getContractOrderDetails() {
    this.contractListDataActive = [];
    this.contractListDataInactive = [];
    this.billGroupList = [];
    this.commonService.getDetail('menuItemList').subscribe((data) => {

      if (data && data.billingRecipent) {
        this.billGroupList = data.billingRecipent;
        if (this.billGroupList.length == 1) {
          this.clientSearchForm.get('billcontrol').setValue(this.billGroupList[0].billGroup)

        } else {
          this.clientSearchForm.get('billcontrol').setValue('')
        }
      }

      // if (data && data.contractList) {
      //   this.contractListData = data.contractList;
      // } else {
      //   this.contractListData = [];
      // }
      // if (this.contractListData) {
      //   for (let i = 0; i < this.contractListData.length; i++) {
      //     if (this.contractListData[i].status == '21') {

      //       this.contractListDataActive.push(this.contractListData[i]);
      //     }
      //     if (this.contractListData[i].status == '22') {

      //       this.contractListDataInactive.push(this.contractListData[i]);
      //     }
      //   }

      if (data && data.activeContractDetails) {
        for (let i = 0; i < data.activeContractDetails.length; i++) {
          this.contractListDataActive.push(data.activeContractDetails[i]);
        }
      }
      if (data && data.contractList) {
        for (let i = 0; i < data.contractList.length; i++) {
          this.contractListDataInactive.push(data.contractList[i]);
        }
      }
      if (this.contractListDataActive) {
        this.dataSource = new MatTableDataSource<contractData>();
        this.paginator = null;
        this.user = this.contractListDataActive;
        this.dataSource = new MatTableDataSource(this.user);

        this.dataSource.paginator = this.paginator;
        this.count = this.user.length;
      }
      if (this.contractListDataInactive) {
        this.dataSource1 = new MatTableDataSource<contractData>();
        this.paginator1 = null;
        this.user1 = this.contractListDataInactive;

        this.dataSource1 = new MatTableDataSource(this.user1);

        this.dataSource1.paginator = this.paginator1;
        this.count1 = this.user1.length;
      }

      if ((this.contractListDataInactive != null && this.contractListDataInactive != '') ||
        (this.contractListDataActive != null && this.contractListDataActive != '')) {
        this.searchResultFlag = false;
      } else {
        this.searchResultFlag = true;
      }
      // }

    });
  }

  customerSearch() {
    this.contractListDataActive = [];
    this.contractListDataInactive = [];
    this.searchResultFlag = false;
    let searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
    let loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let reqParam = {
      billControl: this.clientSearchForm.value.billcontrol ? (this.clientSearchForm.value.billcontrol).trim() : '',
      peselId: this.clientSearchForm.value.pesel ? (this.clientSearchForm.value.pesel).trim() : '',
      lastName: this.clientSearchForm.value.lastName ? (this.clientSearchForm.value.lastName).trim() : '',
      contractNumber: this.clientSearchForm.value.contractNo ? (this.clientSearchForm.value.contractNo).trim() : '',
      clientId: searchedClientDetails ? searchedClientDetails.customerId : '',
      requesterId: loggedInUserDetail ? loggedInUserDetail.requesterId : '',
      requesterRole: '3037',
      userId: loggedInUserDetail ? loggedInUserDetail.userName : ''
    }

    this.commonhttpService.postData(this.baseUrl.ecustomer.wardenSearch, reqParam, '').subscribe(data => {


      if (data && ((data.contractList != null && data.contractList != '') || (data.activeContractDetails != null && data.activeContractDetails != ''))) {
        this.contractListDataActive = [];
        this.contractListDataInactive = [];
        if (data && data.activeContractDetails) {
          for (let i = 0; i < data.activeContractDetails.length; i++) {
            this.contractListDataActive.push(data.activeContractDetails[i]);
          }
        }
        if (data && data.contractList) {
          for (let i = 0; i < data.contractList.length; i++) {
            this.contractListDataInactive.push(data.contractList[i]);
          }
        }
        if (this.contractListDataActive) {
          this.dataSource = new MatTableDataSource<contractData>();
          this.paginator = null;
          this.user = this.contractListDataActive;

          this.dataSource = new MatTableDataSource(this.user);

          this.dataSource.paginator = this.paginator;
          this.count = this.user.length;
        }
        if (this.contractListDataInactive) {
          this.dataSource1 = new MatTableDataSource<contractData>();
          this.paginator1 = null;
          this.user1 = this.contractListDataInactive;

          this.dataSource1 = new MatTableDataSource(this.user1);

          this.dataSource1.paginator = this.paginator1;
          this.count1 = this.user1.length;
        }
      } else {
        this.searchResultFlag = true;
      }


    })

  }

  goToContactMainPage() {
    this.router.navigate(['/MyContracts']);
  }


  getNotificationList(data) {
    if (data.investAccNumList.length > 0 || data.debtPoliciesList.length > 0 || data.suspendedPoliciesList.length > 0 || data.renderAddressChange || data.renderPasswordChange) {

      this.notificationList = data;

      this.notificationList.debtPoliciesList.forEach(policy => {
        if (policy) {
          this.debtPolicyList.push({
            contractNumber: policy.policyNo,
            status: policy.status ? policy.status : '',
            benefitType: policy.benefitType
          });
        } else {
          this.debtPolicyList = [];
        }
      });
      this.getInvestmentList();
      this.getSuspendedPolicy();
    } else {
      this.notificationList = null;
    }

  }

  getInvestmentList() {
    if (this.notificationList && this.notificationList.investAccNumList) {
      this.notificationList.investAccNumList.forEach(policy => {
        if (policy) {
          this.investAccNumList.push({
            contractNumber: policy.investAccNumber,
            fundCode: policy.fundCode ? policy.fundCode : '',
            status: policy.status ? policy.status : '',
            benefitType: policy.benefitType
          });
        }
      });
    } else {
      this.investAccNumList = [];
    }


  }

  getSuspendedPolicy() {
    if (this.notificationList && this.notificationList.suspendedPoliciesList) {
      this.notificationList.suspendedPoliciesList.forEach(policy => {
        if (policy.policyNo) {
          this.suspendedPoliciesList.push({
            contractNumber: policy.policyNo,
            status: policy.status ? policy.status : '',
            benefitType: policy.benefitType
          });
        } else {
          this.suspendedPoliciesList = [];
        }
      });
    }
  }

  goToPersonlaData() {
    const customerOrderId = JSON.parse(sessionStorage.getItem('searcClientID'));
    sessionStorage.setItem('personalDataOrderId', customerOrderId);
    this.router.navigate(['/personalInfo']);
  }

  goToChangePassword() {
    // this.broadCastService.broadcast('fromHomePage', true);
    this.commonService.setterData('fromHomePage', true);
    this.router.navigate(['/setting']);
  }

  navigateToContractDetails(contract) {
    sessionStorage.setItem('contractDetails', JSON.stringify(contract));
    this.menuItemService.getSubmenuList(contract);
  }

  goToContractDetails(contract) {
    sessionStorage.setItem('contractDetails', JSON.stringify(contract));
    this.menuItem.getSubmenuList(contract);

  }

}
