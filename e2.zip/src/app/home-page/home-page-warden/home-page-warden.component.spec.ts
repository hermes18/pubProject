import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';


import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from '../../app.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { HomePageModule } from '../home-page.module';
import { HomePageWardenComponent } from './home-page-warden.component';
import { HomePageWardenService } from './service/home-page-warden.service';
import { of } from 'rxjs';
import { Router } from '@angular/router';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
describe('HomePageWardenComponent', () => {
  let component: HomePageWardenComponent;
  let fixture: ComponentFixture<HomePageWardenComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  let homepagewardenservice: HomePageWardenService;
  let sharedService: SharedServiceService,
    commonService: HttpCommonService;
  const menuClinetList = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": null,
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "personalInformationDTO": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  }
  const menulist = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  }
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        "notificationService": host + '/api/v1/users/notifications'
      }
    }
  };

  let notificationList = {
    debtPoliciesList: [
      {
        "id": "1732885",
        "policyNumber": "20032799",
        "insurer": "I=O=NAME_1732885",
        "insured": "I=O=NAME_1732885",
        "paymentMode": null,
        "premiumDueDate": null,
        "currentPremiumAmount": 100.5500,
        "bankAccount": null,
        "debtStatus": "TRUE",
        "lastPremiumAmount": null,
        "indexedPremiumAmount": null,
        "indexationDocument": "-1",
        "suspendStatus": "TRUE",
        "suspendDate": null,
        "additionalbankAccount": null,
        "additionalBankAccountLabel": null,
        "additionalBankAccountTip": null,
        "coinsured1": null,
        "coinsured2": null,
        "coinsured3": null,
        "coinsured4": null,
        "coinsured5": null,
        "coinsured6": null,
        "coinsured7": null,
        "coinsured8": null,
        "coinsured9": null,
        "billGroup": "BILL_10",
        "bill": null
      }
    ],
    suspendedPoliciesList: [
      {
        "id": "1732885",
        "policyNumber": "20032799",
        "insurer": "I=O=NAME_1732885",
        "insured": "I=O=NAME_1732885",
        "paymentMode": null,
        "premiumDueDate": null,
        "currentPremiumAmount": 100.5500,
        "bankAccount": null,
        "debtStatus": "TRUE",
        "lastPremiumAmount": null,
        "indexedPremiumAmount": null,
        "indexationDocument": "-1",
        "suspendStatus": "TRUE",
        "suspendDate": null,
        "additionalbankAccount": null,
        "additionalBankAccountLabel": null,
        "additionalBankAccountTip": null,
        "coinsured1": null,
        "coinsured2": null,
        "coinsured3": null,
        "coinsured4": null,
        "coinsured5": null,
        "coinsured6": null,
        "coinsured7": null,
        "coinsured8": null,
        "coinsured9": null,
        "billGroup": "BILL_10",
        "bill": null
      }
    ],
    investAccNumList: [
      {
        "fundCode": "OLAS|058",
        "fundName": null,
        "unitPrice": null,
        "unitPriceActual": null,
        "sort": null,
        "investAccNumber": "20391636",
        "investAccType": null,
        "investAccNumberTip": null,
        "investAccNumberTipId": null
      }
    ],
    renderPasswordChange: true,
    canChangeData: true,
    renderAddressChange: true,
    daysSincePasswordNotChanged: "-22"
  };
  let router = {
    navigate: jasmine.createSpy('navigate')
  };
  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    window.sessionStorage.setItem('menuListFromClientSearch', JSON.stringify(menulist));
    window.sessionStorage.setItem('menuItemList', JSON.stringify(menuClinetList));
    const userImfo =
      { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], clientId: 101583, "requesterId": "-1", "requesterRole": "3033" }
    const serachClient =
      { clientId: '1234', opeType: "search" }
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HomePageModule, HttpClientTestingModule],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, { provide: Router, useValue: router }, TranslateService, HomePageWardenService],
      declarations: [],
    })
      .compileComponents();
    fixture = TestBed.createComponent(HomePageWardenComponent);
    homepagewardenservice = TestBed.get(HomePageWardenService);
    sharedService = TestBed.get(SharedServiceService);
    commonService = TestBed.get(HttpCommonService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {

  // });

  it('should create', () => {
    const response = { "debtPoliciesList": [{ "policyNo": "20032799", "benefitType": "Życie + ", "status": 22 }, { "policyNo": "20386578", "benefitType": "Senior", "status": 22 }, { "policyNo": "21137369", "benefitType": "Amplico Inwestor", "status": 22 }, { "policyNo": "21282475", "benefitType": "SuperKapitał S", "status": 21 }, { "policyNo": "21295126", "benefitType": "SuperKapitał S", "status": 21 }, { "policyNo": "21295127", "benefitType": "SuperKapitał S", "status": 21 }, { "policyNo": "32386578", "benefitType": "Lokata jubileuszowa", "status": 22 }, { "policyNo": "7101352", "benefitType": "Bezpieczne Jutro", "status": 21 }], "suspendedPoliciesList": [{ "policyNo": "7101352", "benefitType": "Bezpieczne Jutro", "status": 21 }], "investAccNumList": [{ "fundCode": "OLAS | 007", "fundName": "AFK OBLIGACJI ", "unitPrice": null, "unitPriceActual": null, "sort": null, "status": 23, "investAccNumber": "21295126", "investAccType": "1", "investAccNumberTip": null, "investAccNumberTipId": null }], "renderPasswordChange": true, "canChangeData": true, "renderAddressChange": false, "daysSincePasswordNotChanged": "379" }
    spyOn(homepagewardenservice, 'gteNotificationList').and.returnValue(of(response));

    expect(component).toBeTruthy();
  });

  it('should call getNotificationList', () => {
    component.getNotificationList(notificationList);
  });

  it('should call getNotificationList case debtPoliciesList length > 0 ', () => {
    let notificationList = {
      debtPoliciesList: [
        {
          "id": "1732885",
          "policyNumber": "20032799",
          "insurer": "I=O=NAME_1732885",
          "insured": "I=O=NAME_1732885",
          "paymentMode": null,
          "premiumDueDate": null,
          "currentPremiumAmount": 100.5500,
          "bankAccount": null,
          "debtStatus": "TRUE",
          "lastPremiumAmount": null,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        }
      ],
      suspendedPoliciesList: [
      ],
      investAccNumList: [

      ],
      renderPasswordChange: true,
      canChangeData: true,
      renderAddressChange: true,
      daysSincePasswordNotChanged: "-22"
    };
    component.getNotificationList(notificationList);
  });

  it('should call getNotificationList suspended length', () => {

    let notificationList = {
      debtPoliciesList: [{
        "id": "2180501",
        "policyNumber": "21295127",
        "insurer": "O=NAME_2180501",
        "insured": "I=NAME_2180501",
        "paymentMode": "11",
        "premiumDueDate": 1334514600000,
        "currentPremiumAmount": 100.5500,
        "bankAccount": "32 1030 1944 9000 0500 2129 5127",
        "debtStatus": "TRUE",
        "lastPremiumAmount": 153.6700,
        "indexedPremiumAmount": null,
        "indexationDocument": "-1",
        "suspendStatus": "TRUE",
        "suspendDate": null,
        "additionalbankAccount": null,
        "additionalBankAccountLabel": null,
        "additionalBankAccountTip": null,
        "coinsured1": null,
        "coinsured2": null,
        "coinsured3": null,
        "coinsured4": null,
        "coinsured5": null,
        "coinsured6": null,
        "coinsured7": null,
        "coinsured8": null,
        "coinsured9": null,
        "billGroup": "BILL_10",
        "bill": null
      }],
      suspendedPoliciesList: [
        {
          "id": "1732885",
          "policyNumber": "20032799",
          "insurer": "I=O=NAME_1732885",
          "insured": "I=O=NAME_1732885",
          "paymentMode": null,
          "premiumDueDate": null,
          "currentPremiumAmount": 100.5500,
          "bankAccount": null,
          "debtStatus": "TRUE",
          "lastPremiumAmount": null,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        }
      ],
      "investAccNumList": [

      ],
      renderPasswordChange: true,
      canChangeData: true,
      renderAddressChange: true,
      daysSincePasswordNotChanged: "-22"
    };
    component.getNotificationList(notificationList);
  });

  it('should call getNotificationList renderAddressChange as false', () => {

    let notificationList = {
      debtPoliciesList: [],
      suspendedPoliciesList: [],
      investAccNumList: [],
      renderPasswordChange: true,
      canChangeData: true,
      renderAddressChange: false,
      daysSincePasswordNotChanged: "-22"
    };
    component.getNotificationList(notificationList);
  });

  it('should call getNotificationList renderPasswordChange as false', () => {

    let notificationList = {
      debtPoliciesList: [],
      suspendedPoliciesList: [],
      investAccNumList: [],
      renderPasswordChange: false,
      canChangeData: true,
      renderAddressChange: true,
      daysSincePasswordNotChanged: "-22"
    };
    component.getNotificationList(notificationList);
  });

  it('should call getInvestmentList method', () => {
    component.getInvestmentList();
  });

  it('should call getSuspendedPolicy method', () => {
    component.getSuspendedPolicy();
  });
  it('should call getNotificationList', () => {
    component.getNotificationList(notificationList);
  });

  it('should call getNotificationList case debtPoliciesList length > 0 ', () => {
    let notificationList = {
      "debtPoliciesList": [
        {
          "id": "1732885",
          "policyNumber": "20032799",
          "insurer": "I=O=NAME_1732885",
          "insured": "I=O=NAME_1732885",
          "paymentMode": null,
          "premiumDueDate": null,
          "currentPremiumAmount": 100.5500,
          "bankAccount": null,
          "debtStatus": "TRUE",
          "lastPremiumAmount": null,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        },
        {
          "id": "1698707",
          "policyNumber": "20386578",
          "insurer": "I=O=NAME_1698707",
          "insured": "I=O=NAME_1698707",
          "paymentMode": null,
          "premiumDueDate": null,
          "currentPremiumAmount": 100.5500,
          "bankAccount": null,
          "debtStatus": "TRUE",
          "lastPremiumAmount": null,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        },
        {
          "id": "2314786",
          "policyNumber": "21137369",
          "insurer": "I=O=NAME_2314786",
          "insured": "I=O=NAME_2314786",
          "paymentMode": "12",
          "premiumDueDate": null,
          "currentPremiumAmount": 100.5500,
          "bankAccount": "123456789",
          "debtStatus": "TRUE",
          "lastPremiumAmount": 9362.0100,
          "indexedPremiumAmount": 200.0000,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": "123456789123456",
          "additionalBankAccountLabel": "ABL001",
          "additionalBankAccountTip": null,
          "coinsured1": "Coinsured 1",
          "coinsured2": "Coinusred 2",
          "coinsured3": "Coinsured 3",
          "coinsured4": null,
          "coinsured5": "Coinsured 5",
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": "Coinsured 9",
          "billGroup": "BILL_10",
          "bill": null
        },
        {
          "id": "2330782",
          "policyNumber": "21282475",
          "insurer": "I=O=NAME_2330782",
          "insured": "I=O=NAME_2330782",
          "paymentMode": "11",
          "premiumDueDate": 1332873000000,
          "currentPremiumAmount": 100.5500,
          "bankAccount": "qq asdf 1944 9000 0500 2128 2475",
          "debtStatus": "TRUE",
          "lastPremiumAmount": 157.3200,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        },
        {
          "id": "2180501",
          "policyNumber": "21295127",
          "insurer": "O=NAME_2180501",
          "insured": "I=NAME_2180501",
          "paymentMode": "11",
          "premiumDueDate": 1334514600000,
          "currentPremiumAmount": 100.5500,
          "bankAccount": "32 1030 1944 9000 0500 2129 5127",
          "debtStatus": "TRUE",
          "lastPremiumAmount": 153.6700,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        }
      ],
      "suspendedPoliciesList": [
      ],
      "investAccNumList": [

      ],
      "renderPasswordChange": true,
      "canChangeData": true,
      "renderAddressChange": true,
      "daysSincePasswordNotChanged": "-22"
    };
    component.getNotificationList(notificationList);
  });

  it('should call getNotificationList suspended length', () => {

    let notificationList = {
      "debtPoliciesList": [{
        "id": "2180501",
        "policyNumber": "21295127",
        "insurer": "O=NAME_2180501",
        "insured": "I=NAME_2180501",
        "paymentMode": "11",
        "premiumDueDate": 1334514600000,
        "currentPremiumAmount": 100.5500,
        "bankAccount": "32 1030 1944 9000 0500 2129 5127",
        "debtStatus": "TRUE",
        "lastPremiumAmount": 153.6700,
        "indexedPremiumAmount": null,
        "indexationDocument": "-1",
        "suspendStatus": "TRUE",
        "suspendDate": null,
        "additionalbankAccount": null,
        "additionalBankAccountLabel": null,
        "additionalBankAccountTip": null,
        "coinsured1": null,
        "coinsured2": null,
        "coinsured3": null,
        "coinsured4": null,
        "coinsured5": null,
        "coinsured6": null,
        "coinsured7": null,
        "coinsured8": null,
        "coinsured9": null,
        "billGroup": "BILL_10",
        "bill": null
      }],
      "suspendedPoliciesList": [
        {
          "id": "1732885",
          "policyNumber": "20032799",
          "insurer": "I=O=NAME_1732885",
          "insured": "I=O=NAME_1732885",
          "paymentMode": null,
          "premiumDueDate": null,
          "currentPremiumAmount": 100.5500,
          "bankAccount": null,
          "debtStatus": "TRUE",
          "lastPremiumAmount": null,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        },
        {
          "id": "1698707",
          "policyNumber": "20386578",
          "insurer": "I=O=NAME_1698707",
          "insured": "I=O=NAME_1698707",
          "paymentMode": null,
          "premiumDueDate": null,
          "currentPremiumAmount": 100.5500,
          "bankAccount": null,
          "debtStatus": "TRUE",
          "lastPremiumAmount": null,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        },
        {
          "id": "2314786",
          "policyNumber": "21137369",
          "insurer": "I=O=NAME_2314786",
          "insured": "I=O=NAME_2314786",
          "paymentMode": "12",
          "premiumDueDate": null,
          "currentPremiumAmount": 100.5500,
          "bankAccount": "123456789",
          "debtStatus": "TRUE",
          "lastPremiumAmount": 9362.0100,
          "indexedPremiumAmount": 200.0000,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": "123456789123456",
          "additionalBankAccountLabel": "ABL001",
          "additionalBankAccountTip": null,
          "coinsured1": "Coinsured 1",
          "coinsured2": "Coinusred 2",
          "coinsured3": "Coinsured 3",
          "coinsured4": null,
          "coinsured5": "Coinsured 5",
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": "Coinsured 9",
          "billGroup": "BILL_10",
          "bill": null
        },
        {
          "id": "2330782",
          "policyNumber": "21282475",
          "insurer": "I=O=NAME_2330782",
          "insured": "I=O=NAME_2330782",
          "paymentMode": "11",
          "premiumDueDate": 1332873000000,
          "currentPremiumAmount": 100.5500,
          "bankAccount": "qq asdf 1944 9000 0500 2128 2475",
          "debtStatus": "TRUE",
          "lastPremiumAmount": 157.3200,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        },
        {
          "id": "1547762",
          "policyNumber": "21295126",
          "insurer": "O=NAME_1547762",
          "insured": "I=NAME_1547762",
          "paymentMode": "11",
          "premiumDueDate": 1334514600000,
          "currentPremiumAmount": 100.5500,
          "bankAccount": "59 1030 1944 9000 0500 2129 5126",
          "debtStatus": "FALSE",
          "lastPremiumAmount": 153.6700,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "true",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        },
        {
          "id": "2180501",
          "policyNumber": "21295127",
          "insurer": "O=NAME_2180501",
          "insured": "I=NAME_2180501",
          "paymentMode": "11",
          "premiumDueDate": 1334514600000,
          "currentPremiumAmount": 100.5500,
          "bankAccount": "32 1030 1944 9000 0500 2129 5127",
          "debtStatus": "TRUE",
          "lastPremiumAmount": 153.6700,
          "indexedPremiumAmount": null,
          "indexationDocument": "-1",
          "suspendStatus": "TRUE",
          "suspendDate": null,
          "additionalbankAccount": null,
          "additionalBankAccountLabel": null,
          "additionalBankAccountTip": null,
          "coinsured1": null,
          "coinsured2": null,
          "coinsured3": null,
          "coinsured4": null,
          "coinsured5": null,
          "coinsured6": null,
          "coinsured7": null,
          "coinsured8": null,
          "coinsured9": null,
          "billGroup": "BILL_10",
          "bill": null
        }
      ],
      "investAccNumList": [

      ],
      "renderPasswordChange": true,
      "canChangeData": true,
      "renderAddressChange": true,
      "daysSincePasswordNotChanged": "-22"
    };
    component.getNotificationList(notificationList);
  });

  it('should call getNotificationList renderAddressChange as false', () => {

    let notificationList = {
      "debtPoliciesList": [],
      "suspendedPoliciesList": [],
      "investAccNumList": [],
      "renderPasswordChange": true,
      "canChangeData": true,
      "renderAddressChange": false,
      "daysSincePasswordNotChanged": "-22"
    };
    component.getNotificationList(notificationList);
  });

  it('should call getNotificationList renderPasswordChange as false', () => {

    let notificationList = {
      "debtPoliciesList": [],
      "suspendedPoliciesList": [],
      "investAccNumList": [],
      "renderPasswordChange": false,
      "canChangeData": true,
      "renderAddressChange": true,
      "daysSincePasswordNotChanged": "-22"
    };
    component.getNotificationList(notificationList);
  });

  it('should call getNotificationList else part', () => {

    let notificationList = {
      "debtPoliciesList": [],
      "suspendedPoliciesList": [],
      "investAccNumList": [],
      "renderPasswordChange": false,
      "canChangeData": true,
      "renderAddressChange": false,
      "daysSincePasswordNotChanged": "-22"
    };
    component.getNotificationList(notificationList);
  });
  it('should call getInvestmentList method', () => {
    component.getInvestmentList();
  });

  it('should call getSuspendedPolicy method', () => {
    component.getSuspendedPolicy();
  });

  it('should call goToContactMainPage method', () => {
    component.goToContactMainPage();
    expect(router.navigate).toHaveBeenCalledWith(['/MyContracts']);
  });


  it('should call goToPersonlaData method', () => {
    component.goToPersonlaData();
    expect(router.navigate).toHaveBeenCalledWith(['/personalInfo']);
  });

  it('should call goToChangePassword method', () => {
    component.goToChangePassword();
    // expect(router.navigate).toHaveBeenCalledWith(['/personalInfo']);
  });

  it('should call navigateToContractDetails method', () => {
    const test = {
      contractList: [{
        benefitType: "Grupowe ubezpieczenie na życie",
        businessRoleList: ["insured"],
        contractDetailsDTO: {
          additionalBankAccount: null,
          additionalBankAccountLabel: null,
          additionalBankAccountTip: null,
          anniverseryDueDate: null,
          bankAccount: null,
          billControl: null,
          billGroup: null,
          clientId: null,
          coinsured1: null,
          coinsured2: null,
          coinsured3: null,
          coinsured4: null,
          coinsured5: null,
          coinsured6: null,
          coinsured7: null,
          coinsured8: null,
          coinsured9: null,
          contractNumber: null,
          currentPremiumAmt: null,
          debtStatus: "FALSE",
          effectiveDate: "01.09.2008",
          frequency: null,
          indexRate1: null,
          indexRate2: null,
          indexationDocument: "0",
          indexationEligible: 0,
          indexedPremiumAmt: null,
          indexedPremiumAmt2: null,
          indxPremiumAmt: null,
          insured: "INSURED_1859/100:181",
          insurer: "INSURER_1859/100:181",
          lastPremiumAmt: null,
          noOfPolicies: 0,
          paymentMode: null,
          policySearchDTOsList: [],
          policyStatus: null,
          premiumDueDate: null,
          status: 21,
          suspendDate: null,
          suspendStatus: "FALSE",
          totalPremiumAmount: null
        },
        contractNumber: "1859/100:181",
        contractNumberList: null,
        effectiveDate: "01.09.2008",
        indexedPremiumAmount: null,
        insuredName: "INSURED_1859/100:181",
        premiumAmount: "",
        premiumAmt: null,
        premiumAmtType: "17",
        premiumDueDate: null,
        premiumPaymentMode: null,
        premiumType: null,
        processingSystem: "GMD",
        status: 21
      }]
    };
    component.navigateToContractDetails(test);
    // expect(router.navigate).toHaveBeenCalledWith(['/personalInfo']);
  });

  it('should call customerSearch', () => {
    component.customerSearch();
  })

  it('should call getContractOrderDetails', () => {
    const response = {
      billingRecipent: [{ id: "0004", billGroup: "1400000067", recipent: "823594" }
      ],
      activeContractDetails: [{
        benefitType: "Grupowe ubezpieczenie na życie",
        businessRoleList: ["insured"],
        contractDetailsDTO: {
          additionalBankAccount: null,
          additionalBankAccountLabel: null,
          additionalBankAccountTip: null,
          anniverseryDueDate: null,
          bankAccount: null,
          billControl: null,
          billGroup: null,
          clientId: null,
          coinsured1: null,
          coinsured2: null,
          coinsured3: null,
          coinsured4: null,
          coinsured5: null,
          coinsured6: null,
          coinsured7: null,
          coinsured8: null,
          coinsured9: null,
          contractNumber: null,
          currentPremiumAmt: null,
          debtStatus: "FALSE",
          effectiveDate: "01.09.2008",
          frequency: null,
          indexRate1: null,
          indexRate2: null,
          indexationDocument: "0",
          indexationEligible: 0,
          indexedPremiumAmt: null,
          indexedPremiumAmt2: null,
          indxPremiumAmt: null,
          insured: "INSURED_1859/100:181",
          insurer: "INSURER_1859/100:181",
          lastPremiumAmt: null,
          noOfPolicies: 0,
          paymentMode: null,
          policySearchDTOsList: [],
          policyStatus: null,
          premiumDueDate: null,
          status: 21,
          suspendDate: null,
          suspendStatus: "FALSE",
          totalPremiumAmount: null
        },
        contractNumber: "1859/100:181",
        contractNumberList: null,
        effectiveDate: "01.09.2008",
        indexedPremiumAmount: null,
        insuredName: "INSURED_1859/100:181",
        premiumAmount: "",
        premiumAmt: null,
        premiumAmtType: "17",
        premiumDueDate: null,
        premiumPaymentMode: null,
        premiumType: null,
        processingSystem: "GMD",
        status: 21
      }],

      callRetrievePolicies: false,
      callRetriveClientData: false,
      callRetriveClientOffers: false,
      ccDBAddressDTO: { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
      claimList: null,
      clientAdministration: false,
      clientId: "823594",
      clientIdList: [],
      clientIdbillControlList: [],
      clientLoginId: null,
      clientRoleIds: "3037",
      clientRoleNames: "rWarden",
      contractList: [{
        benefitType: "Grupowe ubezpieczenie na życie",
        businessRoleList: ["insured"],
        contractDetailsDTO: {
          additionalBankAccount: null,
          additionalBankAccountLabel: null,
          additionalBankAccountTip: null,
          anniverseryDueDate: null,
          bankAccount: null,
          billControl: null,
          billGroup: null,
          clientId: null,
          coinsured1: null,
          coinsured2: null,
          coinsured3: null,
          coinsured4: null,
          coinsured5: null,
          coinsured6: null,
          coinsured7: null,
          coinsured8: null,
          coinsured9: null,
          contractNumber: null,
          currentPremiumAmt: null,
          debtStatus: "FALSE",
          effectiveDate: "01.09.2008",
          frequency: null,
          indexRate1: null,
          indexRate2: null,
          indexationDocument: "0",
          indexationEligible: 0,
          indexedPremiumAmt: null,
          indexedPremiumAmt2: null,
          indxPremiumAmt: null,
          insured: "INSURED_1859/100:181",
          insurer: "INSURER_1859/100:181",
          lastPremiumAmt: null,
          noOfPolicies: 0,
          paymentMode: null,
          policySearchDTOsList: [],
          policyStatus: null,
          premiumDueDate: null,
          status: 21,
          suspendDate: null,
          suspendStatus: "FALSE",
          totalPremiumAmount: null
        },
        contractNumber: "1859/100:181",
        contractNumberList: null,
        effectiveDate: "01.09.2008",
        indexedPremiumAmount: null,
        insuredName: "INSURED_1859/100:181",
        premiumAmount: "",
        premiumAmt: null,
        premiumAmtType: "17",
        premiumDueDate: null,
        premiumPaymentMode: null,
        premiumType: null,
        processingSystem: "GMD",
        status: 21
      }],
      documentsList: null,
      eClaimsURL: "https://qa.eclaim.metlife.pl?countryCode=pl&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca346021ed4f7abd2b17057cee0fe8575ca2f7199621bc567a0c7ed4f99c97e33a37ee1ccd317710b404e42a45ca39087d12b0",
      fundPriceDetails: null,
      menuItems: [{ menuId: "3", accessSpec: "RW", menuName: "Change Password", parentMenu: "Settings" }],
      offerResponse: null,
      orderHistory: null,
      personalInformationDTO: { policyNumber: null, dateOfBirth: null, gender: null, residenceTelephone: "", mobile: null },
      renderClaims: false,
      renderDocuments: false,
      renderFundPriceMonitoring: false,
      renderMyCompany: true,
      renderMyContract: true,
      renderMyData: false,
      renderOffers: false,
      renderOrderReview: false,
      renderUserAcctAdministration: false,
      route: "Home",
      searchFlag: true,
      wardenRoleCheck: true
    };
    spyOn(sharedService, 'getDetail').and.returnValue(of(response));
    component.getContractOrderDetails();
  });

  it('should call customerSearch', () => {
    const response = {
      activeContractDetails: [{
        benefitType: "Grupowe ubezpieczenie na życie",
        businessRoleList: ["insured"],
        contractDetailsDTO: {
          additionalBankAccount: null,
          additionalBankAccountLabel: null,
          additionalBankAccountTip: null,
          anniverseryDueDate: null,
          bankAccount: null,
          billControl: null,
          billGroup: null,
          clientId: null,
          coinsured1: null,
          coinsured2: null,
          coinsured3: null,
          coinsured4: null,
          coinsured5: null,
          coinsured6: null,
          coinsured7: null,
          coinsured8: null,
          coinsured9: null,
          contractNumber: null,
          currentPremiumAmt: null,
          debtStatus: "FALSE",
          effectiveDate: "01.09.2008",
          frequency: null,
          indexRate1: null,
          indexRate2: null,
          indexationDocument: "0",
          indexationEligible: 0,
          indexedPremiumAmt: null,
          indexedPremiumAmt2: null,
          indxPremiumAmt: null,
          insured: "INSURED_1859/100:181",
          insurer: "INSURER_1859/100:181",
          lastPremiumAmt: null,
          noOfPolicies: 0,
          paymentMode: null,
          policySearchDTOsList: [],
          policyStatus: null,
          premiumDueDate: null,
          status: 21,
          suspendDate: null,
          suspendStatus: "FALSE",
          totalPremiumAmount: null
        },
        contractNumber: "1859/100:181",
        contractNumberList: null,
        effectiveDate: "01.09.2008",
        indexedPremiumAmount: null,
        insuredName: "INSURED_1859/100:181",
        premiumAmount: "",
        premiumAmt: null,
        premiumAmtType: "17",
        premiumDueDate: null,
        premiumPaymentMode: null,
        premiumType: null,
        processingSystem: "GMD",
        status: 21
      }],
      contractList: [{
        benefitType: "Grupowe ubezpieczenie na życie",
        businessRoleList: ["insured"],
        contractDetailsDTO: {
          additionalBankAccount: null,
          additionalBankAccountLabel: null,
          additionalBankAccountTip: null,
          anniverseryDueDate: null,
          bankAccount: null,
          billControl: null,
          billGroup: null,
          clientId: null,
          coinsured1: null,
          coinsured2: null,
          coinsured3: null,
          coinsured4: null,
          coinsured5: null,
          coinsured6: null,
          coinsured7: null,
          coinsured8: null,
          coinsured9: null,
          contractNumber: null,
          currentPremiumAmt: null,
          debtStatus: "FALSE",
          effectiveDate: "01.09.2008",
          frequency: null,
          indexRate1: null,
          indexRate2: null,
          indexationDocument: "0",
          indexationEligible: 0,
          indexedPremiumAmt: null,
          indexedPremiumAmt2: null,
          indxPremiumAmt: null,
          insured: "INSURED_1859/100:181",
          insurer: "INSURER_1859/100:181",
          lastPremiumAmt: null,
          noOfPolicies: 0,
          paymentMode: null,
          policySearchDTOsList: [],
          policyStatus: null,
          premiumDueDate: null,
          status: 21,
          suspendDate: null,
          suspendStatus: "FALSE",
          totalPremiumAmount: null
        },
        contractNumber: "1859/100:181",
        contractNumberList: null,
        effectiveDate: "01.09.2008",
        indexedPremiumAmount: null,
        insuredName: "INSURED_1859/100:181",
        premiumAmount: "",
        premiumAmt: null,
        premiumAmtType: "17",
        premiumDueDate: null,
        premiumPaymentMode: null,
        premiumType: null,
        processingSystem: "GMD",
        status: 21
      }]
    };
    spyOn(commonService, 'postData').and.returnValue(of(response));
    component.customerSearch();
  });

  it('should call customerSearch else part', () => {
    const response = {
      activeContractDetails: [],
      contractList: []
    };
    spyOn(commonService, 'postData').and.returnValue(of(response));
    component.customerSearch();
  });

  it('should call goToContractDetails method', () => {
    const test = {
      contractList: [{
        benefitType: "Grupowe ubezpieczenie na życie",
        businessRoleList: ["insured"],
        contractDetailsDTO: {
          additionalBankAccount: null,
          additionalBankAccountLabel: null,
          additionalBankAccountTip: null,
          anniverseryDueDate: null,
          bankAccount: null,
          billControl: null,
          billGroup: null,
          clientId: null,
          coinsured1: null,
          coinsured2: null,
          coinsured3: null,
          coinsured4: null,
          coinsured5: null,
          coinsured6: null,
          coinsured7: null,
          coinsured8: null,
          coinsured9: null,
          contractNumber: null,
          currentPremiumAmt: null,
          debtStatus: "FALSE",
          effectiveDate: "01.09.2008",
          frequency: null,
          indexRate1: null,
          indexRate2: null,
          indexationDocument: "0",
          indexationEligible: 0,
          indexedPremiumAmt: null,
          indexedPremiumAmt2: null,
          indxPremiumAmt: null,
          insured: "INSURED_1859/100:181",
          insurer: "INSURER_1859/100:181",
          lastPremiumAmt: null,
          noOfPolicies: 0,
          paymentMode: null,
          policySearchDTOsList: [],
          policyStatus: null,
          premiumDueDate: null,
          status: 21,
          suspendDate: null,
          suspendStatus: "FALSE",
          totalPremiumAmount: null
        },
        contractNumber: "1859/100:181",
        contractNumberList: null,
        effectiveDate: "01.09.2008",
        indexedPremiumAmount: null,
        insuredName: "INSURED_1859/100:181",
        premiumAmount: "",
        premiumAmt: null,
        premiumAmtType: "17",
        premiumDueDate: null,
        premiumPaymentMode: null,
        premiumType: null,
        processingSystem: "GMD",
        status: 21
      }]
    };
    component.goToContractDetails(test);
    // expect(router.navigate).toHaveBeenCalledWith(['/personalInfo']);
  });

});
