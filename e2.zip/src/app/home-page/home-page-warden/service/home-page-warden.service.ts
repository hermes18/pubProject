import { Injectable } from '@angular/core';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';

@Injectable()
export class HomePageWardenService {
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  canChangeDataflag :boolean = false;
  constructor(private cService: HttpCommonService) { }

  activeContractArray: any = [];
  wardenRoleCheck: boolean = false;
  gteNotificationList(data, customerId, userrole) { 
    let clientID;
    let contractList =[];
    let loginOpeType = sessionStorage.getItem('loginOperationType');
    let multipleRole = encodeURIComponent(userrole);
    if (customerId && customerId.opeType == 'search') {
      clientID = customerId.clientID ? customerId.clientID : '';
    } else {
      clientID = data.clientId ? data.clientId : null;
    }
    const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    const menuItemList2 = JSON.parse(sessionStorage.getItem('menuItemList'));
    let homeContractList = menuItemList?menuItemList.contractList:(menuItemList2?menuItemList2.contractList:[]);
    for (let i = 0; i < homeContractList.length; i++) {
      let contract ={};
     //contract['contractNumber'] = homeContractList[i].contractNumber;
     //contract['benefitType'] = homeContractList[i].benefitType;
     contractList.push(homeContractList[i].contractNumber);
    }
    const loggedUserInfo = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let clientLoginId = "";
    let clientRole = "";
    if (menuItemList) {
      clientLoginId = menuItemList.clientLoginId  ? menuItemList.clientLoginId : '';
      clientRole = menuItemList.clientRoleIds ? menuItemList.clientRoleIds : '';
      this.activeContractArray = menuItemList.activeContractDetails ? menuItemList.activeContractDetails : null;
      this.canChangeDataflag = menuItemList.personalInformationDTO.flagOfCapabilityOfChangeData=== 'true' ? true:false;
      this.wardenRoleCheck = menuItemList.wardenRoleCheck ? menuItemList.wardenRoleCheck : false;
    } else if (menuItemList2) {
     
      let username = loggedUserInfo? loggedUserInfo.userName :'';
      let clientuserrole = loggedUserInfo? loggedUserInfo.requesterRole :'';
      this.activeContractArray = menuItemList2.activeContractDetails ? menuItemList2.activeContractDetails : null;
      clientLoginId = menuItemList2.clientLoginId ? menuItemList2.clientLoginId : username;
      clientRole = menuItemList2.clientRoleIds ? menuItemList2.clientRoleIds : clientuserrole;
      this.canChangeDataflag = menuItemList2.personalInformationDTO.flagOfCapabilityOfChangeData=== 'true' ? true:false;
      this.wardenRoleCheck = menuItemList2.wardenRoleCheck ? menuItemList2.wardenRoleCheck : false;
    }
    if ((this.wardenRoleCheck == true) && this.activeContractArray != null && this.activeContractArray.length > 0) {
      /// this.wardernContractArray = this.contractList.concat(this.activeContractArray); 
      for (var i of this.activeContractArray) {
          contractList.push(i.contractNumber);
      }
    }
    // let role = data.roleInfo ? data.roleInfo[0] ? data.roleInfo[0].name : '' : '',
    const reqParam = {
      userId: data.userName,
      canChangeData:this.canChangeDataflag,
      role: userrole,
      pwdExpirationDelay: loggedUserInfo ? (loggedUserInfo.pwdExpirationDelay? loggedUserInfo.pwdExpirationDelay: ''):'' ,
      clientId: clientID,
      clientLoginId: clientLoginId,
      clientRoleIds: clientRole,
      requesterID: data.requesterId, 
      requesterRole: data.requesterRole,
      "contractNoList": contractList? contractList.toString() :"",
      creationDate: loggedUserInfo.creationDate,
      pwdExpirationDate: loggedUserInfo.pwdExpirationDate,
      customerPasswordExprationCode:loggedUserInfo.customerPasswordExprationCode, 
      userDn : loggedUserInfo.userDn,
      ldapUserName : loggedUserInfo.userName,
      "opeType": (customerId && customerId.opeType) ? customerId.opeType : loginOpeType,
    };
    //let url = `${this.baseUrl.ecustomer.notificationService}${data.userName}/${clientID}/${userrole}`;
    return this.cService['postData'](this.baseUrl.ecustomer.notificationService, reqParam, '');
  }
}
