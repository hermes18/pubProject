import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HomePageRoutingModule } from './home-page-routing.module';
import { HomePageComponent } from './home-page.component';
import { HomeOfferListComponent } from './home-offer-list/home-offer-list.component';
import { HomeOfferListPictureComponent} from './home-offer-list-picture/home-offer-list-picture.component';
import { HomeContractListComponent } from './home-contract-list/home-contract-list.component';
import { MatDatepickerModule, MatFormFieldModule, MatInputModule, MatNativeDateModule, MatTableModule, MatPaginatorModule } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { HomePageWardenComponent } from './home-page-warden/home-page-warden.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [HomeOfferListComponent,HomeOfferListPictureComponent, HomePageComponent, HomeContractListComponent, HomePageWardenComponent],
  imports: [
    CommonModule,
    TranslateModule,
    HomePageRoutingModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    NgxPaginationModule,
    MatPaginatorModule,
    MatDatepickerModule, MatNativeDateModule,
    // NgbModule.forRoot(),
  ]
})
export class HomePageModule { }
