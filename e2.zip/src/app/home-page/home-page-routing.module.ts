import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './home-page.component';
import { CanDeactivateGuardService } from '../core/gaurds/can-deactivate-guard';
import { CanActivateGuard } from '../core/gaurds/can-activate-guard';
import { NavigationGuard } from '../core/gaurds/navigation-guard';


const routes: Routes = [
  {
    path: '', component: HomePageComponent,
    canDeactivate: [NavigationGuard],
    data: { requiresLogin: true }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [CanActivateGuard, CanDeactivateGuardService]
})
export class HomePageRoutingModule { }
