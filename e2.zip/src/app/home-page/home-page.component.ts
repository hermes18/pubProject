import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpCommonService } from '../shared/services/http-common.service';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

import { CanComponentDeactivate } from '../core/gaurds/can-deactivate-guard';
@Component({
  selector: 'home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  roleBasedhomePage: boolean = false;
  canDeactivate(component: CanComponentDeactivate, route: ActivatedRouteSnapshot, state: RouterStateSnapshot,
    nextState: RouterStateSnapshot): Observable<boolean> | boolean {
    // if (route.data.requiresLogin && (nextState.url == '/login' || nextState.url == '/announcement')) {
    //   return false;
    // }
    return true;
  }

  constructor() { }

  ngOnInit() {
    this.roleBasedhomePage = false;
    let clientSearch =
      JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    const menuItemList2 = JSON.parse(sessionStorage.getItem('menuItemList'));
    // //("clientSearch", clientSearch)
    // //("clientSearch", clientSearch.wardenRoleCheck)
    // if (clientSearch && clientSearch.wardenRoleCheck) {
    //   this.roleBasedhomePage = clientSearch.wardenRoleCheck;
    // }
    if (menuItemList) {

      this.roleBasedhomePage = menuItemList ? menuItemList.wardenRoleCheck : false;
    } else if (menuItemList2) {

      this.roleBasedhomePage = menuItemList2 ? menuItemList2.wardenRoleCheck : false;
    }
  }

}
