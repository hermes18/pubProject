import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FakeLandingRoutingModule } from './fake-landing-routing.module';
import { FakeLandingComponent } from './fake-landing.component';


@NgModule({
  declarations: [FakeLandingComponent],
  imports: [
    CommonModule,
    FakeLandingRoutingModule
  ]
})
export class FakeLandingModule { }
