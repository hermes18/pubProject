import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { FakeLandingComponent } from './fake-landing.component';


const routes: Routes = [{
  path: '',
  component: FakeLandingComponent, canDeactivate: [NavigationGuard]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FakeLandingRoutingModule { }
