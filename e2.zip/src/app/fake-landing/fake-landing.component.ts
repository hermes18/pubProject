import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fake-landing',
  templateUrl: './fake-landing.component.html',
  styleUrls: ['./fake-landing.component.scss']
})
export class FakeLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
