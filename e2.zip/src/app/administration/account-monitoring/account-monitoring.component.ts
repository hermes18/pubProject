import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { HttpCommonService } from './../../shared/services/http-common.service';
import { environment } from 'src/environments/environment';
import { FormBuilder, Validators, FormArray, FormGroup, FormControl } from '@angular/forms';
import { utf8Encode } from '@angular/compiler/src/util';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';

@Component({
  selector: 'account-monitoring',
  templateUrl: './account-monitoring.component.html',
  styleUrls: ['./account-monitoring.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class AccountMonitoringComponent implements OnInit {

  settingParamValue = {
    'clientSearch': false,
    'userSearch': false,
    'userDetails': false
  }
  lang: string;
  country: string;
  displayRoOption: boolean = false;
  accountDetail;
  fundDetails;
  accountMonitoring: FormGroup
  FundSwitchRequestDTO: any = [];
  emailInValid: boolean = false
  personalInfo: any;
  clientId: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(public commonService: HttpCommonService, public fb: FormBuilder,
    public sharedService: SharedServiceService,
    private menuItemService: MenuItemsService) {
    this.accountMonitoring =
      this.fb.group({
        accountMaxValue: ['', Validators.required],
        accountMinValue: ['', Validators.required],
        email: ['', Validators.email],
        fundPriceDTOs: this.fb.array([]),
      })
  }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    if (this.country == 'ro') {
      this.displayRoOption = true;
    } else {
      this.displayRoOption = false;
    }
    this.sharedService.getDetail('menuItemList').subscribe((data) => {
     // this.clientId = data.clientId;
      // if (data.fundPriceDetails) {
      //   this.accountDetail = data.fundPriceDetails;
      //   this.fundDetails = this.accountDetail.fundSwitchDTOs[0].fundSwitchDTOs;
      //   //(this.fundDetails.length);
      //   for (var i = 0; i < this.fundDetails.length; i++) {
      //     this.add(i);
      //   }
      //   //(this.accountMonitoring);
      // } else {
      //   this.accountDetail = [];
      // }
      // if (data.personalInformationDTO) {
      //   this.personalInfo = data.personalInformationDTO;
      // } else {
      //   this.personalInfo = null;
      // }
    });
  }

  fundPriceDTOs(): FormArray {
    return this.accountMonitoring.get('fundPriceDTOs') as FormArray;
  }

  new(index): FormGroup {
    return this.fb.group({
      fundCode: this.fundDetails[index].fundCode,
      fundName: this.fundDetails[index].fundName,
      unitPrice: this.fundDetails[index].unitPrice,
      unitPriceActual: this.fundDetails[index].unitPriceActual,
      sort: this.fundDetails[index].sort,
      minimumFundAllocation: [''],
      maximumFundAllocation: [''],
    })
  }

  add(index) {
    this.fundPriceDTOs().push(this.new(index));
  }

  onSubmit() {
    let req = {
      "clientId": this.clientId,//"11088615",
      "email": this.personalInfo.emailBasic,//"Shabana.Shaikh@Metlife.pl",
      "firstName": this.personalInfo.firstName,//"Shabana",
      "lastName": this.personalInfo.lastName,//"Shaikh",
      "policyNumber": this.personalInfo.policyNumber,//"10293697",
      "language": "en",
      "accountValue": this.accountDetail.accountValue,//"100",
      "accountMaxValue": this.accountMonitoring.value.accountMaxValue,//"125",
      "accountMinValue": this.accountMonitoring.value.accountMinValue,//"75",
      "fundPriceDTOs": this.getFundPriceDTOs()
    }
    //(req);
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.fundPriceSubmit;
    this.commonService['postData'](url, req, headers).subscribe(data => {
      //response goes here
    });
  }

  getFundPriceDTOs() {
    let fundPriceDTOsObject =
      [{
        "fundCode": "",//"36",
        "fundName": "",//"Leu confortabil",
        "unitPrice": "",//"200.0000 RON",
        "unitPriceActual": null,//200,
        "sort": 1
      }];
    fundPriceDTOsObject.length = this.accountMonitoring.controls.fundPriceDTOs.value.length;
    this.accountMonitoring.controls.fundPriceDTOs.value.forEach(element => {
      fundPriceDTOsObject.forEach(data => {
        data.fundCode = element.fundCode,
          data.fundName = element.fundName,
          data.unitPrice = element.unitPriceActual,
          data.unitPriceActual = element.unitPriceActual,
          data.sort = element.sort
      })
    });
  }

  changedmin(event) {
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

}
export interface FundPriceDTO {
  minimumFundAllocation: number;
  maximumFundAllocation: number;
}