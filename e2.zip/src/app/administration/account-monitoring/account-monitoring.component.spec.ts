import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from '../../app.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { TranslateService } from '@ngx-translate/core';
import { AccountMonitoringComponent } from './account-monitoring.component';
import { AdministrationModule } from '../administration.module';

describe('AccountMonitoringComponent', () => {
  let component: AccountMonitoringComponent;
  let fixture: ComponentFixture<AccountMonitoringComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'fundPriceSubmit': host + '/api/v1/users/fundprice'
      }
    }
  };
  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, AdministrationModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(AccountMonitoringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(AccountMonitoringComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
