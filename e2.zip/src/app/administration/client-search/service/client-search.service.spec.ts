import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppModule } from 'src/app/app.module';
import { AdministrationModule } from '../../administration.module';

import { ClientSearchService } from './client-search.service';

xdescribe('ClientSearchService', () => {
  let service: ClientSearchService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, AdministrationModule, HttpClientTestingModule],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }],
    });
    service = TestBed.get(ClientSearchService);
  });

  // it('should be created', () => {
  //   const service: ClientSearchService = TestBed.get(ClientSearchService);
  //   expect(service).toBeTruthy();
  // });

  // it('should call getClientID',()=>{
  //   service.getClientID();
  // })
});
