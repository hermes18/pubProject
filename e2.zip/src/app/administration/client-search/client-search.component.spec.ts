import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientSearchComponent } from './client-search.component';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from '../../app.module';
import { AdministrationModule } from './../administration.module'
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TranslateService } from '@ngx-translate/core';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { of } from 'rxjs';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
describe('ClientSearchComponent', () => {
  let component: ClientSearchComponent;
  let fixture: ComponentFixture<ClientSearchComponent>;
  let httpCommonService: HttpCommonService;
  let menuItemsService: MenuItemsService;

  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, AdministrationModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(ClientSearchComponent);
    httpCommonService = TestBed.get(HttpCommonService);
    menuItemsService = TestBed.get(MenuItemsService);
    component = fixture.componentInstance;
    component.ClientSearchRequestDTO = {
      birthDate: null,
      customerId: "101583",
      identifierId: "",
      identifierType: "",
      lastName: "",
      requesterId: "-1",
      requesterRole: "3033",
      userId: "osamaAdmin2"
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('call customerSearch', () => {
    spyOn(component, 'customerSearch').and.callThrough();
    component.customerSearch();
    expect(component.customerSearch).toHaveBeenCalledWith();

  });
  it('call dateOnblur', () => {
    spyOn(component, 'dateOnblur').and.callThrough();
    component.dateOnblur('02/01/2000');
    expect(component.dateOnblur).toHaveBeenCalledWith('02/01/2000');

  });

  it('should call customerSearch', () => {
    component.customerSearch();
  });

  it('should call customerSearchList', () => {
    const response = {
      clientSearchDTOs: [{
        clientFirstName: "",
        clientLastName: "",
        customerId: "101583",
        dateOfBirth: "2021-04-09",
        id: "49040107229",
        idType: "PESEL",
        requesterID: null,
        requesterRole: null
      }],
      maxRecordSizeExceed: false
    };

    spyOn(httpCommonService, 'postData').and.returnValue(of(response));
    component.customerSearchList();
  });

  it('should call checkvalidity', () => {
    component.checkvalidity();
  });

  it('should call getSelectedRow', () => {
    const row = {
      clientFirstName: "",
      clientLastName: "",
      customerId: "101583",
      dateOfBirth: "2021-04-09",
      id: "49040107229",
      idType: "PESEL",
      requesterID: null,
      requesterRole: null
    };
    const test = {
      "menuItems": [{ "menuId": "1", "accessSpec": "RW", "menuName": "Account Management", "parentMenu": "Settings" }, { "menuId": "3", "accessSpec": "RW", "menuName": "Change Password", "parentMenu": "Settings" }, { "menuId": "4", "accessSpec": "RW", "menuName": "Changing the Settings", "parentMenu": "Settings" }, { "menuId": "5", "accessSpec": "RW", "menuName": "My Contract", "parentMenu": "Main Menu" }, { "menuId": "6", "accessSpec": "RW", "menuName": "My Data", "parentMenu": "Main Menu" }, { "menuId": "7", "accessSpec": "RW", "menuName": "Offer", "parentMenu": "Main Menu" }, { "menuId": "8", "accessSpec": "RW", "menuName": "Review Of Orders", "parentMenu": "Main Menu" }, { "menuId": "9", "accessSpec": "RW", "menuName": "Claims", "parentMenu": "Main Menu" }, { "menuId": "11", "accessSpec": "RW", "menuName": "Individual Contract Details", "parentMenu": "My Contract" }, { "menuId": "12", "accessSpec": "RW", "menuName": "Individual Contract Benefits", "parentMenu": "My Contract" }, { "menuId": "13", "accessSpec": "RW", "menuName": "Individual Contract Beneficiaries", "parentMenu": "My Contract" }, { "menuId": "14", "accessSpec": "RW", "menuName": "Individual Contract Financial Info", "parentMenu": "My Contract" }, { "menuId": "15", "accessSpec": "RW", "menuName": "Invest Strategy Change", "parentMenu": "My Contract" }, { "menuId": "16", "accessSpec": "RW", "menuName": "Allocation Change", "parentMenu": "My Contract" }, { "menuId": "17", "accessSpec": "RW", "menuName": "Fund Transfer", "parentMenu": "My Contract" }],
      "activeContractDetails": null,
      "billingRecipent": null,
      "callRetrievePolicies": false,
      "callRetriveClientData": false,
      "callRetriveClientOffers": false,
      "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
      "claimList": null,
      "clientAdministration": true,
      "clientId": "",
      "clientIdList": [],
      "clientIdbillControlList": [],
      "clientLoginId": null,
      "clientRoleIds": "3032|3033|3034",
      "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
      "contractList": [{
        "benefitType": "SuperKapitał",
        "businessRoleList": ["insured", "owner"],
        "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
        "contractNumber": "21223250",
        "contractNumberList": null,
        "effectiveDate": "28.11.2007",
        "indexedPremiumAmount": null,
        "insuredName": "INSURED_21223250",
        "premiumAmount": null,
        "premiumAmt": null,
        "premiumAmtType": "17",
        "premiumDueDate": null,
        "premiumPaymentMode": null,
        "premiumType": "17",
        "processingSystem": "OLAS",
        "status": 22
      }],
      "personalInformationDTO": {
        "dateOfBirth": null,
        "emailBasic": "cosmin.misici@gmail.com",
        "emailSecondary": null,
        "firstName": "COSMIN ADRIAN",
        "flagOfCapabilityOfChangeData": "true",
        "gender": null,
        "identifier": null,
        "identifierType": null,
        "lastName": "MISICI",
        "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
        "mobile": null,
        "mobilePhone": "0723347690",
        "officeFax": null,
        "policyNumber": null,
        "postalCode": null,
        "residenceFax": null,
        "residenceTelephone": "",
        "safePhone": null,
        "updatedEmailBasic": null,
        "updatedEmailSecondary": null,
        "updatedMobile": null,
        "updatedResidenceTelephone": null,
        "updatedSafePhone": null,
        "updatedmarketingConsentList": null,
        "versionMarker": "2020-12-22T12:13:17.867"
      },
      "documentsList": null,
      "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
      "fundPriceDetails": null,
      "offerResponse": null,
      "orderHistory": null,
      "renderClaims": false,
      "renderDocuments": false,
      "renderFundPriceMonitoring": false,
      "renderMyCompany": false,
      "renderMyContract": false,
      "renderMyData": false,
      "renderOffers": false,
      "renderOrderReview": false,
      "renderUserAcctAdministration": true,
      "route": "DisplayClientSearch",
      "searchFlag": false,
      "wardenRoleCheck": false
    };
    spyOn(menuItemsService, 'menuItemApi').and.returnValue(of(test));
    component.getSelectedRow(row);
  });

  it('should call toggleFieldTextType', () => {
    const row = {
      clientFirstName: "",
      clientLastName: "",
      customerId: "101583",
      dateOfBirth: "2021-04-09",
      id: "49040107229",
      idType: "PESEL",
      requesterID: null,
      requesterRole: null
    };
    component.toggleFieldTextType(row);
  });

  it('should call getpesel list', () => {
    const data = [{
      clientFirstName: "",
      clientLastName: "",
      customerId: "101583",
      dateOfBirth: "2021-04-09",
      id: "49040107229",
      idType: "PESEL",
      requesterID: null,
      requesterRole: null
    }];
    component.getPeselList(data);
  });

  it('should call changeEvent', () => {
    const event = {
      bubbles: true,
      cancelBubble: false,
      cancelable: false,
      composed: false,
      defaultPrevented: false,
      eventPhase: 2,
      isTrusted: true,
      returnValue: true,
      timeStamp: 434043.3750000084,
      type: "change"
    };
    component.changeEvent(event);
  });

  it('should call onDateBlur', () => {
    component.dateOnblur('');
  });

  it('should call onChangeIdType', () => {
    component.onChangeIdType(true);
  });

  it('should call onChange', () => {
    const test = {
      bubbles: true,
      cancelBubble: false,
      cancelable: false,
      composed: false,
      defaultPrevented: false,
      eventPhase: 2,
      isTrusted: true,
      returnValue: true,
      timeStamp: 434043.3750000084,
      type: "change"
    };
    component.onChange(test);
  })
});
