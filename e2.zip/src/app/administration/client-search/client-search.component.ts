import { Component, OnInit, ViewChild, Output, EventEmitter, ElementRef } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Validators, FormBuilder } from '@angular/forms';
import { ClientSearchService } from './service/client-search.service';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material';
import * as moment from 'moment';
import { CustomDatePickerAdapter } from '../administration.module';
import { MAT_MOMENT_DATE_FORMATS } from '@angular/material-moment-adapter';
import { filter } from 'rxjs/operators';
// import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/shared/component/date-field/date-field.component';
// import * as _moment from 'moment';

import { UtilityService } from '../../shared/utilities/utility.service';

export interface UserData {
  customerId: string;
  clientFirstName: string;
  clientLastName: string;
  idType: string;
  id: string;
}

@Component({
  selector: 'client-search',
  templateUrl: './client-search.component.html',
  styleUrls: ['./client-search.component.scss']
})
export class ClientSearchComponent implements OnInit {
  public p: number;
  displayedColumns: string[] = ['customerId', 'clientFirstName', 'clientLastName', 'idType', 'id'];
  dataSource: MatTableDataSource<UserData>;
  minDate: Date;
  maxDate: Date;
  private paginator: MatPaginator;
  private sort: MatSort;
  searchclick: boolean = false;
  clientSearchFormValide: boolean;
  goToDbMainPage: any;
  datepipe: any;

  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.dataSource)
      this.dataSource.paginator = this.paginator;
  }
  @ViewChild(MatSort, { static: false }) set matSort(mp: MatSort) {
    this.sort = mp;
    if (this.dataSource)
      this.dataSource.sort = this.sort;
  }
  settingParamValue = {
    'clientSearch': false,
    'userSearch': false,
    'userDetails': false
  }
  @Output('userAccountValue') valueChange = new EventEmitter<any>();
  lang: string;
  country: string;
  ClientSearchRequestDTO: any;
  user: any;
  SelectedUser;
  clientId;
  // clientId = 101583;
  zeroRecordFound: boolean = false;
  displayPoOption: boolean = false;
  displayRoOption: boolean = false;
  searchButtonActive: boolean = false;
  RecordsFound: boolean = false;
  isVisible: boolean = false;
  maxRecord: boolean = false;
  clientSearchFormValid: boolean = false;
  count: number;
  hideGotoDbField: boolean = false;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  showPeselFieldValue: boolean = true;
  peselIdList = [];

  // url = this.baseUrl.ecustomer.customerSearch + this.clientId;
  //url= environment.customerSearch.url;
  // url= environment.host+environment.customerSearch.url+this.clientId;
  iDTypeList = [
    {
      key: "PESEL",
      value: "PESEL"
    },
    {
      key: "NIP",
      value: "NIP"
    }
  ]
  @ViewChild('dobInput', { static: true }) dobInputRef: ElementRef;

  constructor(public fb: FormBuilder, public clientService: ClientSearchService, public commonService: HttpCommonService, public service: ClientSearchService, private readonly menuItemService: MenuItemsService,
    public sharedService: SharedServiceService, public deviceDetector: DeviceDetectorService, private dateAdapter: DateAdapter<Date>) {
    this.minDate = new Date(1900, 0, 1);
    this.maxDate = new Date(2050, 0, 1);
    // this.sharedService.getLangChange().subscribe((data) => {
    //   //("after lang change", data);
    //   this.dateAdapter.setLocale(data);
    // })
  }
  public mask = {
    guide: true,
    showMask: true,
    mask: [/\d/, /\d/, '/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/]
  };
  isMobile = this.deviceDetector.isMobile();

  ngOnInit() {
    this.specialId = false;
    this.dataChanged = false;
    this.RecordsFound = false;
    this.zeroRecordFound = false;
    this.specialId = false;
    this.InvalidDate = false;
    this.maxRecord = false;
    this.clientSearch.reset();
    this.clientSearch.controls['idType'].setValue('0');
    this.searchclick = false;
    this.hideGotoDbField = false;
    this.country = sessionStorage.getItem('countryCode');
    //("country", this.country)

    this.lang = sessionStorage.getItem('defaultLanguage');
    //("oninitlang", this.lang)
    this.dateAdapter.setLocale(this.lang);
    let loggedInCountryCheck = UtilityService.getCountry();
    // if (this.country == 'pl')
    if (loggedInCountryCheck)
      this.displayPoOption = true;
    else
      this.displayRoOption = true;
    // this.commonService['getData'](this.baseUrl.ecustomer.goToDbMainPage).subscribe(data => {
    //  this.goToDbMainPage =  data.ccdbFullAddress; 
    // })
    this.sharedService.getDetail('menuItemList').subscribe((data) => {
      if (data) {
        this.goToDbMainPage = data.ccDBAddressDTO.ccdbFullAddress;
      }
    })
    let loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    if (loggedInUserDetail.roleInfo.length == 1 && loggedInUserDetail.roleInfo[0].name === 'rAdvisor') {
      this.customerSearch();
      this.hideGotoDbField = true;
    }
  
  if(this.country==='gr'){
    this.iDTypeList = [
      {
        key: "TaxID",
        value: "taxid"
      },
      {
        key: "Email",
        value: "email"
      }
    ]
  }
  }
  openSite(siteUrl) {
    window.open("//" + siteUrl, '_blank');
  }
  onChangeIdType(event) {
    this.searchclick = false;
  }

  ngAfterViewInit() {

    this.sharedService.getLangChange().subscribe((data) => {

      const lang = sessionStorage.getItem("defaultLanguage");
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_gr': 'el',
        'gr_en': 'en',
        'gr': 'el'
      }
      //("after lang change", data);
      const language = data ? data === 'gr' ? dateTranslate[lang] : data : dateTranslate[lang];

      this.dateAdapter.setLocale(language);
      // this.clientSearch.controls['lastName'].setValue(this.resetDate);
      // this.clientSearch.get('dateOfBirth').value.reset();
      // console.log("1111",this.clientSearch.get('dateOfBirth').value);
      // console.log("reset", this.resetDate)
      //this.clientSearch.controls['dateOfBirth'].setValue(this.resetDate);
      //this.clientSearch.controls['dateOfBirth'].setValue("10/23/1212");
      setTimeout(() => {
        if (this.invalidDateStore && this.invalidDateStore != '') {
          this.dobInputRef.nativeElement.value = this.invalidDateStore;
        }
        // console.log("2222222222222222222222",this.dobInputRef.nativeElement.value) 
      }, 1000);
      // if(this.invalidDateStore && this.invalidDateStore!=''){
      //   this.dobInputRef.nativeElement.value = this.invalidDateStore;
      // }



    })

  }
  resetDate: any = '';
  invalidDateStore: any = '';
  dateOnblur(val) {
    // this.resetDate = (this.clientSearch.value.dateOfBirth ? new Date(this.clientSearch.value.dateOfBirth).toLocaleDateString() : null),
    // this.resetDate = (val ? new Date(val) : null);
    this.resetDate = val;
    // console.log(this.resetDate)
    this.invalidDateStore = '';
    if (this.clientSearch.get('dateOfBirth').value) {

    } else {
      this.invalidDateStore = val;
    }


    //(val, "hell");
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  // submit():void{
  //   this.customerSearch();
  // }

  clientSearch = this.fb.group({
    idType: null,
    id: null,
    lastName: null,
    dateOfBirth: '',
    customerId: null,
    policyNumber:null
    //customerId: [null, Validators.pattern("^[0-9]*$")],

  });
  InvalidDate: boolean = false;
  specialId: boolean = false;
  specialSearchAlert: boolean = false;
  invalidSearch: boolean = false;
  successfulValidation: boolean = false;
  Dob
  dataChanged: boolean = false;
  onChange(event: any) {
    // console.log("event", event.value);
    this.invalidDateStore = null;
    this.dataChanged = true;
  }
  headers = new HttpHeaders();
  customerSearch() {
    this.showPeselFieldValue = true;
    this.InvalidDate = false;
    this.RecordsFound = false;
    this.searchclick = true;
    this.zeroRecordFound = false;
    this.maxRecord = false;
    this.specialId = false;
    this.specialSearchAlert = false;
    const customerId = this.clientSearch.value.customerId,
      loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
      userrole = this.menuItemService.getAllRoles();
    //(userrole);
    //this.clientId = this.clientService.getClientID(loggedInUserDetail, customerId, userrole);

    // }

    if (loggedInUserDetail.roleInfo.length == 1 && loggedInUserDetail.roleInfo[0].name === 'rAdvisor') {
      if (this.clientSearch.value.lastName != null || this.clientSearch.value.lastName != '') {
        this.clientSearch.get('lastName').setValue('*')
      }
    }
    // //(this.clientSearch.value.dateOfBirth)

    this.Dob = moment(this.clientSearch.value.dateOfBirth)
    //(this.Dob)

    //(this.dataChanged)
    if (this.invalidDateStore != null &&
      this.invalidDateStore != '' &&
      this.dataChanged && !this.Dob.isValid()) {
      this.InvalidDate = true;
      this.dataChanged = true;
      this.clientSearchFormValid = false;
      //("invalid")
      //  this.clientSearch.invalid
      window.scrollTo(0, 0);
    } else {
      this.clientSearchFormValid = true;
      this.InvalidDate = false;
      this.dataChanged = false;
      //("vvvvvalid")
      // this.date=new Date();


      //  let DateFormat =this.datepipe.transform(this.Dob, 'dd/MM/yyyy');
      // console.log( this.Dob.format("DD/MM/YYYY"))
      this.ClientSearchRequestDTO = {
        identifierType: (this.clientSearch.value.idType !== '0' ? (this.clientSearch.value.idType).trim() : ''),
        identifierId: (this.clientSearch.value.id ? (this.clientSearch.value.id).trim() : ''),
        lastName: (this.clientSearch.value.lastName ? (this.clientSearch.value.lastName).trim() : ''),
        // birthDate: (this.clientSearch.value.dateOfBirth ? new Date(this.clientSearch.value.dateOfBirth).toLocaleDateString() : null),
        // birthDate: (this.clientSearch.value.dateOfBirth ? new Date(this.clientSearch.value.dateOfBirth). : null),
        birthDate: (this.clientSearch.value.dateOfBirth ? this.Dob.format("DD/MM/YYYY") : null),
        customerId: (this.clientSearch.value.customerId ? (this.clientSearch.value.customerId).trim() : ''),
        requesterId: loggedInUserDetail ? loggedInUserDetail.requesterId : '',
        requesterRole: loggedInUserDetail ? loggedInUserDetail.requesterRole : '',
        userId: loggedInUserDetail ? loggedInUserDetail.userName : '',
        policyNumber:(this.clientSearch.value.policyNumber ? (this.clientSearch.value.policyNumber).trim() : '')
      }
      this.Dob = moment(this.clientSearch.value.dateOfBirth)

      if (((this.ClientSearchRequestDTO.identifierType != '' && this.ClientSearchRequestDTO.identifierId != '') ||
        this.ClientSearchRequestDTO.lastName || (this.ClientSearchRequestDTO.birthDate != null) ||
        this.ClientSearchRequestDTO.customerId) && this.clientSearch.valid) {
        //("valid")
        this.clientSearchFormValid = true;
      }
      else {
        this.clientSearchFormValid = false;
        window.scrollTo(0, 0);
      }
      //(this.Dob)
      if ((this.ClientSearchRequestDTO.identifierType !== '' && this.ClientSearchRequestDTO.identifierId == '') ||
        (this.ClientSearchRequestDTO.identifierType == '' && this.ClientSearchRequestDTO.identifierId != '')) {
        this.specialId = true;
        this.clientSearchFormValid = false;
        window.scrollTo(0, 0);
      } else {
        this.specialId = false;
        this.clientSearchFormValid = true;
      }

      if ((this.specialId && (this.ClientSearchRequestDTO.customerId != null)) || (this.specialId && (this.ClientSearchRequestDTO.lastName != null)) ||
        (this.specialId && (this.Dob.isValid()))) {
        //(this.specialId, this.Dob.isValid())
        // this.specialId = true;
        this.clientSearchFormValid = false;
        window.scrollTo(0, 0);
      }
      else {
        this.specialId = false;
        this.clientSearchFormValid = true;
      }



      //(this.clientSearchFormValid)
      if (this.clientSearchFormValid)
        this.customerSearchList();
    }

  }

  getPeselList(data) {
    data.forEach((item, index) => {
      // const idList = index;
      this.peselIdList.push({ 'id': item.id, 'showPesel': true });
      // console.log(this.peselIdList);

    });
  }
  customerSearchList() {
    // this.dataChanged = false;
    const url = this.baseUrl.ecustomer.customerSearch;
    this.RecordsFound = false;
    //(this.ClientSearchRequestDTO);
    let clientId = this.ClientSearchRequestDTO.customerId ? this.ClientSearchRequestDTO.customerId : null;

    //(url)
    this.commonService['postData'](url, this.ClientSearchRequestDTO, this.headers).subscribe(data => {
      // this.commonService[environment.customerSearch.method](this.url).subscribe(data=>{
      this.dataSource = new MatTableDataSource<UserData>();
      this.paginator = null;
      this.sort = null;
      this.user = data;
      //('client', this.user)
      this.SelectedUser = this.user.clientSearchDTOs;
      this.peselIdList = [];
      this.getPeselList(this.SelectedUser)
      //this.SelectedUser=this.user.ClientSearchResponseDTO.clientSearchDTOs[0].clientSearchDTOs;
      this.dataSource = new MatTableDataSource(this.user.clientSearchDTOs);

      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      if (this.user.maxRecordSizeExceed == true) {
        this.maxRecord = true;
      }
      else {
        this.maxRecord = false;
      }
      // setTimeout(() => {
      //   this.maxRecord = false;
      // }, 4000);

      this.count = this.user.clientSearchDTOs.length;
      if (this.count > 0) {
        this.RecordsFound = true;
      } else {
        this.zeroRecordFound = true;
        window.scrollTo(0, 0);
      }

    })
    this.specialId = false;
    this.searchclick = false;
    // this.dataChanged = false;

  }
  checkvalidity() {

    if (this.searchclick) {

      this.searchclick = false;

    }
  }

  getSelectedRow(row) {
    //("clientId",row);
    const customerSearch = {
      clientID: row.customerId,
      // clientId:row,
      opeType: 'search'
    }
    sessionStorage.setItem('searcClientID', JSON.stringify(customerSearch));
    sessionStorage.setItem('searchedClientDetails', JSON.stringify(row));

    this.menuItemService.menuItemApi(row.customerId, 'search').subscribe((data) => {
      sessionStorage.setItem('menuListFromClientSearch', JSON.stringify(data));
      this.sharedService.setDetail('menuItemList', data);
      this.menuItemService.navigationBasedOnRole(data);
    });
  }

  changeEvent(event) {
    //(event)
  }

  toggleFieldTextType(row) {
    this.peselIdList.filter((currentValue, index, arr) => {
      if (row.id === currentValue.id) {
        currentValue.showPesel = !currentValue.showPesel;
      }
    });

    //this.showPeselFieldValue = !this.showPeselFieldValue;
  }
}

// if ((this.clientSearch.value.idType !== '0' && this.clientSearch.value.id == null) || (this.clientSearch.value.idType == '0' && this.clientSearch.value.id != null)) {
//   this.specialId = true;
//   this.clientSearchFormValid = false;
// } else {
//   this.specialId = false;
// }

// if ((this.specialId && (this.clientSearch.value.customerId != null)) || (this.specialId && (this.clientSearch.value.lastName != null)) ||
//   (this.specialId && (this.Dob.isValid()))) {
//   //(this.specialId, this.Dob.isValid())
//   this.specialSearchAlert = true;
//   this.clientSearchFormValid = false;
//   //("1", this.clientSearchFormValid)
// }
// else {
//   this.specialSearchAlert = false;
//   this.clientSearchFormValid = false;
// }

// if (((this.clientSearch.value.idType !== '0' && this.clientSearch.value.id != null) ||
//   this.clientSearch.value.lastName || (this.Dob.isValid() != false) ||
//   this.clientSearch.value.customerId) && this.clientSearch.valid) {
//   //("valid")
//   this.clientSearchFormValid = true;
//   //("2", this.clientSearchFormValid, this.Dob.isValid())
// }
// else {
//   this.specialSearchAlert = false;
//   this.clientSearchFormValid = false;
// }
// }

// //("3", this.clientSearchFormValid)

// if (this.clientSearchFormValid) {



// this.ClientSearchRequestDTO = {
//   identifierType: (this.clientSearch.value.idType !== '0' ? (this.clientSearch.value.idType).trim() : ''),
//   identifierId: (this.clientSearch.value.id ? (this.clientSearch.value.id).trim() : ''),
//   lastName: (this.clientSearch.value.lastName ? (this.clientSearch.value.lastName).trim() : ''),
//   // birthDate: this.clientSearch.value.dateOfBirth,
//   birthDate: (this.clientSearch.value.dateOfBirth ? new Date(this.clientSearch.value.dateOfBirth).toLocaleDateString() : null),
//   // birthDate: new Date(this.clientSearch.value.dateOfBirth).toLocaleDateString(),
//   // birthDate:this.clientSearch.value.dateOfBirth.toLocaleDateString(),
//   // birthDate: (this.clientSearch.value.dateOfBirth?(moment(this.clientSearch.value.dateOfBirth).utcOffset('+0000').format('DD/MM/YYYY')):''),
//   customerId: (this.clientSearch.value.customerId ? (this.clientSearch.value.customerId).trim() : ''),
//   requesterId: loggedInUserDetail ? loggedInUserDetail.requesterId : '',
//   requesterRole: loggedInUserDetail ? loggedInUserDetail.requesterRole : '',
//   userId: loggedInUserDetail ? loggedInUserDetail.userName : ''
// }
// // 

// this.customerSearchList();
// }
// //

// }
