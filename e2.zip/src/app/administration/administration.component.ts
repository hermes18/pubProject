import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { UserSearchComponent } from './user-search/user-search.component';
import { ClientSearchComponent } from './client-search/client-search.component';
import { NewaccountErrorComponent } from './newaccount-error/newaccount-error.component';
import { SharedServiceService } from '../shared-service/shared-service.service';
import * as utils from 'lodash';
import { NavigationEnd, Router, RouterEvent } from '@angular/router';
import { filter } from 'rxjs/operators';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { DateAdapter } from '@angular/material';

@Component({
  selector: 'administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.scss']
})
export class AdministrationComponent implements OnInit {
  @ViewChild(UserSearchComponent, { static: false }) userSearchComp: UserSearchComponent;
  @ViewChild(ClientSearchComponent, { static: false }) clientSearchComp: ClientSearchComponent;
  @ViewChild('matGroupRef', { static: false }) matGroupRef;


  navLinks;
  settingParamValue = {
    'clientSearch': false,
    'userSearch': false,
    'userDetails': false,
    'newaccountError': false,
    'ordersReport': false,
    'uId': '',
    'customerId': '',
    //  'accountMonitoring': false
  }
  currentItem: any;
  customerId;
  adminTabList = {
    'userTab': false,
    'customerTab': false,
    'orderReport': false,
    'newAccountErrorTab': false
  };

  matSelectedTabIndex = 0;
  isSetLocale: boolean = false;
  settingTabIndex;
  constructor(public commonService: SharedServiceService, private cdRef: ChangeDetectorRef,
    private menuItemService: MenuItemsService, public router: Router, private dateAdapter: DateAdapter<Date>) { }


  ngOnInit() {
    // this.sharedServiceService.setDetail('breadCrumbList', 'userDetail')


    this.commonService.getLangChange().subscribe((data) => {
      const lang = sessionStorage.getItem("defaultLanguage");
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_en': 'en',
        'gr_gr': 'el'
      }
      //("after lang change", data);
      const language = data ? data : dateTranslate[lang];
      this.dateAdapter.setLocale(language);
      //this.cdRef.detectChanges();
    });


    this.router.events.pipe(filter((event: RouterEvent) => event instanceof NavigationEnd)
    ).subscribe(() => {
      //(this.router)
      //(JSON.parse(sessionStorage.getItem('activeTabInAdminBackButton')));
      const backFromSearchScreen = JSON.parse(sessionStorage.getItem('activeTabInAdminBackButton'));
      // to make the user seach component display when navigate form other route
      if (backFromSearchScreen) {
        this.settingParamValue.userSearch = backFromSearchScreen.userSearch;
        this.settingParamValue.newaccountError = true;
        this.settingParamValue.userDetails = backFromSearchScreen.userDetails;

      } else {
        this.settingParamValue.userSearch = true;
        this.matSelectedTabIndex = 0;
        if (this.adminTabList.customerTab && this.clientSearchComp) {
          this.clientSearchComp.ngOnInit();
        }
        if (this.adminTabList.userTab && this.userSearchComp) {
          this.userSearchComp.ngOnInit();
        }
      }

    });
    this.commonService.getDetail('menuItemList').subscribe((list) => {
      const data = JSON.parse(sessionStorage.getItem('menuItemList'));
      if (data) {
        const menuListInAdminn = utils.filter(data.menuItems, obj => {
          if (obj.parentMenu && obj.parentMenu == "Administration") return obj;
        });
        menuListInAdminn.forEach(menu => {
          if (menu.menuName === "Users") {
            this.adminTabList.userTab = true;
          }
          if (menu.menuName === 'Customers')
            this.adminTabList.customerTab = true;
          if (menu.menuName === 'Orders Report')
            this.adminTabList.orderReport = true;

          if (menu.menuName === 'New Account Errors')
            this.adminTabList.newAccountErrorTab = true;
        });
      }
    });
    this.settingParamValue.clientSearch = true;
    this.settingParamValue.userSearch = false;
    this.settingParamValue.userDetails = false;
    this.settingParamValue.ordersReport = false;
    this.settingParamValue.newaccountError = false;
    //this.settingParamValue.accountMonitoring = false;
  }
  onTabClick() {
    ////("matSelectedTabIndex",this.matSelectedTabIndex);
    this.router.navigate(['administartion']);
    //this.ngOnInit();
    this.onTabChanged('');

  }
  calenderLang() {
    this.isSetLocale = false;

  }

  // ngAfterViewInit() {
  //   //('afer', this.matGroupRef._selectedIndex,
  //     this.matGroupRef._tabs._results[this.matGroupRef._selectedIndex].textLabel);
  //   this.onTabChanged(this.matGroupRef._tabs._results[this.matGroupRef._selectedIndex].textLabel)
  // }

  displayArray(theArray) {
    this.settingParamValue.clientSearch = theArray.clientSearch;
    this.settingParamValue.userSearch = theArray.userSearch;
    this.settingParamValue.userDetails = theArray.userDetails;
    this.settingParamValue.ordersReport = theArray.ordersReport;
    this.settingParamValue.newaccountError = theArray.newaccountError;
    this.settingParamValue.uId = theArray.uId;
    this.settingParamValue.customerId = theArray.customerId;
    this.currentItem = theArray.uId;
    this.customerId = theArray.customerId;
    // this.settingParamValue.accountMonitoring = theArray.accountMonitoring;
    //("setting component", this.settingParamValue)
  }

  onTabChanged(ev) {
    this.settingParamValue.clientSearch = true;
    this.settingParamValue.userSearch = true;
    this.settingParamValue.userDetails = false;
    this.settingParamValue.ordersReport = true;
    this.settingParamValue.newaccountError = true;
    ev ? this.isSetLocale = true : '';

    const activeTab = {
      userSearch: this.settingParamValue.userSearch
      //  userDetails: this.settingParamValue.userDetails
    }
    sessionStorage.setItem('activeTabInAdminBackButton', JSON.stringify(activeTab));
    this.router.navigate(['administartion']);
    // this.settingTabIndex = ev;
    // this.settingParamValue.accountMonitoring = true;
    if (this.userSearchComp)
      this.userSearchComp.ngOnInit();
    if (this.clientSearchComp)
      this.clientSearchComp.ngOnInit();

    // this.navigateToChildTab(ev.tab.textLabel);
  }

  // navigateToChildTab(textLabel) {
  //   if (textLabel === 'Users') {
  //     this.router.navigate(['administartion/userSearch']);
  //   }
  //   if (textLabel == 'Customers') {
  //     this.router.navigate(['administartion'])
  //   }
  //}
  gotoHome() {
    this.settingParamValue.clientSearch = true;
    this.settingParamValue.userSearch = false;
    this.settingParamValue.userDetails = false;
    this.settingParamValue.ordersReport = false;
    this.settingParamValue.newaccountError = false;
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    sessionStorage.setItem('activeTabInAdminBackButton', null);
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }



  navigatetoAdminTab() {
    sessionStorage.setItem('activeTabInAdminBackButton', null);
    this.router.navigate(['/administartion']);
  }

  orderReportTabClick() {
    this.settingParamValue.ordersReport = false;
    setTimeout(() => {
      this.settingParamValue.ordersReport = true;
    })
  }
}
