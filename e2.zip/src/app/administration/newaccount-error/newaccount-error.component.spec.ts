import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { AppConfig } from 'src/config/app.config';
import { AdministrationModule } from '../administration.module';

import { NewaccountErrorComponent } from './newaccount-error.component';

describe('NewaccountErrorComponent', () => {
  let component: NewaccountErrorComponent;
  let fixture: ComponentFixture<NewaccountErrorComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'newAccountError': host + '/api/v1/users/error-info'
      }
    }
  };
  let appConfig: AppConfig = AppConfig.getConfig();
  let globalObjectService: jasmine.SpyObj<AppConfig>;


  beforeEach(() => {
    globalObjectService = jasmine.createSpyObj('AppConfig', ['getConfig']);
    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, AdministrationModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(NewaccountErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(NewaccountErrorComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('call displayinfo', () => {
    spyOn(component, 'displayinfo').and.callThrough();
    component.displayinfo();
    expect(component.displayinfo).toHaveBeenCalledWith();

  });
});
