import { APP_BASE_HREF } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppModule } from 'src/app/app.module';

import { NewAccountErrorService } from './new-account-error.service';

xdescribe('NewAccountErrorService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [RouterTestingModule, AppModule],
    providers: [NewAccountErrorService, { provide: APP_BASE_HREF, useValue: '/' }],
  }));

  it('should be created', () => {
    const service: NewAccountErrorService = TestBed.get(NewAccountErrorService);
    expect(service).toBeTruthy();
  });
});
