import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { environment } from 'src/environments/environment';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';


@Component({
  selector: 'newaccount-error',
  templateUrl: './newaccount-error.component.html',
  styleUrls: ['./newaccount-error.component.scss']
})
export class NewaccountErrorComponent implements OnInit {
  p: number;
  displayedColumns: string[] = ['logDate', 'logMessage'];
  dataSource: MatTableDataSource<NewAccountError>;

  private paginator: MatPaginator;
  private sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.dataSource)
      this.dataSource.paginator = this.paginator;
  }
  @ViewChild(MatSort, { static: false }) set matSort(mp: MatSort) {
    this.sort = mp;
    if (this.dataSource)
      this.dataSource.sort = this.sort;
  }
  // @ViewChild('tooltip', { static: false }) tooltip;
  // @ViewChild('tooltip1', { static: false }) tooltip1;
  // @ViewChild('tooltip2', { static: false }) tooltip2;
  // @ViewChild('tooltip3', { static: false }) tooltip3;

  //@HostListener('window:scroll', ['$event'])
  // scrollHandler(event) {
  //   this.tooltip ? this.tooltip.hide() : '';
  //   this.tooltip1 ? this.tooltip1.hide() : '';
  //   this.tooltip2 ? this.tooltip2.hide() : '';
  //   this.tooltip3 ? this.tooltip3.hide() : '';
  // }

  users = [];
  showTable
  displayErrorDetails: boolean = false;
  maxRecord: boolean = false;
  // url = environment.newAccountError.testurl;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  url = this.baseUrl.ecustomer.newAccountError;
  constructor(public commonService: HttpCommonService) { }

  screenRequestObj: any;
  headers = new HttpHeaders();

  count: any;
  ngOnInit() {
    this.showTable = true;
    let requestObj = new ReqModel();

    requestObj.logType = "FIRST_LOGIN_FAILURE";

    //(this.url)
    this.commonService['postData'](this.url, requestObj, this.headers).subscribe(data => {
      if (data) {
        this.dataSource = new MatTableDataSource<NewAccountError>();
        this.paginator = null;
        this.sort = null;
        this.users = data;
        this.showTable = true;

        this.dataSource = new MatTableDataSource(this.users);

        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.sort.disableClear = true;
        this.count = this.dataSource.data.length;
       
        // console.log(this.count)
      }
      else {
        this.showTable = false;
      }
      // data.forEach(element => {
      //   element.openTooltipMessage = null;
      // })
      // this.users = data;

      // //(this.users.length)
      // if(this.users.maxRecordSizeExceed == true){
      //     this.maxRecord = true;
      //   }
      //   else{
      //   this.maxRecord=false;
      // }
      // setTimeout(() => {
      //   this.maxRecord = false;
      // }, 4000);
    });
  }
  displayinfo() {
    if (!this.displayErrorDetails) {
      this.displayErrorDetails = true;
      this.users.forEach(element => {
        element.openTooltipMessage = true;
      })
    } else {
      this.displayErrorDetails = false;
      this.users.forEach(element => {
        element.openTooltipMessage = false;
      })
    }

  }
  closeinfo() {
    this.displayErrorDetails = false
  }

}
export class ReqModel {

  id: string = null;
  usersLogin: string = null;
  usersAccountID: string = null;
  systemType: string = null;
  processName: string = null;
  logId: string = null;
  logDate: string = null;
  logMessage: string = null;
  request: string = null;
  clientId: string = null;
  logType: string = null;

}
export class NewAccountError {
  logDate: string = null;
  logMessage: string = null;
}