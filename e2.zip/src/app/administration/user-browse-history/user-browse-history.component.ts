import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DateAdapter, MatPaginator, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { HistoryData } from 'src/app/contract-details/fund-history/fund-history.component';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UserBrowseHistory } from './model/user-browser-history.model';
import { UserBrowseHistoryService } from './service/user-browse-history.service';
import { StylePaginatorDirective } from 'src/app/shared/directives/style-paginator.directive';
@Component({
  selector: 'user-browse-history',
  templateUrl: './user-browse-history.component.html',
  styleUrls: ['./user-browse-history.component.scss'],
  providers: [UserBrowseHistoryService]
})
export class UserBrowseHistoryComponent implements OnInit {
  userAccountHistoryModel: UserBrowseHistory;
  numberOfDaysToAdd = 30;
  private paginator: MatPaginator;

  constructor(private readonly formBuilder: FormBuilder, public deviceDetector: DeviceDetectorService, private menuItemService: MenuItemsService, private router: Router, public sharedService: SharedServiceService, private dateAdapter: DateAdapter<Date>,
    private readonly userHistoryService: UserBrowseHistoryService) {
    this.userAccountHistoryModel = new UserBrowseHistory();
  }
  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.userAccountHistoryModel.userHistoryList)
      this.userAccountHistoryModel.userHistoryList.paginator = this.paginator;
    if (this.directive) {
      this.directive.ngAfterViewInit();
    }
  }
  @ViewChild(StylePaginatorDirective, { static: false }) directive: StylePaginatorDirective;


  selectedProcessName;
  selectedLogType;
  searchClientID;
  defaultLanguage: string;
  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.searchClientID = JSON.parse(sessionStorage.getItem('userDetailResponse'));
    this.userAccountHistoryModel.userAccountHistory = this.formBuilder.group({
      processName: ['', Validators.required],
      processStatus: ['', Validators.required],
      fromDateRange: '',
      toDateRange: new Date()
    });
    this.sharedService.getLangChange().subscribe((data) => {
      this.defaultLanguage = sessionStorage.getItem("defaultLanguage");

    });

    this.setDateValue();
    this.selectedProcessName = this.userAccountHistoryModel.processNameList[0].value;
    this.selectedLogType = this.userAccountHistoryModel.processStatus[0].key;

    this.userAccountHistoryModel.userAccountHistory.patchValue({
      processName: this.selectedProcessName,
      processStatus: this.selectedLogType
    })
    const fromDateRange = moment(this.userAccountHistoryModel.userAccountHistory.value.fromDateRange).format("DD-MM-YYYY"),
      toDateRange = moment(this.userAccountHistoryModel.userAccountHistory.value.toDateRange).format("DD-MM-YYYY"),
      loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));

    const requestParam = {
      "toDate": toDateRange,
      "fromDate": fromDateRange,
      "processName": this.selectedProcessName,
      "userLogin": this.searchClientID ? this.searchClientID.userName : '',
      "logType": this.selectedLogType
    }

    this.historyApiCall(requestParam);
  }

  goToPreviousPeriod() {
    let numberOfDaysToAdd = 31;
    const currentFromDate = this.userAccountHistoryModel.userAccountHistory.controls.fromDateRange.value,
      currentToDate = this.userAccountHistoryModel.userAccountHistory.controls.toDateRange.value,
      fromDate = moment(currentFromDate),
      toDate = moment(currentToDate);
    numberOfDaysToAdd = toDate.diff(fromDate, 'days') + 1;
    // fromDateRange = new Date(currentFromDate.setMonth(currentFromDate.getMonth() - 1)),
    // toDateRange = new Date(currentToDate.setMonth(currentToDate.getMonth() - 1));
    let fromDateRange = currentFromDate._d ?
      new Date(currentFromDate._d.setDate(currentFromDate._d.getDate() - numberOfDaysToAdd)) :
      new Date(currentFromDate.setDate(currentFromDate.getDate() - numberOfDaysToAdd)),
      toDateRange = currentToDate._d ?
        new Date(currentToDate._d.setDate(currentToDate._d.getDate() - numberOfDaysToAdd)) :
        new Date(currentToDate.setDate(currentToDate.getDate() - numberOfDaysToAdd));
    // const yearDateFromat = currentFromDate.toLocaleDateString().split('/')[2] + '-' + currentFromDate.toLocaleDateString().split('/')[1];
    // const daysInAMonth = moment(yearDateFromat, "YYYY-MM").daysInMonth();
    // //(daysInAMonth)
    this.userAccountHistoryModel.userAccountHistory.patchValue({
      fromDateRange: fromDateRange,
      toDateRange: toDateRange
    })

  }

  goToNextPeriod() {
    let numberOfDaysToAdd = 31;
    const currentFromDate = this.userAccountHistoryModel.userAccountHistory.controls.fromDateRange.value,
      currentToDate = this.userAccountHistoryModel.userAccountHistory.controls.toDateRange.value;
    let fromDate = moment(currentFromDate),
      toDate = moment(currentToDate);
    numberOfDaysToAdd = toDate.diff(fromDate, 'days') + 1;
    // fromDateRange = new Date(currentFromDate.setMonth(currentFromDate.getMonth() + 1)),
    // toDateRange = new Date(currentToDate.setMonth(currentToDate.getMonth() + 1))
    let fromDateRange = currentFromDate._d ?
      new Date(currentFromDate._d.setDate(currentFromDate._d.getDate() + numberOfDaysToAdd)) :
      new Date(currentFromDate.setDate(currentFromDate.getDate() + numberOfDaysToAdd)),
      toDateRange = currentToDate._d ?
        new Date(currentToDate._d.setDate(currentToDate._d.getDate() + numberOfDaysToAdd)) :
        new Date(currentToDate.setDate(currentToDate.getDate() + numberOfDaysToAdd));
    this.userAccountHistoryModel.userAccountHistory.patchValue({
      fromDateRange: fromDateRange,
      toDateRange: toDateRange
    })

  }
  ngAfterViewInit() {
    this.sharedService.getLangChange().subscribe((data) => {
      const lang = sessionStorage.getItem("defaultLanguage");
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_gr': 'el',
        'gr_en': 'en',
        'gr': 'el'
      }
      //("after lang change", data);
      const language = data ? data === 'gr' ? dateTranslate[lang] : data : dateTranslate[lang];
      this.dateAdapter.setLocale(language);
    })

  }

  setDateValue() {
    let toDateRange = new Date();
    //    const fromDateRange = new Date(toDateRange.setMonth(toDateRange.getMonth() - 1));
    const fromDateRange = new Date(toDateRange.setDate(toDateRange.getDate() - this.numberOfDaysToAdd));
    this.userAccountHistoryModel.userAccountHistory.patchValue({
      fromDateRange: fromDateRange
    })


  }

  searchHistory() {
    this.userAccountHistoryModel.isSubmitclicked = false;
    const fromDateRange = moment(this.userAccountHistoryModel.userAccountHistory.value.fromDateRange).format("DD-MM-YYYY"),
      toDateRange = moment(this.userAccountHistoryModel.userAccountHistory.value.toDateRange).format("DD-MM-YYYY"),
      loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));

    const requestParam = {
      "toDate": toDateRange,
      "fromDate": fromDateRange,
      "logType": this.userAccountHistoryModel.userAccountHistory.value.processStatus,
      "processName": this.userAccountHistoryModel.userAccountHistory.value.processName,
      "userLogin": this.searchClientID ? this.searchClientID.userName : '',
    }
    //(this.userAccountHistoryModel.userAccountHistory.value)
    const diffInDays = this.getDateValidation(fromDateRange, toDateRange);
    if (new Date(this.userAccountHistoryModel.userAccountHistory.value.fromDateRange).getTime() <
      new Date(this.userAccountHistoryModel.userAccountHistory.value.toDateRange).getTime()) {
      if (diffInDays > 365) {
        this.userAccountHistoryModel.userHistoryList = new MatTableDataSource([]);
        this.userAccountHistoryModel.userAccountHistory.controls.fromDateRange.setErrors({ 'dateExceed365': true });
      } else {
        this.userAccountHistoryModel.userAccountHistory.controls.fromDateRange.setErrors({ 'dateExceed365': false });
        this.historyApiCall(requestParam);
      }
    } else {
      this.userAccountHistoryModel.userHistoryList = new MatTableDataSource([]);
      this.userAccountHistoryModel.userAccountHistory.controls.fromDateRange.setErrors({ 'formDateIsGreater': true });
    }
  }

  getDateValidation(fromDate, toDate) {
    //     const date1 = new Date('7/13/2010');
    // const date2 = new Date('12/15/2010');
    // const diffTime = Math.abs(toDate - fromDate);
    // const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    // const dateFormat = "YYYY-MM-DD",
    //   fromDateFormat = moment(fromDate).format(dateFormat),
    //   toDateFormat = moment(toDate).format(dateFormat);

    const fromDateRange = moment(this.userAccountHistoryModel.userAccountHistory.value.fromDateRange),
      toDateRange = moment(this.userAccountHistoryModel.userAccountHistory.value.toDateRange);
    const diffDays = Math.abs(fromDateRange.diff(toDateRange, 'days'));

    return diffDays;

  }


  historyApiCall(requestParam) {
    this.userHistoryService.getUserHistory(requestParam).subscribe((data) => {
      //(data);
      this.getHistoryData(data);
    })
  }

  getHistoryData(data) {
    const userHistoryRecord = [];
    this.userAccountHistoryModel.historyListResponse = data;
    if (data.length > 0) {
      data.forEach(element => {
        userHistoryRecord.push({
          processName: element.processName,
          logType: element.logType,
          logDate: element.logDate,
          logMessage: element.logMessage,
          logDateFromat: element.logDate ? element.logDate.split(' ')[0] : '',
          logTime: element.logDate ? element.logDate.split(' ')[1] : ''

        })

      });
      this.paginator = null;
      this.userAccountHistoryModel.userHistoryList = new MatTableDataSource(userHistoryRecord);
      //(this.userAccountHistoryModel.userHistoryList)
      this.userAccountHistoryModel.userHistoryList.paginator = this.paginator;

    } else {
      this.userAccountHistoryModel.isSubmitclicked = true;
      this.userAccountHistoryModel.userHistoryList = new MatTableDataSource(userHistoryRecord);

    }
  }
  navigateToUserTab() {
    const activeTab = {
      userSearch: true,
      userDetails: false
    }
    sessionStorage.setItem('activeTabInAdminBackButton', JSON.stringify(activeTab));
    this.router.navigate(['administartion']);

  }

  applyFailure(row) {
    if (row.logType !== null) {
      if (row.logType.indexOf("FAILURE") > -1 || row.logType.indexOf('ERROR') > -1) {
        return 'historyTable';
      }
    }
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    sessionStorage.setItem('activeTabInAdminBackButton', null);
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

}
