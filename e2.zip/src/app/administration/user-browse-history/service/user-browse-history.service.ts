import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';

import { HttpCommonService } from '../../../shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
@Injectable()


export class UserBrowseHistoryService {

  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(private cService: HttpCommonService) { }

  getUserHistory(reqParam) {
    return this.cService['postData'](this.baseUrl.ecustomer.brosweHistory, reqParam, '');
  }
}
