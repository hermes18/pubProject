import { APP_BASE_HREF } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppModule } from 'src/app/app.module';
import { AdministrationModule } from '../../administration.module';

import { UserBrowseHistoryService } from './user-browse-history.service';

describe('UserBrowseHistoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [RouterTestingModule, AppModule, AdministrationModule],
    providers: [UserBrowseHistoryService, { provide: APP_BASE_HREF, useValue: '/' }],
  }));

  it('should be created', () => {
    const service: UserBrowseHistoryService = TestBed.get(UserBrowseHistoryService);
    expect(service).toBeTruthy();
  });
});
