import { FormGroup } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';


export class UserBrowseHistory {
    userAccountHistory: FormGroup;
    subscribeFlag: boolean;
    processNameList: Array<any>;
    processStatus: Array<any>;
    columnList: string[];
    userHistoryList: MatTableDataSource<any>;
    historyListResponse: any;
    isSubmitclicked: boolean;
    constructor() {
        this.subscribeFlag = true;
        this.isSubmitclicked = false;
        this.columnList = ['processName', 'logType', 'logDate', 'logMessage'];
        this.processNameList = [{
            key: 'ALL', value: 'ALL'
        },
        { key: "CREATE_ACCOUNT", value: "CREATE ACCOUNT" },
        { key: "RESET_PASSWORD", value: "RESET PASSWORD" },
        { key: "LOGIN", value: "LOGIN" },
        { key: "LOGOUT", value: "LOGOUT" },
        { key: "CHANGE_PASSWORD", value: "CHANGE_PASSWORD" },
        { key: "ACCOUNT_DATA", value: "ACCOUNT DATA" },
        { key: "UPDATE_ACCOUNT_DATA", value: "UPDATE ACCOUNT DATA" }
        ];
        this.processStatus = [{ key: 'ALL', value: 'ALL' }, { key: 'CREATE_ACCOUNT_FAILURE', value: 'CREATE ACCOUNT FAILURE' },
        { key: 'CREATE_ACCOUNT_SUCCESSFULLY', value: 'CREATE ACCOUNT SUCCESSFULLY' },
        { key: 'RESET_PASSWORD_FAILURE', value: 'RESET PASSWORD FAILURE' },
        { key: 'RESET_PASSWORD_SUCCESSFULLY', value: 'RESET PASSWORD SUCCESSFULLY' },
        { key: 'ACTIVATE_ACCOUNT_FAILURE', value: 'ACTIVATE ACCOUNT FAILURE' },
        { key: 'ACTIVATE_ACCOUNT_SUCCESSFULLY', value: 'ACTIVATE ACCOUNT SUCCESSFULLY' },
        { key: 'LOGIN_FAILURE', value: 'LOGIN FAILURE' },
        { key: 'LOGIN_SUCCESSFUL', value: 'LOGIN SUCCESSFUL' },
        { key: 'REASON_STANDARD_LOGOUT', value: 'LOGOUT SUCCESSFUL' },
        { key: 'REASON_SESSION_TIMEOUT', value: 'LOGOUT WITH_ERROR' },
        { key: 'CHANGE_PASSWORD_FAILURE', value: 'CHANGE PASSWORD FAILURE' },
        { key: 'CHANGE_PASSWORD_SUCCESSFULLY', value: 'CHANGE PASSWORD SUCCESSFULLY' },
        { key: 'ACCOUNT_DATA_ERROR', value: 'ACCOUNT DATA ERROR' },
        { key: 'UPDATE_ACCOUNT_DATA_ERROR', value: 'UPDATE ACCOUNT DATA ERROR' },
        { key: 'UPDATE_ACCOUNT_DATA_SUCCESSFULL', value: 'UPDATE ACCOUNT DATA SUCCESSFULL' }];
    }
}