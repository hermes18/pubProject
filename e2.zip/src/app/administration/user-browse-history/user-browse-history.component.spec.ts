import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, ComponentFixtureAutoDetect, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from 'src/app/app.module';
import { AdministrationModule } from '../administration.module';
import { UserBrowseHistoryService } from './service/user-browse-history.service';

import { UserBrowseHistoryComponent } from './user-browse-history.component';

describe('UserBrowseHistoryComponent', () => {
  let component: UserBrowseHistoryComponent;
  let fixture: ComponentFixture<UserBrowseHistoryComponent>;
  let userService: UserBrowseHistoryService;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'brosweHistory': host + '/api/v1/users/browser-history',
      }
    }
  };
  let router = {
    navigate: jasmine.createSpy('navigate')
  };
  const menuItemList = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  };
  // window['__env'].environmentConstURLs = environmentConstURL;
  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule, AppModule, AdministrationModule, HttpClientTestingModule],
  //     declarations: [],
  //     providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
  //   })
  //     .compileComponents();
  // }));

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    sessionStorage.setItem('menuItemList', JSON.stringify(menuItemList));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, AdministrationModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, UserBrowseHistoryService, { provide: Router, useValue: router }, { provide: 'Window', useFactory: () => window }, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(UserBrowseHistoryComponent);
    userService: TestBed.get(UserBrowseHistoryService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create  userbrowsehistory', () => {
    expect(component).toBeTruthy();
  });

  it('should call goToPreviousPeriod', () => {
    component.goToPreviousPeriod();
  });


  it('should call goToNextPeriod', () => {
    component.goToNextPeriod();
  });

  it('should call setDateValue', () => {
    component.setDateValue();
  });

  it('should call searchHistory', () => {
    component.searchHistory();
  });
  xit('should call historyApiCall', () => {
    const requestParam = {
      fromDate: "01-01-2020",
      logType: "ALL",
      processName: "ALL",
      toDate: "03-11-2020",
      userLogin: "shabana"
    };
    const response = [{
      appendUsecaseUniqueId: null,
      clientId: null,
      fromDate: null,
      id: "00000000000000625189_00000001595589391332_00017",
      logDate: "24.07.2020 14:16:31",
      logId: "00000000000000625189_00000001595589391332_00017",
      logMessage: "LM500211: E11: Wrong password: User Login = shabana> not logged in.INIT password has expired.",
      logType: "LOGIN_FAILURE",
      processName: "Login",
      request: null,
      systemType: "eCustomer",
      toDate: null,
      userAccountID: null,
      userLogin: "shabana"
    }];
    spyOn(userService, 'getUserHistory').and.callThrough();;
    component.historyApiCall(requestParam);
  });


  it('should call getHistoryData', () => {
    const response = [{
      appendUsecaseUniqueId: null,
      clientId: null,
      fromDate: null,
      id: "00000000000000625189_00000001595589391332_00017",
      logDate: "24.07.2020 14:16:31",
      logId: "00000000000000625189_00000001595589391332_00017",
      logMessage: "LM500211: E11: Wrong password: User Login = shabana> not logged in.INIT password has expired.",
      logType: "LOGIN_FAILURE",
      processName: "Login",
      request: null,
      systemType: "eCustomer",
      toDate: null,
      userAccountID: null,
      userLogin: "shabana"
    }];
    // const expectValue=[{
    //   processName: "Login",
    //   logType: "LOGIN_FAILURE",
    //   logDate: "24.07.2020 14:16:31",
    //   logMessage: "LM500211: E11: Wrong password: User Login = shabana> not logged in.INIT password has expired.",
    //   logDateFromat: '24.07.2020',
    //   logTime: '14:16:31'
    // }]
    component.getHistoryData(response);
  });

  it('should call getHistoryData else part ', () => {
    const data = [];
    component.getHistoryData(data);
  });

  it('should call navigateToUserTab', () => {
    const activeTab = {
      userSearch: true,
      userDetails: false
    }
    window.sessionStorage.setItem('activeTabInAdminBackButton', JSON.stringify(activeTab));
    component.navigateToUserTab();
    expect(router.navigate).toHaveBeenCalledWith(['administartion']);
  });

  it('should call applyFailure', () => {
    const row = {
      logDate: "24.07.2020 14:16:31",
      logDateFromat: "24.07.2020",
      logMessage: "LM500211: E11: Wrong password: User Login = shabana> not logged in.INIT password has expired.",
      logTime: "14:16:31",
      logType: "LOGIN_FAILURE",
      processName: "Login"
    }
    component.applyFailure(row);
  });

  it('should call gotoHome', () => {
    component.gotoHome();
  })
});
