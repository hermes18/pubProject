import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdministrationRoutingModule } from './administration-routing.module';
import { AdministrationComponent } from './administration.component';
import {
  MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule, MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule,
  MatProgressSpinnerModule, MatExpansionModule, MatTabsModule, MatTooltipModule,
  MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatInputModule,
  MatSortModule, MatTableModule, MatPaginatorModule
} from '@angular/material';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter, MatDatepickerIntl, NativeDateAdapter } from '@angular/material';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule, TranslatePipe, TranslateService } from '@ngx-translate/core';
import { NgxPaginationModule } from 'ngx-pagination';
import { UserSearchComponent } from './user-search/user-search.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { ClientSearchComponent } from './client-search/client-search.component';
import { NewaccountErrorComponent } from './newaccount-error/newaccount-error.component';
import { SharedModule } from './../shared/shared.module';
import { AccountMonitoringComponent } from './account-monitoring/account-monitoring.component';
import { BnNgIdleService } from 'bn-ng-idle';
import { AuthService } from '../core/services/auth.service';
import { initTranslation } from '../app.module';
import { HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpConfigInterceptor } from '../core/interceptors/http-config.interceptor';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { UserBrowseHistoryComponent } from './user-browse-history/user-browse-history.component';
import { OrdersReportComponent } from './orders-report/orders-report.component';


export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMMM YYYY',
    // monthYearLabel:{year: 'numeric', month: 'short'},
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

export class CustomDatePickerAdapter extends NativeDateAdapter {

  parse(value: any): Date | null {
    ////(value);
    if ((typeof value === 'string') && (value.indexOf('/') > -1)) {
      const str = value.split('/');
      const year = Number(str[2]);
      const month = Number(str[1]) - 1;
      const date = Number(str[0]);
      // //("year, month, date",year, month, date)
      ////("year, month, date",new Date(year, month, date))
      if (year > 0 && month < 12 && date > 0 && date <= 31) {
        return new Date(year, month, date);
      }


    }
    const timestamp = typeof value === 'number' ? value : Date.parse(value);
    ////("timestamp",timestamp)
    return isNaN(timestamp) ? null : new Date(timestamp);
  }

  private _to2digit(n: number) {
    ////("_to2digit",('00' + n).slice(-2))
    return ('00' + n).slice(-2);
  }
  format(date: Date, displayFormat: string): string {
    ////(displayFormat," ------>",date,displayFormat )

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    ////("input",(this._to2digit(day) + '/' + this._to2digit(month) + '/' + year) )
    return this._to2digit(day) + '/' + this._to2digit(month) + '/' + year;

  }
}

const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule,];

@NgModule({
  declarations: [AdministrationComponent, UserSearchComponent, UserDetailsComponent, OrdersReportComponent,
    ClientSearchComponent, NewaccountErrorComponent, AccountMonitoringComponent, UserBrowseHistoryComponent,],
  imports: [
    CommonModule,
    AdministrationRoutingModule,
    // NgbModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    ...materialModule,
    NgxPaginationModule,
    MatDatepickerModule, MatNativeDateModule,
    SharedModule,
  ],
  providers: [BnNgIdleService, AuthService, TranslatePipe,
    //   {
    //   'provide': APP_INITIALIZER,
    //   'useFactory': initTranslation,
    //   'deps': [TranslateService],
    //   'multi': true
    // },
    { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true },
    // { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {
      provide: DateAdapter,
      useClass: CustomDatePickerAdapter

    },

    // { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
    // {
    //   provide: DateAdapter,
    //   useClass: MomentDateAdapter,
    //   deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    // }
  ]
})
export class AdministrationModule { }
