import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material';
import { AdministrationComponent } from './administration.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { UserBrowseHistoryComponent } from './user-browse-history/user-browse-history.component';
import { UserSearchComponent } from './user-search/user-search.component';
import { ClientSearchComponent } from './client-search/client-search.component';
import { OrdersReportComponent } from './orders-report/orders-report.component';
import { NewaccountErrorComponent } from './newaccount-error/newaccount-error.component';
const routes: Routes = [
  {
    path: '', component: AdministrationComponent,
    canDeactivate: [NavigationGuard],
    children: [
      { path: 'clientSearch', component: ClientSearchComponent, canDeactivate: [NavigationGuard] },
      // { path: '', component: UserSearchComponent, canDeactivate: [NavigationGuard] },
      { path: 'orderReport', component: OrdersReportComponent, canDeactivate: [NavigationGuard] },
      { path: 'userBrowseHistory', component: UserBrowseHistoryComponent, canDeactivate: [NavigationGuard] },
      { path: 'userDetails', component: UserDetailsComponent, canDeactivate: [NavigationGuard] },
      { path: 'newAccountError', component:NewaccountErrorComponent, canDeactivate: [NavigationGuard] }

    ]
  }


];

@NgModule({
  imports: [RouterModule.forChild(routes), MatFormFieldModule],
  exports: [RouterModule, MatFormFieldModule]
})
export class AdministrationRoutingModule { }
