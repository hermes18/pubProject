import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { AdministrationModule } from '../administration.module';

import { OrdersReportComponent } from './orders-report.component';
import { OrdersreportServiceService } from './ordersreport-service.service';

describe('OrdersReportComponent', () => {
  let component: OrdersReportComponent;
  let fixture: ComponentFixture<OrdersReportComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {

        'orderReport': host + '/api/v1/order/order-report',
      }
    }
  };

  // beforeEach(async(() => {
    beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, AdministrationModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, OrdersreportServiceService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
  // }));

  // beforeEach(() => {
    fixture = TestBed.createComponent(OrdersReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
