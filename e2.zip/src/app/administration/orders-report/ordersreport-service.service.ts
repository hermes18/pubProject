import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';

@Injectable({
  providedIn: 'root'
})
export class OrdersreportServiceService {
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(public cService : HttpCommonService,private http: HttpClient,) { }
  
  downloadExcel(baseUrl,data,headersOption): Observable<any> {

    const token = JSON.parse(sessionStorage.getItem('userToken'));
   
      
    let apictoken = token.apicToken;
    let country = sessionStorage.getItem('countryCode')
    let httpHeaderObj = {
      'accept-language': sessionStorage.getItem('defaultLanguage'),
      'x-tenant-id': sessionStorage.getItem('countryCode'),
      'content-type': 'application/json',
      'accept': '*/*',
      'x-system-id': 'ecustomer',
      'Authorization': `Bearer ${token.token}`
    }
    if(country == 'gr'){
        httpHeaderObj['apicToken'] = apictoken
    }
   
 
    let headerOptions = {
      headers: new HttpHeaders(httpHeaderObj),
      observe: 'response'
    };
    let submitUrl = this.baseUrl.ecustomer.orderReport;
    return this.cService['postDataWithHeader'](
      this.baseUrl.ecustomer.orderReport, data,{
        headers: headerOptions,
        responseType: 'text' as any
  
    });
  }  
  
}
