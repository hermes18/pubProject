import { formatDate } from '@angular/common';
import { HttpHeaders } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';

import { AppConfig } from 'src/config/app.config';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { ConfirmDialogComponent } from 'src/app/shared/dialog/confirm-dialog/confirm-dialog.component';
import { ConfirmDialogModel, DownloadfileDialogComponent } from 'src/app/shared/dialog/downloadfile-dialog/downloadfile-dialog.component';
import { OrdersreportServiceService } from './ordersreport-service.service';
import { DateAdapter, MatDialog } from '@angular/material';
import { DatePipe } from '@angular/common';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import * as moment from 'moment';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
// export class Post {
//   dateFrom: Date;
//   dateTo: Date;
// }

@Component({
  selector: 'orders-report',
  templateUrl: './orders-report.component.html',
  styleUrls: ['./orders-report.component.scss'],
  providers: [DatePipe]
})

export class OrdersReportComponent implements OnInit {
  // orderTypeChangeListenerPo = [
  //   { key: "Fundtransfer", value: "46" }, { key: "Allocationchange", value: "47" }, { key: "DeposittoExistingInvestAccount", value: "44" }, { key: "DepositAsNewInvestAccount", value: "45" }, { key: "Clientdatachange", value: "50" }, { key: "ClientsConsentUpdate", value: "49" },
  // ]
  // orderTypeChangeListenerRo = [
  //   { key: "Fundtransfer", value: "46" }, { key: "Allocationchange", value: "47" }, { key: "DeposittoExistingInvestAccount", value: "44" }, { key: "DepositAsNewInvestAccount", value: "45" }, { key: "Clientdatachange", value: "50" }, { key: "ClientsConsentUpdate", value: "49" }, { key: "IndexationBenefit", value: "51" },
  // ]
  orderTypeChangeListenerPo = [
    { key: "Fundtransfer", value: "46" }, { key: "Allocationchange", value: "47" },
    { key: "DeposittoExistingInvestAccount", value: "44" }, { key: "DepositAsNewInvestAccount", value: "45" },
    { key: "Clientdatachange", value: "48" }, { key: "ClientsConsentChange", value: "49" },

  ]
  orderTypeChangeListenerRo = [
    { key: "Fundtransfer", value: "46" }, { key: "Allocationchange", value: "47" },
    { key: "DeposittoExistingInvestAccount", value: "44" }, { key: "DepositAsNewInvestAccount", value: "45" },
    { key: "Clientdatachange", value: "48" }, { key: "ClientsConsentChange", value: "49" },
    { key: "IndexationBenefit", value: "51" },
  ]
  orderTypeChangeListenerGR = [
    { key: "Fundtransfer", value: "46" }, { key: "Allocationchange", value: "47" },
    { key: "Clientdatachange", value: "48" }, { key: "ClientsConsentChange", value: "49" }
  ]
  orderStatusChangeListener = [
    { key: "Registered", value: "Registered" }, { key: "Processing", value: "Processing" }, { key: "Executed", value: "Executed" }, { key: "Rejected", value: "Rejected" }
  ]
  submittedByChangeListener = [{ key: "Client", value: "Client" }, { key: "Employee", value: "Employee" }]

  // post = {
  //   dateFrom: new Date(new Date().setFullYear(new Date().getFullYear() - 1)),
  //   dateTo: new Date(Date.now())
  // }
  // @Output('userAccountValue') valueChange = new EventEmitter<any>();
  // ordersReport: FormGroup;
  country;
  lang;
  // dateAdapter;
  displayPoOption: boolean = false;
  displayRoOption: boolean = false;
  noReportFound: boolean = false;
  selectCheckBoxAlert: boolean = false;
  headers = new HttpHeaders();
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  orderReportUrl = this.baseUrl.ecustomer.orderReport;
  orderReportDTO: any;
  setLocaleDatePicker;
  displayGROption: boolean = false;

  constructor(public fb: FormBuilder, private dateAdapter: DateAdapter<Date>, public sharedService: SharedServiceService, public datepipe: DatePipe, public reportService: OrdersreportServiceService, public dialog: MatDialog, public commonService: HttpCommonService, public translate: TranslateService) { }

  @Output('setCalenderLanguage') calenderLangugae = new EventEmitter<any>();

  @Input() set setLocale(flag) {
    //(flag)
    if (flag) {
      this.sharedService.getLangChange().subscribe((data) => {
        const lang = sessionStorage.getItem("defaultLanguage");
        let dateTranslate = {
          'pl_en': 'en',
          'pl_pl': 'pl',
          'ro_ro': 'ro',
          'ro_en': 'en',
          'gr_gr': 'el',
          'gr_en': 'en',
          'gr': 'el'
        }
        //("after lang change", data);
        const language = data ? data === 'gr' ? dateTranslate[lang] : data : dateTranslate[lang];
        this.dateAdapter.setLocale(language);
        this.setLocaleDatePicker = flag;
      });
    }
    this.calenderLangugae.emit(this.setLocaleDatePicker);
  }

  ngAfterViewInit() {
    this.sharedService.getLangChange().subscribe((data) => {
      const lang = sessionStorage.getItem("defaultLanguage");
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_gr': 'el',
        'gr_en': 'en',
        'gr': 'el'
      }
      const language = data ? data === 'gr' ? dateTranslate[lang] : data : dateTranslate[lang];
      this.dateAdapter.setLocale(language);
    })
    this.calenderLangugae.emit(this.setLocaleDatePicker);

  }
  // @Input() set orderTabIndex(index) {
  //   if (this.ordersReportForm) {
  //     this.ordersReportForm ? this.ordersReportForm.reset() : '';
  //     this.ordersReportForm.markAsUntouched();

  //     this.ordersReportForm.reset();
  //     // this.successChangePassword = false;
  //   }
  // }


  ordersReportForm = this.fb.group({
    orderTypes: this.fb.array([]),
    orderStatuses: this.fb.array([]),
    submittedBy: this.fb.array([]),
    dateFrom: '',
    dateTo: new Date()

  });


  ngOnInit() {
    // this.ordersReportForm.reset();
    this.noReportFound = false;
    this.selectCheckBoxAlert = false;
    this.country = sessionStorage.getItem('countryCode');
    //("country", this.country)
    this.lang = sessionStorage.getItem('defaultLanguage');
    //("oninitlang", this.lang)
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      //if (this.country == 'pl' || this.country == 'gr') {
      this.displayPoOption = true;
      this.displayGROption = false;
    }
    else {
      this.displayRoOption = true;
    }
    if (this.country == 'gr' && loggedInCountryCheck) {
      this.displayGROption = true;
      this.displayPoOption = false;
    } else {
      this.displayGROption = false;
    }

    this.setDateValue();
    //("report", this.ordersReportForm)

  }

  setDateValue() {
    let toDateRange = new Date();
    const setFromDate = new Date(new Date().setMonth(new Date().getMonth() - 1));
    // const fromDateRange = new Date(setFromDate.setDate(setFromDate.getDate() + 1));
    this.ordersReportForm.patchValue({
      // dateFrom: fromDateRange,
      dateFrom: setFromDate,
      dateTo: toDateRange
    });
  }
  totalPolicy
  generateExporttoCSV() {
    const message = this.translate.instant("eCustomer.orderReport.CacheWarning");
    //("msg", message)
    const dialogData = new ConfirmDialogModel("Confirm Action", message);
    const dialogRef =
      this.dialog.open(DownloadfileDialogComponent, { data: dialogData });
    dialogRef.afterClosed().subscribe(result => {
      //(result)
      if (result === true) {
        //("report", this.ordersReportForm)
        // const a = this.ordersReportForm.value.orderTypes;
        // console.log("11111111111111111111111111",a)
        // for (let i = 0; i < a.length; i++) {

        //   this.totalPolicy.push(a[i]);
        // }
        // console.log("11111111111111111111111111",this.totalPolicy)
        this.orderReportDTO = {
          orderTypes: (this.ordersReportForm.value.orderTypes ? (this.ordersReportForm.value.orderTypes) : ''),
          dateFrom: (this.ordersReportForm.value.dateFrom ? (this.ordersReportForm.value.dateFrom) : ''),
          dateTo: (this.ordersReportForm.value.dateTo ? (this.ordersReportForm.value.dateTo) : ''),
          orderStatuses: (this.ordersReportForm.value.orderStatuses ? (this.ordersReportForm.value.orderStatuses) : ''),
          submittedBy: (this.ordersReportForm.value.submittedBy ? (this.ordersReportForm.value.submittedBy) : ''),

        }
        const fromDate = moment(this.orderReportDTO.dateFrom)
        const toDate = moment(this.orderReportDTO.dateTo)
        //(fromDate.isValid(), toDate.isValid())
        // console.log("orderDTO", this.orderReportDTO)
        if (this.orderReportDTO.orderTypes.length == 0 || this.orderReportDTO.orderStatuses.length == 0 || this.orderReportDTO.submittedBy.length == 0 ||
          (!fromDate.isValid()) || (!toDate.isValid())) {
          this.selectCheckBoxAlert = true;
          this.noReportFound = false;
          window.scrollTo(0, 0);
          //(fromDate.isValid());
        } else if (this.orderReportDTO.orderTypes.length != 0 && this.orderReportDTO.orderStatuses.length != 0 && this.orderReportDTO.submittedBy.length != 0 &&
          (fromDate > toDate)) {
          this.selectCheckBoxAlert = true;
          this.noReportFound = false;
        } else {
          this.selectCheckBoxAlert = false;
          // }

          this.commonService['downloadExcel'](this.orderReportUrl, this.orderReportDTO, '').subscribe(data => {
            // this.reportService['downloadExcel']( this.orderReportDTO, this.orderReportDTO, '').subscribe(data => {
            //(data)

            // //(data.headers.get('Content-Type'));
            if (String(data) == 'No orders found') {
              //("yes");
              this.noReportFound = true;
              this.selectCheckBoxAlert = false;
              window.scrollTo(0, 0);
            } else {
              this.noReportFound = false;
              // this.downloadFile(data),
              this.downloadFiles(data, this.orderReportDTO.dateFrom, this.orderReportDTO.dateTo),
                //  this.downloadFiles(data,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                error => //("Error downloading the file."),
                  () => console.info("OK");
            }
          });
        }
        //
      }
      //
    });
  }


  downloadFiles(data: any, dateFrom: any, dateTo: any) {
    var csvData = new Blob([data], { type: 'application/csv;charset=utf-8;' });
    var csvURL = null;
    const fromDate = this.datepipe.transform(dateFrom, 'dd.MM.yyyy');
    const toDate = this.datepipe.transform(dateTo, 'dd.MM.yyyy');
    //(fromDate, toDate)
    const filename = 'eCustomer_Order_Report_' + fromDate + '_' + toDate + '.csv';
    //(filename)
    if (navigator.msSaveBlob) {
      csvURL = navigator.msSaveBlob(csvData, filename);
    } else {
      csvURL = window.URL.createObjectURL(csvData);
    }
    var tempLink = document.createElement('a');
    tempLink.href = csvURL;
    tempLink.setAttribute('download', filename);
    tempLink.click();
  }

  downloadFile(data: any) {
    // const blob = new Blob([(<any>data)], { type: 'application/vnd.ms-excel' });
    const blob = new Blob([(<any>data)], { type: 'text/csv' });
    // const blob = new Blob([(<any>data)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    window.open(url);
  }

  downloadForm(a: any) {
    //("data", a)
    // let blob = new Blob([data], { type: "application/csv" });
    let blob = new Blob([a], { type: "text/csv;charset=utf-8" });
    if (window.navigator.msSaveOrOpenBlob) {
      //IE11 & Edge
      window.navigator.msSaveOrOpenBlob(blob);
    } else {
      let url = window.URL.createObjectURL(blob);
      window.open(url);
    }
  }

  onChange(event) {
    //     const orderTypes = <FormArray>this.ordersReportForm.get('orderTypes') as FormArray;
    //     // for (var key in this.arr1[0]) {
    //     //   if (this.arr1[0].hasOwnProperty(key)) {
    //     //     this. a = this.columnsArr.push(key);
    //     //   }
    //     //   console.log(this.columnsArr);
    //     // }
    //     if (event.checked) {


    //       orderTypes.push(new FormControl(event.source.value));
    //       if(event.source.value == "49"){
    //         orderTypes.push(new FormControl(event.source.value));
    //      let value="50"

    //      const urlControl = this.initUrl(value);
    // orderTypes.push(urlControl);

    const orderTypes = this.ordersReportForm.get('orderTypes') as FormArray;
    if (event.checked) {
      // const additionalvalue = 50"
      // console.log(event.source.value)
      if (event.source.value == 49) {
        orderTypes.push(new FormControl(event.source.value));
        // console.log("clicked");
        // console.log("clicked", new FormControl(event.source.value));

        // orderTypes.push("50")
        // if (!orderTypes.value.includes(url)) {
        orderTypes.push(this.fb.control("50"));
        // }
      } else {

        if (orderTypes.value.includes("50")) {

          if (!orderTypes.value.includes(49)) {
            orderTypes.push(new FormControl(event.source.value));
          }
          else {
            const i = orderTypes.controls.findIndex(x => x.value == 50);
            orderTypes.removeAt(i);
            orderTypes.push(new FormControl(event.source.value));
          }

        }
        else {
          orderTypes.push(new FormControl(event.source.value));
        }
      }
    }

    else {

      const i = orderTypes.controls.findIndex(x => x.value === event.source.value);

      orderTypes.removeAt(i);
      if (event.source.value == 49) {
        const a = orderTypes.controls.findIndex(x => x.value == 50);
        orderTypes.removeAt(i);
      }
    }
  }

  // initUrl(value) {
  //   return this.fb.group({
  //       value: [value],
  //   });
  // }

  onChange1(event) {
    const orderStatuses = <FormArray>this.ordersReportForm.get('orderStatuses') as FormArray;

    if (event.checked) {
      orderStatuses.push(new FormControl(event.source.value))
    } else {
      const i = orderStatuses.controls.findIndex(x => x.value === event.source.value);
      orderStatuses.removeAt(i);
    }
  }

  onChange2(event) {
    const submittedBy = <FormArray>this.ordersReportForm.get('submittedBy') as FormArray;

    if (event.checked) {
      submittedBy.push(new FormControl(event.source.value))
    } else {
      const i = submittedBy.controls.findIndex(x => x.value === event.source.value);
      submittedBy.removeAt(i);
    }
  }
  // onChangeOrder(value: string, isChecked: boolean) {
  //   const orderType = <FormArray>this.ordersReportForm.controls.orderTypes;
  //   if (isChecked) {
  //     orderType.push(new FormControl(value));
  //   } else {
  //     let index = orderType.controls.findIndex(x => x.value == value)
  //     orderType.removeAt(index);
  //   }
  // }
  // onChangeStatus(value: string, isChecked: boolean) {
  //   const status = <FormArray>this.ordersReportForm.controls.orderStatuses;
  //   if (isChecked) {
  //     status.push(new FormControl(value));
  //   } else {
  //     let index = status.controls.findIndex(x => x.value == value)
  //     status.removeAt(index);
  //   }
  // }
  // onChangeSubmit(value: string, isChecked: boolean) {
  //   const submitedBy = <FormArray>this.ordersReportForm.controls.submittedBy;
  //   if (isChecked) {
  //     submitedBy.push(new FormControl(value));
  //   } else {
  //     let index = submitedBy.controls.findIndex(x => x.value == value)
  //     submitedBy.removeAt(index);
  //   }
  // }
}
