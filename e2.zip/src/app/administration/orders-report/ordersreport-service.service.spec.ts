import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';


import { OrdersreportServiceService } from './ordersreport-service.service';
import { APP_BASE_HREF } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { AppModule } from 'src/app/app.module';
import { AdministrationModule } from '../administration.module';

describe('OrdersreportServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [RouterTestingModule, AppModule, AdministrationModule, HttpClientTestingModule],
    providers: [OrdersreportServiceService, { provide: APP_BASE_HREF, useValue: '/' }]
  }));

  it('should be created', () => {
    const service: OrdersreportServiceService = TestBed.get(OrdersreportServiceService);
    expect(service).toBeTruthy();
  });
});
