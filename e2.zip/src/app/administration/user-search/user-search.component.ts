import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { max } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';
import { AfterViewInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { AppConfig } from 'src/config/app.config';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UserDetailsComponent } from '../user-details/user-details.component';
import { ActivatedRoute, Router } from '@angular/router';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
export interface UserData {
  uId: string;
  customerId: string;
  firstName: string;
  lastName: string;
  status: string;
}
@Component({
  selector: 'user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.scss']
})

export class UserSearchComponent implements OnInit {
  displayedColumns: string[] = ['uId', 'customerId', 'firstName', 'lastName', 'status'];
  dataSource: MatTableDataSource<UserData>;

  private paginator: MatPaginator;
  private sort: MatSort;
  country: string;
  lang: any;
  displayPoland: boolean = false;

  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.dataSource)
      this.dataSource.paginator = this.paginator;
  }
  @ViewChild(MatSort, { static: false }) set matSort(mp: MatSort) {
    this.sort = mp;
    if (this.dataSource)
      this.dataSource.sort = this.sort;
  }
  settingParamValue = {
    'clientSearch': false,
    'userSearch': false,
    'userDetails': false,
    'ordersReport': false,
    'uId': '',
    'customerId': '',
    // 'accountMonitoring':false
  }

  @Output('userAccountValue') valueChange = new EventEmitter<any>();
  public p: number;
  //detail: any;
  //baseUrl = environment.host + environment.userSearchConfig.url;
  //baseUrl =  environment.userSearchConfig.url;
  RecordsFound: boolean;
  // RecordsFound:boolean=false;
  count: any;
  user: any;
  searchedUser
  selectedUser
  maxRecord: boolean = false;
  zeroRecordFound: boolean = false;
  constructor(public route: ActivatedRoute, private router: Router,
    public fb: FormBuilder, public commonService: HttpCommonService) { }
  ngAfterViewInit() { }
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];


  userSearchForm = this.fb.group({
    uId: '',
    lastName: '',
    Email: ''
  });
  ngOnInit() {

    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      // if (this.country == 'pl') {
      this.displayPoland = true;
    }
    else {
      this.displayPoland = false;
    }
    this.maxRecord = false;
    this.RecordsFound = false;
    this.zeroRecordFound = false;
    //this.dataSource.sort = this.sort;
    this.userSearchForm.reset();
  }
  headers = new HttpHeaders();
  submit() {
    this.zeroRecordFound = false;
    this.maxRecord = false;
    this.RecordsFound = false;
    let screenRequestObj = new ScreenRenderReqModel();
    screenRequestObj.loginId = (this.userSearchForm.value.uId ? (this.userSearchForm.value.uId).trim() : '');
    screenRequestObj.lastName = (this.userSearchForm.value.lastName ? (this.userSearchForm.value.lastName).trim() : '');
    screenRequestObj.email = (this.userSearchForm.value.Email ? (this.userSearchForm.value.Email).trim() : '');
    let url = this.baseUrl.ecustomer.userSearchConfig;
    //(screenRequestObj)
    this.commonService['postData'](url, screenRequestObj, this.headers).subscribe(data => {
      // this.commonService.getData(this.baseUrl).subscribe(data => {
      //this.dataSource = data;
      this.dataSource = new MatTableDataSource<UserData>();
      this.paginator = null;
      this.sort = null;
      this.user = data;
      if (this.user.maxRecordSizeExceed)
        this.maxRecord = true;
      else
        this.maxRecord = false;

      if (screenRequestObj.loginId == '' && screenRequestObj.lastName == '' && screenRequestObj.email == '') {
        // this.selectedUser = this.user.userSearchDTOs;
        this.dataSource = new MatTableDataSource(this.user.userSearchDTOs);

        //this.dataSource = this.user.userSearchDTOs;
        //this.selectedUser = this.user.UserSearchResponseDTO.userSearchDTOs; // mock json result 
      }
      else {
        // this.selectedUser = this.user.UserSearchResponseDTO.userSearchDTOs; // mock json result
        //this.selectedUser = this.user.userSearchDTOs // main 
        this.dataSource = new MatTableDataSource(this.user.userSearchDTOs);

        //this.dataSource = this.user.userSearchDTOs;

      }

      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.dataSource.sortingDataAccessor = (data, attribute) =>  data[attribute] 
      if (this.user.userSearchDTOs) {
        this.count = this.user.userSearchDTOs.length;
      }
      //("---------------------", this.count);
      if (this.count > 0) {
        this.RecordsFound = true;
      } else {
        this.zeroRecordFound = true;
      }
    })
  }

  userDeatilScreen(id, customerId) {
    //("value setting", this.settingParamValue)
    this.settingParamValue.userSearch = false;
    this.settingParamValue.userDetails = true;
    this.settingParamValue.clientSearch = false;
    this.settingParamValue.ordersReport = false;
    this.settingParamValue.uId = id;
    this.settingParamValue.customerId = customerId;
    //this.settingParamValue.accountMonitoring = false;
    //("value setting 1", this.settingParamValue)
    const data = {
      id: this.settingParamValue.uId,
      customerId: this.settingParamValue.customerId
    }
    this.valueChange.emit(this.settingParamValue);
    const activeTab = {
      userSearch: this.settingParamValue.userSearch,
      userDetails: this.settingParamValue.userDetails
    }
    sessionStorage.setItem('activeTabInAdminBackButton', JSON.stringify(activeTab));
    sessionStorage.setItem('ClientSearchCutomerId', JSON.stringify(data));
    this.router.navigate(['administartion/userDetails']);
  }



}

export class ScreenRenderReqModel {

  loginId: string = null;
  lastName: string = null;
  email: string = null;



}

