import { APP_BASE_HREF } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppModule } from 'src/app/app.module';
import { AdministrationModule } from '../../administration.module';

import { UserSearchService } from './user-search.service';

describe('UserSearchService', () => {
  let service: UserSearchService;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'userSearchConfig': host + '/api/v1/users/browser-history',
      }
    }
  };
  beforeEach(() => {
    //  window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, AdministrationModule],
      providers: [UserSearchService, { provide: APP_BASE_HREF, useValue: '/' }],
    });
    service = TestBed.get(UserSearchService);

  });

  it('should be created', () => {
    //  const service: UserSearchService = TestBed.get(UserSearchService);
    expect(service).toBeTruthy();
  });
});
