import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';
import { TranslateService } from '@ngx-translate/core';
import { DialogService } from '../../shared/services/dialog.service';
import { AppConfig } from 'src/config/app.config';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { ForgotloginDialogComponent } from 'src/app/shared/dialog/forgotlogin-dialog/forgotlogin-dialog.component';
import { UserSearchComponent } from '../user-search/user-search.component';
import { forwardRef } from '@angular/core';
import { AdministrationComponent } from '../administration.component';
import { Router } from '@angular/router';
import { ConfirmDialogComponent } from 'src/app/shared/dialog/confirm-dialog/confirm-dialog.component';
import { UseraccountClosureDialogComponent } from 'src/app/shared/dialog/useraccount-closure-dialog/useraccount-closure-dialog.component';
import { BroadcasterService } from 'src/app/core/services/broadcaster.service';

@Component({
  selector: 'user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss']
})
export class UserDetailsComponent implements OnInit {
  user: any;
  selectedUserDetails: any;
  showSelectedUser: any;
  //url = environment.userDetailsConfig.url;
  //Url = environment.userSearchConfig.url;
  userId
  forgotLoginUser
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  loginReqUser: any;
  constructor(public route: ActivatedRoute, public commonService: HttpCommonService,
    private router: Router, private readonly broadCastService: BroadcasterService,
    private translate: TranslateService, public dialogService: DialogService) { }

  // @ViewChild(forwardRef(() => AdministrationComponent), { static: false }) 
  //private adminComp: AdministrationComponent;
  settingParamValue = {
    'clientSearch': false,
    'userSearch': false,
    'userDetails': false,
    'uId': '',
    //'accountMonitoring': false
  }
  //@Input() item: string;
  @Output('userAccountValue') valueChange = new EventEmitter<any>();
  //@Input() customerId: any;
  item: string;
  customerId: any;

  ngOnInit() {
    // const userId = + (this.route.snapshot.paramMap.get('uId'));
    const searchDetails = JSON.parse(sessionStorage.getItem('ClientSearchCutomerId'));
    //(this.item);
    this.item = searchDetails.id;
    this.customerId = searchDetails.customerId
    // this.route.params.subscribe(params => {
    // this.userId = params['uId'];
    this.userId = this.item;
    //(this.userId)
    //let url = this.baseUrl.ecustomer.userSearchConfig + '/' + this.userId; })

    this.userDetailsConfig();
    this.broadCastService.on<any>('flag').subscribe((data) => {
      let status = this.selectedUserDetails ? this.selectedUserDetails.status : '';
      if ("LOCKED" === status.toUpperCase() || "ACTIVE" === status.toUpperCase() ||
        "ACTIVATE" === status.toUpperCase()) {
        status = "CLOSED";
      } else if ("CLOSED" === status.toUpperCase() || "CLOSE" === status.toUpperCase()) {
        status = "ACTIVE";
      }
      if (data) {
        let flag = this.updateuserAccountStatus(data, this.selectedUserDetails, status);

        this.broadCastService.broadcast('flag', false);;
      }
    });
  }

  async userDetailsConfig() {

    const reqParam = {
      userId: this.userId
    };
    this.commonService.postData(this.baseUrl.ecustomer.userDetailsConfig, reqParam, '').subscribe(data => {
      this.user = data

      //this.showSelectedUser = this.user.filter(x => x.userName == this.userId)
      this.selectedUserDetails = data;// this.showSelectedUser[0]
      //(this.selectedUserDetails)
    })

  }

  forgotLogin() {

    // this.commonService[environment.userSearchConfig.method](environment.userSearchConfig.url, '', '').subscribe(data => {
    //   this.forgotLoginUser = data.UserSearchResponseDTO.userSearchDTOs[0].userSearchDTOs
    //   this.loginReqUser = this.forgotLoginUser.filter(x => x.uId == this.userId)
    //   const loginId = this.loginReqUser[0].customerId
    //   //(loginId) 'forgotLoginSupportUser': '/api/v1/users/supportuserforgotlogin',
    // url: "/api/v1/users/forgotlogin",
    // method: "postData"
    //("this.customerId", this.customerId)
    if (this.customerId != null && this.customerId != '') {
      // let forgotLoginUrl = environment.host + environment.forgotLogin.url;
      let forgotLoginUrl = this.baseUrl.ecustomer.forgotLoginSupportUser,
        reqParam = {
          clientId: this.customerId
        };
      this.commonService.postData(this.baseUrl.ecustomer.forgotLoginSupportUser, reqParam, '').subscribe()
    }
    this.dialogService.openDialog(ForgotloginDialogComponent, { 'heading': this.translate.instant('eCustomer.forgotLogin.confirmationLabel'), 'body': this.translate.instant('eCustomer.forgotLogin.SuccessMessage'), 'primaryButton': 'OK' });
    // })
  }
  userSearchScreen() {
    //("value setting", this.settingParamValue)
    this.settingParamValue.userSearch = true;
    this.settingParamValue.userDetails = false;
    this.settingParamValue.clientSearch = false;
    // this.settingParamValue.accountMonitoring = false;
    //("value setting 1", this.settingParamValue)
    this.valueChange.emit(this.settingParamValue);
    const activeTab = {
      userSearch: this.settingParamValue.userSearch,
      userDetails: this.settingParamValue.userDetails
    }
    sessionStorage.setItem('activeTabInAdminBackButton', JSON.stringify(activeTab));
    this.router.navigate(['administartion']);
  }

  navigateToBrowseHistory() {
    sessionStorage.setItem('userDetailResponse', JSON.stringify(this.selectedUserDetails));
    this.router.navigate(['administartion/userBrowseHistory'])
  }

  closeUserAccount() {

    let status = this.selectedUserDetails ? this.selectedUserDetails.status : '';
    // this.updateuserAccountStatus(true,this.selectedUserDetails,"ACTIVE")
    if ("LOCKED" === status.toUpperCase() || "ACTIVE" === status.toUpperCase() || "ACTIVATE" === status.toUpperCase()) {
      status = "CLOSED";
      //this.flag = confirm(this.translate.instant("eCustomer.addNew.ToconfirmaccountclosureclickOK"))
      let submsg = this.translate.instant("eCustomer.addNew.ToconfirmaccountclosureclickOK")
      let bodymsg = this.translate.instant("eCustomer.addNew.ToconfirmaccountclosureclickOK1")
      this.dialogBox(submsg, bodymsg);

    } else if ("CLOSED" === status.toUpperCase() || "CLOSE" === status.toUpperCase()) {
      status = "ACTIVE";
      // this.flag =confirm(this.translate.instant("eCustomer.addNew.ToconfirmaccountactivationclickOK"))
      let submsg = this.translate.instant("eCustomer.addNew.ToconfirmaccountactivationclickOK")
      let bodymsg = this.translate.instant("eCustomer.addNew.ToconfirmaccountactivationclickOK2")
      this.dialogBox(submsg, bodymsg);

    }
  }

  dialogBox(submsg, bodymsg) {
    this.dialogService.openDialog(UseraccountClosureDialogComponent, {
      'heading': " ",
      'body': submsg,
      'subBody': bodymsg,
      'gotohometxt': '',
      secondaryButton: 'Ok',
    });
  }

  updateuserAccountStatus(flag, selectedUserDetails, status): Promise<any> {

    if (flag) {

      const searchDetails = JSON.parse(sessionStorage.getItem('ClientSearchCutomerId'));
      const reqParam = {
        userName: searchDetails.id ? searchDetails.id : "",
        clientId: searchDetails.customerId ? searchDetails.customerId : "",
        accountStatus: status ? status : "",
        accountType: selectedUserDetails ? selectedUserDetails.accountType : "",
        email: selectedUserDetails ? selectedUserDetails.email : "",
        firstName: selectedUserDetails ? selectedUserDetails.firstName : "",
        lastName: selectedUserDetails ? selectedUserDetails.lastName : "",
        language: selectedUserDetails ? selectedUserDetails.language : "",
        userRole: selectedUserDetails ?
          (selectedUserDetails.roles.length > 0 ? selectedUserDetails.roles.join(', ') : '') : "",
        globalEmployeeId: selectedUserDetails ?
          (selectedUserDetails.globalEmployeeId ? selectedUserDetails.globalEmployeeId : '') : ''
      };
      this.commonService.postData(this.baseUrl.ecustomer.closeUserAcccountConfig, reqParam, '')
        .subscribe(data => {

          //(data); 
          if (data === "true" || (data)) {
            this.userDetailsConfig();

          }
        })
    }
    return flag;
  }

}
