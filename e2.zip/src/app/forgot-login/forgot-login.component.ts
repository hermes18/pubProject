import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { HttpCommonService } from '../shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { AlertDialogComponent } from '../shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from '../shared/services/dialog.service';
import { TranslateService } from '@ngx-translate/core';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UtilityService } from '../shared/utilities/utility.service';

@Component({
  selector: 'forgot-login',
  templateUrl: './forgot-login.component.html',
  styleUrls: ['./forgot-login.component.scss']
})
export class ForgotLoginComponent implements OnInit {

  @ViewChild('tooltip1', { static: false }) tooltip1;
  @ViewChild('tooltip2', { static: false }) tooltip2;

  @HostListener('window:scroll', ['$event'])
  scrollHandler(event) {
    this.tooltip1 ? this.tooltip1.hide() : '';
    this.tooltip2 ? this.tooltip2.hide() : '';
  }

  countryCode = sessionStorage.getItem('countryCode');
  forgotLoginForm: FormGroup;
  questionSet;
  clientIdentifierTextType;
  errorCodeMessage: string;
  showAlert: boolean = false;
  submitted: boolean = false;
  successForgotLogin: boolean = false;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  loggedInCountry = UtilityService.getCountry();
  constructor(public fb: FormBuilder, public commonService: HttpCommonService,public deviceDetector:DeviceDetectorService, public translate: TranslateService,
    public dialog: DialogService) {

  }
  // forgotLoginForm = this.fb.group({
  //   clientIdentifier: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
  //   question: ['', Validators.required],
  //   answer: ['', Validators.required]
  // })
  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    if (this.countryCode == 'gr') {
      this.forgotLoginForm = this.fb.group({
        // clientIdentifier: ['', [Validators.required]],
        question: ['', Validators.required],
        answer: ['', Validators.required],
        emailId:['', [Validators.required]]
      })
    } else {
      this.forgotLoginForm = this.fb.group({
        clientIdentifier: ['', [Validators.required]],
        question: ['', Validators.required],
        answer: ['', Validators.required],
        // emailId: ['', [Validators.required]]
      })
    }
    this.errorCodeMessage = ''
    // let url = environment.host + environment.getQuestionSet.url;
    // this.commonService[environment.getQuestionSet.method](url, '').subscribe(data => {
    //   this.questionSet = data

    // })
  }
  restrictPaste() {
    if (this.countryCode === 'ro') {
      this.dialog.openDialog(AlertDialogComponent, { 'heading': 'Alert', 'body': this.translate.instant("eCustomer.loginData.copyPasteDisabled") });
      return false
    }
  }
  ngAfterViewInit() {
    let url = this.baseUrl.ecustomer.getQuestionSet;
    this.commonService['getDataValueHeaders'](url, '').subscribe(data => {
      this.questionSet = data

    })
  }
  get f() { return this.forgotLoginForm.controls; }

  toggleFieldTextType(textType) {
    this[textType] = !this[textType];
  }

  // successResponse: boolean = false;
  forgotLogin() {
    this.submitted = true;
    let headerOptions = {
      headers: new HttpHeaders({
        'accept-language': sessionStorage.getItem('defaultLanguage'),
        'x-tenant-id': sessionStorage.getItem('countryCode'),
        'x-system-id': 'ecustomer',
        'content-type': 'application/json',
        'accept': 'application/json'
      })
    };
    if (this.countryCode != "gr") {
      if ((this.forgotLoginForm.controls['clientIdentifier'].value.trim() == '') &&
        (this.forgotLoginForm.controls['answer'].value.trim() == '')) {
        this.forgotLoginForm.controls["clientIdentifier"].setErrors({ 'required': true });
        this.forgotLoginForm.controls['answer'].setErrors({ 'required': true });
        this.forgotLoginForm.controls['clientIdentifier'].setValue('');
        this.forgotLoginForm.controls['answer'].setValue('');
      } else if (this.forgotLoginForm.controls['clientIdentifier'].value.trim() == '') {
        this.forgotLoginForm.controls['clientIdentifier'].setErrors({ 'required': true });
        this.forgotLoginForm.controls['clientIdentifier'].setValue('');
      } else if (this.forgotLoginForm.controls['answer'].value.trim() == '') {
        this.forgotLoginForm.controls['answer'].setErrors({ 'required': true });
        this.forgotLoginForm.controls['answer'].setValue('');
      } else if (this.forgotLoginForm.controls['clientIdentifier'].errors == null
        && this.forgotLoginForm.controls['question'].errors == null &&
        this.forgotLoginForm.controls['answer'].errors == null) {
        this.callApi(headerOptions);
      }
    } else {
      if ((this.forgotLoginForm.controls['emailId'].value.trim() == '') &&
      (this.forgotLoginForm.controls['answer'].value.trim() == '')) {
      this.forgotLoginForm.controls["emailId"].setErrors({ 'required': true });
      this.forgotLoginForm.controls['answer'].setErrors({ 'required': true });
      this.forgotLoginForm.controls['emailId'].setValue('');
      this.forgotLoginForm.controls['answer'].setValue('');
    } else if (this.forgotLoginForm.controls['emailId'].value.trim() == '') {
      this.forgotLoginForm.controls['emailId'].setErrors({ 'required': true });
      this.forgotLoginForm.controls['emailId'].setValue('');
    } else if (this.forgotLoginForm.controls['answer'].value.trim() == '') {
      this.forgotLoginForm.controls['answer'].setErrors({ 'required': true });
      this.forgotLoginForm.controls['answer'].setValue('');
    } else if (this.forgotLoginForm.controls['emailId'].errors == null
      && this.forgotLoginForm.controls['question'].errors == null &&
      this.forgotLoginForm.controls['answer'].errors == null) {
        this.callApi(headerOptions);
      }
    }
   /*  if ((this.forgotLoginForm.controls['emailId'].value.trim() == '') &&
      (this.forgotLoginForm.controls['answer'].value.trim() == '')) {
      this.forgotLoginForm.controls["emailId"].setErrors({ 'required': true });
      this.forgotLoginForm.controls['answer'].setErrors({ 'required': true });
      this.forgotLoginForm.controls['emailId'].setValue('');
      this.forgotLoginForm.controls['answer'].setValue('');
    } else if (this.forgotLoginForm.controls['emailId'].value.trim() == '') {
      this.forgotLoginForm.controls['emailId'].setErrors({ 'required': true });
      this.forgotLoginForm.controls['emailId'].setValue('');
    } else if (this.forgotLoginForm.controls['answer'].value.trim() == '') {
      this.forgotLoginForm.controls['answer'].setErrors({ 'required': true });
      this.forgotLoginForm.controls['answer'].setValue('');
    } else if (this.forgotLoginForm.controls['emailId'].errors == null
      && this.forgotLoginForm.controls['question'].errors == null &&
      this.forgotLoginForm.controls['answer'].errors == null) {
      //  //("inside forgotlogin")
      // this.successForgotLogin = true
      let clientdetails = {
        clientIdentifier: "",
        emailId: this.forgotLoginForm.value.emailId,
        securityAnswer: this.forgotLoginForm.value.answer,
        securityQuestion: this.forgotLoginForm.value.question,
        emailValidationOn: this.countryCode == 'gr' ? true : false,
      }
      //(clientdetails)
      let forgotLoginUrl = this.baseUrl.ecustomer.forgotLogin;
      this.commonService['postDataWithHeader'](forgotLoginUrl, JSON.stringify(clientdetails), headerOptions).subscribe((data) => {
        //(data);

        // if (data['response'] != null && data['response'] == 'Success') {
        //   this.successForgotLogin = true
        //   this.errorCodeMessage = ''
        // } else {
        //   this.successForgotLogin = false
        //   this.errorCodeMessage = data['errorCode']
        //  if (data['response'] != null) {
        // this.successResponse = true;
        this.successForgotLogin = true
        this.errorCodeMessage = '';
        // }
        // }
      },
      )
    } */
  }

  callApi(headerOptions){
    //  //("inside forgotlogin")
      // this.successForgotLogin = true
      let clientdetails = {
        clientIdentifier: this.countryCode != 'gr' ? this.forgotLoginForm.value.clientIdentifier : "",
        emailId: this.countryCode == 'gr' ? this.forgotLoginForm.value.emailId : "",
        securityAnswer: this.forgotLoginForm.value.answer,
        securityQuestion: this.forgotLoginForm.value.question,
        emailValidationOn: this.countryCode == 'gr' ? true : false,
      }
      //(clientdetails)
      let forgotLoginUrl = this.baseUrl.ecustomer.forgotLogin;
      this.commonService['postData'](forgotLoginUrl, JSON.stringify(clientdetails), headerOptions).subscribe((data) => {
        //(data);

        // if (data['response'] != null && data['response'] == 'Success') {
        //   this.successForgotLogin = true
        //   this.errorCodeMessage = ''
        // } else {
        //   this.successForgotLogin = false
        //   this.errorCodeMessage = data['errorCode']
        //  if (data['response'] != null) {
        // this.successResponse = true;
        this.successForgotLogin = true
        this.errorCodeMessage = '';
        // }
        // }
      },
      )
  }
}
