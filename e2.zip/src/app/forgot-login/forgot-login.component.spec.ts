import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from '../app.module';
import { HttpCommonService } from '../shared/services/http-common.service';

import { ForgotLoginComponent } from './forgot-login.component';

describe('ForgotLoginComponent', () => {
  let component: ForgotLoginComponent;
  let fixture: ComponentFixture<ForgotLoginComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  let commonHttpService: HttpCommonService;

  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'getQuestionSet': host + '/api/v1/users/security-questions'
      }
    }
  };


  beforeEach(() => {
    const countryCode = "ro";
    window['__env'].environmentConstURLs = environmentConstURL;
    window.sessionStorage.setItem('countryCode', JSON.stringify(countryCode));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HttpClientTestingModule, TranslateModule.forRoot()],

      declarations: [],
      providers: [TranslateService]
    })
      .compileComponents();
    fixture = TestBed.createComponent(ForgotLoginComponent);
    commonHttpService = TestBed.get(HttpCommonService);

    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.countryCode = "ro";
    expect(component).toBeTruthy();
  });

  it('should call restrictPaste', () => {
    const countryCode = "ro";
    window.sessionStorage.setItem('countryCode', (countryCode));
    component.restrictPaste();
  });
  it('should call toggleFieldTextType', () => {
    component.toggleFieldTextType(true);
  });

  it('should call forgotLogin', () => {
    const data = null;
    spyOn(commonHttpService, 'postDataValueHeaders').and.returnValue(of(data));

    component.forgotLogin();
  })
});
