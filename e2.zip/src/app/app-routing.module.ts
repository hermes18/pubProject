import { NgModule } from '@angular/core';
import {
  Routes, RouterModule, PreloadingStrategy,
  PreloadAllModules
} from '@angular/router';
//import {AddNewClaimModule}from './add-new-claim/add-new-claim.module';
//import { LandingPageComponent } from './landing-page/landing-page.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { ErrorComponent } from './error/error.component';
import { SessionExpiredComponent } from './session-expired/session-expired.component';
import { PageNotFoundComponent } from './core/components';
// import { PolicyComponent } from './policy/policy.component';
// import { OrderComponent } from './order/order.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { LogoutComponent } from './logout/logout.component';
import { ContactFormComponent } from './contact-form/contact-form.component';

import { CanDeactivateGuardService } from './core/gaurds/can-deactivate-guard';
import { BroadcasterService } from './core/services/broadcaster.service';
import { NavigationGuard } from './core/gaurds/navigation-guard';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { ForgotLoginComponent } from './forgot-login/forgot-login.component';
import { NoDataComponent } from './no-data/no-data.component';
import { ErrorPageComponent } from './error-page/error-page.component';
// import { ChangePremiumSplitComponent } from './change-premium-split/change-premium-split.component';
// import { MyContractsComponent } from './contracts/my-contracts/my-contracts.component';

const routes: Routes = [

  { path: '', redirectTo: '/login', pathMatch: 'full' }, // redirect to `landing page component`
  //{ path: 'landing', component: LandingPageComponent },
  {
    path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule)
  },
  { path: 'access-denied', component: AccessDeniedComponent },
  { path: 'session-expired', component: SessionExpiredComponent },
  { path: 'error', component: ErrorComponent },
  { path: 'page-not-found', component: PageNotFoundComponent },
  // { path: 'policy', component: PolicyComponent },
  // { path: 'contact-form', component: ContactFormComponent },
  // { path: 'order', component: OrderComponent },
  { path: 'forgotlogin', component: ForgotLoginComponent, canDeactivate: [NavigationGuard] },
  { path: 'forgotpassword', component: ForgotPasswordComponent, canDeactivate: [NavigationGuard] },
  { path: 'changepassword', component: ChangePasswordComponent },
  { path: 'no-data', component: NoDataComponent, canDeactivate: [NavigationGuard] },
  { path: 'logout', component: LogoutComponent, canDeactivate: [NavigationGuard] },
  //{path:'change-premium-split',component: ChangePremiumSplitComponent, canDeactivate:[NavigationGuard]},
  {
    path: 'MyContracts',

    loadChildren: () => import('./contracts/contracts.module').then(m => m.ContractsModule)
  },

  {
    path: 'fakelanding',

    loadChildren: () => import('./fake-landing/fake-landing.module').then(m => m.FakeLandingModule)
  },
  //{ path: 'mycontracts', component: MyContractsComponent },
  // {
  //   path: 'newaccountError',
  //   loadChildren: () => import('./administration/newaccount-error/newaccount-error.module').then(m => m.NewaccountErrorModule)
  // },
  // {
  //   path: 'clientSearch',
  //   loadChildren: () => import('./administration/client-search/client-search.module').then(m => m.ClientSearchModule)
  // },  
  // {
  //   path: 'userdetail/:uId',
  //   loadChildren: () => import('./administration/user-details/user-details.module').then(m => m.UserDetailsModule)
  // }, 
  // {
  //   path: 'usersearch',
  //   loadChildren: () => import('./administration/user-search/user-search.module').then(m => m.UserSearchModule)
  // },
  {
    path: 'orderHistory',

    loadChildren: () => import('./orderstab/orderstab.module').then(m => m.OrderstabModule)
  },
  {
    path: 'mycompany',

    loadChildren: () => import('./my-company/my-company.module').then(m => m.MyCompanyModule)
  },
  {
    path: 'contracts',

    loadChildren: () => import('./contracts/contracts.module').then(m => m.ContractsModule)
  },
  {
    path: 'contactdetail',

    loadChildren: () => import('./contact-details/contact-details.module').then(m => m.ContactDetailsModule)
  },
  {
    path: 'homepage',

    loadChildren: () => import('./home-page/home-page.module').then(m => m.HomePageModule)
  },
  {
    path: 'announcement',

    loadChildren: () => import('./announcement-display/announcement-display.module').then(m => m.AnnouncementDisplayModule)
  },
  {
    path: 'contact-form',

    loadChildren: () => import('./contact-form/contact-form.module').then(m => m.ContactFormModule)
  },
  {
    path: 'setting',

    loadChildren: () => import('./setting/setting.module').then(m => m.SettingModule)
  },
  {
    path: 'setting/account-setting',

    loadChildren: () => import('./setting/setting.module').then(m => m.SettingModule)
  },
  {
    path: 'setting/change-password',

    loadChildren: () => import('./setting/setting.module').then(m => m.SettingModule)
  },
  {
    path: 'administartion',

    loadChildren: () => import('./administration/administration.module').then(m => m.AdministrationModule)
  },
  {
    path: 'registeruser',

    loadChildren: () => import('./register-user/register-user.module').then(m => m.RegisterUserModule)
  },
  {
    path: 'myOffers',
    loadChildren: () => import('./my-offers/my-offers.module').then(m => m.MyOffersModule)
  },
  {
    path: 'myClaim',
    loadChildren: () => import('./my-claim/my-claim.module').then(m => m.MyClaimModule)
  },
  {
    path: 'fundPriceMonitoring',
    loadChildren: () => import('./fund-price-monitoring/fund-price-monitoring.module').then(m => m.FundPriceMonitoringModule)
  },
  {
    path: 'document',
    loadChildren: () => import('./documents/documents.module').then(m => m.DocumentsModule)
  },
  { path: 'errorPage', component: ErrorPageComponent },

  {
    path: 'contract-details',
    loadChildren: () => import('./contract-details/contract-details.module').then(m => m.ContractDetailsModule)
  },
  // {
  //   path: 'change-premium-split',
  //   loadChildren: () => import('./change-premium-split/change-premium-split-module').then(m => m.ChangePremiumSplitModule)
  // },
  {
    path: 'order',

    loadChildren: () => import('./order/order.module').then(m => m.OrderModule)
  },
  {
    path: 'personalInfo',
    loadChildren: () => import('./personal-data/personal-data.module').then(m => m.PersonalDataModule)
  },
  {
    path: 'wardenContract',
    loadChildren: () => import('./warden-contract/warden-contract.module').then(m => m.WardenContractModule)
  }
  /*,
  { path: 'existedClaim', component: ExistingClaimComponent, resolve:{         
    existClaimData:ExistingClaimResolve  
  }  },
  { path: 'newClaim', component: AddNewClaimComponent, resolve:{         
    existClaimData:ExistingClaimResolve  
  }  
}*/

  /*{ path: 'newClaim',
   data: { preload: true },
   loadChildren: () =>  AddNewClaimModule},
   */
  //{ path: '**', pathMatch: 'full', redirectTo: '/landing' } // catch any unfound routes and redirect to home page

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules, useHash: true, onSameUrlNavigation: 'reload', scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule],
  providers: [CanDeactivateGuardService, BroadcasterService]
})
export class AppRoutingModule { }
