import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { AppModule } from '../app.module';

import { RegisterUserComponent } from './register-user.component';
import { RegisterUserModule } from './register-user.module';

describe('RegisterUserComponent', () => {
  let component: RegisterUserComponent;
  let fixture: ComponentFixture<RegisterUserComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'getQuestionSet': host + '/api/v1/users/security-questions'

      }
    }
  };

  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule, AppModule, RegisterUserModule, HttpClientTestingModule, TranslateModule.forRoot()],
  //     providers: [{ provide: APP_BASE_HREF, useValue: '/' }],
  //     declarations: []
  //   })
  //     .compileComponents();
  // }));

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, RegisterUserModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(RegisterUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('termsOfService should call termsOfService ', () => {
    
    spyOn(component, 'termsOfService').and.callThrough();
    component.termsOfService();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.termsOfService();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.termsOfService();
    expect(component.termsOfService).toHaveBeenCalled();
  });
  it('siteSecurity should call siteSecurity ', () => {
    
    spyOn(component, 'siteSecurity').and.callThrough();
    component.siteSecurity();
    sessionStorage.setItem("defaultLanguage","ro_ro");
    component.siteSecurity();
    sessionStorage.setItem("defaultLanguage","ro_en");
    component.siteSecurity();
    expect(component.siteSecurity).toHaveBeenCalled();
  });
    it('should call form submitValue', () => {
    component.  submitValue() ;
  });
});
