import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AppConfig } from 'src/config/app.config';
import { HttpCommonService } from '../shared/services/http-common.service';
import { RegisterUserModel } from './model/register-user.model';
import { DeviceDetectorService } from 'ngx-device-detector';

@Component({
  selector: 'register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.scss']
})
export class RegisterUserComponent implements OnInit {

  @ViewChild('tooltip1', { static: false }) tooltip1;
  @ViewChild('tooltip2', { static: false }) tooltip2;
  @ViewChild('tooltip3', { static: false }) tooltip3;

  @HostListener('window:scroll', ['$event'])
  scrollHandler(event) {
    this.tooltip1 ? this.tooltip1.hide() : '';
    this.tooltip2 ? this.tooltip2.hide() : '';
    this.tooltip3 ? this.tooltip3.hide() : '';
  }
  questionSet2: any;
  questionSet1: any;
  registerCompModel: RegisterUserModel;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(public fb: FormBuilder, public deviceDetector: DeviceDetectorService, public commonService: HttpCommonService) {
    this.registerCompModel = new RegisterUserModel();
  }

  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.registerCompModel.registerFormGroup = this.fb.group({
      clientIdentifier: ['', [Validators.required]],
      question: ['', Validators.required],
      answer: ['', [Validators.required, Validators.minLength(3)]],
      question2: ['', Validators.required],
      answer2: ['', [Validators.required, Validators.minLength(3)]],
      emailId: ['', Validators.required],
      acceptCondition: ['', Validators.required],
      loginId: ['', Validators.required],
    })
  }
  get f() { return this.registerCompModel.registerFormGroup.controls; }

  ngAfterViewInit() {
    let url = this.baseUrl.ecustomer.getQuestionSet;
    this.commonService['getDataValueHeaders'](url, '').subscribe(data => {
      this.registerCompModel.questionSet = data
      this.questionSet1 = data;
      this.questionSet2 = data;
    })
  }

  toggleFieldTextType(textType) {
    this.registerCompModel[textType] = !this.registerCompModel[textType];
  }


  submitValue() {
    this.registerCompModel.submitted = true;
    let headerOptions = {
      headers: new HttpHeaders({
        'accept-language': sessionStorage.getItem('defaultLanguage'),
        'x-tenant-id': sessionStorage.getItem('countryCode'),
        'x-system-id': 'ecustomer',
        'content-type': 'application/json',
        'accept': 'application/json'
      })
    };



    Object.keys(this.registerCompModel.registerFormGroup.controls).forEach(key => {
      if (key !== 'acceptCondition' && key !== 'question' && key !== 'question2') {
        if (this.registerCompModel.registerFormGroup.controls[key].value.trim() == '') {
          this.registerCompModel.registerFormGroup.controls[key].setErrors({ 'required': true });
          this.registerCompModel.registerFormGroup.controls[key].setValue('');
        }
      }
    });
    this.registerCompModel.answerFlag = false;
    if (this.registerCompModel.registerFormGroup.valid && ((this.registerCompModel.registerFormGroup.controls['answer'].value).toUpperCase() ===
      (this.registerCompModel.registerFormGroup.controls['answer2'].value).toUpperCase())) {
      this.registerCompModel.answerFlag = true;
      return;
    }
    if (this.registerCompModel.registerFormGroup.valid &&
      this.registerCompModel.registerFormGroup.controls['acceptCondition'].value != 'false') {
      this.registerCompModel.successForgotLogin = true;
      let clientdetails = {
        clientIdentifier: this.registerCompModel.registerFormGroup.value.clientIdentifier,
        securityAnswer: this.registerCompModel.registerFormGroup.value.answer,
        securityQuestion: this.registerCompModel.registerFormGroup.value.question,
        securityAnswer2: this.registerCompModel.registerFormGroup.value.answer2,
        securityQuestion2: this.registerCompModel.registerFormGroup.value.question2,
        email: this.registerCompModel.registerFormGroup.value.emailId,
        preferredUserId: this.registerCompModel.registerFormGroup.value.loginId
      }

      let registerUserUrl = this.baseUrl.ecustomer.registerUser;
      this.commonService['postDataWithHeader'](registerUserUrl, JSON.stringify(clientdetails), headerOptions).subscribe();
    }
  }


  termsOfService() {
    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'ro_ro': window.open("/assets/mocks/Terms_condition_Ro_ro.pdf");
        break;
      case 'ro_en': window.open("/assets/mocks/Terms_condition_Ro_en.pdf");
        break;
    }
  }
  siteSecurity() {

    let language = sessionStorage.getItem("defaultLanguage");

    switch (language) {
      case "ro_ro": window.open("/assets/mocks/MetLife_Politica_de_prelucrare_date_clienti_Life_si_NonLife_aug2019.pdf");
        break;
      case "ro_en": window.open("/assets/mocks/MetLife_Politica_de_prelucrare_date_clienti_Life_si_NonLife_aug2019.pdf");
        break;
    }
  }


  question1Change(value) {
    this.questionSet2 = [];
    this.questionSet2 = this.registerCompModel.questionSet.filter(function (el) {
      return value.indexOf(el) < 0;
    });
    //console.log(this.questionSet1)
  }

  question2DropdownChange(value) {
    this.questionSet1 = [];
    this.questionSet1 = this.registerCompModel.questionSet.filter(function (el) {
      return value.indexOf(el) < 0;
    });
    //   this.questionSet.forEach((data)=>{
    //     if(data == value){
    //     }else{
    //      this.questionSet2.push(this.questionSet.slice(data,1));
    //console.log(this.questionSet2)
    //     }
    // });
  }

}
