import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { RegisterUserComponent } from './register-user.component';


const routes: Routes = [
  { path: '', component: RegisterUserComponent, canDeactivate: [NavigationGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RegisterUserRoutingModule { }
