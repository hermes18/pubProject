import { FormGroup } from '@angular/forms';


export class RegisterUserModel {
    registerFormGroup: FormGroup;
    subscribeFlag: boolean;
    submitted: boolean;
    questionSet: any;
    showAlert: boolean;
    successForgotLogin: boolean;
    answerFlag: boolean;
    registerCNPFieldTextType: boolean;
    constructor() {
        this.subscribeFlag = true;
        this.submitted = false;
        this.successForgotLogin = false;
        this.showAlert = false;
        this.answerFlag = false;
        this.registerCNPFieldTextType = false;
    }

}