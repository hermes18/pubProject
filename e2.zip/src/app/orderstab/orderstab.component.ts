import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'orderstab',
  templateUrl: './orderstab.component.html',
  styleUrls: ['./orderstab.component.scss']
})
export class OrderstabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
