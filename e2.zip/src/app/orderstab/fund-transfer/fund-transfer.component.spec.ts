import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from 'src/app/app.module';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { OrderstabModule } from '../orderstab.module';

import { FundTransferComponent } from './fund-transfer.component';

describe('FundTransferComponent', () => {
  let component: FundTransferComponent;
  let fixture: ComponentFixture<FundTransferComponent>;
  let appConfig: AppConfig = AppConfig.getConfig();

  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'fundTransferHistory': host + '/api/v1/order/order-request-object',
        'printPdfGeneration': host + '/api/v1/order/service-request-pdf-generation',
        'statementPdf': host + '/api/v1/order/statement-pdf',
        'fundExternalLink': host + '/api/v1/policy/fund-configurations'
      }
    }
  };
const response = {"id":"00000000000000409595_00000001619186943953_00088",
"policyNumber":"21295126","serviceRequestId":"00002040",
"createDate":"23.04.2021, 02:09:03","lastModifiedDate":"23.04.2021, 02:57:34",
"userId":"JDaniel_PL","actionedBy":"Prabhu Jaison",
"acknowledgedBy":"JDaniel_PL","status":"Processing",
"serviceRequestType":"46","sourceSystem":"eCustomer",
"renderOrderIdAsLink":false,"renderPolicynumberMsg":false,
"requestingSystem":"eCustomer","processingSystem":"OLAS",
"cutOffTime":61200000,"orderStatusDate":1619189854509,
"orderCancellationLevel":0,
"fundTransferOrderDTO":{"sourceFundsOrderDetails":
[{"fundId":"OLAS|007","fundName":"AFK OBLIGACJI ","allocationPercentage":"70","transferPrencentage":null}],"targetFundsOrderDetails":[{"fundId":"OLAS|001","fundName":"OBLIGACYJNY ","allocationPercentage":"50","transferPrencentage":null},{"fundId":"OLAS|002","fundName":"FUNDUSZ ZRÓWNOWAŻONEGO WZROSTU ","allocationPercentage":"50","transferPrencentage":null}],"forcedAllocationChangeFlag":"NOT"},"language":"pl_en","country":"pl","createDateUI":"23.04.2021, 16:09:03","investAccNumberTip":"InvestAccountTypeInfoTip1","statementButtonRender":false,"renderRealizationDate":false,"requesting":{"firstName":null,"lastName":null,"email":null,"createDate":null,"requesterContactInfoDTO":null,"userAddressDetailDTO":null,"beneficiaryDTO":null,"fundVctr":null,"policyCancellationDTO":null,"policyReinstatementVctr":null,"clientId":null,"userName":"Prabhu Jaison","userLogin":"JDaniel_PL","clientLogin":"UserIdNotFound","clientName":""},
"invest":{"contractNumber":"21295126","investAccNumber":"21295126","effectiveDate":"15.06.2010","status":23,"investValue":5620.17,"productPlan":"UB2B000K3","valuationDt":1380664800000,"accountType":1,
"fundSingleInvAccounts":[{"investAccNumber":"21295126","fundId":"OLAS|007","units":218.17430000,"unitPrice":25.76000000,"fundValue":5620.1700,"valuationDate":1380664800000,
"fundConfigurationDTO":{"fundId":"OLAS|007","fundName":"AFK OBLIGACJI ","closeDate":null,"fundExternalLink":"cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS007","system":"OLAS","flag":"true","sort":35,"unitPriceDec":2,"unitLinkedPolicy":null,"unitPrice":null},"allocationPercentage":100}],
"productPlanConfigDTO":null,"investAccType":1,"policyNumber":"21295126","bankAccount":"59 1030 1944 9000 0500 2129 5126","accountNumber":"59 1030 1944 9000 0500 2129 5126"}}

let menuItemList = {
  "activeContractDetails": null,
  "billingRecipent": null,
  "callRetrievePolicies": false,
  "callRetriveClientData": false,
  "callRetriveClientOffers": false,
  "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
  "claimList": null,
  "clientAdministration": true,
  "clientId": "78667",
  "clientIdList": [],
  "clientIdbillControlList": [],
  "clientLoginId": null,
  "clientRoleIds": "3032|3033|3034",
  "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
  "contractList": [{
    "benefitType": "SuperKapitał",
    "businessRoleList": ["insured", "owner"],
    "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
    "contractNumber": "21223250",
    "contractNumberList": null,
    "effectiveDate": "28.11.2007",
    "indexedPremiumAmount": null,
    "insuredName": "INSURED_21223250",
    "premiumAmount": null,
    "premiumAmt": null,
    "premiumAmtType": "17",
    "premiumDueDate": null,
    "premiumPaymentMode": null,
    "premiumType": "17",
    "processingSystem": "OLAS",
    "status": 22
  }],
  "personalInformationDTO": {
    "dateOfBirth": null,
    "emailBasic": "cosmin.misici@gmail.com",
    "emailSecondary": null,
    "firstName": "COSMIN ADRIAN",
    "flagOfCapabilityOfChangeData": "true",
    "gender": null,
    "identifier": null,
    "identifierType": null,
    "lastName": "MISICI",
    "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
    "mobile": null,
    "mobilePhone": "0723347690",
    "officeFax": null,
    "policyNumber": null,
    "postalCode": null,
    "residenceFax": null,
    "residenceTelephone": "",
    "safePhone": null,
    "updatedEmailBasic": null,
    "updatedEmailSecondary": null,
    "updatedMobile": null,
    "updatedResidenceTelephone": null,
    "updatedSafePhone": null,
    "updatedmarketingConsentList": null,
    "versionMarker": "2020-12-22T12:13:17.867"
  },
  "documentsList": null,
  "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
  "fundPriceDetails": null,
  "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
  "offerResponse": null,
  "orderHistory": null,
  "renderClaims": false,
  "renderDocuments": false,
  "renderFundPriceMonitoring": false,
  "renderMyCompany": false,
  "renderMyContract": false,
  "renderMyData": false,
  "renderOffers": false,
  "renderOrderReview": false,
  "renderUserAcctAdministration": true,
  "route": "DisplayClientSearch",
  "searchFlag": false,
  "wardenRoleCheck": false
};


const serachClient =
{ "clientId": 1234, "opeType": "search" };

const userImfo =
{ "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" };

  beforeEach(() => {
    const data = {
      "login": "OsamaAdmin",
      "orderDate": "09.12.2020",
      "orderNumber": "00001055",
      "orderType": "44",
      "refersToContract": "21280988",
      "status": "Processing"
    }
    window['__env'].environmentConstURLs = environmentConstURL;
    const countryCode = "ro";
    window.sessionStorage.setItem('countryCode', JSON.stringify(countryCode));
    window.sessionStorage.setItem('orderData', JSON.stringify(data))
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, OrderstabModule, HttpClientTestingModule, TranslateModule.forRoot()],

      declarations: [],
      providers: [TranslateService, HttpCommonService]
    })
      .compileComponents();
    fixture = TestBed.createComponent(FundTransferComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(FundTransferComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    const reqParam =
      "121212";
    const response =
      { "id": "00000000000000060704_00000001607523918942_00013", "policyNumber": "21280988", "serviceRequestId": "00001055", "createDate": "09.12.2020, 02:25:18", "lastModifiedDate": "09.12.2020, 02:48:05", "userId": "OsamaAdmin", "actionedBy": "Osama M", "acknowledgedBy": "OsamaAdmin", "status": "Processing", "closureDate": 1607523918066, "serviceRequestType": "44", "investAccountNumber": "21280988", "sourceSystem": "eCustomer", "renderOrderIdAsLink": false, "clientId": "10013", "fundInjectionDetaislDTO": { "fundDTO": null, "premiumAmount": null, "totalPercentage": null, "injectionType": null, "additionalTopUpUnits": null, "addTopUpUnitsForLumpSum": "800", "totalAmountWithTopUp": null, "fundSelectionType": null, "totalAmount": null, "currencyType": null, "maxPaymentPeriod": "10", "additionalCoverageAmount": null }, "investAccountDTO": { "investAccountNumber": "21280988", "investAccountType": 1, "productPlan": " UB2BTEB07", "bankAccountNumber": "90 1030 1944 9000 0500 2128 0988", "funds": null }, "renderPolicynumberMsg": false, "requestingSystem": "eCustomer", "processingSystem": "OLAS", "cutOffTime": 45000000, "orderCutOffTime": "12/09/2020", "orderStatusDate": 1607525285746, "orderCancellationLevel": 0, "fundTransferOrderDTO": { "sourceFundsOrderDetails": null, "targetFundsOrderDetails": null, "forcedAllocationChangeFlag": null }, "language": "pl_en", "country": "pl", "loggedInUserFirstName": "Osama", "loggedInUserLastName": "M", "loggedInUserId": "OsamaAdmin", "declaredPaymentAmount": "800", "requesting": { "firstName": null, "lastName": null, "email": null, "createDate": null, "requesterContactInfoDTO": null, "userAddressDetailDTO": null, "beneficiaryDTO": null, "fundVctr": null, "policyCancellationDTO": null, "policyReinstatementVctr": null, "clientId": null, "userName": "Osama M", "clientName": "OsamaAdmin", "clientLogin": "OsamaAdmin", "userLogin": "OsamaAdmin" }, "invest": { "contractNumber": "21280988", "investAccNumber": "21280988", "effectiveDate": "17.11.2009", "status": 23, "investValue": 2130.08, "productPlan": " UB2BTEB07", "valuationDt": 1332268200000, "accountType": 1, "fundSingleInvAccounts": [{ "investAccNumber": "21280988", "fundId": "OLAS|001", "units": 15.9125, "unitPrice": 27.43, "fundValue": 436.48, "valuationDate": 1332268200000, "fundConfigurationDTO": { "fundId": "OLAS|001", "fundName": "FUNDUSZ STABILNY ", "closeDate": null, "fundExternalLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS001", "system": "OLAS", "flag": "FALSE", "sort": 1, "unitPriceDec": null }, "allocationPercentage": 20 }, { "investAccNumber": "21280988", "fundId": "OLAS|003", "units": 72.4999, "unitPrice": 23.36, "fundValue": 1693.6, "valuationDate": 1332268200000, "fundConfigurationDTO": { "fundId": "OLAS|003", "fundName": "FUNDUSZ DYNAMICZNY ", "closeDate": null, "fundExternalLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003", "system": "OLAS", "flag": "FALSE", "sort": 3, "unitPriceDec": null }, "allocationPercentage": 80 }], "productPlanConfigDTO": null, "investAccType": 1, "policyNumber": "21280988", "bankAccount": "90 1030 1944 9000 0500 2128 0988", "accountNumber": "90 1030 1944 9000 0500 2128 0988" } };
    spyOn(HttpCommonService.prototype, 'postData').and.returnValue(of(response));
    sessionStorage.setItem('countryCode','ro');
    const orderdata = {
      "login": "OsamaAdmin",
      "orderDate": "09.12.2020",
      "orderNumber": "00001055",
      "orderType": "44",
      "refersToContract": "21280988",
      "status": "Processing"
    }
    sessionStorage.setItem('orderData',JSON.stringify(orderdata));
    sessionStorage.setItem('defaultLanguage','ro_ro');
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));
    sessionStorage.setItem('menuItemList', JSON.stringify(menuItemList));
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    // component.reviewResponse = response;
    component.getFundHistoryDetail(reqParam);
    expect(component).toBeTruthy();
  });

  it('call navigate to orders tab method', () => {
    spyOn(component, 'backOrderPage').and.callThrough();
    component.backOrderPage();
    expect(component.backOrderPage).toHaveBeenCalled();
  });

  it('call gotoHome method', () => {
    spyOn(component, 'gotoHome').and.callThrough();
    component.gotoHome();
    expect(component.gotoHome).toHaveBeenCalled();
  });

  it('call downloadPdf method', () => {
    spyOn(component, 'downloadPdf').and.callThrough();
    component.downloadPdf();
    expect(component.downloadPdf).toHaveBeenCalled();
  });

  it('call externalLink method', () => {
    spyOn(component, 'externalLink').and.callThrough();
    component.externalLink("OLAS|007");
    expect(component.externalLink).toHaveBeenCalled();
  });

  it('call fund history detail method', () => {
    spyOn(component, 'getFundHistoryDetail').and.callThrough();
    component.getFundHistoryDetail("00002040");
    expect(component.getFundHistoryDetail).toHaveBeenCalled();
  });
});