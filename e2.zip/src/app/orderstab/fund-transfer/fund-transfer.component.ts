import { Component, OnInit } from '@angular/core';
import { MatDialog, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { ConfirmDialogModel, DownloadfileDialogComponent } from 'src/app/shared/dialog/downloadfile-dialog/downloadfile-dialog.component';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';

export interface SourceFundsOrder {
  fundName: String;
  fundId: String;
  allocationPercentage: String;
  transferPrencentage: String;
}
export interface TargetFundsOrder {
  fundName: String;
  fundId: String;
  keyLink: String;
  allocationPercentage: String;
  transferPrencentage: String;
}

@Component({
  selector: 'fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.scss']
})
export class FundTransferComponent implements OnInit {

  reviewResponse;
  investData;
  sourceFundsOrderDetailsList;
  targetFundsOrderDetailsList;
  dataSourceSourceFundsOrder: MatTableDataSource<SourceFundsOrder>;
  dataSourceTargetFundsOrder: MatTableDataSource<TargetFundsOrder>;

  displayedColumnsSource: String[] = [
    'fundName',
    'fundId',
    'allocationPercentage'];
  displayedColumnsSourceMob: String[] = [
    'fundName', 'allocationPercentage',
    'fundId',
  ];
  displayedColumnsTarget: String[] = [
    'fundName',
    'fundId',
    'allocationPercentage'];
  displayedColumnsTargetMob: String[] = [
    'fundName', 'allocationPercentage',
    'fundId',
  ];
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  additionalPremiumDetails;
  fundDetails;
  country;
  showMsg: any;
  constructor(public commonService: HttpCommonService, private readonly router: Router, private menuItemService: MenuItemsService,
    public dialog: MatDialog, public translate: TranslateService) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    const data = JSON.parse(sessionStorage.getItem('orderData'));
    this.fundDetails = data;
    const reqParam =
      data.orderNumber;
    // const reqParam = {
    //   "orderId": data.orderNumber 
    // };

    let url = `${this.baseUrl.ecustomer.indexationOrderHistory}/${data.orderNumber}`;
    this.getFundHistoryDetail(reqParam);

  }

  getFundHistoryDetail(reqParam) {
    this.commonService.postData(this.baseUrl.ecustomer.fundTransferHistory, reqParam, '').subscribe(data => {
      this.reviewResponse = data;
      this.investData = (data && data.invest && data.invest.fundSingleInvAccounts) ? data.invest.fundSingleInvAccounts : '';

      this.sourceFundsOrderDetailsList = data && data.fundTransferOrderDTO ? data.fundTransferOrderDTO.sourceFundsOrderDetails : '';
      this.targetFundsOrderDetailsList = data && data.fundTransferOrderDTO ? data.fundTransferOrderDTO.targetFundsOrderDetails : '';
      this.dataSourceSourceFundsOrder = new MatTableDataSource(this.sourceFundsOrderDetailsList);
      this.dataSourceTargetFundsOrder = new MatTableDataSource(this.targetFundsOrderDetailsList);

    });
  }

  backOrderPage() {
    this.router.navigate(['/orderHistory']);
  }

  externalLink(fundId) {


    // if (this.investData != null && this.investData != '') {
    //   for (let i = 0; i < this.investData.length; i++) {
    //     if (this.investData[i].fundConfigurationDTO.fundId === fundId) {
    //       url = this.investData[i].fundConfigurationDTO.fundExternalLink
    //     }
    //   }
    //   if (url != null && url != '') {

    //     window.open("//" + url, '_blank');
    //   }
    // }
    let param = {
      "fundId": fundId
    }
    this.commonService.postData(this.baseUrl.ecustomer.fundExternalLink, param, '').subscribe(data => {

      let fundExternalLink = data.fundExternalLink
      if (data && data.fundExternalLink) {
        window.open('//' + fundExternalLink, '_blank');
      }
    })
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }


  downloadPdf() {
    const message = this.translate.instant("eCustomer.orderReport.CacheWarning");
    //("msg", message)
    const dialogData = new ConfirmDialogModel("Confirm Action", message);
    const dialogRef =
      this.dialog.open(DownloadfileDialogComponent, { data: dialogData });
    dialogRef.afterClosed().subscribe(result => {
      //(result)
      if (result === true) {
        let dateTranslate = {
          'pl_en': 'en',
          'pl_pl': 'pl',
          'ro_ro': 'ro',
          'ro_en': 'en',
          'gr_gr': 'gr',
          'gr_en': 'en'
        }
        let language = sessionStorage.getItem('defaultLanguage')
        const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
        const customerDetails = JSON.parse(sessionStorage.getItem('searcClientID'));
        let clientId = '';
        if (customerDetails && customerDetails.clientID) {
          clientId = customerDetails.clientID;
        }
        else if (loggedUser['requesterId'] && loggedUser['requesterId'] != -1) {
          clientId = loggedUser['requesterId'];
        }
        const reqParam =
        {
          "orderId": this.fundDetails.orderNumber,
          "language": dateTranslate[language],
          "closureDate": this.reviewResponse && this.reviewResponse.estResolutionDate ? this.reviewResponse.estResolutionDate : null,
          "loggedInUserFirstName": loggedUser['firstName'],
          "loggedInUserLastName": loggedUser['lastName'],
          "loggedInUserId": loggedUser['userName'],
          "clientId": clientId,
        }
        // //(reqParam)
        this.commonService.postData(this.baseUrl.ecustomer.printPdfGeneration, reqParam, '').subscribe(data => {


          // //(data)
          const byteCharacters = atob(data.data);

          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);

          let blob = new Blob([byteArray], { type: "application/pdf" });
          if (window.navigator.msSaveOrOpenBlob) {

            window.navigator.msSaveOrOpenBlob(blob);
          } else {
            let url = window.URL.createObjectURL(blob);
            window.open(url);
          }
        });
      }
    });
  }

  openTooltipMsg() {
    if (this.reviewResponse.investAccNumberTip == 'InvestAccountTypeInfoTip5') {
      if (!this.showMsg) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
      }
    }
  }

  generateStatementPdf() {
    const message = this.translate.instant("eCustomer.orderReport.CacheWarning");
    //("msg", message)
    const dialogData = new ConfirmDialogModel("Confirm Action", message);
    const dialogRef =
      this.dialog.open(DownloadfileDialogComponent, { data: dialogData });
    dialogRef.afterClosed().subscribe(result => {
      //(result)
      if (result === true) {
        let request = {
          "requestId": this.reviewResponse.serviceRequestId ? this.reviewResponse.serviceRequestId : null,
          "userFirstName": this.reviewResponse.requesting.firstName ? this.reviewResponse.requesting.firstName : null,
          "userLastName": this.reviewResponse.requesting.lastName ? this.reviewResponse.requesting.lastName : null,
          "userLogin": this.reviewResponse.requesting.userLogin ? this.reviewResponse.requesting.userLogin : null,
          "depositAmount": null,
          "orderType": this.reviewResponse.serviceRequestType ? this.reviewResponse.serviceRequestType : null,//update this no according to the order type! – 44/45/46/47
          // "policyNumber": this.reviewResponse.invest.policyNumber ? this.reviewResponse.invest.policyNumber : null
        }
        this.commonService.postData(this.baseUrl.ecustomer.statementPdf, request, '').subscribe(data => {
          //console.log(data);
          const byteCharacters = atob(data.data);

          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);

          let blob = new Blob([byteArray], { type: "application/pdf" });
          if (window.navigator.msSaveOrOpenBlob) {

            window.navigator.msSaveOrOpenBlob(blob);
          } else {
            let url = window.URL.createObjectURL(blob);
            window.open(url);
          }
        });
      }
    });
  }

}
