import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { AdditionalContractPremiumComponent } from './additional-contract-premium/additional-contract-premium.component';
import { AdditionalPremiumComponent } from './additional-premium/additional-premium.component';
import { ChangepremimumReviewComponent } from './changepremimum-review/changepremimum-review.component';
import { IndexationOrderComponent } from './indexation-order/indexation-order.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { OrderstabComponent } from './orderstab.component';
import { ClientDataChangeComponent } from './client-data-change/client-data-change.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';


const routes: Routes = [
  {
    path: '', component: OrderstabComponent, canDeactivate: [NavigationGuard],
    children: [
      { path: '', component: OrderHistoryComponent, canDeactivate: [NavigationGuard] },
      { path: 'indexationorderhistory', component: IndexationOrderComponent, canDeactivate: [NavigationGuard] },
      { path: 'allocationChange', component: ChangepremimumReviewComponent, canDeactivate: [NavigationGuard] },
      { path: 'additionalContributionSave', component: AdditionalContractPremiumComponent, canDeactivate: [NavigationGuard] },
      { path: 'singlePremiumSave', component: AdditionalPremiumComponent, canDeactivate: [NavigationGuard] },
      { path: 'clientDataChange', component: ClientDataChangeComponent, canDeactivate: [NavigationGuard] },
      { path: 'fundtransfer', component: FundTransferComponent, canDeactivate: [NavigationGuard] }
    ]
  }



];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrderstabRoutingModule { }
