import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { OrderstabRoutingModule } from './orderstab-routing.module';
import { OrderstabComponent } from './orderstab.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter, MatDatepickerIntl, NativeDateAdapter } from '@angular/material';
import {
  MatDatepickerModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatTableModule, MatPaginatorModule, MatListModule,
} from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { NgxPaginationModule } from 'ngx-pagination';
import { SharedModule } from '../shared/shared.module';
import { IndexationOrderComponent } from './indexation-order/indexation-order.component';
import { ChangepremimumReviewComponent } from './changepremimum-review/changepremimum-review.component';
import { AdditionalContractPremiumComponent } from './additional-contract-premium/additional-contract-premium.component';
import { AdditionalPremiumComponent } from './additional-premium/additional-premium.component';
import { ClientDataChangeComponent } from './client-data-change/client-data-change.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};

export class CustomDatePickerAdapter extends NativeDateAdapter {

  parse(value: any): Date | null {
    ////(value);
    if ((typeof value === 'string') && (value.indexOf('/') > -1)) {
      const str = value.split('/');
      const year = Number(str[2]);
      const month = Number(str[1]) - 1;
      const date = Number(str[0]);
      // //("year, month, date",year, month, date)
      ////("year, month, date",new Date(year, month, date))
      if (year > 0 && month < 12 && date > 0 && date <= 31) {
        return new Date(year, month, date);
      }


    }
    const timestamp = typeof value === 'number' ? value : Date.parse(value);
    ////("timestamp",timestamp)
    return isNaN(timestamp) ? null : new Date(timestamp);
  }

  private _to2digit(n: number) {
    ////("_to2digit",('00' + n).slice(-2))
    return ('00' + n).slice(-2);
  }
  format(date: Date, displayFormat: string): string {
    ////(displayFormat," ------>",date,displayFormat )

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    ////("input",(this._to2digit(day) + '/' + this._to2digit(month) + '/' + year) )
    return this._to2digit(day) + '/' + this._to2digit(month) + '/' + year;

  }
}

@NgModule({
  declarations: [OrderstabComponent, OrderHistoryComponent, IndexationOrderComponent, ChangepremimumReviewComponent,
    AdditionalContractPremiumComponent, AdditionalPremiumComponent, ClientDataChangeComponent, FundTransferComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    OrderstabRoutingModule,
    MatDatepickerModule,
    SharedModule,
    MatInputModule, MatTableModule, MatPaginatorModule,
    MatSelectModule, MatFormFieldModule,
    NgxPaginationModule,
    TranslateModule

  ],
  exports: [OrderHistoryComponent],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {
      provide: DateAdapter,
      useClass: CustomDatePickerAdapter

    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ]

})
export class OrderstabModule { }
