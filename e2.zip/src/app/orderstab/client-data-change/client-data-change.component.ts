import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PersonalDataService } from '../../personal-data/personal-data.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { MatDialog, MatTableDataSource } from '@angular/material';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmDialogModel, DownloadfileDialogComponent } from 'src/app/shared/dialog/downloadfile-dialog/downloadfile-dialog.component';

import { countryList, UtilityService } from '../../shared/utilities/utility.service';
@Component({
  selector: 'client-data-change',
  templateUrl: './client-data-change.component.html',
  styleUrls: ['./client-data-change.component.scss']
})
export class ClientDataChangeComponent implements OnInit {

  loggedInCountry = sessionStorage.getItem("countryCode");
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  loggedInCountryCheck = UtilityService.getCountry();

  constructor(private readonly router: Router,
    public personalDataService: PersonalDataService,
    public commonService: HttpCommonService, private menuItemService: MenuItemsService,
    public sharedService: SharedServiceService, public dialog: MatDialog, public translate: TranslateService) { }
  newPersonalData: any;
  orderId: any;
  ngOnInit() {
    if (sessionStorage.getItem('personalDataOrderId')) {
      this.orderId = sessionStorage.getItem('personalDataOrderId');

    }
    this.orderDetailsService();
    this.sharedService.getLangChange().subscribe((data) => {
      if (this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')]) {
        this.countryList = this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')];
      } else {
        this.getCountryList();
      }

    });
  }
  countryList: any;
  getCountryList() {
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.countryList;
    this.commonService['getData'](url).subscribe(data => {
      ////("data", data);
      this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')] = data;
      this.countryList = data;

    });
  }
  closuredate: any;
  orderDetailsService() {
    //this.router.navigate(['/orderHistory/clientDataChange']); 
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerDetails = JSON.parse(sessionStorage.getItem('searcClientID'));
    let clientId = '';
    if (customerDetails && customerDetails.clientID) {
      clientId = customerDetails.clientID;
    }
    else if (loggedUser['requesterId'] && loggedUser['requesterId'] != -1) {
      clientId = loggedUser['requesterId'];
    }
    let req = {
      "orderId": this.orderId,
      "clientId": clientId
      //"orderId":  "00000720"
    }

    //(req);
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.personalOrderDetails;
    this.commonService['postData'](url, req, headers).subscribe(data => {
      //("data", data);


      if (data) {
        if (data.hasOwnProperty('validUser') && (data.validUser == false)) {
          this.router.navigate(['/logout']);
        } else {
          this.existingPersonalData = data;
          this.existingAddressList = data.policyAddressList;
          this.newPersonalData = data.addressChange;
          this.closuredate = data.estResolutionDate;
        }
      }

    });
  }
  existingPersonalData: any;
  existingAddressList: any = [];

  generatePdf() {

    const message = this.translate.instant("eCustomer.orderReport.CacheWarning");
    //("msg", message)
    const dialogData = new ConfirmDialogModel("Confirm Action", message);
    const dialogRef = this.dialog.open(DownloadfileDialogComponent, { data: dialogData });
    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
        const customerDetails = JSON.parse(sessionStorage.getItem('searcClientID'));
        let clientId = '';
        if (customerDetails && customerDetails.clientID) {
          clientId = customerDetails.clientID;
        }
        else if (loggedUser['requesterId'] && loggedUser['requesterId'] != -1) {
          clientId = loggedUser['requesterId'];
        }
        let req = {
          "orderId": this.orderId,
          "language": "en",
          "loggedInUserFirstName": loggedUser['firstName'],
          "loggedInUserLastName": loggedUser['lastName'],
          "loggedInUserId": loggedUser['userName'],
          "clientId": clientId,
          "closureDate": this.closuredate
        }
        let headers = new HttpHeaders();
        let url = this.baseUrl.ecustomer.personalDataPdfGen;
        this.commonService['postData'](url, req, headers).subscribe(data => {

          this.downloadPdf(data);
        });

      }

    });

  }
  downloadPdf(data) {
    if (data.data) {

      const byteCharacters = atob(data.data);

      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);

      let blob = new Blob([byteArray], { type: "application/pdf" });
      if (window.navigator.msSaveOrOpenBlob) {

        window.navigator.msSaveOrOpenBlob(blob);
      } else {
        let url = window.URL.createObjectURL(blob);
        window.open(url);
      }
    } else {
      //console.log("data - No Data", data.data)
    }

  }
  downloadFile(data) {
    let blob = new Blob([data], { type: "application/pdf" });
    if (window.navigator.msSaveOrOpenBlob) {
      //IE11 & Edge
      window.navigator.msSaveOrOpenBlob(blob);
    } else {
      let url = window.URL.createObjectURL(blob);
      window.open(url);
    }
  }
  navigateToOrdersTab() {
    this.router.navigate(['/orderHistory']);
  }

}
