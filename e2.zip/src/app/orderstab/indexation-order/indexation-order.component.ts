import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';

@Component({
  selector: 'indexation-order',
  templateUrl: './indexation-order.component.html',
  styleUrls: ['./indexation-order.component.scss']
})
export class IndexationOrderComponent implements OnInit {
  indexationOrderData;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  indexationDetails;
  constructor(public commonService: HttpCommonService, private readonly router: Router, private menuItemService: MenuItemsService) {

  }

  ngOnInit() {
    this.formInit()
  }

  navigateToOrdersTab() {
    this.router.navigate(['/orderHistory']);
  }
  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

  formInit() {
    const data = JSON.parse(sessionStorage.getItem('orderData'));

    //(data)
    this.indexationDetails = data;

    const reqParam = data.orderNumber

    this.commonService.postData(this.baseUrl.ecustomer.indexationOrderHistory, reqParam, '').subscribe(data => {

      this.indexationOrderData = data;
    })
  }

  backOrderPage() {
    this.router.navigate(['/orderHistory']);
  }

}
