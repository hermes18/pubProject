import { Component, OnInit } from '@angular/core';
import { MatDialog, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { ConfirmDialogModel, DownloadfileDialogComponent } from 'src/app/shared/dialog/downloadfile-dialog/downloadfile-dialog.component';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../../contract-details/allocation-change/allocation-change-service';

export interface FundSummaryData {
  premiumSplitBfreChange: String;
  // fundName: String;
  unitPricePastLink: String;
  premiumSplitAfterChange: String;
  unitPriceNewLink: String;
  keyLink: String;
  pastSplit: String;
  newSplit: String;
}

export interface FundSummaryDataBfre {
  fundName: String;
  unitPricePastLink: String;
  pastSplit: String;
}
export interface FundSummaryData {
  fundName: String;
  unitPriceNewLink: String;
  keyLink: String;
  newSplit: String;
}

@Component({
  selector: 'changepremimum-review',
  templateUrl: './changepremimum-review.component.html',
  styleUrls: ['./changepremimum-review.component.scss']
})
export class ChangepremimumReviewComponent implements OnInit {

  displayedColumnsBfre: String[] = [
    'fundName', 'unitPricePastLink',
    'pastSplit',
  ];
  displayedColumnsBfreMob: String[] = [
    'fundName', 'pastSplit', 'unitPricePastLink',

  ];
  displayedColumns: String[] = ['fundName',
    'unitPriceNewLink',
    'newSplit'];
  displayedColumnsMob: String[] = ['fundName', 'newSplit',
    'unitPriceNewLink',
  ];
  dataSourceFundDetailsBfre: MatTableDataSource<FundSummaryDataBfre>;
  dataSourceFundDetails: MatTableDataSource<FundSummaryData>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  summaryDetBfre: any;
  summaryDetAfter: any;
  reviewResponse: any;
  contractDetail: any;
  contractNo: any;
  userrole: string;
  clientId: any;
  accountDetails: any;
  confDetails: any;
  confResult: any;
  orderDetails: any;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  showMsg: any;
  constructor(private commonService: HttpCommonService, private readonly router: Router, private menuItemService: MenuItemsService, private sharedService: SharedServiceService,
    private newPremiumService: AllocationChangeSharedService,
    public dialog: MatDialog, public translate: TranslateService) { }

  ngOnInit() {
    this.contractDetail = null;
    this.contractNo = this.sharedService.getContractNo();
    const contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));
    let userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    const contractnumber = JSON.parse(sessionStorage.getItem('contract'));
    const data = JSON.parse(sessionStorage.getItem('orderData'));
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }
    //(data)
    this.changePremiumDetails = data;
    // if (this.userrole === "rClient") {
    //   this.clientId = userdetail.clientID;
    // } else {
    //   this.clientId = customerId.clientID;
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (userdetail) {
      this.clientId = userdetail.clientId ? userdetail.clientId : '';
    }
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = data;
    })
    if (this.changePremiumDetails != null) {
      this.callApi();
    }
    this.newPremiumService.getConfReqData().subscribe((val) => {
      this.confResult = val;
    })
  }

  changePremiumDetails: any;
  callApi() {
    const data = JSON.parse(sessionStorage.getItem('orderData'));
    this.orderDetails = data;
    //(data)

    const reqParam =
    {
      "orderId": data.orderNumber
    };

    this.commonService.postData(this.baseUrl.ecustomer.allocationChangeReview, reqParam, '').subscribe(data => {
      this.dataSourceFundDetailsBfre = new MatTableDataSource(data.fundsPriorToChange);
      this.dataSourceFundDetails = new MatTableDataSource(data.fundsAfterChange);
      this.reviewResponse = data;
    });

  }

  navigateToOrdersTab() {
    this.router.navigate(['/orderHistory']);
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

  downloadPdf() {
    const message = this.translate.instant("eCustomer.orderReport.CacheWarning");
    //("msg", message)
    const dialogData = new ConfirmDialogModel("Confirm Action", message);
    const dialogRef =
      this.dialog.open(DownloadfileDialogComponent, { data: dialogData });
    dialogRef.afterClosed().subscribe(result => {
      //(result)
      if (result === true) {
        let dateTranslate = {
          'pl_en': 'en',
          'pl_pl': 'pl',
          'ro_ro': 'ro',
          'ro_en': 'en',
          'gr_gr': 'gr',
          'gr_en': 'en'
        }
        let language = sessionStorage.getItem('defaultLanguage')
        const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
        const customerDetails = JSON.parse(sessionStorage.getItem('searcClientID'));
        let clientId = '';
        if (customerDetails && customerDetails.clientID) {
          clientId = customerDetails.clientID;
        }
        else if (loggedUser['requesterId'] && loggedUser['requesterId'] != -1) {
          clientId = loggedUser['requesterId'];
        }
        const reqParam =
        {
          "orderId": this.changePremiumDetails.orderNumber,
          "language": dateTranslate[language],
          "closureDate": this.reviewResponse && this.reviewResponse.estResolutionDate ? this.reviewResponse.estResolutionDate : null,
          "loggedInUserFirstName": loggedUser['firstName'],
          "loggedInUserLastName": loggedUser['lastName'],
          "loggedInUserId": loggedUser['userName'],
          "clientId": clientId,
        }
        // //(reqParam)
        this.commonService.postData(this.baseUrl.ecustomer.printPdfGeneration, reqParam, '').subscribe(data => {


          // //(data)
          const byteCharacters = atob(data.data);

          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);

          let blob = new Blob([byteArray], { type: "application/pdf" });
          if (window.navigator.msSaveOrOpenBlob) {

            window.navigator.msSaveOrOpenBlob(blob);
          } else {
            let url = window.URL.createObjectURL(blob);
            window.open(url);
          }
        });
      }
    });
  }

  openTooltipMsg() {
    if (this.reviewResponse.investAccNumberTip == 'InvestAccountTypeInfoTip5') {
      if (!this.showMsg) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
      }
    }
  }

  generateStatementPdf() {
    const message = this.translate.instant("eCustomer.orderReport.CacheWarning");
    //("msg", message)
    const dialogData = new ConfirmDialogModel("Confirm Action", message);
    const dialogRef =
      this.dialog.open(DownloadfileDialogComponent, { data: dialogData });
    dialogRef.afterClosed().subscribe(result => {
      //(result)
      if (result === true) {
        let request = {
          "requestId": this.reviewResponse.orderId ? this.reviewResponse.orderId : null,
          "userFirstName": this.reviewResponse.requesting.firstName ? this.reviewResponse.requesting.firstName : null,
          "userLastName": this.reviewResponse.requesting.lastName ? this.reviewResponse.requesting.lastName : null,
          "userLogin": this.reviewResponse.requesting.userLogin ? this.reviewResponse.requesting.userLogin : null,
          "depositAmount": null,
          "orderType": this.reviewResponse.serviceRequestType ? this.reviewResponse.serviceRequestType : null,//update this no according to the order type! – 44/45/46/47
          // "policyNumber": this.reviewResponse.policyNumber ? this.reviewResponse.policyNumber : null
        }
        this.commonService.postData(this.baseUrl.ecustomer.statementPdf, request, '').subscribe(data => {
          //console.log(data);
          const byteCharacters = atob(data.data);

          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);

          let blob = new Blob([byteArray], { type: "application/pdf" });
          if (window.navigator.msSaveOrOpenBlob) {

            window.navigator.msSaveOrOpenBlob(blob);
          } else {
            let url = window.URL.createObjectURL(blob);
            window.open(url);
          }
        });
      }
    });
  }


}

