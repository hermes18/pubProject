import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { AppConfig } from 'src/config/app.config';
import { OrderstabModule } from '../orderstab.module';

import { ChangepremimumReviewComponent } from './changepremimum-review.component';

describe('ChangepremimumReviewComponent', () => {
  let component: ChangepremimumReviewComponent;
  let fixture: ComponentFixture<ChangepremimumReviewComponent>;
  let menuItemService: MenuItemsService;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  let orderDetailsReview;
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'allocationChangeReview': host + '/api/v1/order/allocation-change-order-details',
        'printPdfGeneration': host + '/api/v1/order/service-request-pdf-generation',
        'statementPdf': host + '/api/v1/order/statement-pdf'
      }
    }
  };
    const menuItemList = {
      "activeContractDetails": null,
      "billingRecipent": null,
      "callRetrievePolicies": false,
      "callRetriveClientData": false,
      "callRetriveClientOffers": false,
      "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
      "claimList": null,
      "clientAdministration": true,
      "clientId": "",
      "clientIdList": [],
      "clientIdbillControlList": [],
      "clientLoginId": null,
      "clientRoleIds": "3032|3033|3034",
      "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
      "contractList": [{
        "benefitType": "SuperKapitał",
        "businessRoleList": ["insured", "owner"],
        "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
        "contractNumber": "21223250",
        "contractNumberList": null,
        "effectiveDate": "28.11.2007",
        "indexedPremiumAmount": null,
        "insuredName": "INSURED_21223250",
        "premiumAmount": null,
        "premiumAmt": null,
        "premiumAmtType": "17",
        "premiumDueDate": null,
        "premiumPaymentMode": null,
        "premiumType": "17",
        "processingSystem": "OLAS",
        "status": 22
      }],
      "personalInformationDTO": {
        "dateOfBirth": null,
        "emailBasic": "cosmin.misici@gmail.com",
        "emailSecondary": null,
        "firstName": "COSMIN ADRIAN",
        "flagOfCapabilityOfChangeData": "true",
        "gender": null,
        "identifier": null,
        "identifierType": null,
        "lastName": "MISICI",
        "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
        "mobile": null,
        "mobilePhone": "0723347690",
        "officeFax": null,
        "policyNumber": null,
        "postalCode": null,
        "residenceFax": null,
        "residenceTelephone": "",
        "safePhone": null,
        "updatedEmailBasic": null,
        "updatedEmailSecondary": null,
        "updatedMobile": null,
        "updatedResidenceTelephone": null,
        "updatedSafePhone": null,
        "updatedmarketingConsentList": null,
        "versionMarker": "2020-12-22T12:13:17.867"
      },
      "documentsList": null,
      "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
      "fundPriceDetails": null,
      "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
      "offerResponse": null,
      "orderHistory": null,
      "renderClaims": false,
      "renderDocuments": false,
      "renderFundPriceMonitoring": false,
      "renderMyCompany": false,
      "renderMyContract": false,
      "renderMyData": false,
      "renderOffers": false,
      "renderOrderReview": false,
      "renderUserAcctAdministration": true,
      "route": "DisplayClientSearch",
      "searchFlag": false,
      "wardenRoleCheck": false
    }
  
    beforeEach(() => {
      window['__env'].environmentConstURLs = environmentConstURL;
  
      window.sessionStorage.setItem("defaultLanguage", "pl_pl");
    const userImfo =
      { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" }
    const serachClient =
      { "clientId": 1234, "opeType": "search" }
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    window.sessionStorage.setItem('menuItemList',JSON.stringify(menuItemList));
    orderDetailsReview = {"policyNumber":"21282475","investAccNumber":"21282475","investAccNumberTip":"InvestAccountTypeInfoTip1","accountNotSelectedErrorRender":false,"activeOrderErrorRender":false,"orderCutOffMessageRender":false,"confirmSectionRender":false,"fundsPriorToChange":[{"fundId":"OLAS|003","fundName":"DYNAMICZNY ","unitPrice":null,"sort":null,"investAccNumber":null,"externalLink":"cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003","allocationPercentage":"100","dataError":false,"newAllocationPercentage":null,"minimumAmountPerFund":null,"keyInfoLinkForFund":null,"investAccType":null,"fundValue":null,"totalAmtCurrent":null,"units":null}],"fundsAfterChange":[{"fundId":"OLAS|001","fundName":"OBLIGACYJNY ","unitPrice":null,"sort":null,"investAccNumber":null,"externalLink":"cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS001","allocationPercentage":"30","dataError":false,"newAllocationPercentage":null,"minimumAmountPerFund":null,"keyInfoLinkForFund":null,"investAccType":null,"fundValue":null,"totalAmtCurrent":null,"units":null},{"fundId":"OLAS|002","fundName":"FUNDUSZ ZRÓWNOWAŻONEGO WZROSTU ","unitPrice":null,"sort":null,"investAccNumber":null,"externalLink":"cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS002","allocationPercentage":"40","dataError":false,"newAllocationPercentage":null,"minimumAmountPerFund":null,"keyInfoLinkForFund":null,"investAccType":null,"fundValue":null,"totalAmtCurrent":null,"units":null},{"fundId":"OLAS|003","fundName":"DYNAMICZNY ","unitPrice":null,"sort":null,"investAccNumber":null,"externalLink":"cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003","allocationPercentage":"30","dataError":false,"newAllocationPercentage":null,"minimumAmountPerFund":null,"keyInfoLinkForFund":null,"investAccType":null,"fundValue":null,"totalAmtCurrent":null,"units":null}],"incorrectAllocationErrorRender":false,"noChangeOfAllocationErrorRender":false,"allocationChangeAccess":false,"authorizationErrorRender":false,"orderId":"00002038","investAccType":1,"acceptanceSectionRender":false,"orderErrorRender":false,"orderDetailsSectionRender":true,"statementButtonRender":false,"renderRealizationDate":false,"createDate":"23.04.2021 16:04:39","renderContractNumber":true,"requestStatus":"Processing","reportedBy":"Prabhu Jaison (JDaniel_PL)","renderInvestAccountNumber":true,"requesting":{"firstName":null,"lastName":null,"email":null,"createDate":null,"requesterContactInfoDTO":null,"userAddressDetailDTO":null,"beneficiaryDTO":null,"fundVctr":null,"policyCancellationDTO":null,"policyReinstatementVctr":null,"clientId":null,"userName":"Prabhu Jaison","userLogin":"JDaniel_PL","clientLogin":"UserIdNotFound","clientName":""},"serviceRequestType":"47","activeUser":false}
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, OrderstabModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: [],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService]
    })
      .compileComponents();
    // }));

    // beforeEach(() => {
    fixture = TestBed.createComponent(ChangepremimumReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('call Api method', () => {
    const reqParam =
    {
      "orderId": orderDetailsReview.orderId
    };
    spyOn(component, 'callApi').and.callThrough();
    component.callApi();
    expect(component.callApi).toHaveBeenCalled();
  });

  it('call navigate to orders tab method', () => {
    spyOn(component, 'navigateToOrdersTab').and.callThrough();
    component.navigateToOrdersTab();
    expect(component.navigateToOrdersTab).toHaveBeenCalled();
  });

  it('call gotoHome method', () => {
    spyOn(component, 'gotoHome').and.callThrough();
    component.gotoHome();
    expect(component.gotoHome).toHaveBeenCalled();
  });

  it('call downloadPdf method', () => {
    spyOn(component, 'downloadPdf').and.callThrough();
    component.downloadPdf();
    expect(component.downloadPdf).toHaveBeenCalled();
  });
});
