import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from '../app.module';

import { OrderstabComponent } from './orderstab.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('OrderstabComponent', () => {
  let component: OrderstabComponent;
  let fixture: ComponentFixture<OrderstabComponent>;

  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: [OrderstabComponent],
      providers: [
        { provide: APP_BASE_HREF, useValue: '/' }
      ]

    })
      .compileComponents();
    fixture = TestBed.createComponent(OrderstabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
