import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from 'src/app/app.module';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { OrderstabModule } from '../orderstab.module';

import { AdditionalPremiumComponent } from './additional-premium.component';

describe('AdditionalPremiumComponent', () => {
  let component: AdditionalPremiumComponent;
  let fixture: ComponentFixture<AdditionalPremiumComponent>;
  let sharedService: SharedServiceService;
  let menuItemService: MenuItemsService;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        "fundTransferHistory": host + '/api/v1/order/order-request-object',
        'printPdfGeneration': host + '/api/v1/order/service-request-pdf-generation',
        'statementPdf': host + '/api/v1/order/statement-pdf'
      }
    }
  };

  let menuItemList = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "78667",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  };

  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    const data = {
      orderNumber: 12313
    };
    window.sessionStorage.setItem('orderData', JSON.stringify(data));
    window['__env'].environmentConstURLs = environmentConstURL;

    sessionStorage.setItem('orderData', JSON.stringify(data));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, OrderstabModule, HttpClientTestingModule],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(AdditionalPremiumComponent);
    sharedService = TestBed.get(SharedServiceService);
    menuItemService = TestBed.get(MenuItemsService);
    //component.additionalPremiumDetails ={"id":"00000000000000409583_00000001619186511842_00076","policyNumber":"21282475","serviceRequestId":"00002036","createDate":"23.04.2021, 02:01:51","lastModifiedDate":"23.04.2021, 02:57:33","userId":"JDaniel_PL","actionedBy":"Prabhu Jaison","acknowledgedBy":"JDaniel_PL","status":"Processing","serviceRequestType":"44","sourceSystem":"eCustomer","renderOrderIdAsLink":false,"fundInjectionDetaislDTO":{"fundDTO":null,"premiumAmount":null,"totalPercentage":null,"injectionType":null,"additionalTopUpUnits":null,"addTopUpUnitsForLumpSum":"1000.88","totalAmountWithTopUp":null,"fundSelectionType":null,"totalAmount":null,"currencyType":null,"maxPaymentPeriod":"10","additionalCoverageAmount":null},"investAccountDTO":{"investAccountNumber":"21282475","investAccountType":1,"productPlan":"UB2B000K3","bankAccountNumber":"02 1030 1944 9000 0500 2128 2475","funds":null},"renderPolicynumberMsg":false,"requestingSystem":"eCustomer","processingSystem":"OLAS","cutOffTime":61200000,"orderCutOffTime":"16:01","orderStatusDate":1619189853931,"orderCancellationLevel":0,"fundTransferOrderDTO":{"sourceFundsOrderDetails":null,"targetFundsOrderDetails":null,"forcedAllocationChangeFlag":null},"language":"en","country":"PL","loggedInUserFirstName":"Prabhu","loggedInUserLastName":"Jaison","loggedInUserId":"JDaniel_PL","declaredPaymentAmount":"1000.88","createDateUI":"23.04.2021, 16:01:51","investAccNumberTip":"InvestAccountTypeInfoTip1","statementButtonRender":false,"renderRealizationDate":false,"requesting":{"firstName":null,"lastName":null,"email":null,"createDate":null,"requesterContactInfoDTO":null,"userAddressDetailDTO":null,"beneficiaryDTO":null,"fundVctr":null,"policyCancellationDTO":null,"policyReinstatementVctr":null,"clientId":null,"userName":"Prabhu Jaison","userLogin":"JDaniel_PL","clientLogin":"JDaniel_PL","clientName":"JDaniel_PL"},"invest":{"contractNumber":"21282475","investAccNumber":"21282475","effectiveDate":"27.12.2009","status":23,"investValue":6372.35,"productPlan":"UB2B000K3","valuationDt":1380664800000,"accountType":1,"fundSingleInvAccounts":[{"investAccNumber":"21282475","fundId":"OLAS|003","units":247.37380000,"unitPrice":25.76000000,"fundValue":6372.3500,"valuationDate":1380664800000,"fundConfigurationDTO":{"fundId":"OLAS|003","fundName":"DYNAMICZNY ","closeDate":1356994800000,"fundExternalLink":"cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003","system":"OLAS","flag":"false","sort":34,"unitPriceDec":2,"unitLinkedPolicy":null,"unitPrice":null},"allocationPercentage":100}],"productPlanConfigDTO":null,"investAccType":1,"policyNumber":"21282475","bankAccount":"02 1030 1944 9000 0500 2128 2475","accountNumber":"02 1030 1944 9000 0500 2128 2475"}}
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.langChange = "pl_pl";
    sharedService.setLangChange('pl_pl');
    spyOn(sharedService, 'getLangChange').and.returnValue(of(component.langChange));
    const orderData = {login: "JDaniel_PL",
    orderDate: "23.04.2021",
    orderNumber: "00002036",
    orderType: "44",
    refersToContract: "21282475",
    status: "Processing"};
    window.sessionStorage.setItem('orderData', JSON.stringify(orderData));
    const response = {"id":"00000000000000409583_00000001619186511842_00076","policyNumber":"21282475","serviceRequestId":"00002036","createDate":"23.04.2021, 02:01:51","lastModifiedDate":"23.04.2021, 02:57:33","userId":"JDaniel_PL","actionedBy":"Prabhu Jaison","acknowledgedBy":"JDaniel_PL","status":"Processing","serviceRequestType":"44","sourceSystem":"eCustomer","renderOrderIdAsLink":false,"fundInjectionDetaislDTO":{"fundDTO":null,"premiumAmount":null,"totalPercentage":null,"injectionType":null,"additionalTopUpUnits":null,"addTopUpUnitsForLumpSum":"1000.88","totalAmountWithTopUp":null,"fundSelectionType":null,"totalAmount":null,"currencyType":null,"maxPaymentPeriod":"10","additionalCoverageAmount":null},"investAccountDTO":{"investAccountNumber":"21282475","investAccountType":1,"productPlan":"UB2B000K3","bankAccountNumber":"02 1030 1944 9000 0500 2128 2475","funds":null},"renderPolicynumberMsg":false,"requestingSystem":"eCustomer","processingSystem":"OLAS","cutOffTime":61200000,"orderCutOffTime":"16:01","orderStatusDate":1619189853931,"orderCancellationLevel":0,"fundTransferOrderDTO":{"sourceFundsOrderDetails":null,"targetFundsOrderDetails":null,"forcedAllocationChangeFlag":null},"language":"en","country":"PL","loggedInUserFirstName":"Prabhu","loggedInUserLastName":"Jaison","loggedInUserId":"JDaniel_PL","declaredPaymentAmount":"1000.88","createDateUI":"23.04.2021, 16:01:51","investAccNumberTip":"InvestAccountTypeInfoTip1","statementButtonRender":false,"renderRealizationDate":false,"requesting":{"firstName":null,"lastName":null,"email":null,"createDate":null,"requesterContactInfoDTO":null,"userAddressDetailDTO":null,"beneficiaryDTO":null,"fundVctr":null,"policyCancellationDTO":null,"policyReinstatementVctr":null,"clientId":null,"userName":"Prabhu Jaison","userLogin":"JDaniel_PL","clientLogin":"JDaniel_PL","clientName":"JDaniel_PL"},"invest":{"contractNumber":"21282475","investAccNumber":"21282475","effectiveDate":"27.12.2009","status":23,"investValue":6372.35,"productPlan":"UB2B000K3","valuationDt":1380664800000,"accountType":1,"fundSingleInvAccounts":[{"investAccNumber":"21282475","fundId":"OLAS|003","units":247.37380000,"unitPrice":25.76000000,"fundValue":6372.3500,"valuationDate":1380664800000,"fundConfigurationDTO":{"fundId":"OLAS|003","fundName":"DYNAMICZNY ","closeDate":1356994800000,"fundExternalLink":"cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003","system":"OLAS","flag":"false","sort":34,"unitPriceDec":2,"unitLinkedPolicy":null,"unitPrice":null},"allocationPercentage":100}],"productPlanConfigDTO":null,"investAccType":1,"policyNumber":"21282475","bankAccount":"02 1030 1944 9000 0500 2128 2475","accountNumber":"02 1030 1944 9000 0500 2128 2475"}};
    component.additionalPremiumDetails = response;
    expect(component).toBeTruthy();
  });


it('call navigation to orders tab method', () => {
  spyOn(component, 'navigateToOrdersTab').and.callThrough();
  component.navigateToOrdersTab();
  expect(component.navigateToOrdersTab).toHaveBeenCalled();
});

it('call navigation to home page method', () => {
  // const menuItemList = {};
  // spyOn(menuItemService, 'navigationBasedOnRole').and.returnValue(of(menuItemList));
  spyOn(component, 'gotoHome').and.callThrough();
  component.gotoHome();
  expect(component.gotoHome).toHaveBeenCalled();
});

it('call download pdf method', () => {
  spyOn(component, 'downloadPdf').and.callThrough();
  component.downloadPdf();
  expect(component.downloadPdf).toHaveBeenCalled();
});

it('call generate pdf method', () => {
  spyOn(component, 'generateStatementPdf').and.callThrough();
  component.generateStatementPdf();
  expect(component.generateStatementPdf).toHaveBeenCalled();
});

});
