import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';

import { HttpCommonService } from '../../../shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';

@Injectable()

export class OrderHistoryService {
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(private cService: HttpCommonService) { }

  getOrderType() {
    return this.cService['getData'](
      this.baseUrl.ecustomer.orderTypes);
  }

  getOrderStatus() {
    return this.cService['getData'](
      this.baseUrl.ecustomer.orderStatus);
  }

  getHistoryContract() {
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let clientIDfromLogin = loggedUser.clientId ? loggedUser.clientId : null;
    const serachClientId = JSON.parse(sessionStorage.getItem('searcClientID'));

    const clientID = {
      "clientId": serachClientId ? serachClientId.clientID : clientIDfromLogin
    }
    return this.cService['postData'](
      this.baseUrl.ecustomer.orderHistoryContracts, clientID, '');
  }


  getHistoryOfContract(reqParam) {
    return this.cService['postData'](
      this.baseUrl.ecustomer.orderHistoryGrid, reqParam, '');
  }
}
