import { async, ComponentFixture, ComponentFixtureAutoDetect, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from '../../app.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { filter, takeWhile } from 'rxjs/operators';
import * as moment from 'moment';
import { DateAdapter, MatPaginator, MatTableDataSource } from '@angular/material';

import { TranslateService } from '@ngx-translate/core';

import { OrderHistoryComponent } from './order-history.component';
import { OrderstabModule } from '../orderstab.module';
import { OrderHistoryService } from './service/order-history.service';
import { of } from 'rxjs';
import { Router } from '@angular/router';
describe('OrderHistoryComponent', () => {
  let component: OrderHistoryComponent;
  let fixture: ComponentFixture<OrderHistoryComponent>;
  let orderHistoryService: OrderHistoryService;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  let router = {
    navigate: jasmine.createSpy('navigate')
  };
  const userToken = {
    token: "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJPc2FtYUFkbWluIiwidXNlciI6eyJ1c2VyTmFtZSI6Ik9zYW1hQWRtaW4iLCJmaXJzdE5hbWUiOiJPc2FtYSIsImxhc3ROYW1lIjoiTW8iLCJlbWFpbCI6Im9zYW1hLmtoYWxpZEBtZXRsaWZlLmNvbSIsInByZWZlcnJlZExhbmd1YWdlIjoiZW4iLCJjcmVhdGlvbkRhdGUiOiJXZWQgSmFuIDA2IDE0OjQyOjI0IENFVCAyMDIxIiwicGFzc3dvcmRUeXBlIjoiU1RBTkRBUkQiLCJjdXN0b21lclBhc3N3b3JkRXhwcmF0aW9uQ29kZSI6IjEiLCJwYXNzd29yZFN0YXR1c0NvZGUiOiJBQ1RJVkUiLCJzZWN1cml0eVBvbGljeUlkIjoiMTIzNDUiLCJ0b2tlbkV4cGlyYXRpb25EYXRlIjoiRnJpIFNlcCAxOCAxNzowMzo1MCBDRVNUIDIwMjAiLCJlbXBsb3llZU51bWJlciI6bnVsbCwicHdkRXhwaXJhdGlvbkRhdGUiOiJGcmkgTWFyIDE5IDE0OjQyOjI0IENFVCAyMDIxIiwiZmFpbGVkTG9naW5Db3VudHMiOiIwIiwiYXV0aG9yaXplZEFwcGxpY2F0aW9uQ29kZSI6ImVDdXN0b21lciIsInRlbXBvcmFyeUxvY2tEYXRlIjpudWxsLCJyb3V0ZSI6bnVsbCwicHdkRXhwaXJlZCI6bnVsbCwiZGF5c1NpbmNlUHdkTm90Q2hhbmdlZCI6bnVsbCwicHdkQ2hhbmdlRGF0ZSI6bnVsbCwicm9sZUluZm8iOlt7InJvbGVJZCI6IjMwMzMiLCJuYW1lIjoiclN1cGVyVXNlciIsImRlc2NyaXB0aW9uIjoiUlN1cGVyVXNlciJ9LHsicm9sZUlkIjoiMzAzNCIsIm5hbWUiOiJyQWRtaW5pc3RyYXRvciIsImRlc2NyaXB0aW9uIjoiU3lzdGVtQWRtaW5pc3RyYXRvciJ9XSwiY2xpZW50SWQiOm51bGwsInJlcXVlc3RlcklkIjpudWxsLCJyZXF1ZXN0ZXJSb2xlIjpudWxsLCJ1c2VyRG4iOiJvdT1QZW9wbGUsbz1hZmZpbGlhdGVzLGM9UG9sYW5kLG89bWV0bGlmZSxkYz1tZXRsaWZlLGRjPWNvbSIsInVzZXJDaGVjayI6dHJ1ZX0sImlhdCI6MTYxMjMzNzA1NCwiZXhwIjoxNjEyMzgwMjU0fQ.DF3cfAMA1Z0BLYN_k5yrqtWDcq1ed9z1Vu5EkIgj_x0",
    userName: "OsamaAdmin"
  };
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'orderTypes': host + '/api/v1/order/order-history/order-types',
        'orderStatus': host + '/api/v1/order/order-history/order-status',
        'orderHistoryContracts': host + '/api/v1/order/order-history/contracts',
        'orderHistoryGrid': host + '/api/v1/order/order-history'
      }
    }
  };
  const menuItemList = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "78667",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  };


  const serachClient =
    { "clientId": 1234, "opeType": "search" };

  const userImfo =
    { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" };
  beforeEach(() => {
    window.sessionStorage.setItem('userToken', JSON.stringify(userToken));
    window['__env'].environmentConstURLs = environmentConstURL;
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));
    sessionStorage.setItem('menuItemList', JSON.stringify(menuItemList));
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, OrderstabModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, OrderHistoryService, { provide: Router, useValue: router }, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(OrderHistoryComponent);
    orderHistoryService = TestBed.get(OrderHistoryService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(OrderHistoryComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    component.getContractHistoryList();
    expect(component).toBeTruthy();
  });

  it('should call getContractHistoryList', () => {
    const contarctList = ["20032799",
      "21137369", "20386578"
      , "7101352"
      , "21295126"
      , "21295127"
      , "32386578"
      , "21282475"];
    spyOn(orderHistoryService, 'getHistoryContract').and.returnValue(of(contarctList));
    component.getContractHistoryList();
  });
  it('should call getContractHistoryList', () => {
    const contarctList = [];
    spyOn(orderHistoryService, 'getHistoryContract').and.returnValue(of(contarctList));
    component.getContractHistoryList();
  });

  it('should call getOrderTpeList', () => {
    const orderType = [46, 47, 44, 45, 48, 49];
    spyOn(orderHistoryService, 'getOrderType').and.returnValue(of(orderType));
    component.getOrderTpeList();
  });


  it('should call getOrderStatus', () => {
    const orderStatus = ["REGISTERED", "PROCESSING", "EXECUTED", "REJECTED"];
    spyOn(orderHistoryService, 'getOrderStatus').and.returnValue(of(orderStatus));
    component.getOrderStatus();

  });

  it('should call getOrderStatus', () => {
    const orderStatus = [];
    spyOn(orderHistoryService, 'getOrderStatus').and.returnValue(of(orderStatus));
    component.getOrderStatus();
  });

  it('should call getOrderHistory', () => {
    const orderHistory = [{
      "contract": "21295126",
      "login": "JDaniel_PL",
      "orderDate": "23.04.2021",
      "orderNumber": "00002040",
      "orderType": "46",
      "status": "Processing"
    }];
    spyOn(orderHistoryService, 'getHistoryOfContract').and.returnValue(of(orderHistory));
    component.getOrderHistory();
  });

  it('should call formatGridData', () => {
    const orderHistory = [{
      "contract": "21295126",
      "login": "JDaniel_PL",
      "orderDate": "23.04.2021",
      "orderNumber": "00002040",
      "orderType": "46",
      "status": "Processing"
    }];
    component.formatGridData(orderHistory);

  })
  it('should call searchHistory', () => {
    component.searchHistory();
  });

  it('should call gotoHome', () => {
    component.gotoHome();
  });

  it('should call goToPreviousPeriod', () => {
    component.goToPreviousPeriod();
  });

  it('should call goToNextPeriod', () => {
    component.goToNextPeriod();
  });


  it('should call routeOrderDetail case 44', () => {
    let individualOrder = [{
      "refersToContract": "21295126",
      "login": "JDaniel_PL",
      "orderDate": "23.04.2021",
      "orderNumber": "00002040",
      "orderType": "44",
      "status": "Processing"
    }];

    window.sessionStorage.setItem('personalDataOrderId', individualOrder['orderNumber']);
    window.sessionStorage.setItem('orderData', JSON.stringify(individualOrder));
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    component.routeOrderDetail(individualOrder);
    /// expect(router.navigate).toHaveBeenCalledWith(['/orderHistory/singlePremiumSave']);
  });

  it('should call route orderDetails case 47', () => {
    let individualOrder = [{
      "refersToContract": "21295126",
      "login": "JDaniel_PL",
      "orderDate": "23.04.2021",
      "orderNumber": "00002040",
      "orderType": "47",
      "status": "Processing"
    }];

    window.sessionStorage.setItem('personalDataOrderId', individualOrder['orderNumber']);
    window.sessionStorage.setItem('orderData', JSON.stringify(individualOrder));
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    component.routeOrderDetail(individualOrder);

  });

  it('should call routeOrderDetail case 45', () => {
    let individualOrder = [{
      "refersToContract": "21295126",
      "login": "JDaniel_PL",
      "orderDate": "23.04.2021",
      "orderNumber": "00002040",
      "orderType": "45",
      "status": "Processing"
    }];

    window.sessionStorage.setItem('personalDataOrderId', individualOrder['orderNumber']);
    window.sessionStorage.setItem('orderData', JSON.stringify(individualOrder));
    const mobileContractView = {
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    component.routeOrderDetail(individualOrder);
  });

  it('should call routeOrderSetail case 51', () => {
    let individualOrder = [{
      "refersToContract": "21295126",
      "login": "JDaniel_PL",
      "orderDate": "23.04.2021",
      "orderNumber": "00002040",
      "orderType": "51",
      "status": "Processing"
    }];

    window.sessionStorage.setItem('personalDataOrderId', individualOrder['orderNumber']);
    window.sessionStorage.setItem('orderData', JSON.stringify(individualOrder));
    const mobileContractView = {
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    component.routeOrderDetail(individualOrder);

  });

  it('should call routeOrderDetail case 48', () => {
    let individualOrder = [{
      "refersToContract": "21295126",
      "login": "JDaniel_PL",
      "orderDate": "23.04.2021",
      "orderNumber": "00002040",
      "orderType": "48",
      "status": "Processing"
    }];

    window.sessionStorage.setItem('personalDataOrderId', individualOrder['orderNumber']);
    window.sessionStorage.setItem('orderData', JSON.stringify(individualOrder));
    const mobileContractView = {
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    component.routeOrderDetail(individualOrder);

  });

  it('should call routeOrderDetail case 46 ', () => {
    let individualOrder = [{
      "refersToContract": "21295126",
      "login": "JDaniel_PL",
      "orderDate": "23.04.2021",
      "orderNumber": "00002040",
      "orderType": "46",
      "status": "Processing"
    }];

    window.sessionStorage.setItem('personalDataOrderId', individualOrder['orderNumber']);
    window.sessionStorage.setItem('orderData', JSON.stringify(individualOrder));
    const mobileContractView = {
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    component.routeOrderDetail(individualOrder);
  });



});
