import { FormGroup } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';


export class OrderHistoryModel {
    orderHistoryForm: FormGroup;
    subscribeFlag: boolean;
    orderTypeList: Array<number>;
    orderStatusList;
    conrtactHistory: Array<any>;
    applicantList: Array<any>;
    orderHistoryGrid: MatTableDataSource<any>;;
    columnList: string[];
    constructor() {
        this.columnList = ['orderDate', 'login', 'orderType', 'refersToContract', 'status', 'orderNumber'];
        this.subscribeFlag = true;
        this.orderTypeList = [];
        this.orderStatusList = [];
        this.conrtactHistory = [];
        this.applicantList = [{
            "key": "ALL", "value": "All"
        },
        {
            "key": "ApplicantClient", "value": "Customer"
        },
        {
            "key": "ApplicantEmployee", "value": "Employee"
        }
        ];
        // this.orderStatusList = [{
        //     'key': 'Registered'
        // },
        // { 'key': 'Processing' },
        // { 'key': 'Executed' },
        // { 'key': 'Rejected' }
        // ];

    }
}