import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { filter, takeWhile } from 'rxjs/operators';
import * as moment from 'moment';
import { DateAdapter, MatPaginator, MatTableDataSource } from '@angular/material';

import { OrderHistoryModel } from './model/order-history.model';
import { OrderHistoryService } from './service/order-history.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { StylePaginatorDirective } from 'src/app/shared/directives/style-paginator.directive';

@Component({
  selector: 'order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.scss'],
  providers: [OrderHistoryService]
})
export class OrderHistoryComponent implements OnInit {
  orderHistoryModel: OrderHistoryModel;
  private paginator: MatPaginator;
  numberOfDaysToAdd: number = 30;
  maxDate: Date;
  minDate: Date;
  constructor(private readonly formBuilder: FormBuilder, public deviceDetector: DeviceDetectorService, private menuItemService: MenuItemsService, public sharedService: SharedServiceService, private dateAdapter: DateAdapter<Date>, private router: Router, private readonly orderHistoryService: OrderHistoryService) {
    this.orderHistoryModel = new OrderHistoryModel();
    this.minDate = new Date(1900, 0, 1);
    this.maxDate = new Date(2050, 0, 1);
  }

  inContractTabMenu = {
    displayField: false,
    contractNumber: null
  }
  @Input() set inContractTab(flag) {
    //(flag)
    this.inContractTabMenu = flag;

  }

  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.orderHistoryModel.orderHistoryGrid) {
      this.orderHistoryModel.orderHistoryGrid.paginator = this.paginator;
      if (this.directive) {
        this.directive.ngAfterViewInit();
      }
    }
  }

  @ViewChild(StylePaginatorDirective, { static: false }) directive: StylePaginatorDirective;

  defaultLanguage: string;
  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.orderHistoryModel.orderHistoryForm = this.formBuilder.group({
      orderTypeControl: ['ALL'],
      refersContractControl: ['ALL'],
      fromDateRange: '',
      toDateRange: new Date(),
      status: ['ALL'],
      applicant: ['']
    });
    this.setDateValue();
    this.patchApplicantValue();
    this.getOrderTpeList();
    this.getOrderStatus();
    this.getContractHistoryList();
    this.getOrderHistory();
    this.displayApplicantFieldRoleBase();
    this.sharedService.getLangChange().subscribe((data) => {
      this.defaultLanguage = sessionStorage.getItem("defaultLanguage");
    });

  }

  ngOnDestroy() {
    this.orderHistoryModel.subscribeFlag = false;
  }
  ngAfterViewInit() {
    this.sharedService.getLangChange().subscribe((data) => {
      const lang = sessionStorage.getItem("defaultLanguage");
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_gr': 'el',
        'gr_en': 'en',
        'gr': 'el'
      }
      //("after lang change", data);
      const language = data ? data === 'gr' ? dateTranslate[lang] : data : dateTranslate[lang];
      this.dateAdapter.setLocale(language);
    })

  }

  toDisplatApplicatField = null;

  displayApplicantFieldRoleBase() {
    const role = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    if (role) {
      role.roleInfo.filter((data) => {
        if (data.name == 'rSuperUser' || data.name == 'rStandardUser' || data.name === 'rAdministrator') {
          this.toDisplatApplicatField = data;
        };
      });
    }
  }


  patchApplicantValue() {
    this.orderHistoryModel.orderHistoryForm.patchValue({
      applicant: this.orderHistoryModel.applicantList[0].value
    })
  }
  setDateValue() {
    let toDateRange = new Date();
    // const fromDateRange = new Date(toDateRange.setMonth(toDateRange.getMonth() - 1));
    const fromDateRange = new Date(toDateRange.setDate(toDateRange.getDate() - this.numberOfDaysToAdd));
    this.orderHistoryModel.orderHistoryForm.patchValue({
      fromDateRange: fromDateRange
    });
  }


  getContractHistoryList() {
    this.orderHistoryService.getHistoryContract().pipe(takeWhile(() => this.orderHistoryModel.subscribeFlag)).subscribe((contractList) => {
      if (contractList) {
        contractList.unshift('ALL');
        this.orderHistoryModel.conrtactHistory = contractList;
        this.orderHistoryModel.orderHistoryForm.patchValue({
          refersContractControl: this.orderHistoryModel.conrtactHistory[0]
        });
      } else {
        this.orderHistoryModel.conrtactHistory = [];
      }
    });
  }


  getOrderTpeList() {
    this.orderHistoryService.getOrderType().pipe(takeWhile(() => this.orderHistoryModel.subscribeFlag)).subscribe((orderList) => {
      if (orderList) {
        orderList.unshift('ALL');
        this.orderHistoryModel.orderTypeList = orderList;
        this.orderHistoryModel.orderHistoryForm.patchValue({
          orderTypeControl: this.orderHistoryModel.orderTypeList[0]
        });
      } else {
        this.orderHistoryModel.orderTypeList = [];
      }
    });
  }

  getOrderStatus() {
    this.orderHistoryService.getOrderStatus().pipe(takeWhile(() => this.orderHistoryModel.subscribeFlag)).subscribe((status) => {
      if (status) {
        status.unshift('ALL');
        this.orderHistoryModel.orderStatusList = status;
        this.orderHistoryModel.orderHistoryForm.patchValue({
          status: this.orderHistoryModel.orderStatusList[0]
        });
      } else {
        this.orderHistoryModel.orderStatusList = [];
      }
    });
  }

  getOrderHistory() {
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let clientIDfromLogin = loggedUser.clientId ? loggedUser.clientId : null;
    const serachClientId = JSON.parse(sessionStorage.getItem('searcClientID')),
      formControls = this.orderHistoryModel.orderHistoryForm.value,
      fromDateRange = moment(this.orderHistoryModel.orderHistoryForm.value.fromDateRange).format("YYYY-MM-DD"),
      toDateRange = moment(this.orderHistoryModel.orderHistoryForm.value.toDateRange).format("YYYY-MM-DD");
    const requestParam = {
      "clientId": serachClientId ? serachClientId.clientID : clientIDfromLogin,
      "orderType": formControls.orderTypeControl == "ALL" ? null : formControls.orderTypeControl,
      "orderStatus": formControls.status === "ALL" ? null : formControls.status,
      "contract": !this.inContractTabMenu.displayField ? formControls.refersContractControl === "ALL" ? null : formControls.refersContractControl : this.inContractTabMenu.contractNumber,
      "dateFrom": fromDateRange,
      "dateTo": toDateRange,
      "applicant": formControls.applicant,
      "requestingSystem": "eCustomer",
      "loggedInUserId": loggedUser.userName
    }
    //(requestParam);
    if (fromDateRange !== "Invalid date" && toDateRange !== "Invalid date") {
      this.inValiDate = false;
      this.orderHistoryService.getHistoryOfContract(requestParam).pipe(takeWhile(() => this.orderHistoryModel.subscribeFlag)).subscribe((data) => {
        this.paginator = null;
        if (data.length > 0) {
          this.orderHistoryModel.orderHistoryForm.controls.fromDateRange.setErrors({ 'noResultInTimeSpan': false });
          this.formatGridData(data);
        } else {
          this.orderHistoryModel.orderHistoryGrid = new MatTableDataSource([]);
          this.orderHistoryModel.orderHistoryForm.controls.fromDateRange.setErrors({ 'noResultInTimeSpan': true });
        }
      });
    } else {
      this.orderHistoryModel.orderHistoryGrid = new MatTableDataSource([]);
      this.orderHistoryModel.orderHistoryForm.controls.fromDateRange.setErrors({ 'noResultInTimeSpan': false });
      this.inValiDate = true;

    }
  }
  inValiDate: boolean = false;
  searchHistory() {
    this.getOrderHistory();
  }

  formatGridData(data) {
    const orderHistoryList = [];
    if (data.length > 0) {
      data.forEach(element => {
        orderHistoryList.push({
          orderDate: element.orderDate,
          login: element.login,
          orderType: element.orderType,
          refersToContract: element.contract,
          status: element.status,
          orderNumber: element.orderNumber

        })

      });

      this.orderHistoryModel.orderHistoryGrid = new MatTableDataSource(orderHistoryList);
      //(this.orderHistoryModel.orderHistoryGrid)
      this.orderHistoryModel.orderHistoryGrid.paginator = this.paginator;
    } else {
      this.orderHistoryModel.orderHistoryGrid = new MatTableDataSource(orderHistoryList);
    }
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }


  goToPreviousPeriod() {
    let numberOfDaysToAdd = 31;
    const currentFromDate = this.orderHistoryModel.orderHistoryForm.controls.fromDateRange.value,
      currentToDate = this.orderHistoryModel.orderHistoryForm.controls.toDateRange.value,
      fromDate = moment(currentFromDate),
      toDate = moment(currentToDate);
    numberOfDaysToAdd = toDate.diff(fromDate, 'days') + 1;
    // fromDateRange = new Date(currentFromDate.setMonth(currentFromDate.getMonth() - 1)),
    // toDateRange = new Date(currentToDate.setMonth(currentToDate.getMonth() - 1));
    let fromDateRange = currentFromDate._d ?
      new Date(currentFromDate._d.setDate(currentFromDate._d.getDate() - numberOfDaysToAdd)) :
      new Date(currentFromDate.setDate(currentFromDate.getDate() - numberOfDaysToAdd)),
      toDateRange = currentToDate._d ?
        new Date(currentToDate._d.setDate(currentToDate._d.getDate() - numberOfDaysToAdd)) :
        new Date(currentToDate.setDate(currentToDate.getDate() - numberOfDaysToAdd));
    // const yearDateFromat = currentFromDate.toLocaleDateString().split('/')[2] + '-' + currentFromDate.toLocaleDateString().split('/')[1];
    // const daysInAMonth = moment(yearDateFromat, "YYYY-MM").daysInMonth();
    ////(daysInAMonth)
    this.orderHistoryModel.orderHistoryForm.patchValue({
      fromDateRange: fromDateRange,
      toDateRange: toDateRange
    })
  }

  goToNextPeriod() {
    let numberOfDaysToAdd = 31;
    const currentFromDate = this.orderHistoryModel.orderHistoryForm.controls.fromDateRange.value,
      currentToDate = this.orderHistoryModel.orderHistoryForm.controls.toDateRange.value;
    let fromDate = moment(currentFromDate),
      toDate = moment(currentToDate);
    numberOfDaysToAdd = toDate.diff(fromDate, 'days') + 1;
    // fromDateRange = new Date(currentFromDate.setMonth(currentFromDate.getMonth() + 1)),
    // toDateRange = new Date(currentToDate.setMonth(currentToDate.getMonth() + 1))

    let fromDateRange = currentFromDate._d ?
      new Date(currentFromDate._d.setDate(currentFromDate._d.getDate() + numberOfDaysToAdd)) :
      new Date(currentFromDate.setDate(currentFromDate.getDate() + numberOfDaysToAdd)),
      toDateRange = currentToDate._d ?
        new Date(currentToDate._d.setDate(currentToDate._d.getDate() + numberOfDaysToAdd)) :
        new Date(currentToDate.setDate(currentToDate.getDate() + numberOfDaysToAdd));

    // using moment
    // let fromDate = moment(this.orderHistoryModel.orderHistoryForm.controls.fromDateRange.value),
    //   toDate = moment(this.orderHistoryModel.orderHistoryForm.controls.toDateRange.value),
    //   daysInBetween = fromDate.diff(toDate, 'days') + 1;
    // // fromDate.subtract(daysInBetween, 'd');
    // // toDate.subtract(daysInBetween, 'd');

    // let previousDateRange = fromDate.add(daysInBetween, 'days'),
    //   nextDateRange = toDate.add(daysInBetween, 'days')


    // //(daysInBetween);

    // //(previousDateRange);
    // //(nextDateRange);


    this.orderHistoryModel.orderHistoryForm.patchValue({
      fromDateRange: fromDateRange,
      toDateRange: toDateRange
    })

  }

  routeOrderDetail(data) {
    sessionStorage.setItem('personalDataOrderId', data.orderNumber);
    sessionStorage.setItem('orderData', JSON.stringify(data));
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    this.sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    switch (data.orderType) {

      case '51':
        this.router.navigate(['/orderHistory/indexationorderhistory']);
        break;
      case '45':
        this.router.navigate(['/orderHistory/additionalContributionSave']);
        break;
      case '47':
        this.router.navigate(['/orderHistory/allocationChange']);
        break;
      case '44':
        this.router.navigate(['/orderHistory/singlePremiumSave']);
        break;
      case '48':
        sessionStorage.setItem('personalDataOrderId', data.orderNumber);
        this.router.navigate(['/orderHistory/clientDataChange']);
        break;
      case '46':
        this.router.navigate(['/orderHistory/fundtransfer']);
        break;
    }
  }
}
