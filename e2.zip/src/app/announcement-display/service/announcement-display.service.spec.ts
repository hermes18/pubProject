import { TestBed } from '@angular/core/testing';


import { HttpClientTestingModule } from '@angular/common/http/testing';


import { AnnouncementDisplayService } from './announcement-display.service';
import { APP_BASE_HREF } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { AppModule } from 'src/app/app.module';
import { AnnouncementDisplayModule } from '../announcement-display.module';

describe('AnnouncementDisplayService', () => {
  let service: AnnouncementDisplayService
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'retrieveAnnounceMent': host + '/api/v1/announcement'
      }
    }
  };
  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, AnnouncementDisplayModule],
      providers: [AnnouncementDisplayService, { provide: APP_BASE_HREF, useValue: '/' }],
    })
    service = TestBed.get(AnnouncementDisplayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
