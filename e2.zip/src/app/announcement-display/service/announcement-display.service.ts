import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';

@Injectable({
  providedIn: 'root'
})
export class AnnouncementDisplayService {
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  // userInfo = sessionStorage.getItem('loggedInUserInfo');
  // userdetail = JSON.parse(this.userInfo)

  constructor(private readonly commonService: HttpCommonService) { }

  getAnnouncemnetDetails() {
    let userInfo = sessionStorage.getItem('loggedInUserInfo');
    let userdetail = JSON.parse(userInfo);
    let url = `${this.baseUrl.ecustomer.retrieveAnnounceMent}/${userdetail['userName']}`;
    return this.commonService['getData'](url);

  }

  updateDisplayDate(announceID) {
    let userInfo = sessionStorage.getItem('loggedInUserInfo'),
      userdetail = JSON.parse(userInfo);
    const url = `${this.baseUrl.ecustomer.retrieveAnnounceMent}/${userdetail['userName']}/${announceID}`;
    return this.commonService['putData'](url, '');
  }

  saveHistoryDate(announceID) {
    let userInfo = sessionStorage.getItem('loggedInUserInfo'),
      userdetail = JSON.parse(userInfo);
    const url = `${this.baseUrl.ecustomer.retrieveAnnounceMent}/${userdetail['userName']}/${announceID}`;
    return this.commonService['postData'](url, '', '');
  }
}
