import { FormGroup } from '@angular/forms';


export class AnnouncementDisplayModel {
    anouncementDetails: any;
    acceptCounter: number;
    componentMessageContent: any;
    titleContent;
    url;
    documentDownload;
    acceptanceText;
    announceMentForm: FormGroup;
    submitted: boolean;
    subscribeFlag: boolean;
    constructor() {
        this.acceptCounter = 0;
        this.submitted = false;
        this.subscribeFlag = true;
    }
}