import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AnnouncementDisplayComponent } from './announcement-display.component';
import { NavigationGuard } from '../core/gaurds/navigation-guard';


const routes: Routes = [{
  path: '',
  component: AnnouncementDisplayComponent,
  data: { requiresLogin: true },
  canDeactivate: [NavigationGuard]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnnouncementDisplayRoutingModule { }
