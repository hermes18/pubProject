import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule } from '@angular/forms';

import { AnnouncementDisplayRoutingModule } from './announcement-display-routing.module';
import { AnnouncementDisplayComponent } from './announcement-display.component';


@NgModule({
  declarations: [AnnouncementDisplayComponent],
  imports: [
    CommonModule,
    TranslateModule,
    ReactiveFormsModule,
    AnnouncementDisplayRoutingModule
  ]
})
export class AnnouncementDisplayModule { }
