import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AnnouncementDisplayService } from './service/announcement-display.service';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { LogoutDialogComponent } from '../shared/dialog/logout-dialog/logout-dialog.component';
import { AnnouncementDisplayModel } from './model/announcement-display.model';

import { TranslateService } from '@ngx-translate/core';
import { DialogService } from '../shared/services/dialog.service';
import { CanComponentDeactivate } from '../core/gaurds/can-deactivate-guard';
import { Observable } from 'rxjs';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { takeWhile } from 'rxjs/operators';
import { MenuItemsService } from '../shared-service/menu-items.service';

@Component({
  selector: 'announcement-display',
  templateUrl: './announcement-display.component.html',
  styleUrls: ['./announcement-display.component.scss']
})
export class AnnouncementDisplayComponent implements OnInit {
  announcmentModel: AnnouncementDisplayModel;


  canDeactivate(component: CanComponentDeactivate, route: ActivatedRouteSnapshot, state: RouterStateSnapshot,
    nextState: RouterStateSnapshot): Observable<boolean> | boolean {
    //  console.log(nextState, route, state);
    if (route.data.requiresLogin && nextState.url == '/login') {
      return false;
    }
    return true;
  }

  constructor(private readonly router: Router, private readonly announcement: AnnouncementDisplayService,
    private formbuilder: FormBuilder, private readonly menuItemService: MenuItemsService,
    public commonService: SharedServiceService,
    private sharedService: SharedServiceService, public translate: TranslateService, public dialogService: DialogService) {
    this.announcmentModel = new AnnouncementDisplayModel();
  }

  ngOnInit() {
    this.announcmentModel.announceMentForm = this.formbuilder.group({
      acceptAck: ['', Validators.required]
    });
    this.sharedService.getDetail('announceMentDetail').pipe(takeWhile(() => this.announcmentModel.subscribeFlag)).subscribe((data) => {
      // this.announcement.getAnnouncemnetDetails().subscribe((data) => {
      if (data) {
        this.getAnnouncement(data);
      } else {
        this.announcement.getAnnouncemnetDetails().subscribe((data) => {
          this.getAnnouncement(data);
        });
      }
    });
  }
  getAnnouncement(data) {
    this.updateDisplayDate(data[0].announceId, data[0].announceType);
    this.announcmentModel.anouncementDetails = data;
    this.announcmentModel.titleContent = data[0].titleCode;
    this.announcmentModel.documentDownload = data[0].documents;
    this.announcmentModel.acceptanceText = data[0].acceptanceCode;
    this.convertByteToImage(0);
    this.announcmentModel.componentMessageContent = this.announcmentModel.anouncementDetails[0].announceCode;
  }

  ngOnDestroy() {
    this.announcmentModel.subscribeFlag = false;
  }



  updateDisplayDate(announceId, annouceType) {
    if (annouceType.toLowerCase() === 'personal')
      this.announcement.updateDisplayDate(announceId).pipe(takeWhile(() => this.announcmentModel.subscribeFlag))
        .subscribe((data) => {

        });

  }

  convertByteToImage(index) {
    if (this.announcmentModel.anouncementDetails[index].announceImage) {
      let bytes = this.announcmentModel.anouncementDetails[index].announceImage; // get from server
      //var uints = new Uint8Array(bytes);
      let base64String = btoa(String.fromCharCode(...new Uint8Array(bytes)))
      // var base64 = btoa(String.fromCharCode(null, uints));
      this.announcmentModel.url = 'data:image/jpeg;base64,' + base64String;
    } else {
      this.announcmentModel.url = '';
    }
  }
  acceptClickHandler(event) {
    event.preventDefault();
    if (this.announcmentModel.anouncementDetails[this.announcmentModel.acceptCounter].acceptanceMode == '1REQ') {
      if (this.announcmentModel.announceMentForm.valid && this.announcmentModel.announceMentForm.controls.acceptAck.value) {
        this.getNextAnnouncment();
      } else {
        this.announcmentModel.submitted = true;
      }
    } else {
      this.getNextAnnouncment();
    }
  }

  getNextAnnouncment() {
    this.announcmentModel.announceMentForm.reset();
    this.announcmentModel.submitted = false;
    this.saveHistoryDate(this.announcmentModel.anouncementDetails[this.announcmentModel.acceptCounter]);
    this.announcmentModel.acceptCounter = this.announcmentModel.acceptCounter + 1;
    if (this.announcmentModel.acceptCounter < this.announcmentModel.anouncementDetails.length) {
      //this.announcmentModel.acceptCounter = this.announcmentModel.acceptCounter + 1;
      this.updateDisplayDate(this.announcmentModel.anouncementDetails[this.announcmentModel.acceptCounter].announceId,
        this.announcmentModel.anouncementDetails[this.announcmentModel.acceptCounter].announceType);
      this.convertByteToImage(this.announcmentModel.acceptCounter);
      this.announcmentModel.acceptanceText = this.announcmentModel.anouncementDetails[this.announcmentModel.acceptCounter].acceptanceCode;
      this.announcmentModel.titleContent = this.announcmentModel.anouncementDetails[this.announcmentModel.acceptCounter].titleCode;
      this.announcmentModel.documentDownload = this.announcmentModel.anouncementDetails[this.announcmentModel.acceptCounter].documents;
      this.announcmentModel.componentMessageContent = this.announcmentModel.anouncementDetails[this.announcmentModel.acceptCounter].announceCode;
    }
    else {
      //this.router.navigate(['/contactdetail']);
      //this.router.navigate(['/homepage']);
      const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      sessionStorage.setItem('loginOperationType', 'login');
      let clientID = loggedUser && loggedUser.clientId ? loggedUser.clientId : null;
      this.menuItemService.menuItemApi(clientID, 'login').subscribe((data) => {
        sessionStorage.setItem('menuItemList', JSON.stringify(data));
        this.commonService.setDetail('menuItemList', data);
        this.menuItemService.navigationBasedOnRole(data);
      },
        (error: Error) => {
          //  this.router.navigate(['/homepage']);
        });
    }
  }

  saveHistoryDate(annpunceDetail) {
    if (annpunceDetail.announceType.toLowerCase() === 'personal')
      this.announcement.saveHistoryDate(annpunceDetail.announceId).pipe(takeWhile(() => this.announcmentModel.subscribeFlag))
        .subscribe((data) => {
        });
  }

  downloadForm(document) {
    if (document.document) {
      const byteCharacters = atob(document.document);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      // const blob = new Blob([byteArray], { type: "application/pdf" });
      // let url = window.URL.createObjectURL(blob);
      // window.open(url);
      let blob = new Blob([byteArray], { type: "application/pdf" });
      if (window.navigator.msSaveOrOpenBlob) {
        //IE11 & Edge
        window.navigator.msSaveOrOpenBlob(blob);
      } else {
        let url = window.URL.createObjectURL(blob);
        window.open(url);
      }
    }
  }

  onLogoutClickHandler() {
    this.translate.instant("eCustomer.logout.logOutDialogText1")
    // let message1 = `${this.translate.instant("eCustomer.logout.logOutDialogText1")}
    // ${this.translate.instant("eCustomer.logout.logOutDialogText2")}`;
    let message1 = `${this.translate.instant("eCustomer.logout.logOutDialogText")}`
    this.dialogService.openDialog(LogoutDialogComponent, {
      'heading': this.translate.instant("eCustomer.header.Logout"), 'body': message1
    });
  }
}
