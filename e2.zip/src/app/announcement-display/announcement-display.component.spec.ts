import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { AppModule } from '../app.module';

import { AnnouncementDisplayComponent } from './announcement-display.component';
import { AnnouncementDisplayModule } from './announcement-display.module';
import { AnnouncementDisplayService } from './service/announcement-display.service'
describe('AnnouncementDisplayComponent', () => {
  let component: AnnouncementDisplayComponent;
  let fixture: ComponentFixture<AnnouncementDisplayComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'retrieveAnnounceMent': host + '/api/v1/announcement'
      }
    }
  };
  const userToken = {
    token: "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJPc2FtYUFkbWluIiwidXNlciI6eyJ1c2VyTmFtZSI6Ik9zYW1hQWRtaW4iLCJmaXJzdE5hbWUiOiJPc2FtYSIsImxhc3ROYW1lIjoiTW8iLCJlbWFpbCI6Im9zYW1hLmtoYWxpZEBtZXRsaWZlLmNvbSIsInByZWZlcnJlZExhbmd1YWdlIjoiZW4iLCJjcmVhdGlvbkRhdGUiOiJXZWQgSmFuIDA2IDE0OjQyOjI0IENFVCAyMDIxIiwicGFzc3dvcmRUeXBlIjoiU1RBTkRBUkQiLCJjdXN0b21lclBhc3N3b3JkRXhwcmF0aW9uQ29kZSI6IjEiLCJwYXNzd29yZFN0YXR1c0NvZGUiOiJBQ1RJVkUiLCJzZWN1cml0eVBvbGljeUlkIjoiMTIzNDUiLCJ0b2tlbkV4cGlyYXRpb25EYXRlIjoiRnJpIFNlcCAxOCAxNzowMzo1MCBDRVNUIDIwMjAiLCJlbXBsb3llZU51bWJlciI6bnVsbCwicHdkRXhwaXJhdGlvbkRhdGUiOiJGcmkgTWFyIDE5IDE0OjQyOjI0IENFVCAyMDIxIiwiZmFpbGVkTG9naW5Db3VudHMiOiIwIiwiYXV0aG9yaXplZEFwcGxpY2F0aW9uQ29kZSI6ImVDdXN0b21lciIsInRlbXBvcmFyeUxvY2tEYXRlIjpudWxsLCJyb3V0ZSI6bnVsbCwicHdkRXhwaXJlZCI6bnVsbCwiZGF5c1NpbmNlUHdkTm90Q2hhbmdlZCI6bnVsbCwicHdkQ2hhbmdlRGF0ZSI6bnVsbCwicm9sZUluZm8iOlt7InJvbGVJZCI6IjMwMzMiLCJuYW1lIjoiclN1cGVyVXNlciIsImRlc2NyaXB0aW9uIjoiUlN1cGVyVXNlciJ9LHsicm9sZUlkIjoiMzAzNCIsIm5hbWUiOiJyQWRtaW5pc3RyYXRvciIsImRlc2NyaXB0aW9uIjoiU3lzdGVtQWRtaW5pc3RyYXRvciJ9XSwiY2xpZW50SWQiOm51bGwsInJlcXVlc3RlcklkIjpudWxsLCJyZXF1ZXN0ZXJSb2xlIjpudWxsLCJ1c2VyRG4iOiJvdT1QZW9wbGUsbz1hZmZpbGlhdGVzLGM9UG9sYW5kLG89bWV0bGlmZSxkYz1tZXRsaWZlLGRjPWNvbSIsInVzZXJDaGVjayI6dHJ1ZX0sImlhdCI6MTYxMjMzNzA1NCwiZXhwIjoxNjEyMzgwMjU0fQ.DF3cfAMA1Z0BLYN_k5yrqtWDcq1ed9z1Vu5EkIgj_x0",
    userName: "OsamaAdmin"
  };
  // beforeEach(async(() => {
  //   // window['__env'].environmentConstURLs = environmentConstURL;

  // }));

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, AnnouncementDisplayModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: [],
      providers: [AnnouncementDisplayService]
    })
      .compileComponents();
    window.sessionStorage.setItem('userToken', JSON.stringify(userToken));
    fixture = TestBed.createComponent(AnnouncementDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create announcement', () => {
    expect(component).toBeTruthy();
  });

  it('should create onLogoutClickHandler', () => {
    component.onLogoutClickHandler();
  });

  it('should call getAnnouncement ', () => {
    const response = [{
      announceType: 'personal',
      titleCode: 'ATR',
      documents: 'asa',
      acceptanceCode: 'adasd',
      announceId: 'sdsd'
    }];
    component.updateDisplayDate(response[0].announceId, response[0].announceType);
    component.getAnnouncement(response);
  });

  xit('should call getNextAnnouncment', () => {
    component.getNextAnnouncment();
    expect(component.announcmentModel.submitted).toEqual(false)
  })

});
