import { Component, OnInit } from '@angular/core';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConfig } from 'src/config/app.config';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { SharedServiceService } from '../../shared-service/shared-service.service';

import * as utils from 'lodash';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';

@Component({
  selector: 'my-offer-list',
  templateUrl: './my-offer-list.component.html',
  styleUrls: ['./my-offer-list.component.scss']
})
export class MyOfferListComponent implements OnInit {

  myOffer: any[];
  clientId = '';//101584;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  myOfferDetails: boolean = false;
  selectedOffer: any = '';
  userDetails: any;
  defaultOfferData: any;



  constructor(public commonService: HttpCommonService, private router: Router,
    private sanitizer: DomSanitizer, private r: ActivatedRoute,
    public sharedService: SharedServiceService, private menuItemService: MenuItemsService) {
    this.sharedService.getcurrentUserLoggedIn().subscribe((data) => {
      this.userDetails = data;
    });
  }

  ngOnInit() {
    this.clientId = this.sharedService.getClientId() != null ? this.sharedService.getClientId() : '';
    this.getMyOffersListData();
  }

  getMyOffersListData() {
    //if (this.clientId) {
    // let url = this.baseUrl.ecustomer.myOffersList + this.clientId + '/';
    // this.commonService['getData'](url).subscribe(data => {
    this.sharedService.getDetail('menuItemList').subscribe((data) => {
      const menuListFromClientSearch = JSON.parse(sessionStorage.getItem('menuListFromClientSearch')),
        menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
      if (menuListFromClientSearch) {
        this.policyOfferListData(menuListFromClientSearch);
      } else if (menuItemList) {
        this.policyOfferListData(menuItemList);
      }

    })
    //}
  }

  policyOfferListData(data) {
    if (data.offerResponse && (data.offerResponse.clientOffersList != null || data.offerResponse.policyOffersList != null)) {
      this.myOffer = data.offerResponse.clientOffersList != null ? utils.cloneDeep(data.offerResponse.clientOffersList) : [];
      // this.myOffer = data.clientOffersList;
      if (data.offerResponse.policyOffersList != null) {
        if (this.myOffer.length > 0) {
          data.offerResponse.policyOffersList.forEach(element => {
            this.myOffer.push(element);
          });
        } else {
          this.myOffer = data.offerResponse.policyOffersList;
        }
      }
      if (this.myOffer && this.myOffer.length != 0) {
        this.myOffer.forEach(item => {
          item.imageBase64 = '';
          item.imageBase64 = "data:image/png;base64," + item.offerMiniatureImage;
          item.imageBase64 = this.sanitizer.bypassSecurityTrustUrl(item.imageBase64);
        });
      }//
      if (this.myOffer && this.myOffer.length == 1) {
        this.gotoDetails(this.myOffer[0]);
      }
      //(this.myOffer);
    } else {
      this.myOffer = [];
    }
    this.sharedService.setOfferListCount(this.myOffer.length);
  }

  gotoDetails(data) {
    // this.router.navigate(['/myOffers/'], {
    //   queryParams: {
    //     id: data.offerListId,
    //   }
    // });
    this.router.navigate(['myOffers/offerlist']);
    //this.myOfferDetails = true;
    sessionStorage.setItem('offerListSingleItem', JSON.stringify(data));
    this.sharedService.setterData('offerList', data);
    //this.selectedOffer = data;
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }
}
