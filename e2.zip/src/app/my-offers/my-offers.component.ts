import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConfig } from 'src/config/app.config';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { SharedServiceService } from '../shared-service/shared-service.service';


@Component({
  selector: 'my-offers',
  templateUrl: './my-offers.component.html',
  styleUrls: ['./my-offers.component.scss']
})
export class MyOffersComponent implements OnInit {
  myOffer: any;
  clientId = '';
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  myOfferDetails: boolean = false;
  selectedOffer: any = '';



  constructor(public commonService: HttpCommonService, private router: Router,
    private sanitizer: DomSanitizer, private r: ActivatedRoute,
    public sharedService: SharedServiceService) {
  }

  ngOnInit() {
    //this.clientId = this.sharedService.getClientId()!= null ? this.sharedService.getClientId() : '';
    // this.getMyOffersListData();
  }

  // getMyOffersListData() {
  //   if (this.clientId) {
  //     let url = this.baseUrl.ecustomer.myOffersList + this.clientId + '/';
  //     this.commonService['getData'](url).subscribe(data => {
  //       this.myOffer = data.clientOffersList;
  //       data.policyOffersList.forEach(element => {
  //         this.myOffer.push(element);
  //       });
  //       this.myOffer.forEach(item => {
  //         item.imageBase64 = '';
  //         item.imageBase64 = "data:image/png;base64," + item.offerMiniatureImage;
  //         item.imageBase64 = this.sanitizer.bypassSecurityTrustUrl(item.imageBase64);
  //       });
  //       //(this.myOffer);
  //     })
  //   }
  // }

  // gotoDetails(data) {
  //   // this.router.navigate(['/myOffers/'], {
  //   //   queryParams: {
  //   //     id: data.offerListId,
  //   //   }
  //   // });
  //   this.router.navigate(['myOffers/offerlist']);
  //   //this.myOfferDetails = true;
  //   this.selectedOffer = data;
  // }


}
