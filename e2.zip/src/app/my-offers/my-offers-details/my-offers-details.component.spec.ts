import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { MyOffersModule } from '../my-offers.module';

import { MyOffersDetailsComponent } from './my-offers-details.component';

describe('MyOffersDetailsComponent', () => {
  let component: MyOffersDetailsComponent;
  let fixture: ComponentFixture<MyOffersDetailsComponent>;
  const menuListFromClientSearch = JSON.parse(sessionStorage.getItem('menuListFromClientSearch')),
    menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
  const menulist = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": {
      "clientOffersList": [{
        "clientId": "101583",
        "contractNumber": null,
        "offerDetailsText": "Pobyt w szpitalu w wyniku wypadku to spore nieprzewidziane koszty. W tym czasie Twoje dochody ulegają znacznemu zmniejszeniu. <BR><BR>Dodatkowy zastrzyk gotówki po wyjściu ze szpitala sprawi, że w razie potrzeby możesz przeznaczyć  dzięki czemu Pan Jacek może spokojnie planować przyszłe wakacje.",
        "offerDueDate": 1400104800000,
        "offerGenerationDate": 1388530800000,
        "offerId": "63D020I16",
        "offerMainImage": "/9j/4AAQSkZJRgABAQEAYABgAAD/4RtKRXhpZgAATU0AKgAAAA",
        "offerMarketingName": "Świadczenie Szpitalne - ochrona dla Ciebie",
        "offerMiniatureImage": "/9j/4AAQSkZJRgABAQEBLAEsAAD/4RJQRXhpZgAATU0AKgAAAA",
        "offerName": "MM16_Świadczenie Szpitalne",
        "offerPremium": 5555.55,
        "offerSort": 1,
        "offerSummaryText": "Świadczenie Szpitalne – to ubezpieczenie na wypadek pobytu w szpitalu wskutek nieszczęśliwego wypadku."
      }],
      "policyOffersList": [{
        "clientId": "101583",
        "contractNumber": "21295127",
        "offerDetailsText": "AmpliMED to ubezpieczenie na wypadek pobytu w szpitalu w następstwie nieszczęśliwego wypadku oraz inwalidztwa wskutek.",
        "offerDueDate": 1398895200000,
        "offerGenerationDate": 1388530800000,
        "offerId": "63D020IA8:B",
        "offerMainImage": "/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQ",
        "offerMarketingName": "AmpliMed – Ochrona dla Ciebie",
        "offerMiniatureImage": "/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQ",
        "offerName": "TM08_AmpliMED",
        "offerPremium": 1234.56,
        "offerSort": 1,
        "offerSummaryText": "AmpliMed to umowa dodatkowa"
      }]
    },
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  }
  const menuItemList2 = JSON.parse(sessionStorage.getItem('menuItemList'));
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'myOfferDetails': host + '/api/v1/announcement/offers'
      }
    }
  };
  const userToken = {
    token: "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJPc2FtYUFkbWluIiwidXNlciI6eyJ1c2VyTmFtZSI6Ik9zYW1hQWRtaW4iLCJmaXJzdE5hbWUiOiJPc2FtYSIsImxhc3ROYW1lIjoiTW8iLCJlbWFpbCI6Im9zYW1hLmtoYWxpZEBtZXRsaWZlLmNvbSIsInByZWZlcnJlZExhbmd1YWdlIjoiZW4iLCJjcmVhdGlvbkRhdGUiOiJXZWQgSmFuIDA2IDE0OjQyOjI0IENFVCAyMDIxIiwicGFzc3dvcmRUeXBlIjoiU1RBTkRBUkQiLCJjdXN0b21lclBhc3N3b3JkRXhwcmF0aW9uQ29kZSI6IjEiLCJwYXNzd29yZFN0YXR1c0NvZGUiOiJBQ1RJVkUiLCJzZWN1cml0eVBvbGljeUlkIjoiMTIzNDUiLCJ0b2tlbkV4cGlyYXRpb25EYXRlIjoiRnJpIFNlcCAxOCAxNzowMzo1MCBDRVNUIDIwMjAiLCJlbXBsb3llZU51bWJlciI6bnVsbCwicHdkRXhwaXJhdGlvbkRhdGUiOiJGcmkgTWFyIDE5IDE0OjQyOjI0IENFVCAyMDIxIiwiZmFpbGVkTG9naW5Db3VudHMiOiIwIiwiYXV0aG9yaXplZEFwcGxpY2F0aW9uQ29kZSI6ImVDdXN0b21lciIsInRlbXBvcmFyeUxvY2tEYXRlIjpudWxsLCJyb3V0ZSI6bnVsbCwicHdkRXhwaXJlZCI6bnVsbCwiZGF5c1NpbmNlUHdkTm90Q2hhbmdlZCI6bnVsbCwicHdkQ2hhbmdlRGF0ZSI6bnVsbCwicm9sZUluZm8iOlt7InJvbGVJZCI6IjMwMzMiLCJuYW1lIjoiclN1cGVyVXNlciIsImRlc2NyaXB0aW9uIjoiUlN1cGVyVXNlciJ9LHsicm9sZUlkIjoiMzAzNCIsIm5hbWUiOiJyQWRtaW5pc3RyYXRvciIsImRlc2NyaXB0aW9uIjoiU3lzdGVtQWRtaW5pc3RyYXRvciJ9XSwiY2xpZW50SWQiOm51bGwsInJlcXVlc3RlcklkIjpudWxsLCJyZXF1ZXN0ZXJSb2xlIjpudWxsLCJ1c2VyRG4iOiJvdT1QZW9wbGUsbz1hZmZpbGlhdGVzLGM9UG9sYW5kLG89bWV0bGlmZSxkYz1tZXRsaWZlLGRjPWNvbSIsInVzZXJDaGVjayI6dHJ1ZX0sImlhdCI6MTYxMjMzNzA1NCwiZXhwIjoxNjEyMzgwMjU0fQ.DF3cfAMA1Z0BLYN_k5yrqtWDcq1ed9z1Vu5EkIgj_x0",
    userName: "OsamaAdmin"
  };
  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    window.sessionStorage.setItem('menuListFromClientSearch', JSON.stringify(menulist));
    window.sessionStorage.setItem('userToken', JSON.stringify(userToken));
    const offerList = {
      "clientId": "101583",
      "contractNumber": null,
      "imageBase64": {
        changingThisBreaksApplicationSecurity: "data:image/png;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/"
      },
      "offerDetailsText": "Złamania i oparzenia w wyniku wypadku to spore nieprzewidziane koszty. W takich przypadkach ważne jest otrzymanie wsparcia finansowego. <BR><BR>Dodatkowy zastrzyk gotówki sprawi, że w razie potrzeby możesz przeznaczyć pieniądze na dostęp do lekarzy specjalistów, nowoczesne leczenie, rehabilitację lub dowolnie wybrany cel. <BR><BR>Praktyczna Ochrocz rzystwo wypłaciło Panu Szymonowi świadczenie, a jego rodzina długo jeszcze będzie wspominać zagraniczne wakacje.",
      "offerDueDate": 1400104800000,
      "offerGenerationDate": 1388530800000,
      "offerId": "75D010I03",
      "offerMainImage": "/9j/4AAQSkZJRgABAQEAYABgAAD/4RL6RXhpZgAATU0AKgAAAA",
      "offerMarketingName": "Praktyczna Ochrona - Oferta dla Ciebie",
      "offerMiniatureImage": "/9j/4AAQSkZJRgABAQEAYABgAAD/4RceRXhpZgAATU0AKgAAAA",
      "offerName": "MM16_Praktyczna Ochrona",
      "offerPremium": 324324,
      "offerSort": 2,
      "offerSummaryText": "Praktyczna Oc"
    };
    sessionStorage.setItem('offerListSingleItem', JSON.stringify(offerList));
    const userImfo =
      { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" }
    const serachClient =
      { "clientId": 1234, "opeType": "search" }
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, MyOffersModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(MyOffersDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(MyOffersDetailsComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
