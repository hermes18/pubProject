import { Component, Input, OnInit } from '@angular/core';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConfig } from 'src/config/app.config';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { TranslateService } from '@ngx-translate/core';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'my-offers-details',
  templateUrl: './my-offers-details.component.html',
  styleUrls: ['./my-offers-details.component.scss']
})
export class MyOffersDetailsComponent implements OnInit {

  appConfig: AppConfig = AppConfig.getConfig();
  @Input() offer: any;
  details: any;
  baseUrl = this.appConfig['api'];
  offerDetails: any;
  myOfferDetails: boolean = true;
  offerMarketingNameHeader: any;
  userDetails: any;
  OfferListLength: any;
  country: string;
  displayPoOption: boolean;
  currencyType: string;
  displayRoOption: boolean;
  langChange: string;

  constructor(public commonService: HttpCommonService, private router: Router,
    private sanitizer: DomSanitizer,
    public sharedService: SharedServiceService,
    public dialog: DialogService,
    private translate: TranslateService,
    private menuItemService: MenuItemsService) {

    //  this.userDetails = sessionStorage.getItem('loggedInUserInfo');

    this.sharedService.getcurrentUserLoggedIn().subscribe((data) => {
      const loggedInUserDetails = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      this.userDetails = loggedInUserDetails;
    });

  }
  lang: any;
  ngOnInit() {
    let clientOffersLength;
    let policyOffersLength;
    const menuListFromClientSearch = JSON.parse(sessionStorage.getItem('menuListFromClientSearch')),
      menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    if (menuListFromClientSearch) {
      clientOffersLength = menuListFromClientSearch.offerResponse.clientOffersList != null ? menuListFromClientSearch.offerResponse.clientOffersList.length : 0
      policyOffersLength = menuListFromClientSearch.offerResponse.policyOffersList != null ? menuListFromClientSearch.offerResponse.policyOffersList.length : 0;
      //this.policyOfferListData(menuListFromClientSearch);
    } else if (menuItemList) {
      //this.policyOfferListData(menuItemList);
      clientOffersLength = menuItemList.offerResponse.clientOffersList != null ? menuItemList.offerResponse.clientOffersList.length : 0
      policyOffersLength = menuItemList.offerResponse.policyOffersList != null ? menuItemList.offerResponse.policyOffersList.length : 0;
    } else {
    }
    this.OfferListLength = clientOffersLength + policyOffersLength;//this.sharedService.getOfferListCount();
    //("offerlength",this.OfferListLength)
    // this.userDetails = sessionStorage.getItem('loggedInUserInfo');
    // const a = sessionStorage.getItem('loggedInUserInfo');
    this.details = JSON.parse(sessionStorage.getItem('offerListSingleItem'));
    //this.sharedService.getterData('offerList') ? this.sharedService.getterData('offerList') : null;
    //("1111111111", this.userDetails);
    this.getOfferDetails();
    this.lang = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if(this.lang == "pl_en"){
      this.lang = "en";
    }else if(this.lang == "pl_pl"){
      this.lang = "pl";
    } else if(this.lang == "ro_en"){
      this.lang = "en";
    }else if(this.lang == "ro_ro"){
      this.lang = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.lang = data;
      }
    });
    this.country = sessionStorage.getItem('countryCode');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
      this.currencyType = 'PLN';
    }
    else {
      this.displayRoOption = true;
      this.currencyType = 'RON';
    }
    this.langChange = sessionStorage.getItem('defaultLanguage');
    if(this.langChange == "pl_en"){
      this.langChange = "en";
    }else if(this.langChange == "pl_pl"){
      this.langChange = "pl";
    } else if(this.langChange == "ro_en"){
      this.langChange = "en";
    }else if(this.langChange == "ro_ro"){
      this.langChange = "ro";
    }
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.langChange = data;
      }
    });
  }

  getOfferDetails() {
   // http://10.64.51.178:9080/emea/api/v1/announcement/retrieveOfferDetails?offerId=60A010I14&clentId=101583&policyNo=&userRole=user
    // localhost:9088/api/v1/announcement/retrieveOfferDetails/?offerId=60A010I14&clentId=101583&policyNo=&userRole=user 
    //let url = this.baseUrl.ecustomer.myOfferDetails + '?' + 'offerId=' + this.details.offerId + '&' + 'clentId=' + this.details.clientId + '&' + 'policyNo=' + (this.details.contractNumber ? this.details.contractNumber : '') + '&' + 'userRole=' + this.userDetails.roleInfo[0].name;
    // let url = this.baseUrl.ecustomer.myOfferDetails + '?offerId=63D020IB8:B&clentId=101584&policyNo=&userRole=';
    let request = {
      "offerId": this.details.offerId ? this.details.offerId : '',//"63HB20IB8:B",
      "clentId": this.details.clientId ? this.details.clientId: '',//"101583",
      "policyNo": this.details.contractNumber ? this.details.contractNumber : '',
      "userRole": this.userDetails.roleInfo[0].name ? this.userDetails.roleInfo[0].name : ''
  }
    this.commonService.postData(this.baseUrl.ecustomer.myOfferDetails,request,'').subscribe(data => {
      if (data && data != null) {
        this.offerDetails = data;
        this.offerMarketingNameHeader = data.offerConfigurationDto.offerName;
        this.offerDetails.imageBase64 = '';
        this.offerDetails.imageBase64 = "data:image/png;base64," + this.offerDetails.offerConfigurationDto.offerMainImage;
        this.offerDetails.imageBase64 = this.sanitizer.bypassSecurityTrustUrl(this.offerDetails.imageBase64);
        this.offerDetails.contractNumber = null;
        this.offerDetails.contractNumber = this.details.contractNumber;
        //(this.offerDetails);
      } else {
        //let url = this.baseUrl.ecustomer.myOfferDetails + '?' + 'offerId=' + '' + '&' + 'clentId=' + this.userDetails.clientId + '&' + 'policyNo=' + '' + '&' + 'userRole=' + this.userDetails.roleInfo[0].name;
        // this.commonService['getData'](url).subscribe(data => {
        //   //(data);
        // });
      }
    })
  }

  gotoList() {
    //this.myOfferDetails = false;
    this.router.navigate(['/myOffers']);
  }

  downloadOffersDoc(document) {
    let url = this.baseUrl.ecustomer.downloadOffersPdf + document.documentId;
    this.commonService.downloadPDF(url).subscribe(data => {
      this.downloadFile(data);
    });
  }

  downloadFile(data) {
    let blob = new Blob([data], { type: "application/pdf" });
    if (window.navigator.msSaveOrOpenBlob) {
      //IE11 & Edge
      window.navigator.msSaveOrOpenBlob(blob);
    } else {
      let url = window.URL.createObjectURL(blob);
      window.open(url);
    }
  }

  gotoContractForm(contract) {
    //this.router.navigate(['/mycontracts']);
    //(contract);
    const mobileContractView = {
      'contractDetails': contract,
      'showSubMenu': true
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    sessionStorage.setItem('menuSelectedItem', 'contractMenu');
    this.sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    sessionStorage.setItem('contractDetails', JSON.stringify(contract));
    this.menuItemService.getSubmenuList(contract);
    // let data = {
    //   "contractNo": contract.contractNumber,
    //   "contractStatus": ''
    // }
    // sessionStorage.setItem('contractDetails', JSON.stringify(contract));
    // this.menuItemService.getSubmenuList(contract);
  }

  navigateToContactForm() {
    // if (this.userDetails.roleInfo[0].name == 'rClient') {
    //   this.gotoContractForm();
    //   //this.router.navigate(['/contact-form']);
    // } else {
    this.dialog.openDialog(AlertDialogComponent, { 'heading': this.translate.instant('eCustomer.offers.Alert'), 'body': this.translate.instant('eCustomer.offers.Youhavenoauthorizationtosentcontacttooffer') });
    // }
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }
}
