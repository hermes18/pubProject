import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyOffersRoutingModule } from './my-offers-routing.module';
import { MyOffersComponent } from './my-offers.component';
import { TranslateModule } from '@ngx-translate/core';
import { MyOffersDetailsComponent } from './my-offers-details/my-offers-details.component';
import { MyOfferListComponent } from './my-offer-list/my-offer-list.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    MyOffersComponent,
    MyOffersDetailsComponent,
    MyOfferListComponent
  ],
  imports: [
    CommonModule,
    TranslateModule,
    MyOffersRoutingModule,SharedModule
  ]
})
export class MyOffersModule { }
