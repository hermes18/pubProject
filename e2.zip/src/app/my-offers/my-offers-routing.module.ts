import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material';
import { MyOffersComponent } from './my-offers.component';
import { MyOffersDetailsComponent } from './my-offers-details/my-offers-details.component';
import { MyOfferListComponent } from './my-offer-list/my-offer-list.component';
import { NavigationGuard } from '../core/gaurds/navigation-guard';

const routes: Routes = [
  {
    path: '', component: MyOffersComponent, canDeactivate: [NavigationGuard],
    children: [
      { path: '', component: MyOfferListComponent, canDeactivate: [NavigationGuard] },
      { path: 'offerlist', component: MyOffersDetailsComponent, canDeactivate: [NavigationGuard] }
    ]

  }



];

@NgModule({
  imports: [RouterModule.forChild(routes), MatFormFieldModule],
  exports: [RouterModule, MatFormFieldModule]
})
export class MyOffersRoutingModule { }
