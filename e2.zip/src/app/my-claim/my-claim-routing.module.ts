import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MyClaimComponent } from './my-claim.component';
import { MatFormFieldModule, MatPaginatorModule } from '@angular/material';
import { NavigationGuard } from '../core/gaurds/navigation-guard';


const routes: Routes = [
  { path: '', component: MyClaimComponent, canDeactivate: [NavigationGuard] }
];

@NgModule({
  declarations: [],

  imports: [RouterModule.forChild(routes), MatFormFieldModule, MatPaginatorModule],
  exports: [RouterModule, MatFormFieldModule, MatPaginatorModule]

})
export class MyClaimRoutingModule { }
