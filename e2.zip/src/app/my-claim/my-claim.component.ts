import { Component, OnInit } from '@angular/core';
import { AppConfig } from 'src/config/app.config';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { HttpCommonService } from '../shared/services/http-common.service';

@Component({
  selector: 'my-claim',
  templateUrl: './my-claim.component.html',
  styleUrls: ['./my-claim.component.scss']
})
export class MyClaimComponent implements OnInit {

  myClaim
  clientId = 101584;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  claimUrl = this.baseUrl.ecustomer.myClaim + this.clientId;

  //claimUrl = environment.myClaim.testurl;//mock json url 
  constructor(public commonService: HttpCommonService, public sharedService: SharedServiceService, private menuItemService: MenuItemsService) { }

  ngOnInit() {

    //(this.claimUrl);
    const reqParam = {
      clientId: this.clientId
    };
    //this.commonService['postData'](this.baseUrl.ecustomer.myClaim,reqParam,'').subscribe(data => {
    this.sharedService.getDetail('menuItemList').subscribe(data => {
      if (data && data.claimList) {
        this.myClaim = data.claimList;
        //(data);
        //(this.myClaim);
      }
    });
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }
}