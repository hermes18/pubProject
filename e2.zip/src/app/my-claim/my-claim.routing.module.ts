import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MyClaimComponent } from './my-claim.component';
import { MatFormFieldModule, MatPaginatorModule } from '@angular/material';


const routes: Routes = [
  { path: '', component: MyClaimComponent }
];

@NgModule({
  declarations: [],
 
    imports: [RouterModule.forChild(routes),MatFormFieldModule,MatPaginatorModule],
    exports: [RouterModule,MatFormFieldModule,MatPaginatorModule]
  
})
export class MyClaimRoutingModule { }
