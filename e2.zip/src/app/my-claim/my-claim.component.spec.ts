import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { AppModule } from '../app.module';

import { MyClaimComponent } from './my-claim.component';
import { MyClaimModule } from './my-claim.module';

describe('MyClaimComponent', () => {
  let component: MyClaimComponent;
  let fixture: ComponentFixture<MyClaimComponent>;

  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule, AppModule, MyClaimModule, HttpClientTestingModule, TranslateModule.forRoot()],

  //     declarations: []
  //   })
  //     .compileComponents();
  // }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, MyClaimModule, HttpClientTestingModule, TranslateModule.forRoot()],

      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(MyClaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
