import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule, MatTooltipModule, MatSidenavModule, MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule, MatExpansionModule, MatTabsModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatInputModule, MatPaginatorModule, MatSortModule, MatTableModule } from '@angular/material';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { NgxPaginationModule } from 'ngx-pagination';
import { SharedModule } from '../shared/shared.module';
import { MyClaimComponent } from './my-claim.component';
import { MyClaimRoutingModule } from './my-claim-routing.module';


const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule,];
@NgModule({
  declarations: [MyClaimComponent],
  imports: [
    CommonModule,
    MyClaimRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    ...materialModule,
    NgxPaginationModule,
    SharedModule
  ]
})
export class MyClaimModule { }




