import { Component, OnInit } from '@angular/core';
import { MenuItemsService } from '../shared-service/menu-items.service';

@Component({
  selector: 'personal-data',
  templateUrl: './personal-data.component.html',
  styleUrls: ['./personal-data.component.scss']
})
export class PersonalDataComponent implements OnInit {

  constructor(private menuItemService: MenuItemsService) { }

  ngOnInit() {
  }
  gotoHome() {
   
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }
}
