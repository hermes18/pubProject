import { Component, OnInit } from '@angular/core';
import { PersonalDataService } from '../personal-data.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'personaldata-order',
  templateUrl: './personaldata-order.component.html',
  styleUrls: ['./personaldata-order.component.scss']
})
export class PersonaldataOrderComponent implements OnInit {
  loggedInCountry = sessionStorage.getItem("countryCode");
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];

  constructor(public personalDataService: PersonalDataService,
    public commonService: HttpCommonService, private readonly router: Router) { }

  ngOnInit() {
    this.orderID = this.personalDataService.personalDataOrderId.orderId;
    sessionStorage.setItem('personalDataOrderId',this.orderID);
  }
orderID;
goToOrderDetails(){
  this.router.navigate(['/orderHistory/clientDataChange']); 
  
  //this.orderDetailsService();
}

  
}
