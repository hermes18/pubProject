import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { PersonalDataModule } from '../personal-data.module';
import { PersonalDataService } from '../personal-data.service';

import { PersonaldataOrderComponent } from './personaldata-order.component';

describe('PersonaldataOrderComponent', () => {
  let component: PersonaldataOrderComponent;
  let fixture: ComponentFixture<PersonaldataOrderComponent>;

  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule, AppModule, PersonalDataModule, HttpClientTestingModule],
  //     providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
  //     declarations: []
  //   })
  //     .compileComponents();
  // }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, PersonalDataModule, HttpClientTestingModule],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(PersonaldataOrderComponent);
    component = fixture.componentInstance;
    component.personalDataService.personalDataOrderId = {
      orderId: 121212
    };
    fixture.detectChanges();
  });

  it('should create', inject([PersonalDataService], (personalDataService: PersonalDataService) => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 7000;

    expect(component).toBeTruthy();
  }));
});
