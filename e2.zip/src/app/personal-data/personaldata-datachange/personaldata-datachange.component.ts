import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PersonalDataChangeModel } from './model/personaldata-datachange.model';
import { PersonalDataService } from '../personal-data.service';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UtilityService, countryList } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'personaldata-datachange',
  templateUrl: './personaldata-datachange.component.html',
  styleUrls: ['./personaldata-datachange.component.scss']
})
export class PersonaldataDatachangeComponent implements OnInit {
  dataChangeModel: PersonalDataChangeModel;
  loggedInCountry = sessionStorage.getItem("countryCode");
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];

  isEmailValid: boolean = true;
  isOptionalEmailValid: boolean = true;
  isMobileValid: boolean = true;
  isLandlineValid: boolean = true;
  isAddressValid: boolean = true;
  addressError: any;
  loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
  //personalDataChangeForm: any;
  constructor(private fb: FormBuilder, private readonly router: Router,
    public personalDataService: PersonalDataService,
    public commonService: HttpCommonService,
    public deviceDetector: DeviceDetectorService,
    public sharedService: SharedServiceService) {
    this.dataChangeModel = new PersonalDataChangeModel();
    //   this.personalDataChangeForm = this.personalDataModel.personalDataForm;
  }
  personalDataChangeForm = this.fb.group({
    "landlineNumberNew": [''],
    "mobileNumberNew": [''],
    "emailNew": [''],
    "optionalEmailNew": [''],
    "addressChange": this.fb.group({
      "policyNumber": [''],
      "policyName": [''],
      "id": [''],
      "clientId": [''],
      "addressInstitution": [''],
      "postOffice": [''],
      "postBox": [''],
      "addressLine1": [''],
      "addressLine2": [''],
      "state": [''],
      "country": "",
      "city": "",
      "pinCode": [''],
      "street": "",
      "flat": [''],
      "house": [''],
      "uploadFileList": [null],
      "uploadFile": [''],
      "addressId": [''],
      "policyNumbersList": [null],
      "policyNameAndNumbersList": [null],
      "streetList": [null],
      "citiesList": [null],
      "postCodeList": [null],
      "streetName": [''],
      "cityName": [''],
      "postCode": [''],
      "countryName": [''],
      "countryCode": [''],
      "countriesResultList": [null],
      "county": [''],
      "apartment": [''],
      "sector": [''],
      "block": [''],
      "entrance": [''],
    })
  });
  existingPersonalData;
  isMobile = this.deviceDetector.isMobile();
  loggedInCountryCheck = UtilityService.getCountry();;
  ngOnInit() {
    let addressControls = this.personalDataChangeForm.get('addressChange')['controls'];
    if (this.loggedInCountryCheck) {
      // if (this.loggedInCountry.toLowerCase() === 'pl') {
      this.getPostalList();
      // this.personalDataChangeForm.get('addressChange').get('countryCode').setValue('PL');
      this.personalDataChangeForm.get('addressChange').get('countryCode').setValue(this.loggedInCountry.toUpperCase());
      this.personalDataChangeForm.get('addressChange').get('country').setValue(this.loggedInCountry.toUpperCase());

      //this.personalDataChangeForm.get('addressChange').get('country').setValue('PL');
    } else {
      this.personalDataChangeForm.get('addressChange').get('countryCode').setValue('');
      this.personalDataChangeForm.get('addressChange').get('country').setValue('');

    }


    this.existingPersonalData = this.personalDataService.getPersonalData();


    if (Object.keys(this.existingPersonalData).length === 0) {
      this.goToPersonalInfo();
    }
    this.personalDataChangeForm.controls['landlineNumberNew'].setValue(this.existingPersonalData.landlineNumberr);
    // if (this.loggedInCountry.toLowerCase() === 'pl') {
    if (this.loggedInCountryCheck) {
      this.personalDataChangeForm.controls['mobileNumberNew'].setValue(this.existingPersonalData.mobileNumber);
    }
    if (this.loggedInCountry.toLowerCase() === 'ro') {
      this.personalDataChangeForm.controls['mobileNumberNew'].setValue(this.existingPersonalData.primaryNumber);
    }
    this.personalDataChangeForm.controls['emailNew'].setValue(this.existingPersonalData.email);
    this.personalDataChangeForm.controls['optionalEmailNew'].setValue(this.existingPersonalData.optionalEmail);

    if (this.existingPersonalData.policyAddressList &&
      this.existingPersonalData.policyAddressList.length == 1) {

      let addressData = this.existingPersonalData.policyAddressList[0].addressChangeDto;
      addressControls['streetName'].setValue(addressData.streetName);
      addressControls['street'].setValue(addressData.street);
      // addressControls['countryCode'].setValue(addressData.countryCode);

      //this.loggedInCountry.toLowerCase() === 'pl'
      if ((addressData.countryCode === null || addressData.countryCode == '') && this.loggedInCountryCheck) {
        addressControls['countryCode'].setValue(this.loggedInCountry.toUpperCase());
      } else {
        addressControls['countryCode'].setValue(addressData.countryCode);
      }
      addressControls['postCode'].setValue(addressData.postCode);
      addressControls['pinCode'].setValue(addressData.pinCode);
      addressControls['city'].setValue(addressData.city);
      // addressControls['country'].setValue(addressData.countryCode);

      //this.loggedInCountry.toLowerCase() === 'pl'
      // addressData.countryCode.toLowerCase()=='pl'
      if (addressData.countryCode && addressData.countryCode.toLowerCase() == countryList.responseCountryList && this.loggedInCountryCheck) {
        addressControls['house'].setValue(addressData.house);
        addressControls['flat'].setValue(addressData.flat);

      } else if (this.loggedInCountry.toLowerCase() === 'ro') {
        addressControls['house'].setValue(addressData.house);
        addressControls['county'].setValue(addressData.country);
        addressControls['apartment'].setValue(addressData.apartment);
        addressControls['block'].setValue(addressData.block);
        addressControls['entrance'].setValue(addressData.entrance);
        addressControls['sector'].setValue(addressData.sector);

      }


    }




    this.dataChangeModel.loggedInCountry = sessionStorage.getItem("countryCode");
    // this.dataChangeModel.contactDetailChangeDataForm = this.formBuilder.group({
    //   phoneNumber: '',
    //   mobileNumber: '',
    //   emailField: ''
    // });
    let addressChange
    if (this.loggedInCountry.toLowerCase() === 'ro') {
      //this.dataChangeModel.contactDetailChangeDataForm.addControl('emailMainAddress', new FormControl(''));
      this.personalDataChangeForm.get('addressChange').get('county').setValidators([Validators.required]);
      this.personalDataChangeForm.get('addressChange').get('streetName').setValidators([Validators.required]);
      this.personalDataChangeForm.get('addressChange').get('city').setValidators([Validators.required]);
      this.personalDataChangeForm.get('addressChange').updateValueAndValidity();
    } else if (this.loggedInCountryCheck) {
      //this.loggedInCountry.toLowerCase() === 'pl'
      let addressFileds = ['countryCode', 'streetName', 'city', 'postCode']
      if (addressControls['house'].value.toLowerCase() === countryList.responseCountryList) {
        addressFileds.push('house');
      }

      for (let i = 0; i < addressFileds.length; i++) {
        this.setAddressValidator(addressFileds[i], [Validators.required]);
      }

      this.personalDataChangeForm.get('addressChange').updateValueAndValidity();

    }



    this.sharedService.getLangChange().subscribe((data) => {

      if (this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')]) {
        this.countryList = this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')];
      } else {
        this.getCountryList(this.personalDataChangeForm.get('addressChange').get('countryCode').value);
      }


    });

    /* this.countryListFilter = this.personalDataChangeForm.get('countryCode').valueChanges.pipe(
       startWith(''),
       map(val => this.filter(val))
     );
    */

    this.personalDataChangeForm.get('addressChange')
      .get('postCode').valueChanges.subscribe((value) => {
        let countryCode = this.personalDataChangeForm.value.addressChange.countryCode;
        if (this.loggedInCountryCheck && countryCode == countryList.upperCaseCountryList) {
          //this.loggedInCountry.toLowerCase() === 'pl'
          this.onPostalChange(value);
        }
      });

    this.personalDataChangeForm.get('addressChange')
      .get('city').valueChanges.subscribe((value) => {
        let countryCode = this.personalDataChangeForm.value.addressChange.countryCode;
        //this.loggedInCountry.toLowerCase() === 'pl'
        if (this.loggedInCountryCheck && countryCode == countryList.upperCaseCountryList) {
          this.getCityList(value);
        }



      });


    this.personalDataChangeForm.get('addressChange')
      .get('streetName').valueChanges.subscribe((value) => {
        let countryCode = this.personalDataChangeForm.value.addressChange.countryCode;
        if (this.loggedInCountryCheck && countryCode == 'PL') {
          //this.loggedInCountry.toLowerCase() === 'pl'
          this.getStreetList(value);
        }



      });

    /*
    this.streetFilterOptions = this.personalDataChangeForm.get('addressChange').get('streetName').valueChanges.pipe(
      startWith(''),
      map(value => this.streetFilter(value))
    ); */

  }

  setAddressValidator(field, arr) {
    this.personalDataChangeForm.get('addressChange').get(field).setValidators(arr);
  }

  streetFilter(val): string[] {
    //const filterValue = val.toLowerCase();

    const filterValue = this._normalizeValue(val);
    // return this.streetList.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
    return this.streetList.filter(option => this._normalizeValue(option).includes(filterValue));
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }


  ngOnDestroy() {
    this.dataChangeModel.subscribeFlag = false;
  }

  goToPersonalInfo() {
    this.router.navigate(['personalInfo']);

  }
  goToPersonalReview() {
    console.log(this.personalDataChangeForm.get('addressChange').valid, "addresschange");
    this.markFormGroupTouched(this.personalDataChangeForm.get('addressChange'));
    if (this.loggedInCountry == 'ro') {
      if (!this.isOptionalEmailValid) {
        return;
      }
    }
    if (this.isEmailValid && this.isMobileValid
      && this.isLandlineValid) {


      if (this.personalDataChangeForm.get('addressChange').valid) {
        if (this.loggedInCountry == 'ro') {
          this.doForValidAddress();
        } else {
          this.validateAddress('isAddressValid', 'addressError');
        }

      }







    }

  }
  countryList: any;
  countryListFilter: any;
  postalCodeList: any = [];
  postalListFilter: any;
  cityList: any = [];
  cityListFilter: any;
  streetList: any = [];
  streetFilterOptions: any = [];

  getCountryList(selectedCountry) {
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.countryList;
    this.commonService['getData'](url).subscribe(data => {
      ////("data", data);
      this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')] = data;

      this.countryList = data;

      setTimeout(() => {
        this.personalDataChangeForm.get('addressChange').get('countryCode').setValue(selectedCountry);
        this.personalDataChangeForm.get('addressChange').get('country').setValue(selectedCountry);
      });
    });
  }

  onCountrySelect(countryCode) {

    // if (this.loggedInCountry.toLowerCase() === 'pl') {
    if (this.loggedInCountryCheck) {
      if (countryCode && countryCode != '' && countryCode == 'PL'
      ) {
        this.getPostalList();
      } else {
        this.postalCodeList = [];
        this.cityList = [];
        this.streetList = [];
      }
      if (countryCode == 'PL') {

        this.personalDataChangeForm.get('addressChange').get('flat').enable();
        this.personalDataChangeForm.get('addressChange').get('house').enable();

      } else if (countryCode != 'PL') {
        this.personalDataChangeForm.get('addressChange').get('flat').setValue('');
        this.personalDataChangeForm.get('addressChange').get('house').setValue('');

        this.personalDataChangeForm.get('addressChange').get('flat').disable();
        this.personalDataChangeForm.get('addressChange').get('house').disable();
      }


      this.isAddressValid = true;
    }
  }
  postalSelected: any = false;
  onPostalSelect() {
    setTimeout(() => {
      //console.log("ads",this.personalDataChangeForm.value.addressChange.postCode);

      // if(this.postalSelected){
      let countryCode = this.personalDataChangeForm.value.addressChange.countryCode;
      if (this.loggedInCountryCheck && countryCode == 'PL') {
        //this.loggedInCountry.toLowerCase() === 'pl'

        this.getCityList();

      }
      this.postalSelected = false;
      //  }


    }, 500)
    this.isAddressValid = true;
  }
  onCitySelect() {
    /*let countryCode = this.personalDataChangeForm.value.addressChange.countryCode;
    if (this.loggedInCountry.toLowerCase() === 'pl' && countryCode == 'PL') {
      
  
      this.getStreetList();
      
    }*/
    this.isAddressValid = true;
  }

  getPostalList(pinCode?: any) {
    let countryCode = this.personalDataChangeForm.value.addressChange.countryCode;
    let postalCode = pinCode ? pinCode : this.personalDataChangeForm.value.addressChange.postCode;
    let city = this.personalDataChangeForm.value.addressChange.city;
    let street = this.personalDataChangeForm.value.addressChange.streetName;


    let req =
    {
      "countryCode": countryCode,
      "pinCode": postalCode,
      "city": city,
      //"street":street
    };

    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.zipCodeList;
    this.commonService['postData'](url, req, headers, { loader: 'true' }).subscribe(data => {
      ////("data", data);
      this.postalCodeList = data;

    });

  }
  onPostalChange(eventValue) {
    let pinCode = eventValue;
    this.getPostalList(pinCode);


  }

  onStreetBlur() {
    this.isAddressValid = true;
  }
  onBlurFlat() {
    this.isAddressValid = true;
  }
  onBlurHouse() {
    this.isAddressValid = true;
  }
  getCityList(citye?: any) {
    let countryCode = this.personalDataChangeForm.value.addressChange.countryCode;
    let postalCode = this.personalDataChangeForm.value.addressChange.postCode;
    let city = citye ? citye : this.personalDataChangeForm.value.addressChange.city;
    let street = this.personalDataChangeForm.value.addressChange.streetName;


    let req =
    {
      "countryCode": countryCode,
      "pinCode": postalCode,
      "city": city,
      // "street":street
    };
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.cityList;
    this.commonService['postData'](url, req, headers, { loader: 'true' }).subscribe(data => {
      ////("data", data);
      this.cityList = data;
      if (data && data != '' && data.length == 1) {
        //this.personalDataChangeForm.get('addressChange').get('city').setValue(data[0]);
        //this.onCitySelect();
      }

    });

  }
  getStreetList(streeet?: any) {
    let countryCode = this.personalDataChangeForm.value.addressChange.countryCode;
    let postalCode = this.personalDataChangeForm.value.addressChange.postCode;
    let city = this.personalDataChangeForm.value.addressChange.city;
    let street = streeet ? streeet : this.personalDataChangeForm.value.addressChange.streetName;


    let req =
    {
      "countryCode": countryCode,
      "pinCode": postalCode,
      "city": city,
      "street": street
    };
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.street;
    this.commonService['postData'](url, req, headers, { loader: 'true' }).subscribe(data => {
      ////("data", data);
      this.streetList = data;
      if (data && data != '' && data.length == 1) {
        // this.personalDataChangeForm.get('addressChange').get('streetName').setValue(data[0]);
      }
    });

  }
  emailOldValue: any = null;
  optionalEmailOldValue: any = null;

  validateEmail(email, emailValid, oldValue) {

    // let emailText = document.getElementById('newEmaitextid') as HTMLInputElement;
    // let emailchkbx = document.getElementById('emailChkBx') as HTMLInputElement;
    // this.blankInputs =false;    
    this[emailValid] = true;
    let emailValue = email ? email : ''
    if (emailValue && (emailValue != this[oldValue])) {
      this[oldValue] = emailValue;
      let headers = new HttpHeaders({});
      //const baseUrl = this.baseUrl.ecustomer.validationConfig + emailValue + "/validate";
      const param = {
        email: emailValue
      };
      this.commonService.postData(this.baseUrl.ecustomer.emailvalidation, param, '').subscribe((response) => {


        this[emailValid] = response;
        // let old = this.contactDetail.get('currentEmail').value;
        // this.contactDetail.get('newEmail').setValue(old);



      })

    }
  }

  mobileOld: any = null;
  landlineOld: any = null;
  validateMobile(mobileNum, isvalid, oldValue) {
    //this.blankInputs =false;
    this[isvalid] = true;
    //if (this.loggedInCountry.toLowerCase() === 'pl') {
    if (this.loggedInCountryCheck) {
      let mobileValue = mobileNum ? mobileNum : ''
      let userId = this.loggedUser.userName;
      if (mobileValue && (mobileValue != this[oldValue])) {
        this[oldValue] = mobileValue;
        let headers = new HttpHeaders({});
        const baseUrl = this.baseUrl.ecustomer.validationConfig + mobileValue + "/validate/" + userId;
        const param = {
          phoneNumber: mobileValue,
          userId: userId
        }
        this.commonService.postData(this.baseUrl.ecustomer.validationConfig, param, '').subscribe((response) => {
          this[isvalid] = response;
        })
      }
    }
  }




  validateAddress(isvalid, addressError) {
    //this.blankInputs =false;
    // let mobiletxt = document.getElementById('newMobile') as HTMLInputElement;
    // let mobilechkbx = document.getElementById('mobileChkBx') as HTMLInputElement;
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'))
    let userId = loggedUser['userName'];

    let headers = new HttpHeaders({});
    const baseUrl = this.baseUrl.ecustomer.validateAddress;
    let addressVal = this.personalDataChangeForm.value.addressChange;
    const param = {
      "country": addressVal.countryCode,
      "flat": addressVal.flat,
      "city": addressVal.city,
      "house": addressVal.house,
      "pinCode": addressVal.postCode,
      "street": addressVal.streetName,
      "userId": userId,
      "landline": this.personalDataChangeForm.value.landlineNumberNew,
      "mobile": this.personalDataChangeForm.value.mobileNumberNew,
      "email": this.personalDataChangeForm.value.optionalEmailNew,
    }

    this.commonService.postData(this.baseUrl.ecustomer.validateAddress, param, '').subscribe((response) => {


      this[isvalid] = response.validAddress;
      //'eCustomer.personalData.StreetnameisoutofList'
      this[addressError] = this.getErrorMsg(response.errorCode);
      // let old = this.contactDetail.get('currentmobileNO').value;
      // this.contactDetail.get('newmobileNO').setValue(old);


      this.isOptionalEmailValid = response.isValidEmail;
      this.isMobileValid = response.isValidMobile;
      this.isLandlineValid = response.isValidLandLine;

      if (response.validAddress && response.isValidEmail
        && response.isValidLandLine && response.isValidMobile) {
        this.doForValidAddress();
      }
    })


  }

  doForValidAddress() {
    let addressControls = this.personalDataChangeForm.get('addressChange')['controls'];
    this.personalDataChangeForm.get('addressChange').get('house').setValue(this.personalDataChangeForm.value.addressChange.house);
    this.personalDataChangeForm.get('addressChange').get('flat').setValue(this.personalDataChangeForm.value.addressChange.flat);
    // if(addressControls['countryCode']!='PL'){
    //   addressControls['house'].setValue('');
    //   addressControls['flat'].setValue('');
    // }

    this.personalDataService.setNewPersonalData(this.personalDataChangeForm.value);
    this.router.navigate(['personalInfo/personal-dataReview']);

  }

  getErrorMsg(errCode) {
    return ('eCustomer.personalData.' + this.errorConst[errCode]);
  }
  errorConst = {
    "1200510": "Invalidcountryerror",

    "1200518": "Streetisempty",

    "1200522": "Pincodeformatincorrect",

    "1200523": "Cityisempty",

    "1200407": "CitynameisoutofList",

    "1200409": "Postalcodedoesnotfitaddressdetailsprovided",

    "1200406": "StreetnameisoutofList",

    "1200408": "Streetforthegivencitynotfound",

    "1200519": "Nohousenumber",

    "205": "AddressValdiationError",

    "1200405": "AddressValdiationError"
  }


  markFormGroupTouched(formGroup: any) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      // control.updateValueAndValidity();
      if (control['controls']) {
        this.markFormGroupTouched(control);

      }
    })

  }
}

