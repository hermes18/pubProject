import { FormGroup } from '@angular/forms';


export class PersonalDataChangeModel {
    contactDetailChangeDataForm: FormGroup;
    subscribeFlag: boolean;
    loggedInCountry: string;
    constructor() {
        this.loggedInCountry = '';
        this.subscribeFlag = true;

    }
}