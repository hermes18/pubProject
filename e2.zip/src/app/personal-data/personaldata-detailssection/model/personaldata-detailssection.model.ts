import { FormGroup } from '@angular/forms';


export class PersonalDataDetailsSectionModel {
    myConsentForm: FormGroup;
    subscribeFlag: boolean;
    constructor() {
    }
}