import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { PersonalDataModule } from '../personal-data.module';

import { PersonaldataDetailssectionComponent } from './personaldata-detailssection.component';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';

describe('PersonaldataDetailssectionComponent', () => {
  let component: PersonaldataDetailssectionComponent;
  let fixture: ComponentFixture<PersonaldataDetailssectionComponent>;
  let sharedService: SharedServiceService;
  let commonService: HttpCommonService;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'personalDataRender': host + '/api/v1/users/personal-data',
        'countryList': host + '/api/v1/claim/retriveCountryList',
        'consentUpdate': host + '/api/v1/users/personal-data-consent-update',
        'retrieveAnnounceMent': host + '/api/v1/claim/retriveCountryList'
      }
    }
  };
  const userToken = {
    token: "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJPc2FtYUFkbWluIiwidXNlciI6eyJ1c2VyTmFtZSI6Ik9zYW1hQWRtaW4iLCJmaXJzdE5hbWUiOiJPc2FtYSIsImxhc3ROYW1lIjoiTW8iLCJlbWFpbCI6Im9zYW1hLmtoYWxpZEBtZXRsaWZlLmNvbSIsInByZWZlcnJlZExhbmd1YWdlIjoiZW4iLCJjcmVhdGlvbkRhdGUiOiJXZWQgSmFuIDA2IDE0OjQyOjI0IENFVCAyMDIxIiwicGFzc3dvcmRUeXBlIjoiU1RBTkRBUkQiLCJjdXN0b21lclBhc3N3b3JkRXhwcmF0aW9uQ29kZSI6IjEiLCJwYXNzd29yZFN0YXR1c0NvZGUiOiJBQ1RJVkUiLCJzZWN1cml0eVBvbGljeUlkIjoiMTIzNDUiLCJ0b2tlbkV4cGlyYXRpb25EYXRlIjoiRnJpIFNlcCAxOCAxNzowMzo1MCBDRVNUIDIwMjAiLCJlbXBsb3llZU51bWJlciI6bnVsbCwicHdkRXhwaXJhdGlvbkRhdGUiOiJGcmkgTWFyIDE5IDE0OjQyOjI0IENFVCAyMDIxIiwiZmFpbGVkTG9naW5Db3VudHMiOiIwIiwiYXV0aG9yaXplZEFwcGxpY2F0aW9uQ29kZSI6ImVDdXN0b21lciIsInRlbXBvcmFyeUxvY2tEYXRlIjpudWxsLCJyb3V0ZSI6bnVsbCwicHdkRXhwaXJlZCI6bnVsbCwiZGF5c1NpbmNlUHdkTm90Q2hhbmdlZCI6bnVsbCwicHdkQ2hhbmdlRGF0ZSI6bnVsbCwicm9sZUluZm8iOlt7InJvbGVJZCI6IjMwMzMiLCJuYW1lIjoiclN1cGVyVXNlciIsImRlc2NyaXB0aW9uIjoiUlN1cGVyVXNlciJ9LHsicm9sZUlkIjoiMzAzNCIsIm5hbWUiOiJyQWRtaW5pc3RyYXRvciIsImRlc2NyaXB0aW9uIjoiU3lzdGVtQWRtaW5pc3RyYXRvciJ9XSwiY2xpZW50SWQiOm51bGwsInJlcXVlc3RlcklkIjpudWxsLCJyZXF1ZXN0ZXJSb2xlIjpudWxsLCJ1c2VyRG4iOiJvdT1QZW9wbGUsbz1hZmZpbGlhdGVzLGM9UG9sYW5kLG89bWV0bGlmZSxkYz1tZXRsaWZlLGRjPWNvbSIsInVzZXJDaGVjayI6dHJ1ZX0sImlhdCI6MTYxMjMzNzA1NCwiZXhwIjoxNjEyMzgwMjU0fQ.DF3cfAMA1Z0BLYN_k5yrqtWDcq1ed9z1Vu5EkIgj_x0",
    userName: "OsamaAdmin"
  };
  // window['__env'].environmentConstURLs = environmentConstURL;

  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, PersonalDataModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: [],
      providers: [TranslateService]
    })
      .compileComponents();
    window['__env'].environmentConstURLs = environmentConstURL;
    window.sessionStorage.setItem('userToken', JSON.stringify(userToken));

    fixture = TestBed.createComponent(PersonaldataDetailssectionComponent);
    commonService = TestBed.get(HttpCommonService);

    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    // spyOn(commonService, 'postData').and.returnValue(of());

    expect(component).toBeTruthy();
  });
  it('should call personalInfoService', () => {
    component.personalInfoService();
    });
    
  it('should acceptMyConsents', () => {
    component.acceptMyConsents();
    });
    it('should acceptMyConsents', () => {
      component.acceptMyConsentsService();
      });
    it('routeToAccountSetting  should call', () => {
      spyOn(component.router, 'navigate').and.callThrough();
      component.routeToAccountSetting();
      expect(component.router.navigate ).toHaveBeenCalled();
    });
     it('navigateToDataChange  should call', () => {
      spyOn(component.router, 'navigate').and.callThrough();
      component.navigateToDataChange();
      expect(component.router.navigate ).toHaveBeenCalled();
    });
    it('routeToChangePassword  should call', () => {
      spyOn(component.router, 'navigate').and.callThrough();
      component.routeToChangePassword();
      expect(component.router.navigate ).toHaveBeenCalled();
    });
   
});
