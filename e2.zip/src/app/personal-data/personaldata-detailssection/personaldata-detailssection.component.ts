import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormArray, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PersonalDataDetailsSectionModel } from './model/personaldata-detailssection.model';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { PersonalDataService } from '../personal-data.service';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { UtilityService, countryList } from 'src/app/shared/utilities/utility.service';


@Component({
  selector: 'personaldata-detailssection',
  templateUrl: './personaldata-detailssection.component.html',
  styleUrls: ['./personaldata-detailssection.component.scss']
})
export class PersonaldataDetailssectionComponent implements OnInit {
  dataDetailsModel: PersonalDataDetailsSectionModel;
  loggedInCountry = sessionStorage.getItem("countryCode");
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  loggedInCountryCheck = UtilityService.getCountry();
  constructor(private fb: FormBuilder, public readonly router: Router, private menuItemService: MenuItemsService,
    public commonService: HttpCommonService, public personalDataService: PersonalDataService,
    public sharedService: SharedServiceService) {
    this.dataDetailsModel = new PersonalDataDetailsSectionModel();
  }

  ngOnInit() {

    this.personalInfoService();
    this.sharedService.getLangChange().subscribe((data) => {
      if (this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')]) {
        this.countryList = this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')];
      } else {
        this.getCountryList();
      }

    });
  }
  countryList: any;
  getCountryList() {
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.countryList;
    this.commonService['getData'](url).subscribe(data => {
      ////("data", data);
      this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')] = data;
      this.countryList = data;

    });
  }
  ngOnDestroy() {
    this.dataDetailsModel.subscribeFlag = false;
  }


  navigateToDataChange() {
    this.router.navigate(['personalInfo/personal-dataChange']);
  }

  routeToChangePassword() {
    this.router.navigate(['/setting/change-password']);
  }

  routeToAccountSetting() {
    this.router.navigate(['/setting/account-setting']);
  }


  policyAddressList: Array<any> = [];
  personalData: any;

  canChangeDataflag: boolean = false;
  personalInfoService() {
    let contractList = [];
    let loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let customerDetails = JSON.parse(sessionStorage.getItem('searcClientID'));
    const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    const menuItemList2 = JSON.parse(sessionStorage.getItem('menuItemList'));
    let homeContractList = menuItemList ? menuItemList.contractList : (menuItemList2 ? menuItemList2.contractList : []);
    for (let i = 0; i < homeContractList.length; i++) {
      let contract = {};
      contract['contractNumber'] = homeContractList[i].contractNumber;
      contract['benefitType'] = homeContractList[i].benefitType;
      contractList.push(contract);
    }

    if (menuItemList) {
      this.canChangeDataflag = menuItemList.personalInformationDTO.flagOfCapabilityOfChangeData === 'true' ? true : false;
    } else if (menuItemList2) {
      this.canChangeDataflag = menuItemList2.personalInformationDTO.flagOfCapabilityOfChangeData === 'true' ? true : false;
    }
    let clientId = '';

    if (customerDetails && customerDetails.clientID) {
      clientId = customerDetails.clientID;
    } else if (loggedUser['requesterId'] && loggedUser['requesterId'] != -1) {
      clientId = loggedUser['requesterId'];
    }
    let roleName = loggedUser['roleInfo'].find(x => x.roleId === loggedUser['requesterRole']).name;
    let req = {
      "userId": loggedUser['userName'],
      "requesterID": clientId,
      "requesterRole": loggedUser['requesterRole'] ? loggedUser['requesterRole'] : '',
      "role": roleName ? roleName : '',
      canChangeData: this.canChangeDataflag,
      //"role": 'rClient',
      "clientId": clientId,
      "contractList": contractList
    }
    //(req);
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.personalDataRender;
    this.commonService['postData'](url, req, headers).subscribe(data => {
      //("data", data);

      this.personalData = data;
      this.policyAddressList = data.policyAddressList;

      this.personalDataService.setPersonalData(data);
      // && !data.renderMinimumOneActiveOrder
      if (data.marketingConsentList) {
        for (let i = 0; i < data.marketingConsentList.length; i++) {
          this.addConsents(data.marketingConsentList[i]);
        }

      }
    });
  }

  isConsentChecked = true;
  acceptMyConsents() {
    let marketinglist = this.consentForm.get('marketingConsentList')['controls'];
    this.isConsentChecked = false;
    let personalDta = this.personalDataService.getPersonalData();
    for (let i = 0; i < marketinglist.length; i++) {
      personalDta.marketingConsentList[i].agree = marketinglist[i].controls.agree.value;
      if (marketinglist[i].controls.agree.value) {
        this.isConsentChecked = true;
      }
    }

    this.personalDataService.setPersonalData(personalDta);
    if (this.isConsentChecked) {
      this.acceptMyConsentsService();
    }

  }

  orderData = null;
  acceptMyConsentsService() {
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerDetails = JSON.parse(sessionStorage.getItem('searcClientID'));
    const countryCode = sessionStorage.getItem('countryCode');
    const defaultLanguage = sessionStorage.getItem('defaultLanguage');
    const searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
    const menuListFromClientSearch = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    let clientLoginID = '';
    let clientfirstname = '';
    let clientlastName = '';
    if (menuListFromClientSearch) {
      clientLoginID = menuListFromClientSearch['clientLoginId'];
    } else {
      clientLoginID = loggedUser['userName'];
    }
    if (searchedClientDetails) {
      clientfirstname = searchedClientDetails['clientFirstName'];
      clientlastName = searchedClientDetails['clientLastName'];
    } else {
      clientfirstname = loggedUser['firstName'];
      clientlastName = loggedUser['lastName'];
    }
    let clientId = '';
    if (loggedUser['requesterId'] && loggedUser['requesterId'] != -1) {
      clientId = loggedUser['requesterId'];
    } else if (customerDetails.clientID) {
      clientId = customerDetails.clientID;
    }

    let req = this.personalDataService.getPersonalData();
    req.userId = loggedUser['userName'];
    req['firstName'] = loggedUser['firstName'];
    req['lastName'] = loggedUser['lastName'];
    req.requesterID = clientId;

    req.requesterRole = loggedUser['requesterRole'];
    req.language = defaultLanguage ? defaultLanguage : '';
    req.country = countryCode ? countryCode.toUpperCase() : '';
    req.role = null;
    req.roleNames = this.menuItemService.getAllRoles();
    req.clientId = clientId;

    req['clientFirstName'] = clientfirstname;
    req['clientLastName'] = clientlastName;
    req['clientLoginId'] = clientLoginID;
    this.orderData = null;
    /*this.orderData = {
      "userId": null,
      "clientId": null,
      "orderId": 1000345
    };*/
    //(req);
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.consentUpdate;
    this.commonService['postData'](url, req, headers).subscribe(data => {
      //("data", data);
      if (data) {
        if (data.hasOwnProperty('validUser') && (data.validUser == false)) {
          this.router.navigate(['/logout']);
        } else if (data.hasOwnProperty('privilage') && (data.privilage == false)) {
          this.noPrivilage = true;
        } else {
          this.orderData = data;

        }
      }

      //response goes here
    });
  }

  noPrivilage: boolean = false;
  consentForm = this.fb.group({
    marketingConsentList: this.fb.array([])
  })

  get consentLists(): FormArray {
    return this.consentForm.get("marketingConsentList") as FormArray
  }

  addConsents(consentData) {
    this.consentLists.push(this.newConsent(consentData));
  }

  newConsent(consentData): FormGroup {

    return this.fb.group({
      status: consentData.status,
      type: consentData.type,
      recievedOn: consentData.recievedOn,
      agree: [null, Validators.required]
    })
  }

}
