import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { PersonalDataModule } from '../personal-data.module';

import { PersonaldataReviewComponent } from './personaldata-review.component';
import { PersonalDataService } from '../personal-data.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { inject } from '@angular/core';
import { of } from 'rxjs';

describe('PersonaldataReviewComponent', () => {
  let component: PersonaldataReviewComponent;
  let fixture: ComponentFixture<PersonaldataReviewComponent>;
  let personalDataService: PersonalDataService;

  const userToken = {
    token: "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJPc2FtYUFkbWluIiwidXNlciI6eyJ1c2VyTmFtZSI6Ik9zYW1hQWRtaW4iLCJmaXJzdE5hbWUiOiJPc2FtYSIsImxhc3ROYW1lIjoiTW8iLCJlbWFpbCI6Im9zYW1hLmtoYWxpZEBtZXRsaWZlLmNvbSIsInByZWZlcnJlZExhbmd1YWdlIjoiZW4iLCJjcmVhdGlvbkRhdGUiOiJXZWQgSmFuIDA2IDE0OjQyOjI0IENFVCAyMDIxIiwicGFzc3dvcmRUeXBlIjoiU1RBTkRBUkQiLCJjdXN0b21lclBhc3N3b3JkRXhwcmF0aW9uQ29kZSI6IjEiLCJwYXNzd29yZFN0YXR1c0NvZGUiOiJBQ1RJVkUiLCJzZWN1cml0eVBvbGljeUlkIjoiMTIzNDUiLCJ0b2tlbkV4cGlyYXRpb25EYXRlIjoiRnJpIFNlcCAxOCAxNzowMzo1MCBDRVNUIDIwMjAiLCJlbXBsb3llZU51bWJlciI6bnVsbCwicHdkRXhwaXJhdGlvbkRhdGUiOiJGcmkgTWFyIDE5IDE0OjQyOjI0IENFVCAyMDIxIiwiZmFpbGVkTG9naW5Db3VudHMiOiIwIiwiYXV0aG9yaXplZEFwcGxpY2F0aW9uQ29kZSI6ImVDdXN0b21lciIsInRlbXBvcmFyeUxvY2tEYXRlIjpudWxsLCJyb3V0ZSI6bnVsbCwicHdkRXhwaXJlZCI6bnVsbCwiZGF5c1NpbmNlUHdkTm90Q2hhbmdlZCI6bnVsbCwicHdkQ2hhbmdlRGF0ZSI6bnVsbCwicm9sZUluZm8iOlt7InJvbGVJZCI6IjMwMzMiLCJuYW1lIjoiclN1cGVyVXNlciIsImRlc2NyaXB0aW9uIjoiUlN1cGVyVXNlciJ9LHsicm9sZUlkIjoiMzAzNCIsIm5hbWUiOiJyQWRtaW5pc3RyYXRvciIsImRlc2NyaXB0aW9uIjoiU3lzdGVtQWRtaW5pc3RyYXRvciJ9XSwiY2xpZW50SWQiOm51bGwsInJlcXVlc3RlcklkIjpudWxsLCJyZXF1ZXN0ZXJSb2xlIjpudWxsLCJ1c2VyRG4iOiJvdT1QZW9wbGUsbz1hZmZpbGlhdGVzLGM9UG9sYW5kLG89bWV0bGlmZSxkYz1tZXRsaWZlLGRjPWNvbSIsInVzZXJDaGVjayI6dHJ1ZX0sImlhdCI6MTYxMjMzNzA1NCwiZXhwIjoxNjEyMzgwMjU0fQ.DF3cfAMA1Z0BLYN_k5yrqtWDcq1ed9z1Vu5EkIgj_x0",
    userName: "OsamaAdmin"
  };
  // beforeEach(async(() => {
  //   const countryCode = "ro";
  //   window.sessionStorage.setItem('countryCode', (countryCode));
  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule, AppModule, PersonalDataModule, HttpClientTestingModule],
  //     providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
  //     declarations: []
  //   })
  //     .compileComponents();
  // }));
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'countryList': host + '/api/v1/claim/retriveCountryList'
      }
    }
  };
  let existingPersonalData;
  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;

    window.sessionStorage.setItem('userToken', JSON.stringify(userToken));
    const countryCode = "ro";
    window.sessionStorage.setItem('countryCode', (countryCode));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, PersonalDataModule, HttpClientTestingModule],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, PersonalDataService, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(PersonaldataReviewComponent);
    personalDataService = TestBed.get(PersonalDataService);

    component = fixture.componentInstance;
    existingPersonalData = {
      "userId": null, "clientId": null, "requesterRole": null, "requesterID": null, "actionedBy": null, "status": null, "createDate": null, "serviceRequestId": null, "landlineNumberr": "123488888", "mobileNumber": "123488888", "primaryNumber": "123488888", "email": "test@test2.com", "optionalEmail": "101583@metlife.com", "landlineNumberNew": null, "mobileNumberNew": null, "primaryNumberNew": null, "emailNew": null, "optionalEmailNew": null, "renderMinimumOneActiveOrder": false, "canChangeData": true, "renderMinimumOneActiveConsentOrder": false, "renderUnauthorized": false, "renderChangeBtn": true, "showConsentSection": true, "renderChangeConsent": true, "policyAddressList": [{ "policyInfoList": [{ "policyNo": "20032799", "benefitType": "Życie+" }, { "policyNo": "20386578", "benefitType": "Senior" }, { "policyNo": "21137369", "benefitType": "Amplico Inwestor" }, { "policyNo": "21282475", "benefitType": "SuperKapitał S" }, { "policyNo": "21295126", "benefitType": "SuperKapitał S" }, { "policyNo": "21295127", "benefitType": "SuperKapitał S" }, { "policyNo": "32386578", "benefitType": "Lokata jubileuszowa" }, { "policyNo": "7101352", "benefitType": "Bezpieczne Jutro" }], "addressChangeDto": { "policyNumber": null, "policyName": null, "id": null, "clientId": null, "userId": null, "addressInstitution": "", "postOffice": "", "postBox": "", "addressLine1": null, "addressLine2": null, "state": null, "country": "Palestinian Territory, Occupied", "city": "WARSZAWA", "pinCode": null, "street": "TESTSTREET", "flat": "", "house": "", "uploadFileList": [], "uploadFile": null, "addressId": null, "policyNumbersList": [], "policyNameAndNumbersList": [], "streetList": [], "citiesList": [], "postCodeList": [], "streetName": "TESTSTREET", "cityName": null, "postCode": "00-001", "countryName": "Palestinian Territory, Occupied", "countryCode": "PS", "countriesResultList": [], "block": null, "entrance": null, "apartment": "", "sector": null, "mobile": null, "landline": null, "email": null, "postalCode": null } }], "marketingConsentList": [], "addressChange": null, "policyInfoUpdatedList": null, "versionMarker": "2021-03-15T11:00:14.750", "orderCutOffTime": null, "language": null, "country": null, "displayMultipleAddress": false, "roleNames": null, "firstName": null, "lastName": null, "clientFirstName": null, "clientLastName": null, "clientLoginId": null, "renderRealizationDate": false, "estResolutionDate": null, "multipleAddressRequired": false
    };

    component.personalDataService.existingPersonalData = existingPersonalData;

    component.existingAddressList = [{
      addressChangeDto: {
        house: null,
        streetName: null,
        Housenumber: null,
        flat: null
      }
    }];
    // component.existingPersonalData = existingPersonalData;
    fixture.detectChanges();
  });

  it('should create personal data review component', () => {
    spyOn(PersonalDataService.prototype, 'getPersonalData');
    component.existingPersonalData = component.personalDataService.existingPersonalData;
    // component.personalDataService.getPersonalData();
    component.existingPersonalData = existingPersonalData;
    expect(component).toBeTruthy();
  });

  // it('should create getpersonalData', () => {

  //   component.personalDataService.getPersonalData();
  //   //  expect(component.personalDataService.getPersonalData()).toEqual(existingPersonalData);
  // });
});
