import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PersonalDataService } from '../personal-data.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { HttpHeaders } from '@angular/common/http';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'personaldata-review',
  templateUrl: './personaldata-review.component.html',
  styleUrls: ['./personaldata-review.component.scss']
})
export class PersonaldataReviewComponent implements OnInit {
  loggedInCountry = sessionStorage.getItem("countryCode");
  loggedeInCountryCheck: boolean = UtilityService.getCountry();
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];

  constructor(private readonly router: Router,
    public personalDataService: PersonalDataService,
    public commonService: HttpCommonService, private menuItemService: MenuItemsService,
    public sharedService: SharedServiceService) { }
  newPersonalData: any;
  ngOnInit() {
    this.existingPersonalData = this.personalDataService.getPersonalData();
    this.existingAddressList = this.personalDataService.getPersonalData().policyAddressList;
    if (Object.keys(this.existingPersonalData).length === 0) {
      this.goToPersonalInfo();
    }
    this.newPersonalData = this.personalDataService.getNewPersonalData();
    this.sharedService.getLangChange().subscribe((data) => {
      if (this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')]) {
        this.countryList = this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')];
      } else {
        this.getCountryList();
      }

    });
  }
  countryList: any;
  getCountryList() {
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.countryList;
    this.commonService['getData'](url).subscribe(data => {
      ////("data", data);
      this.sharedService.countrylist[sessionStorage.getItem('defaultLanguage')] = data;

      this.countryList = data;

    });
  }

  existingPersonalData: any;
  existingAddressList: any = [];
  goToPersonalOrder() {
    this.router.navigate(['personalInfo/personal-dataOrder']);
  }

  executeForm() {

    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerDetails = JSON.parse(sessionStorage.getItem('searcClientID'));
    const searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
    const menuListFromClientSearch = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    let clientLoginID = '';
    let clientfirstname = '';
    let clientlastName = '';
    if (menuListFromClientSearch) {
      clientLoginID = menuListFromClientSearch['clientLoginId'];
    } else {
      clientLoginID = loggedUser['userName'];
    }
    if (searchedClientDetails) {
      clientfirstname = searchedClientDetails['clientFirstName'];
      clientlastName = searchedClientDetails['clientLastName'];
    } else {
      clientfirstname = loggedUser['firstName'];
      clientlastName = loggedUser['lastName'];
    }

    let clientId = '';
    if (customerDetails && customerDetails.clientID) {
      clientId = customerDetails.clientID;
    }
    else if (loggedUser['requesterId'] && loggedUser['requesterId'] != -1) {
      clientId = loggedUser['requesterId'];
    }

    let personalDataExe = {};

    personalDataExe = this.existingPersonalData;
    personalDataExe['clientFirstName'] = clientfirstname;
    personalDataExe['clientLastName'] = clientlastName;
    personalDataExe['clientLoginId'] = clientLoginID;

    personalDataExe['addressChange'] = JSON.parse(JSON.stringify(this.newPersonalData['addressChange']));
    personalDataExe['emailNew'] = this.newPersonalData['emailNew'];
    personalDataExe['landlineNumberNew'] = this.newPersonalData['landlineNumberNew'];
    personalDataExe['mobileNumberNew'] = this.newPersonalData['mobileNumberNew'];

    personalDataExe['optionalEmailNew'] = this.newPersonalData['optionalEmailNew'];
    personalDataExe['userId'] = loggedUser['userName'];
    personalDataExe['firstName'] = loggedUser['firstName'];
    personalDataExe['lastName'] = loggedUser['lastName'];
    personalDataExe['requesterID'] = clientId;
    // personalDataExe['requesterRole'] = loggedUser['requesterRole'];
    personalDataExe['requesterRole'] = loggedUser['requesterRole'];
    personalDataExe['clientId'] = clientId;
    personalDataExe['addressChange']['clientId'] = clientId;
    personalDataExe['addressChange']['pinCode'] = this.newPersonalData['addressChange']['postCode'];
    personalDataExe['addressChange']['street'] = this.newPersonalData['addressChange']['streetName'];
    personalDataExe['addressChange']['house'] = this.newPersonalData['addressChange']['house'];
    personalDataExe['addressChange']['flat'] = this.newPersonalData['addressChange']['flat'];
    personalDataExe['addressChange']['apartment'] = this.newPersonalData['addressChange']['flat'];
    personalDataExe['addressChange']['cityName'] = this.newPersonalData['addressChange']['city'];
    personalDataExe['addressChange']['country'] = this.newPersonalData['addressChange']['countryCode'];
    personalDataExe['addressChange']['countryName'] = this.newPersonalData['addressChange']['countryCode'];

    if (this.loggedInCountry.toLowerCase() === 'ro') {
      personalDataExe['addressChange']['apartment'] = this.newPersonalData['addressChange']['apartment'];
      personalDataExe['addressChange']['country'] = this.newPersonalData['addressChange']['county'];
      personalDataExe['addressChange']['countryName'] = this.newPersonalData['addressChange']['county'];
      personalDataExe['addressChange']['countryCode'] = this.newPersonalData['addressChange']['county'];

    }

    personalDataExe['role'] = 'rClient';
    personalDataExe['language'] = 'pl_en';
    personalDataExe['policyAddressList'] = this.existingAddressList;
    personalDataExe['roleNames'] = this.menuItemService.getAllRoles();
    /*for(let i=0;i<loggedUser.roleInfo.length;i++){
      
      if(loggedUser['requesterRole'] == loggedUser.roleInfo[i].roleId){
        personalDataExe['role'] = loggedUser.roleInfo[i].name;
        break;
      }
    
    }   
    */
    this.personalInfoExecutionService(personalDataExe);
    // loggedUser['requesterRole'];
  }

  goToPersonalDatachange() {
    this.router.navigate(['personalInfo/personal-dataChange']);
  }

  goToPersonalInfo() {
    this.router.navigate(['personalInfo']);

  }
  noPrivilage: boolean = false;
  personalInfoExecutionService(reqData) {
    // this.goToPersonalOrder();
    //("req",reqData);
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.personalDataExecution;
    this.commonService['postData'](url, reqData, headers).subscribe(data => {
      if (data) {
        if (data.hasOwnProperty('validUser') && (data.validUser == false)) {
          this.router.navigate(['/logout']);
        } else if (data.hasOwnProperty('privilage') && (data.privilage == false)) {
          this.noPrivilage = true;
        } else {
          this.personalDataService.personalDataOrderId = data;
          // this.goToPersonalOrder();
          this.getMenuDetails();
        }
      }


    });
  }
  menuItemList: any;
  getMenuDetails() {
    //  const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    //    let clientID = loggedUser.clientId ? loggedUser.clientId : null;
    let customerDetails = JSON.parse(sessionStorage.getItem('searcClientID'));
    let clientId = '', opType = 'login';
    if (customerDetails && customerDetails.clientID) {
      clientId = customerDetails.clientID;
    }
    if (customerDetails) {
      opType = customerDetails.opeType;
    }


    this.menuItemService.menuItemApi(clientId, opType).subscribe((data) => {
      sessionStorage.setItem('menuListFromClientSearch', JSON.stringify(data));
      //sessionStorage.setItem('menuItemList', JSON.stringify(data));
      this.sharedService.setDetail('menuItemList', data);
      this.menuItemService.navigationBasedOnRole(data);
      this.menuItemList = data;
      this.goToPersonalOrder();
    });

  }
}

