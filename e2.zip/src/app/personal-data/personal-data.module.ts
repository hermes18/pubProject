import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { PersonalDataRoutingModule } from './personal-data-routing.module';
import { PersonalDataComponent } from './personal-data.component';
import { PersonaldataDetailssectionComponent } from './personaldata-detailssection/personaldata-detailssection.component';
import { TranslateModule } from '@ngx-translate/core';

import { MatCheckboxModule } from '@angular/material/checkbox';
import { PersonaldataDatachangeComponent } from './personaldata-datachange/personaldata-datachange.component';
import { MatFormFieldModule, MatInputModule, MatSelectModule } from '@angular/material';
import { PersonaldataOrderComponent } from './personaldata-order/personaldata-order.component';
import { PersonaldataReviewComponent } from './personaldata-review/personaldata-review.component';
import { PersonalDataService } from './personal-data.service';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [PersonalDataComponent, PersonaldataDetailssectionComponent, PersonaldataDatachangeComponent, PersonaldataOrderComponent, PersonaldataReviewComponent],
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    TranslateModule,
    ReactiveFormsModule,
    MatInputModule,
    MatSelectModule,
    PersonalDataRoutingModule,
    MatCheckboxModule,
    SharedModule
  ],
  providers: [PersonalDataService]
})
export class PersonalDataModule { }
