import { environment } from 'src/environments/environment';
import { AppConfig } from 'src/config/app.config';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { HttpCommonService } from './../shared/services/http-common.service';
import { SharedServiceService } from './../shared-service/shared-service.service';


@Injectable({
    providedIn: 'root'
})

export class PersonalDataService {
    appConfig: AppConfig = AppConfig.getConfig();
    baseUrl = this.appConfig['api'];

    constructor(private cService: HttpCommonService, private readonly router: Router,
        public commonService: SharedServiceService) { }

    menuItemApi(clientId, opeType) {
        const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
            //url = `${this.baseUrl.ecustomer.menuItem}/${loggedUser['userName']}/${clientId}/${opeType}`,
            reqParam = {
                "clientId": clientId,
                "opeType": opeType,
                "userId": loggedUser['userName'],
                "requesterId": loggedUser['requesterId'],
                "requesterRole": loggedUser['requesterRole']
            };
        return this.cService['postData'](this.baseUrl.ecustomer.menuItem, reqParam, '');
    }

existingPersonalData: any={};
newPersonalData:any={};
personalDataOrderId:any;

setPersonalData(data){
    this.existingPersonalData = data;
}
getPersonalData(){
return this.existingPersonalData;
}

setNewPersonalData(data){
    this.newPersonalData = data;
}
getNewPersonalData(){
return this.newPersonalData;
}

}