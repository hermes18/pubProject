import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { PersonalDataComponent } from './personal-data.component';
import { PersonaldataDetailssectionComponent } from './personaldata-detailssection/personaldata-detailssection.component';
import { PersonaldataDatachangeComponent } from './personaldata-datachange/personaldata-datachange.component';
import { PersonaldataOrderComponent } from './personaldata-order/personaldata-order.component';
import { PersonaldataReviewComponent } from './personaldata-review/personaldata-review.component';


const routes: Routes = [
  {
    path: '', component: PersonalDataComponent, canDeactivate: [NavigationGuard],
    children: [
      { path: '', component: PersonaldataDetailssectionComponent, canDeactivate: [NavigationGuard] },
      { path: 'personal-dataChange', component: PersonaldataDatachangeComponent, canDeactivate: [NavigationGuard] },
      { path: 'personal-dataReview', component:PersonaldataReviewComponent, canDeactivate: [NavigationGuard] },
      { path: 'personal-dataOrder', component:  PersonaldataOrderComponent, canDeactivate: [NavigationGuard] },

    ]

  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PersonalDataRoutingModule { }
