import { Component, OnInit } from '@angular/core';
import { DialogService } from '../shared/services/dialog.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HttpCommonService } from '../shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { Idle } from '@ng-idle/core';
import { BroadcasterService } from '../core/services/broadcaster.service';

@Component({
  selector: 'app-session-expired',
  templateUrl: './session-expired.component.html',
  styleUrls: ['./session-expired.component.scss']
})
export class SessionExpiredComponent implements OnInit {

  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];

  constructor(private router: Router, private dailogService: DialogService, public sharedService: SharedServiceService,
    private commonService: HttpCommonService, private idle: Idle, public readonly broadCastService: BroadcasterService) { }

  ngOnInit() {
  }
  onRoute() {
    const userInfo = sessionStorage.getItem('loggedInUserInfo'),
      userdetail = JSON.parse(userInfo);
    //window.close();
    let logoutRequest = {
      "userLogin": userdetail.userName,
      "systemType": "eCustomer",
      "processName": "Logout",
      "logType": "REASON_SESSION_TIMEOUT",
      "logMessage": "REASON_SESSION_TIMEOUT",
      "clientId ": ""
    }
    let logoutUrl = this.baseUrl.ecustomer.logoutUrl;
    this.commonService['postData'](logoutUrl, logoutRequest, '')
      .subscribe(data => {
        this.clearSessionStorage();
      },
        (error: Error) => {
          this.clearSessionStorage();
        });

  }

  clearSessionStorage() {
    this.dailogService.closeDialog();
    const countryCode = sessionStorage.getItem('countryCode'),
      defaultLangugae = sessionStorage.getItem('defaultLanguage');
    sessionStorage.clear();
    this.broadCastService.broadcast('setttingroute', false);
    this.sharedService.setcurrentUserLoggedIn([])
    sessionStorage.setItem("defaultLanguage", defaultLangugae);
    sessionStorage.setItem("countryCode", countryCode);
    this.idle.stop();
    this.router.navigate(['/logout']);
  }

}
