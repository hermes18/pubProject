import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../contract-details/allocation-change/allocation-change-service';

export interface FundSummaryData {
  premiumSplitBfreChange: String;
  // fundName: String;
  pastSplit: String;
  unitPricePastLink: String;
  premiumSplitAfterChange: String;
  unitPriceNewLink: String;
  keyLink: String;
  newSplit: String;
}

export interface FundSummaryDataBfre {
  fundName: String;
  pastSplit: String;
  unitPricePastLink: String;
}
export interface FundSummaryData {
  fundName: String;
  unitPriceNewLink: String;
  keyLink: String;
  newSplit: String;
}

@Component({
  selector: 'order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {

  displayedColumnsBfre: String[] = [
    'fundName',
    'pastSplit',
    'unitPricePastLink'];
  displayedColumns: String[] = ['fundName',
    'unitPriceNewLink',
    'keyLink',
    'newSplit'];
  dataSourceFundDetailsBfre: MatTableDataSource<FundSummaryDataBfre>;
  dataSourceFundDetails: MatTableDataSource<FundSummaryData>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  summaryDetBfre: any;
  summaryDetAfter: any;
  reviewResponse: any;
  contractDetail: any;
  contractNo: any;
  userrole: string;
  clientId: any;
  accountDetails: any;
  confDetails: any;
  confResult: any;
  userdetail: any;
  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private newPremiumService: AllocationChangeSharedService) { }

  ngOnInit() {
    this.contractDetail = null;
   // this.contractNo = this.sharedService.getContractNo();
    this.contractDetail = JSON.parse(sessionStorage.getItem('contractDetails'));
    this.userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
   // const contractnumber = JSON.parse(sessionStorage.getItem('contract'));
    if (this.userrole === "rClient") {
      this.clientId = this.userdetail.clientID;
    } else {
      this.clientId = customerId.clientID;
    }
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = data;
    })
    this.newPremiumService.getOrderId().subscribe((val) => {
      this.confResult = val;
      if(this.confResult!='')
      this.callApi();
    })
  }

  callApi() {
    const reqParam =
    {
      "orderId":this.confResult.orderId,// "00000625"
    }
    this.commonService.postData(this.baseUrl.ecustomer.allocationChangeReview, reqParam, '').subscribe(data => {
      this.dataSourceFundDetailsBfre = new MatTableDataSource(data.fundsPriorToChange);
      this.dataSourceFundDetails = new MatTableDataSource(data.fundsAfterChange);
      this.reviewResponse = data;
    });

  }

}
