import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderComponent } from './order.component';
import { OrderRoutingModule } from './order-routing.module';
import { MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule, MatSidenavModule, MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule, MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatInputModule, MatPaginatorModule, MatSortModule, MatTableModule, MatRadioModule, MatStepperModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { NgxPaginationModule } from 'ngx-pagination';

const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule, MatStepperModule];

@NgModule({
  declarations: [OrderComponent],
  imports: [
    CommonModule,
    OrderRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    ...materialModule,
    NgxPaginationModule
  ]
})
export class OrderModule { }
