import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../shared/utilities/utility.service';

@Component({
  selector: 'error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.scss']
})
export class ErrorPageComponent implements OnInit {

  constructor() { }
  country: any;
  loggedInCountryCheck: boolean;
  ngOnInit() {
    this.loggedInCountryCheck = UtilityService.getCountry();
    this.country = sessionStorage.getItem('countryCode');
  }

}
