import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ChangePremiumSplitModule } from '../change-premium-split-module';

import { ChangePremiumConfirmationComponent } from './change-premium-confirmation.component';

xdescribe('ChangePremiumConfirmationComponent', () => {
  let component: ChangePremiumConfirmationComponent;
  let fixture: ComponentFixture<ChangePremiumConfirmationComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'allocationChangeConfirmation': host + '/api/v1/order/allocation-change-confirmation'
      }
    }
  };

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ChangePremiumSplitModule, HttpClientTestingModule],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(ChangePremiumConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.clientId = "11212";
    expect(component).toBeTruthy();
  });
});
