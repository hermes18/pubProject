import { Component, OnInit } from '@angular/core';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { changePremiumSharedService } from '../change-premium-shared-service';

@Component({
  selector: 'change-premium-confirmation',
  templateUrl: './change-premium-confirmation.component.html',
  styleUrls: ['./change-premium-confirmation.component.scss']
})
export class ChangePremiumConfirmationComponent implements OnInit {

  confirmationData: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  accountDetails: any;
  summaryResult: any;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  clientId: any;
  contractDetail: any;
  contractNo: any;
  userrole = this.menuItemService.getAllRoles();

  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private newPremiumService: changePremiumSharedService,
    private menuItemService: MenuItemsService) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }
    this.contractDetail = null;
    this.contractNo = this.sharedService.getContractNo();
    const contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));
    let userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    const contractnumber = JSON.parse(sessionStorage.getItem('contract'));
    if (this.userrole === "rClient") {
      this.clientId = userdetail.clientID;
    } else {
      this.clientId = customerId.clientID;
    }
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = data;
    })
    this.newPremiumService.getConfReqData().subscribe((val) => {
      this.summaryResult = val;
    })
    if (this.accountDetails != null && this.summaryResult != null) {
      this.callApi();
    }
  }
  callApi() {
    let request = {
      "policyNumber": this.accountDetails.policyNumber,//"21295126",
      "investAccNumber": this.accountDetails.investAccNumber,//"21295127",
      "investAccType": this.accountDetails.investAccType + "",//"1",
      "productPlan": "",
      "processingSystem": "OLAS",
      "firstName": "fname",
      "lastName": "lastName",
      "userName": "Testuser210",
      "country": this.country,//"pl",
      "language": this.lang,//"en",
      "userRole": this.userrole,//"rAdvisor",
      "fundsPriorToChange": this.summaryResult.fundsPriorToChange,
      "fundsAfterChange": this.summaryResult.fundsAfterChange
    }
    this.commonService.postData(this.baseUrl.ecustomer.allocationChangeConfirmation, request, '').subscribe(data => {
      this.confirmationData = data;
    });
  }

  gotoPremiumSplitPage() {
    // this.gotoPremiumSplit = true;
    // this.valueChange.emit('allocationChange');
    // this.sharedService.setPageContent('allocationChange');
  }


}
