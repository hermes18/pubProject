import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from '../app.module';
import { ChangePremiumSplitModule } from './change-premium-split-module';

import { ChangePremiumSplitComponent } from './change-premium-split.component';

xdescribe('ChangePremiumSplitComponent', () => {
  let component: ChangePremiumSplitComponent;
  let fixture: ComponentFixture<ChangePremiumSplitComponent>;
  const userImfo =
    { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" }
  const serachClient =
    { "clientId": 1234, "opeType": "search" };
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'accountList': host + '/api/v1/order/change-premium-spilt',
        'getActiveOrder': host + '/api/v1/order/active-order',
        'allocationChange': host + '/api/v1/order/allocation-change',
        'allocationChangeSummary': host + '/api/v1/order/allocation-change-summary',
        'allocationChangeConfirmation': host + '/api/v1/order/allocation-change-confirmation',
      }
    }
  };

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;

    window.sessionStorage.setItem("defaultLanguage", "pl_pl");
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ChangePremiumSplitModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    // }));

    // beforeEach(() => {
    fixture = TestBed.createComponent(ChangePremiumSplitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
