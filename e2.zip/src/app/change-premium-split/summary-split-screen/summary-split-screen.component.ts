import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { changePremiumSharedService } from '../change-premium-shared-service';


export interface FundSummaryDataBfre {
  fundName: String;
  pastSplit: String;
  unitPricePastLink: String;
}
export interface FundSummaryData {
  fundName: String;
  unitPriceNewLink: String;
  keyLink: String;
  newSplit: String;
}

@Component({
  selector: 'summary-split-screen',
  templateUrl: './summary-split-screen.component.html',
  styleUrls: ['./summary-split-screen.component.scss']
})

export class SummarySplitScreenComponent implements OnInit {

  displayedColumnsBfre: String[] = [
    'fundName',
    'pastSplit',
    'unitPricePastLink'];
  displayedColumns: String[] = ['fundName',
    'unitPriceNewLink',
    'keyLink',
    'newSplit'];
  dataSourceFundDetailsBfre: MatTableDataSource<FundSummaryDataBfre>;
  dataSourceFundDetails: MatTableDataSource<FundSummaryData>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  summaryDetBfre: any;
  summaryDetAfter: any;
  valuesSelectedArray: any;
  fundDataArr: any;
  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private newPremiumService: changePremiumSharedService) { }

  ngOnInit() {
    this.newPremiumService.getSummaryReqData().subscribe((arr) => {
      this.fundDataArr = arr;
      if (this.fundDataArr != null && this.fundDataArr.length > 0) {
        this.callApi();
      }
    });
  }
  
  callApi() {
    if(this.baseUrl.ecustomer.allocationChangeSummary!=''){
      const reqParam = {
        "processingSystem": "OLAS",
        "totalNewlyAllocatedPercentage": "100",
        "fundSwitchDTOs": this.fundDataArr
      }
      this.commonService.postData(this.baseUrl.ecustomer.allocationChangeSummary, reqParam, '').subscribe(data => {
        this.dataSourceFundDetailsBfre = new MatTableDataSource(data.fundsPriorToChange);
        this.dataSourceFundDetails = new MatTableDataSource(data.fundsAfterChange);
        //this.newPremiumService.setConfReqData(data);
      })
    }
  }

}
