import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { observable, Subject, Observable } from 'rxjs';

@Injectable({providedIn:'root'})
export class changePremiumSharedService {

    private accountDetails:  BehaviorSubject<any>;
    private selectedFundDetails: BehaviorSubject<any>;
    private summaryReqDetails: BehaviorSubject<any>;
    private confReqDetails: BehaviorSubject<any>;
    private reviewReqDetails: BehaviorSubject<any>;
    constructor() {
        this.selectedFundDetails = new BehaviorSubject(null);
        this.accountDetails = new BehaviorSubject(null);
        this.summaryReqDetails = new BehaviorSubject(null);
        this.confReqDetails = new BehaviorSubject(null);
        this.reviewReqDetails = new BehaviorSubject(null);
    }
    
    setaccountData(data: any) {
        this.accountDetails.next(data);
    }

    getaccountData(): any {
        return this.accountDetails.asObservable();
    }

    getParamValue(param) {
        return this[param];
    }
    setParamValue(param, value) {
        this[param] = value;
    }

    setFundData(data: any) {
        this.selectedFundDetails.next(data);
    }

    getFundData(): any {
        return this.selectedFundDetails.asObservable();
    }

    setSummaryReqData(data: any) {
        this.summaryReqDetails.next(data);
    }

    getSummaryReqData(): any {
        return this.summaryReqDetails.asObservable();
    }

    setConfReqData(data: any) {
        this.confReqDetails.next(data);
    }

    getConfReqData(): any {
        return this.confReqDetails.asObservable();
    }

    setReviewReqData(data: any) {
        this.reviewReqDetails.next(data);
    }

    getReviewReqData(): any {
        return this.reviewReqDetails.asObservable();
    }
}