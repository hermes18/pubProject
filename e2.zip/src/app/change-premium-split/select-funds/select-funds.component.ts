import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { Observable, Subscription } from 'rxjs';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { CreateFormService } from 'src/app/shared/services/create-form.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { changePremiumSharedService } from '../change-premium-shared-service';

export interface FundDataList {
  contact: FundData[];
}
export interface FundData {
  fundName: String;
  quotesLink: String;
  currentSlip: String;
  newSlip: String;
}

@Component({
  selector: 'select-funds',
  templateUrl: './select-funds.component.html',
  styleUrls: ['./select-funds.component.scss']
})
export class SelectFundsComponent implements OnInit {

  displayedColumns: String[] = ['fundName', 'quotesLink', 'currentSlip', 'newSlip'];
  dataSourceFundDetails: MatTableDataSource<FundDataList>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  accountDet: any;
  selectFundForm: FormGroup;
  externalPartiesForm: FormGroup;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  fundDetails: any;
  total: 0;
  subscription: Subscription;
  shareLeft: number;

  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private fb: FormBuilder,
    private menuItemService: MenuItemsService,
    private ref: ChangeDetectorRef,
    private newPremiumService: changePremiumSharedService) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }
    this.createForm();
    this.getFundList();
    // const sample = [
    //   {
    //     "fundId": "OLAS|003",
    //     "fundName": "FUNDUSZ DYNAMICZNY ",
    //     "unitPrice": "10",
    //     "sort": "3",
    //     "investAccNumber": "21295126",
    //     "externalLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003",
    //     "allocationPercentage": "100",
    //     "dataError": false,
    //     "newAllocationPercentage": "0"
    //   },
    //   {
    //     "fundId": "OLAS|003",
    //     "fundName": "FUNDUSZ DYNAMICZNY ",
    //     "unitPrice": "10",
    //     "sort": "3",
    //     "investAccNumber": "21295126",
    //     "externalLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003",
    //     "allocationPercentage": "100",
    //     "dataError": false,
    //     "newAllocationPercentage": "0"
    //   }
    // ];
    this.subscription = this.fundListArray.valueChanges.subscribe(data => {
      this.total = data.reduce((a, b) => a + +b.newAllocationPercentage, 0);
      this.selectFundForm.get('total').setValue(this.total);
      this.shareLeft = 100 - this.total;
    })
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  createForm() {
    this.selectFundForm = this.fb.group({
      total: [0, Validators.required],
      fundListArray: this.fb.array([])
    });
  }

  get fundListArray() {
    return this.selectFundForm.get('fundListArray') as FormArray;

  }

  // fundListArray(): FormArray {
  //   return this.selectFundForm.get('fundListArray') as FormArray;
  // }  

  getFundList() {
    if(this.baseUrl.ecustomer.allocationChange!= null || this.baseUrl.ecustomer.allocationChange!= undefined){
    const reqParam = {
      "investAccNumber": "21295126",
      "clientId": "101583",
      "selectedInvestmentStrategy": "Allocation Change"
    }
    this.commonService.postData(this.baseUrl.ecustomer.allocationChange, reqParam, '').subscribe(data => {
      // this.dataSourceFundDetails = new MatTableDataSource(data);
      this.accountDet = data;
      if (data) {
        this.fundDetails = data;
        for (var i = 0; i < data.length; i++) {
          this.add(i);
        }
        //(data);
      } else {
        //
      }
      this.dataSourceFundDetails = new MatTableDataSource(this.selectFundForm['controls'].fundListArray['controls']);
    });
  }
}

  add(index) {
    this.fundListArray.push(this.new(index));
  }

  new(index): FormGroup {
    return this.fb.group({
      fundId: this.fundDetails[index].fundId,
      fundName: this.fundDetails[index].fundName,
      unitPrice: this.fundDetails[index].unitPrice,
      investAccNumber: this.fundDetails[index].investAccNumber,
      sort: this.fundDetails[index].sort,
      externalLink: this.fundDetails[index].externalLink,
      allocationPercentage: this.fundDetails[index].allocationPercentage,
      dataError: this.fundDetails[index].dataError,
      newSplitErr: false,
      newAllocationPercentage: [this.fundDetails[index].newAllocationPercentage],
    })
  }

  formSubmit() {
    return this.selectFundForm.valid;
  }

  submitSelectedFund() {
    //this.selectFundForm['controls'].fundListArray.markAsTouched()
    if (this.selectFundForm.dirty) {
      if (this.selectFundForm.controls['total'].value == 100) {
        this.newPremiumService.setFundData(this.selectFundForm.controls['fundListArray'].value);
        this.newPremiumService.setParamValue('selectFundForm', this.selectFundForm);
        return this.selectFundForm.valid;
      }
    }

  }

}
