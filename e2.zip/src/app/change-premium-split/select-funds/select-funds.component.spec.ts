import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ChangePremiumSplitModule } from '../change-premium-split-module';

import { SelectFundsComponent } from './select-funds.component';

xdescribe('SelectFundsComponent', () => {
  let component: SelectFundsComponent;
  let fixture: ComponentFixture<SelectFundsComponent>;

  const customerId = sessionStorage.getItem('userData');
  const countryCode = sessionStorage.getItem('countryCode'),
    defaultLangugae = sessionStorage.getItem('defaultLanguage');
  sessionStorage.setItem("defaultLanguage", defaultLangugae);
  window.sessionStorage.setItem('countryCode', JSON.stringify(countryCode));
  window.sessionStorage.setItem('defaultLanguage', JSON.stringify(defaultLangugae));
  window.sessionStorage.setItem('userData', customerId)

  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'allocationChange': host + '/api/v1/order/allocation-change'
      }
    }
  };
  window['__env'].environmentConstURLs = environmentConstURL;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ChangePremiumSplitModule, HttpClientTestingModule],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    // }));

    // beforeEach(() => {
    fixture = TestBed.createComponent(SelectFundsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 7000;
    expect(component).toBeTruthy();
  });
});
