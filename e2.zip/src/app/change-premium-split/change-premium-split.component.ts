import { Component, OnInit, ViewChild, AfterViewInit, ViewEncapsulation, ViewChildren, QueryList, Output, EventEmitter } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormGroup, FormControl, FormArray, NgForm, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material';
import { HttpCommonService } from '../shared/services/http-common.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import * as utils from 'lodash';
import { SelectAccountComponent } from './select-account/select-account.component';
import { SelectFundsComponent } from './select-funds/select-funds.component';
import { AppConfig } from 'src/config/app.config';
import { SummarySplitScreenComponent } from './summary-split-screen/summary-split-screen.component';
import { changePremiumSharedService } from './change-premium-shared-service';

@Component({
  selector: 'change-premium-split',
  templateUrl: './change-premium-split.component.html',
  styleUrls: ['./change-premium-split.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [{
    provide: STEPPER_GLOBAL_OPTIONS, useValue: { showError: true }
  }]
})
export class ChangePremiumSplitComponent implements OnInit {
  confirmationPage: boolean = false;
  previouslySelectedstep = [];
  isStepInteracted = false;
  selectAccountForm: FormGroup;
  selectFundForm: FormGroup;
  responseActiveOrder: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  FundAccountEmpty: boolean = false;
  totalShareError: boolean = false;
  selectAccountSecError: boolean = false;
  showOrderProcessingErr: boolean;
  selectedFundTotalErr: boolean;
  selectFundFormErr: boolean;
  valuesSelectedArray: any[];

  constructor(private translate: TranslateService, private _formBuilder: FormBuilder,
    private httpService: HttpCommonService, private router: Router,
    private route: ActivatedRoute,
    private newPremiumService: changePremiumSharedService
  ) { }

  ngOnInit() {
    this.selectAccountForm = this._formBuilder.group({
    });
    this.selectFundForm = this._formBuilder.group({
    });
  }

  step = 0;
  @ViewChild(SelectAccountComponent, { static: false }) selectAccRefComp: SelectAccountComponent;
  @ViewChild(SelectFundsComponent, { static: false }) selectFundRefComp: SelectFundsComponent;
  @ViewChild(SummarySplitScreenComponent, { static: false }) summaryRefComp: SummarySplitScreenComponent;

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    ////("next step");
    this.stepper.selectedIndex++;
  }

  prevStep() {
    this.step--;
  }

  onStepChange(event) {
  }



  @ViewChild('stepper', { static: false }) stepper: MatStepper;
  headers = new HttpHeaders();


  gotoStep(step) {
    this.stepper.selectedIndex = step;
  }

  changeSelection() {
    if (this.previouslySelectedstep.indexOf(0) && this.stepper && this.stepper['_selectedIndex'] !== 0) {
      return true;
    }
    return false;
  }

  validateSelectAccount() {
    //(this.selectAccRefComp.selectAccountForm)
    this.selectAccRefComp.submitSelectedAccount();
    if (this.selectAccRefComp.selectAccountForm.valid) {
      this.FundAccountEmpty = false;
      this.validateSelectedAccountDetails(this.selectAccRefComp.selectAccountForm.value);
      
    } else {
      this.FundAccountEmpty = true;
      window.scroll(0, 0);
    }
  }

  validateSelectedAccountDetails(value) {
    const reqParam = {
      "policyNumber": value.policyNumber,//"21295126",
      "selectedInvestmentStrategy": "Allocation Change",
      "investAccNumber": value.investAccNumber //"21295127"
    }
    this.httpService.postData(this.baseUrl.ecustomer.getActiveOrder, reqParam, this.headers).subscribe(data => {
      this.responseActiveOrder = data;
      if (!this.responseActiveOrder.activeOrderErrorRender) {
        this.showOrderProcessingErr = false;
        this.nextStep();
      } else {
        //error msg display
        this.showOrderProcessingErr = true;
        window.scroll(0, 0);
      }
    })
  }

  validateSelectFund() {
    this.selectFundRefComp.submitSelectedFund();
    this.FundAccountEmpty = false;
    if (this.selectFundRefComp.selectFundForm.dirty && this.selectFundRefComp.selectFundForm.valid) {
      if (this.selectFundRefComp.selectFundForm.controls['total'].value == '100') {
        let fundDataArr: any[];
        let arraySelected = [];
        this.newPremiumService.getFundData().subscribe((arr) => {
          fundDataArr = arr;
          fundDataArr.forEach((data) => {
            if (data.newAllocationPercentage != "0") {
              if (arraySelected.length == 0) {
                arraySelected.push(data);
              } else if (arraySelected.length >= 1) {
                arraySelected.forEach((val) => {
                  if (val.fundId == data.fundId) {
                    arraySelected.splice(val, 1);
                    arraySelected.push(data);
                  } else {
                    arraySelected.push(data);
                  }
                })
              } else if (arraySelected.length == 1) {
                if (arraySelected[0].fundId != data.fundId) {
                  arraySelected.push(data);
                }

              }
            }
          });
          this.newPremiumService.setSummaryReqData(arraySelected);
          //(arraySelected)
        });
        this.selectedFundTotalErr = false;
        this.nextStep();
      } else {
        this.selectedFundTotalErr = true;
        window.scroll(0, 0);
        //total value error
      }
    } else {
      //form empty
      this.selectedFundTotalErr = true;
      window.scroll(0, 0);
    }
  }

}

