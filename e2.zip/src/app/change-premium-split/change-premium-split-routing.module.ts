import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { ChangePremiumSplitComponent } from './change-premium-split.component';
import { SelectAccountComponent } from './select-account/select-account.component';
import { SelectFundsComponent } from './select-funds/select-funds.component';
import {SummarySplitScreenComponent} from './summary-split-screen/summary-split-screen.component';

const routes: Routes = [
    {
        path: '', component: ChangePremiumSplitComponent, canDeactivate: [NavigationGuard],
        children: [
            {
                path: 'transferFunds', component: SelectAccountComponent, canDeactivate: [NavigationGuard]
            },
            {
                path: '', component: SelectFundsComponent, canDeactivate: [NavigationGuard],
            },
            {
                path:'',component: SummarySplitScreenComponent,canDeactivate: [NavigationGuard],
            },
            {
                path:'',component: SummarySplitScreenComponent,canDeactivate: [NavigationGuard],
            }
        ]

    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ChangePremiumSplitRoutingModule { }
