import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { changePremiumSharedService } from './../change-premium-shared-service'

export interface AccountData {
  accountSelection: String;
  status: String;
  effectiveDate: String;
  investValue: String;
  // number: String;
}
@Component({
  selector: 'select-account',
  templateUrl: './select-account.component.html',
  styleUrls: ['./select-account.component.scss']
})
export class SelectAccountComponent implements OnInit {

  displayedColumns: string[] = ['accountSelection', 'effectiveDate', 'investValue', 'status'];
  // 'number', 
  dataSourceAccDetails: MatTableDataSource<AccountData>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  accountDet: any;
  selectAccountForm: FormGroup;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  checkBoxSelection: any = false;
  selectedAccountNumber: any;
  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private fb: FormBuilder,
    private menuItemService: MenuItemsService,
    private newPremiumService: changePremiumSharedService) { }

  ngOnInit() {
    this.sharedService.getDetail('checkBoxSelection').subscribe((data) => {
      if (data) {
        this.checkBoxSelection = data;
        //(this.checkBoxSelection)

      }
    })
    this.selectedAccountNumber = JSON.parse(sessionStorage.getItem('clickedAccountNumber'));
    //(this.selectedAccountNumber)
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      // if (this.country == 'pl') {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }
    this.selectAccountForm = this.fb.group({
      selectedAccount: new FormControl('', [Validators.required]),
      investAccNumber: new FormControl(''),
      policyNumber: new FormControl('')
    });
    this.getAccounts();
  }

  radiobuttonClick(row) {
    this.selectAccountForm.controls['investAccNumber'].setValue(row.investAccNumber);
    this.selectAccountForm.controls['policyNumber'].setValue(row.policyNumber);
  }

  getAccounts() {
    if (this.baseUrl.ecustomer.accountList != '') {
      const reqParam = {
        "contractNumber": "21295126",
        "clientId": "101583",
        "selectedInvestmentStrategy": "Allocation Change"
      }
      this.commonService.postData(this.baseUrl.ecustomer.accountList, reqParam, '').subscribe(data => {
        this.dataSourceAccDetails = new MatTableDataSource(data);
      })
    }
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

  formSubmit() {
    return this.selectAccountForm.valid;
  }

  submitSelectedAccount() {
    this.selectAccountForm.markAsTouched();
    //markAsTouched
    this.newPremiumService.setaccountData(this.selectAccountForm.value);
    this.newPremiumService.setParamValue('selectAccountForm', this.selectAccountForm);
  }
}
