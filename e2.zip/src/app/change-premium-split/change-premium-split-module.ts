import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule, MatSidenavModule, MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule, MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatInputModule, MatPaginatorModule, MatSortModule, MatTableModule, MatRadioModule, MatStepperModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { NgxPaginationModule } from 'ngx-pagination';
import { ChangePremiumSplitRoutingModule } from './change-premium-split-routing.module';
import { ChangePremiumSplitComponent } from './change-premium-split.component';
import {SelectAccountComponent} from './select-account/select-account.component';
import {SelectFundsComponent } from './select-funds/select-funds.component';
import {SummarySplitScreenComponent} from './summary-split-screen/summary-split-screen.component';
import { ChangePremiumConfirmationComponent } from './change-premium-confirmation/change-premium-confirmation.component';
import { changePremiumSharedService } from './change-premium-shared-service';


const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule, MatStepperModule];

@NgModule({
  declarations: [ChangePremiumSplitComponent,
    SelectAccountComponent,
    SelectFundsComponent,
    SummarySplitScreenComponent,
    ChangePremiumConfirmationComponent],
  imports: [
    CommonModule,
    ChangePremiumSplitRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    ...materialModule,
    NgxPaginationModule
  ],
  exports:[
    ChangePremiumSplitComponent,
    SelectAccountComponent,
    SelectFundsComponent,
    SummarySplitScreenComponent,
    ChangePremiumConfirmationComponent
  ]
})
export class ChangePremiumSplitModule { }
