import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ContactFormComponent } from './contact-form.component';
import { ContactFormModule } from './contact-form.module';
import { ContactFormService } from './service/contact-form.service';

import { of } from 'rxjs';
describe('ContactFormComponent', () => {
  let component: ContactFormComponent;
  let fixture: ComponentFixture<ContactFormComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  let contactFormService: ContactFormService;
  const menuList = {
    activeContractDetails: null,
    billingRecipent: null,
    callRetrievePolicies: false,
    callRetriveClientData: false,
    callRetriveClientOffers: false,
    ccDBAddressDTO: {
      ccdbFullAddress: "https://10.112.202.48/ccdb-web/",
      ccdbAddressPart2: ""
    },
    claimList: null,
    clientAdministration: true,
    clientId: "",
    clientIdList: [],
    clientIdbillControlList: [],
    clientLoginId: null,
    clientRoleIds: "3033|3034",
    clientRoleNames: "rSuperUser|rAdmnistrator",
    contractList: null,
    documentsList: null,
    eClaimsURL: "https://qa.eclaim.metlife.pl?countryCode=pl&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460e22ab4a70a2b886995e3826482fec79fa890f1f92293e6961ccd91c419c3efe9642d615c7d69b2a7",
    fundPriceDetails: null,
    menuItems: [{ menuId: "2", accessSpec: "RW", menuName: "Clients Administration", parentMenu: "Administration" }],
    offerResponse: null,
    orderHistory: null,
    personalInformationDTO: null,
    renderClaims: false,
    renderDocuments: false,
    renderFundPriceMonitoring: false,
    renderMyCompany: false,
    renderMyContract: false,
    renderMyData: false,
    renderOffers: false,
    renderOrderReview: false,
    renderUserAcctAdministration: true,
    route: "DisplayClientSearch",
    searchFlag: false,
    wardenRoleCheck: false
  };
  const userInfo = {
    authorizedApplicationCode: "eCustomer",
    clientId: null,
    creationDate: "Wed Jan 06 14:42:24 CET 2021",
    customerPasswordExprationCode: "1",
    daysSincePwdNotChanged: null,
    email: "osama.khalid@metlife.com",
    employeeNumber: null,
    failedLoginCounts: "0",
    firstName: "Osama",
    lastName: "Mo",
    passwordStatusCode: "ACTIVE",
    passwordType: "STANDARD",
    preferredLanguage: "en",
    pwdChangeDate: null,
    pwdExpirationDate: "Fri Mar 19 14:42:24 CET 2021",
    pwdExpired: "Active",
    requesterId: "-1",
    requesterRole: "3033",
    roleInfo: [{ roleId: "3033", name: "rSuperUser", description: "RSuperUser" }],
    route: "Home",
    securityPolicyId: "12345",
    temporaryLockDate: null,
    tokenExpirationDate: "Fri Sep 18 17:03:50 CEST 2020",
    userCheck: true,
    userDn: "ou=People,o=affiliates,c=Poland,o=metlife,dc=metlife,dc=com",
    userName: "OsamaAdmin"
  };
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'submitContactForm': host + '/api/v1/users/contact/reason/',
        'contactReasons': host + '/api/v1/users/contact-reasons/role',
        'getEmailId': host + '/api/v1/users/validate-email'
      }
    }
  };
  const serachClient =
    { "clientId": 1234, "opeType": "search" };
  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userInfo));
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));

    const countryCode = "ro";
    window.sessionStorage.setItem('countryCode', JSON.stringify(countryCode));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContactFormModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, ContactFormService, { provide: 'Window', useFactory: () => window }, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(ContactFormComponent);
    contactFormService = TestBed.get(ContactFormService)
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.countryCode = "ro";
    expect(component).toBeTruthy();
  });

  it('should call createFormInputs method', () => {
    component.createFormInputs();
  });

  it('should call createCheckList', () => {
    const list = [{
      contactReasonNameforDisplay: null,
      contactReasonPrefix: "OTHER",
      contactReasonStatus: "active",
      contactReasonType: "CONTACT",
      emailAddress: "victor.enache@metropolitanlife.ro",
      emailStatus: "active",
      id: "40GENERAL",
      value: "CONTACT_CODE_40GENERAL"
    }]
    component.createCheckList(list);
  });

  it('should call getContactReasons', () => {
    const response = {
      contactInfo: {
        clientId: '2242',
        emailPrimary: 'test@gmail.com',
        emailSecondary: null,
        firstName: 'test',
        identifier: null,
        lastName: null,
        mobileNumber: 'wewewe',
        residenceTelephone: null,
        safePhone: null,
        userName: 'test'
      },
      contactReasons: [{
        clientId: '34343',
        clientLoginId: null,
        contactReasonName: "CONTACT_CODE_40GENERAL",
        contactReasonNameforDisplay: null,
        contactReasonPrefix: "OTHER",
        contactReasonStatus: "active",
        contactReasonType: "CONTACT",
        contactReasonsId: "40GENERAL",
        contactType: "CONTACT",
        emailAddress: "victor.enache@metropolitanlife.ro",
        emailStatus: "active",
        otherContactType: null,
        peselNumber: null,
        selectedWayToReply: null,
        selectedWayToReplyValue: null,
        userContent: null,
        userName: null
      }]
    };
    spyOn(contactFormService, 'getContactListResons').and.returnValue(of(response))
    component.getContactReasons();
  });

  it('should call onSubmit', () => {
    component.onSubmit();
  });

  it('should call clear method', () => {
    component.clear();
  });

  xit('should call contactSubmit', () => {
    component.contactSubmit();
  });

  xit('should call gotoHome', () => {
    component.gotoHome();
  });

  xit('should call sendRequestParam', () => {
    component.selectedAnswerOption = {
      contactType: "SingleContact",
      id: "other",
      value: "To another e-mail address or phone number"
    }
    component.sendRequestParam();
  })
});
