import { Injectable } from '@angular/core';

import { HttpCommonService } from '../../shared/services/http-common.service';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { AppConfig } from 'src/config/app.config';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';

@Injectable({
  providedIn: 'root'
})
export class ContactFormService {

  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];

  constructor(private cService: HttpCommonService, private readonly menuItemService: MenuItemsService) {

  }
  clientId: any;
  getContactListResons(contactReason) {

    const userInfo = sessionStorage.getItem('loggedInUserInfo');
    let userdetail = JSON.parse(userInfo);
    let userrole = this.menuItemService.getAllRoles();
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    // if (userrole === "rClient") {
    // this.clientId = userdetail ? (userdetail.clientId ? userdetail.clientId : '') : '';
    // } else {
    //   this.clientId = customerId ? (customerId.clientID ? customerId.clientID : '') :'';
    // }
    if (userdetail) {
      // //('userdetail', userdetail)
      this.clientId = userdetail.clientId ? userdetail.clientId : '';
    }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    }

    if (contactReason) {
      contactReason = contactReason;
    } else {
      contactReason = "NoReason";
    }

    const param = {
      "reason": contactReason,
      "role": userrole ? userrole : 'NoRole',
      "userId": userdetail ? userdetail.userName : '',
      "clientId": this.clientId
    }
    // //("baseURL", userdetail.userName)
    return this.cService['postData'](
      this.baseUrl.ecustomer.contactReasons, param, '');
    //this.baseUrl.ecustomer.contactReasons +'/' + userdetail.userName   + '/');
  }
  // let role = userdetail.roleInfo[0] ? userdetail.roleInfo[0].name : 'NoRole'; 
  // let subUrl = '/' + role + '/' + contactReason + '/' + userdetail.userName + '/'; 
  // let reason = "60A010I14";
  // let userName = "ShabanaAdmin";
  // getContactUsDetails() {
  //   let contactReasonsURL = environment.host + environment.contactUs.url;
  //   return this.cService[environment.contactUs.method](
  //     contactReasonsURL + '/' + 'Admin3' + '/');
  // }

  postSubmitForm(requestPayload): Observable<any> {

    const token = JSON.parse(sessionStorage.getItem('userToken'));
     
    let apictoken = token.apicToken;
    let country = sessionStorage.getItem('countryCode')
    let httpHeaderObj = {
      'accept-language': sessionStorage.getItem('defaultLanguage'),
      'x-tenant-id': sessionStorage.getItem('countryCode'),
      'content-type': 'application/json',
      'accept': 'application/json',
      'x-system-id': 'ecustomer',
      'Authorization': token ? `Bearer ${token.token}` : ''
    }
    if(country == 'gr'){
        httpHeaderObj['apicToken'] = apictoken
    }
   
    
    let headerOptions = {
      headers: new HttpHeaders(httpHeaderObj),
      observe: 'response'
    };
    let submitUrl = this.baseUrl.ecustomer.submitContactForm;
    return this.cService['postDataWithHeader'](
      this.baseUrl.ecustomer.submitContactForm, requestPayload, headerOptions);
  }

  getEmailIdValue(emailID) {
    //const url = `${this.baseUrl.ecustomer.getEmailId}/${emailID}/'validate'`;
    const url = this.baseUrl.ecustomer.getEmailId,
      param = {
        email: emailID
      };

    return this.cService['postData'](
      this.baseUrl.ecustomer.getEmailId, param, '');
  }
}
