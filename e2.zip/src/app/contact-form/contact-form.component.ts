import { Component, OnInit, ComponentFactoryResolver } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, FormArray, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { HttpCommonService } from '../shared/services/http-common.service';

import * as lodash from "lodash";

import { ContactFormService } from './service/contact-form.service';
import { takeWhile } from 'rxjs/operators';
import { DialogService } from '../shared/services/dialog.service';

import {
  MatSnackBar, MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { SnackBarComponent } from '../shared/dialog/snack-bar/snack-bar.component';
import { ConfirmDialogComponent } from '../shared/dialog/confirm-dialog/confirm-dialog.component';
import { BroadcasterService } from '../core/services/broadcaster.service';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { TranslateService } from '@ngx-translate/core';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { ValidationService } from '../core/utils/validators';
import { UtilityService } from '../shared/utilities/utility.service';
@Component({
  selector: 'contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.scss'],
  providers: [MatSnackBar]
})
export class ContactFormComponent implements OnInit {

  contactForm: FormGroup;
  name = 'Angular';
  radioSelected: any;
  contactPurposeList = [];
  answerOptionsList = [];
  selectedPurpose;
  contactUsEntireDetails;
  contactSchedule = [];
  selectedAnswerOption;
  countryCode;
  showwEmailInValid: boolean = false
  subscribeFlag = true;
  inValidForm = false;
  answerOptionROlist = [{
    id: 'phoneNumber',
    value: 'By Phone',
    contactType: 'Byphone'
  },
  {
    id: 'email',
    value: 'On e-mail',
    contactType: 'Viaemail'
  }];
  contactDay = [
    { "day": 'day1', "time": 'time1' },
    { "day": 'day2', "time": 'time2' },
    { "day": 'day3', "time": 'time3' },
    { "day": 'day4', "time": 'time4' },
    { "day": 'day5', "time": 'time5' },
    { "day": 'day6', "time": 'time6' },
    { "day": 'day7', "time": 'time7' }
  ];
  contactInfoKey = {
    "mobileNumber": "",
    "residenceTelephone": "",
    "safePhone": "",
    "emailPrimary": "",
    "emailSecondary": "",
  }
  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  loggedInCountry: boolean;
  constructor(private fb: FormBuilder, public httpCommonService: HttpCommonService, public translate: TranslateService,
    private readonly contactFormService: ContactFormService, public dialog: DialogService,
    public snackBar: MatSnackBar, public readonly broadCastService: BroadcasterService, public sharedService: SharedServiceService,
    private menuItemService: MenuItemsService, private validationService: ValidationService) {
  }
  language: any;
  ngOnInit() {
    this.countryCode = sessionStorage.getItem('countryCode');
    this.language = sessionStorage.getItem('defaultLanguage');
    this.loggedInCountry = UtilityService.getCountry();
    //JSON.parse(sessionStorage.getItem('userData')).country;
    //(this.countryCode)
    this.inValidForm = false;

    this.getContactReasons();
    // this.getContactUsDetailsList();
    this.broadCastService.on<any>('resetForm').subscribe((data) => {
      //(data);
      this.contactForm.reset();
      lodash.forIn(this.contactForm.controls, (value: string | number, name: string) => {
        //(value)
        const control = <FormArray>this.contactForm.controls[name];
        //const control = this.contactForm.controls[name] as FormArray;
        for (let i = control.length - 1; i >= 0; i--) {
          control.controls[i].reset();
          control.controls[i].enable();
          // control.controls[i].setErrors(null);
        }

      });
      this.contactForm.updateValueAndValidity();
      //(this.contactForm)

    });
    // this.createFormInputs();
    this.contactForm = this.fb.group({
      contactPurpose: [''],
      answerOption: [''],
      otherEmailOrPhone: [''],
      messageText: [''],
      phoneNumber: [''],
      email: ['']
    });
    this.contactForm.controls.otherEmailOrPhone.disable();
  }

  ngOnDestroy() {
    this.subscribeFlag = false;

  }
  get fValue() { return this.contactForm.controls; }


  contactPurpose: boolean = false;
  createFormInputs() {
    this.contactForm = this.fb.group({
      contactPurpose: this.createCheckList(this.contactPurposeList),
      answerOption: this.createCheckList(this.answerOptionsList),
      otherEmailOrPhone: ['', Validators.pattern(this.emailPattern)],
      phoneNumber: ['', Validators.required],
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      messageText: ['']
    });
    this.contactForm.controls['contactPurpose'].setValidators([Validators.required]);

    if (this.othercontactReason) {
      this.contactForm.controls.contactPurpose["controls"].forEach((purpose, i) => {

        this.contactForm.controls.contactPurpose["controls"][i].setValue(true);
        // this.contactForm.controls.contactPurpose["controls"][i].updateValueAndValidity();
      });
      this.contactPurpose = true;
      this.contactForm.controls['contactPurpose'].disable();

      // this.contactForm.get('contactPurpose').setValue(false);
      this.sharedService.setContactReason(null);
    } else {
      this.contactPurpose = false;
      this.sharedService.setContactReason(null);
      this.contactForm.controls['contactPurpose'].enable();
    }
    //(this.contactForm)
  }

  createCheckList(checkList) {
    const arr = checkList.map(purpose => {
      return new FormControl(purpose.selected || false, [Validators.required]);
    });
    return new FormArray(arr, [Validators.required]);
  }

  // getContactUsDetailsList() {
  //   this.contactFormService.getContactUsDetails().subscribe((data) => {
  //     //(data);
  //     this.contactUsEntireDetails = data;
  //     data.daysAndTime.forEach(dayAndTime => {
  //       this.contactSchedule.push({
  //         id: dayAndTime.day,
  //         value: dayAndTime.time,
  //       })
  //     });
  //   });
  // }
  othercontactReason: any;
  getContactReasons() {
    this.othercontactReason = this.sharedService.getContactReason();
    this.contactFormService.getContactListResons(this.othercontactReason).subscribe((data) => {
      //(data);
      data.contactReasons.forEach(reasons => {
        this.contactPurposeList.push({
          id: reasons.contactReasonsId,
          value: reasons.contactReasonName,
          contactReasonStatus: reasons.contactReasonStatus,
          contactReasonType: reasons.contactReasonType,
          emailAddress: reasons.emailAddress,
          emailStatus: reasons.emailStatus,
          contactReasonNameforDisplay: reasons.contactReasonNameforDisplay,
          contactReasonPrefix: reasons.contactReasonPrefix
        });
      });
      // this.contactPurposeList.push({
      //   id: 'Other',
      //   value: 'Other'
      // });

      for (const key1 in this.contactInfoKey) {
        for (const key in data.contactInfo) {
          if (key1 === key) {
            if (data.contactInfo.hasOwnProperty(key) && data.contactInfo[key]) {
              this.populateAnswerOpyionsList(key, data);
            }
          }
        }
      }
      if (this.answerOptionsList.some(ansOption => ansOption.id === "safePhone")) {
        const indx = this.answerOptionsList.findIndex(v => v.id === "mobileNumber");
        this.answerOptionsList.splice(indx, indx >= 0 ? 1 : 0);
        const indx2 = this.answerOptionsList.findIndex(v => v.id === "residenceTelephone");
        this.answerOptionsList.splice(indx2, indx2 >= 0 ? 1 : 0);
      } else if (!this.answerOptionsList.some(ansOption => ansOption.id === "safePhone") && this.answerOptionsList.some(ansOption => ansOption.id === "mobileNumber")) {

        const indx2 = this.answerOptionsList.findIndex(v => v.id === "residenceTelephone");
        this.answerOptionsList.splice(indx2, indx2 >= 0 ? 1 : 0);
      }
      if (this.answerOptionsList.some(ansOption => ansOption.id === "emailSecondary")) {
        const indx = this.answerOptionsList.findIndex(v => v.id === "emailPrimary");
        this.answerOptionsList.splice(indx, indx >= 0 ? 1 : 0);
      }

      if (data.contactInfo == null && this.countryCode.toLowerCase() === 'ro') {
        this.answerOptionROlist.forEach(list => {
          this.answerOptionsList.push({
            id: list.id,
            value: list.value,
            contactType: list.contactType
          });
        });
      }
      this.answerOptionsList.push({
        id: 'other',
        value: this.translate.instant("eCustomer.contactform.anotherEmail"),
        contactType: 'SingleContact'
      });

      this.createFormInputs();

    });
  }
  populateAnswerOpyionsList(key, data) {
    this.answerOptionsList.push({
      id: key,
      value: data.contactInfo[key],
      contactType: this.getContactType(key)
    });
  }
  getContactType(key) {
    switch (key) {
      case 'mobileNumber':
      case 'residenceTelephone':
      case 'safePhone':
        return 'Byphone'

      case 'emailPrimary':
      case 'emailSecondary':
        return 'Viaemail'
    }

  }

  get purposeForContact() { return this.contactForm.controls.contactPurpose.valid; }
  getSelectedPurpose(event, formControl, selectedList, index) {

    this.contactForm.controls.contactPurpose["controls"].forEach((purpose, i) => {
      if (this.contactPurposeList[i].id !== selectedList.id && event.checked) {
        this.contactForm.controls.contactPurpose["controls"][i].disable();
      } else if (!event.checked) {
        this.contactForm.controls.contactPurpose["controls"][i].enable();
      }
    });
    this.selectedPurpose = selectedList;
  }
  mobileChkBxValid: boolean = false;
  getSelectedAnswerInput(event, answerOption, selectedAnswerOption, index) {

    let element = document.getElementById('answerOption_' + selectedAnswerOption.id)
    if (event.target.value != '' && !answerOption.value) {
      this.contactForm.controls.answerOption["controls"].forEach((option, i) => {

        if (this.answerOptionsList[i].id !== selectedAnswerOption.id) {
          this.contactForm.controls.answerOption["controls"][i].disable();
          if (selectedAnswerOption.id == 'phoneNumber') {
            this.contactForm.get('email').disable();
          } else if (selectedAnswerOption.id == 'email') {
            this.contactForm.get('phoneNumber').disable();
          }
        } else {
          this.contactForm.controls.answerOption["controls"][i].enable();
          element.className = 'errorCheckBox'
        }
      });
    } else {
      if (!answerOption.value) {
        this.contactForm.get('answerOption').enable();
        this.contactForm.get('email').enable();
        this.contactForm.get('phoneNumber').enable();
        if (!this.inValidForm) {
          element.className = 'checkboxAdj'
        }
      }
    }
  }

  getSelectedAnswer(event, formControl, selectedAnswerOption, index) {
    this.inValidForm = false;
    this.invalidEmail = false;
    let element = document.getElementById('answerOption_' + selectedAnswerOption.id)
    this.contactForm.controls.answerOption["controls"].forEach((option, i) => {
      if (this.answerOptionsList[i].id !== selectedAnswerOption.id && event.checked) {
        this.contactForm.controls.answerOption["controls"][i].disable();

      } else if (!event.checked) {
        this.contactForm.controls.answerOption["controls"][i].enable();
      }
    });
    this.selectedAnswerOption = selectedAnswerOption;
    //(this.selectedAnswerOption);
    // if (this.countryCode.toLowerCase() === 'ro') {
    //   this.blurEmailField();
    // }

    if (this.countryCode.toLowerCase() === 'ro' && event.checked) {
      element.className = 'checkboxAdj'
      if (this.selectedAnswerOption.contactType === "Byphone") {
        this.contactForm.controls.phoneNumber.enable();
        this.contactForm.controls.email.disable();
        this.contactForm.controls.email.setValue(null);
      } else if (this.selectedAnswerOption.contactType === "Viaemail") {
        this.contactForm.controls.phoneNumber.disable();
        this.contactForm.controls.phoneNumber.setValue(null);
        this.contactForm.controls.email.enable();
        //}else if(this.selectedAnswerOption.contactType === "other"){  
      } else if (this.selectedAnswerOption.contactType === "SingleContact") {
        this.contactForm.controls.phoneNumber.disable();
        this.contactForm.controls.phoneNumber.setValue(null);
        this.contactForm.controls.email.disable();
        this.contactForm.controls.email.setValue(null);
      }
    } else {
      this.contactForm.controls.phoneNumber.enable();
      this.contactForm.controls.email.enable();
      this.contactForm.controls.phoneNumber.setValue(null);
      this.contactForm.controls.email.setValue(null);
    }
    if (!event.checked && selectedAnswerOption.id === 'other') {
      this.contactForm.controls.otherEmailOrPhone.disable();
      this.contactForm.controls.otherEmailOrPhone.setValue(null);
    } else if (event.checked && selectedAnswerOption.id === 'other') {
      this.contactForm.controls.otherEmailOrPhone.enable();
    }
  }
  clientId: any;
  sendRequestParam() {
    const userInfo = sessionStorage.getItem('loggedInUserInfo'),
      userdetail = JSON.parse(userInfo);
    let userrole = this.menuItemService.getAllRoles();
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    // if (userrole === "rClient") {
    //   this.clientId = userdetail ? (userdetail.clientId ? userdetail.clientId : '') :'';
    // } else {
    //   this.clientId = customerId ? (customerId.clientID ? customerId.clientID : '') :'';
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (userdetail) {
      this.clientId = userdetail.clientId ? userdetail.clientId : '';
    }

    let selectedWayToReplyValue = ''
    if (this.countryCode.toLowerCase() === 'ro') {
      if (this.selectedAnswerOption.contactType === "Byphone") {
        selectedWayToReplyValue = (this.contactForm.controls.phoneNumber ? this.contactForm.controls.phoneNumber.value : "")
      } else if (this.selectedAnswerOption.contactType === "Viaemail") {
        selectedWayToReplyValue = (this.contactForm.controls.email ? this.contactForm.controls.email.value : "")
      }
    }
    let peselNo = "";
    let otherConatct = this.countryCode.toLowerCase() === 'ro' ? "MailingAddress" : "Toanotheremailaddressorphone";
    let otherContactTypeValue = (this.contactForm.controls.otherEmailOrPhone.value ? this.contactForm.controls.otherEmailOrPhone.value : null);
    const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    const menuItemList2 = JSON.parse(sessionStorage.getItem('menuItemList'));
    const searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
    if (searchedClientDetails) {
      peselNo = searchedClientDetails ? searchedClientDetails.id : '';
    }
    let clientLoginId = "";
    let clientRole = "";
    if (menuItemList) {
      clientLoginId = menuItemList.clientLoginId ? menuItemList.clientLoginId : '';
      clientRole = menuItemList.clientRoleIds ? menuItemList.clientRoleIds : '';
    } else if (menuItemList2) {
      // const loggedUserInfo = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
      // let username = loggedUserInfo? loggedUserInfo.userName :''; 
      clientLoginId = menuItemList2.clientLoginId ? menuItemList2.clientLoginId : userdetail.userName;
    }
    return {
      "contactReasonsId": this.selectedPurpose.id,
      "contactReasonName": this.selectedPurpose.value,
      "contactReasonStatus": this.selectedPurpose.contactReasonStatus,
      "contactReasonType": this.selectedPurpose.contactReasonType,
      "contactReasonPrefix": this.selectedPurpose.contactReasonPrefix,
      "emailAddress": this.selectedPurpose.emailAddress,
      "emailStatus": this.selectedPurpose.emailStatus,
      "contactReasonNameforDisplay": this.selectedPurpose.contactReasonNameforDisplay,
      "selectedWayToReply": this.selectedAnswerOption.contactType !== 'SingleContact' ? this.selectedAnswerOption.value : 'SingleContact',
      "selectedWayToReplyValue": selectedWayToReplyValue,
      "contactType": this.selectedAnswerOption.contactType !== 'SingleContact' ? this.selectedAnswerOption.contactType : otherConatct,
      "userContent": this.contactForm.controls.messageText.value,
      "otherContactType": this.selectedAnswerOption.contactType === 'SingleContact' ? otherContactTypeValue : '',
      "userName": userdetail.userName,
      "clientId": this.clientId,
      "clientLoginId": clientLoginId,
      "peselNumber": peselNo
    };
  }
  otherEmailOrPhoneflag: boolean = false;
  invalidEmail: boolean = false;
  onSubmit() {
    this.inValidForm = false;
    this.invalidEmail = false;
    if (!(this.selectedPurpose)) {
      this.selectedPurpose = this.contactPurposeList[0];
    }
    let loggedInCountryCheck = UtilityService.getCountry();
    if (this.selectedAnswerOption && this.selectedAnswerOption.id === "other" && loggedInCountryCheck
      //this.countryCode.toLowerCase() === 'pl'
    ) {
      if (this.contactForm.get("otherEmailOrPhone").value !== "" && this.contactForm.get("otherEmailOrPhone").value !== null) {
        this.otherEmailOrPhoneflag = true;
      } else {
        this.otherEmailOrPhoneflag = false;
      }
    } else {
      this.otherEmailOrPhoneflag = true;
    }
    //   if (this.countryCode.toLowerCase() === 'pl') {
    if (loggedInCountryCheck) {
      if (!(this.contactForm.controls.answerOption.valid)) {
        this.inValidForm = true;
      }
      // this.contactForm.controls.answerOption["controls"].forEach((option, i) => {
      //   if (!option.value) {
      //     this.inValidForm = true; 
      //   }
      // })
    }
    if (this.countryCode.toLowerCase() === 'ro') {
      if (!(this.contactForm.controls.answerOption.valid)) {
        this.inValidForm = true;
      }

      if (this.selectedAnswerOption && this.selectedAnswerOption.id === 'email' &&
        (this.contactForm && this.contactForm.get("email").value === "" ||
          this.contactForm.get("email").value === null)) {
        this.inValidForm = true;
      } else {
        let email = this.contactForm.get("email");
        if (email.value) {
          if (ValidationService.emailValidator(email) == null) {
            this.invalidEmail = false;
          } else {
            this.invalidEmail = true;
            this.inValidForm = false;
          }
        }
      }
      if (this.selectedAnswerOption && this.selectedAnswerOption.id === 'phoneNumber' && (this.contactForm.get("phoneNumber").value === "" ||
        this.contactForm.get("phoneNumber").value === null)) {
        this.inValidForm = true;
      }
    }

    if (this.contactForm.get("messageText").value === "" ||
      this.contactForm.get("messageText").value === null) {
      this.inValidForm = true;
    }

    if ((this.contactForm.controls['contactPurpose'].valid || this.contactPurpose) &&
      ((!this.inValidForm) && this.otherEmailOrPhoneflag) && (!this.invalidEmail)) {

      this.contactSubmit();
    } else {
      if (this.countryCode.toLowerCase() === 'ro' && (this.invalidEmail)) {
        this.inValidForm = false;
      } else {
        this.inValidForm = true;
      }
      //this.clear();
    }
  }
  clear() {
    this.inValidForm = false;
    this.invalidEmail = false;
  }
  contactSubmit() {
    let requestPAram = this.sendRequestParam();
    this.contactFormService.postSubmitForm(requestPAram)
      .pipe(takeWhile(() => this.subscribeFlag)).subscribe((data) => {
        if (data.status == 200) {
          this.inValidForm = false;
          const message = this.translate.instant("eCustomer.contactform.confirmationDesc");
          const confirmtxt = this.translate.instant("eCustomer.contactform.confirmationtx");
          const message2 = this.translate.instant("eCustomer.contactform.confirmationDesc2");
          const gotoHome = this.translate.instant("eCustomer.contactform.gotohometxt");
          this.dialog.openDialog(ConfirmDialogComponent, {
            'heading': confirmtxt,
            'body': message,
            'subBody': message2,
            'gotohometxt': gotoHome,
            secondaryButton: 'Ok',
            fromContact: 'contactForm'
          });
        }
      }, error => {
        //show er
        // const message = "Something went wrong"
        // this.openSnackBar(message, 'pizza-party')

      });
  }

  openSnackBar(message: string, panelClass: string) {
    this.snackBar.openFromComponent(SnackBarComponent, {
      data: message,
      panelClass: 'my-custom-snackbar',
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }

  blurEmailField() {

    //("Email ID", this.contactForm.controls.otherEmailOrPhone.value)
    if (this.contactForm.controls.otherEmailOrPhone.value != '' && this.countryCode.toLowerCase() === 'ro' &&
      this.selectedAnswerOption.contactType && this.selectedAnswerOption.contactType === 'Viaemail') {
      this.contactFormService.getEmailIdValue(this.contactForm.controls.otherEmailOrPhone.value)
        .pipe(takeWhile(() => this.subscribeFlag)).subscribe((data) => {
          //("email", data)
          if (data == true) {
            this.showwEmailInValid = false;
          } else {
            this.showwEmailInValid = true;
          }

        });
    }
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }


}

