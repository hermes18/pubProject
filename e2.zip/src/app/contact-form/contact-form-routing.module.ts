import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { ContactFormComponent } from './contact-form.component';


const routes: Routes = [
  {
    path: '', component: ContactFormComponent,
    canDeactivate: [NavigationGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContactFormRoutingModule { }
