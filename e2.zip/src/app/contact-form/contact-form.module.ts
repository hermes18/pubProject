import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ContactFormComponent } from './contact-form.component';
import { ContactFormRoutingModule } from './contact-form-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ContactFormService } from './service/contact-form.service';
import { ValidationService } from '../core/utils/validators';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [ContactFormComponent],
  imports: [
    CommonModule,
    // NgbModule.forRoot(),
    ContactFormRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    MatCheckboxModule
  ],
  providers: [ContactFormService,ValidationService]
})
export class ContactFormModule { }
