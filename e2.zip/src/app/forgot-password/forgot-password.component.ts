import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogService } from '../shared/services/dialog.service';
import { HttpCommonService } from '../shared/services/http-common.service';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { AppConfig } from 'src/config/app.config';
import { UtilityService } from '../shared/utilities/utility.service';

@Component({
  selector: 'forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup;
  loginID: string
  emailID: string
  country: string
  userType: string
  errorCodeMessage: string
  submitted = false;
  response: string;
  successForgotPassword: boolean = false;
  message: string = "Your temporary password has been sent to the email. The password will be valid for 72 hours"
  headers = new HttpHeaders();
  appConfig: AppConfig = AppConfig.getConfig();
  userResponse: Object;
  loggedInCountry: boolean;
  constructor(private dailogService: DialogService, private cService: HttpCommonService) { }
  baseUrl = this.appConfig['api'];
  ngOnInit() {
    this.forgotPasswordForm = new FormGroup({
      loginId: new FormControl('', [Validators.required]),
      emailId: new FormControl('', [Validators.required]),
    });
    this.country = sessionStorage.getItem('countryCode');
    this.loggedInCountry = UtilityService.getCountry();
    this.errorCodeMessage = ''
    this.userType = ''
  }
  get f() { return this.forgotPasswordForm.controls; }

  chkerr() {

  }

  onPasswordData() {
    this.submitted = true;
    let flagtest = "assets/mocks/forgotPassword.json"
    //  /api/v1/user/{userid}/{emailid}
    if ((this.forgotPasswordForm.controls['emailId'].value.trim() == '') && (this.forgotPasswordForm.controls['loginId'].value.trim() == '')) {
      this.forgotPasswordForm.controls["emailId"].setErrors({ 'required': true });
      this.forgotPasswordForm.controls['loginId'].setErrors({ 'required': true });
      this.forgotPasswordForm.controls["emailId"].setValue('');
      this.forgotPasswordForm.controls['loginId'].setValue('');
    } else if (this.forgotPasswordForm.controls['emailId'].value.trim() == '') {
      this.forgotPasswordForm.controls["emailId"].setErrors({ 'required': true });
      this.forgotPasswordForm.controls["emailId"].setValue('');
    } else if (this.forgotPasswordForm.controls['loginId'].value.trim() == '') {
      this.forgotPasswordForm.controls['loginId'].setErrors({ 'required': true });
      this.forgotPasswordForm.controls['loginId'].setValue('');
    } else if (this.forgotPasswordForm.controls['emailId'].errors == null && this.forgotPasswordForm.controls['loginId'].errors == null) {
      // this.successForgotPassword = true

      let params = {
        email: this.forgotPasswordForm.get('emailId').value,
        userId: this.forgotPasswordForm.get('loginId').value
      }
      // let emailid =  this.forgotPasswordForm.get('emailId').value;
      // let userid= this.forgotPasswordForm.get('loginId').value;
      //et url = this.baseUrl.ecustomer.forgotPasswordConfig + '/' + params.userid + '/' + params.emailid + '/';
      let url = this.baseUrl.ecustomer.forgotPasswordConfig;

      // this.cService['getDataValueHeaders'](url, this.headers)
      this.cService['postDataValueHeaders'](url, params)
        .subscribe((data) => {
          //(data);
          // this.userResponse = data;
          // if (data['response'] != null) {
          this.successForgotPassword = true
          // this.userType = data['errorCode']
          this.errorCodeMessage = ''
          // }
          // else {
          //   this.successForgotPassword = false
          //   this.errorCodeMessage = data['errorCode']
          // }
        });
      // //("data:", this.forgotPasswordForm.get('emailId').value, "", this.forgotPasswordForm.get('loginId').value)
    }
  }



}
