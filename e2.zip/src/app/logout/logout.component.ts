import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { CanComponentDeactivate } from '../core/gaurds/can-deactivate-guard';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';

import { PlatformLocation, LocationStrategy, Location } from '@angular/common';
import { LoginComponent } from '../login/login.component';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { Idle } from '@ng-idle/core';
import { BroadcasterService } from '../core/services/broadcaster.service';
import { UtilityService } from '../shared/utilities/utility.service';
@Component({
  selector: 'logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit {
  pressBackButton = false;

  displayPoOption: boolean = false;
  @HostListener('window:popstate', ['$event'])
  onPopState(event) {
    this.pressBackButton = true;
    // this.location.back();
    //(event);
  }
  @ViewChild(LoginComponent, { static: false }) loginComp: LoginComponent;
  canDeactivate(component: CanComponentDeactivate, route: ActivatedRouteSnapshot, state: RouterStateSnapshot,
    nextState: RouterStateSnapshot): Observable<boolean> | boolean {
    //('can')
    if (this.pressBackButton) {
      this.pressBackButton = false;
      history.pushState(null, null, location.href);
      this.locationStrategy.onPopState(() => {
        history.pushState(null, null, location.href);
      })
      return false;
    } else {
      return true;
    }
  }
  constructor(private readonly locationStrategy: LocationStrategy, public router: Router, public readonly broadCastService: BroadcasterService,
    public sharedService: SharedServiceService, private idle: Idle) { }
  countryCode: string = this.sharedService.countryCode;
  defaultLanguage: string = this.sharedService.defaultLanguage;
  host: "'http://'+window.location.host+'/'";
  country;

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      //  if (this.country == 'pl'){
      this.displayPoOption = true;
    } else {
      this.displayPoOption = false;
    }
    setTimeout(() => {
      window.scrollTo(0, 0);
    });  // setTimeout(() => {
    //   location.replace("/login?language=" + this.defaultLanguage + "&countryCode=" + this.countryCode + "")
    // }, 15000);

  }
  navigationToLogin() {
    this.clearSessionStorage();
    this.router.navigate(['/login']);
    setTimeout(() => {
      window.scrollTo(0, 0);
    });
    /////(this.sharedService.countryCode + "- " + this.sharedService.defaultLanguage); 
    //location.replace("/login?language=" + this.defaultLanguage + "&countryCode=" + this.countryCode + "")


  }

  clearSessionStorage() {
    this.idle.stop();
    const countryCode = sessionStorage.getItem('countryCode'),
      defaultLangugae = sessionStorage.getItem('defaultLanguage');
    sessionStorage.clear();
    this.broadCastService.broadcast('setttingroute', false);
    //this.sharedService.setDetail('menuItemList', null);
    this.sharedService.setcurrentUserLoggedIn([]);
    sessionStorage.setItem("defaultLanguage", defaultLangugae);
    sessionStorage.setItem("countryCode", countryCode);

    // this.router.navigate(['/logout']);
  }

}
