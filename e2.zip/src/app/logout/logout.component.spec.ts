import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from '../app.module';
import { CanComponentDeactivate } from '../core/gaurds/can-deactivate-guard';

import { LogoutComponent } from './logout.component';

describe('LogoutComponent', () => {
  let component: LogoutComponent;
  let fixture: ComponentFixture<LogoutComponent>;

  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    window.sessionStorage.setItem("defaultLanguage", "pl_pl");
    const countryCode = "ro";
    window.sessionStorage.setItem('countryCode', JSON.stringify(countryCode));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: [],
      providers: [TranslateService]

    })
      .compileComponents();
    fixture = TestBed.createComponent(LogoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create', () => {
    component.country = "pl";
    component.ngOnInit();
  });


  it('should create clearSessionStorage', () => {
    component.clearSessionStorage();
  });

  it('should create navigationToLogin', () => {
    component.navigationToLogin();
  })
});
