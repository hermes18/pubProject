import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpCommonService } from '../shared/services/http-common.service';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { AppConfig } from 'src/config/app.config';
import { ChangePasswordModel } from './model/change-password.model';
import { Router } from '@angular/router';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { AlertDialogComponent } from '../shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from '../shared/services/dialog.service';

@Component({
  selector: 'change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ChangePasswordComponent implements OnInit {
  changePasswordModel: ChangePasswordModel;
  // changePasswordForm: FormGroup;
  message = "Password change is successfull";
  // submitted = false;
  // successChangePassword: boolean = false;
  // currentPasswordFieldTextType: boolean = false;
  // newPasswordFieldTextType: boolean = false;
  // confirmPasswordFieldTextType: boolean = false;
  // errorCodeMessage: string;
  countryCode = sessionStorage.getItem('countryCode');
  headers = new HttpHeaders();
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(private dailogService: DialogService, private cService: HttpCommonService, public translate: TranslateService,
    public router: Router, private readonly commonService: SharedServiceService, public dialog: DialogService,
    private readonly menuItemService: MenuItemsService) {
    this.changePasswordModel = new ChangePasswordModel();
  }
  ngOnInit() {
    this.changePasswordModel.changePasswordForm = new FormGroup({
      Password: new FormControl('', [Validators.required]),
      ConfirmPassword: new FormControl('', [Validators.required]),
      oldPassword: new FormControl('', [Validators.required])
    });
  }

  toggleFieldTextType(textType) {
    this.changePasswordModel[textType] = !this.changePasswordModel[textType];
  }

  get f() { return this.changePasswordModel.changePasswordForm.controls; }

  onSubmit() {
    this.changePasswordModel.submitted = true;
    // this.checkPwd();
    let url = true
    const userInfo = sessionStorage.getItem('loggedInUserInfo'),
      userdetail = JSON.parse(userInfo);

    if (this.changePasswordModel.changePasswordForm.controls['Password'].errors == null && this.changePasswordModel.changePasswordForm.controls['ConfirmPassword'].errors == null && this.changePasswordModel.changePasswordForm.controls['oldPassword'].errors == null) {

      let params = {
        oldPassword: btoa(encodeURIComponent(this.changePasswordModel.changePasswordForm.get('oldPassword').value)),
        newPassword: btoa(encodeURIComponent(this.changePasswordModel.changePasswordForm.get('Password').value)),
        reRetypedPassword: btoa(encodeURIComponent(this.changePasswordModel.changePasswordForm.get('ConfirmPassword').value)),
        userId: userdetail.userName,
      }

      // let url = this.baseUrl.ecustomer.changePasswordConfig + '/' + params.userId + '/' + params.oldPassword + '/' + params.newPassword + '/' + params.confirmPassword + '/';
      let url = this.baseUrl.ecustomer.changePasswordConfig
      this.cService.postData(url, params, '')
        .subscribe(data => {

          if (data['errorCode'] != null && (data['errorCode'] == 'LM500408' || data['errorCode'] == 'E00')) {
            this.changePasswordModel.successChangePassword = true;
            let userTokenParam = JSON.parse(sessionStorage.getItem('userToken'));
            userTokenParam.token = data.token;
            sessionStorage.setItem('userToken', JSON.stringify(userTokenParam));
          } else if (data['errorCode'] == 'LM500210' || data['errorCode'] == 'LM500405' || data['errorCode'] == 'E05') {
            this.navigateToLogoutPage();
          } else {
            this.changePasswordModel.successChangePassword = false
            this.changePasswordModel.errorCodeMessage = data['errorCode']
            if (this.changePasswordModel.errorCodeMessage == 'LM500407' || this.changePasswordModel.errorCodeMessage == 'E07' || this.changePasswordModel.errorCodeMessage == 'LM500401' ||
              this.changePasswordModel.errorCodeMessage == 'LM500413' || this.changePasswordModel.errorCodeMessage == 'LM500414' || this.changePasswordModel.errorCodeMessage == 'LM500415' || this.changePasswordModel.errorCodeMessage == 'LM500416' || this.changePasswordModel.errorCodeMessage == 'LM500417' ||
              this.changePasswordModel.errorCodeMessage == 'E08' || this.changePasswordModel.errorCodeMessage == 'LM500409' || this.changePasswordModel.errorCodeMessage == 'LM500410' ||
              this.changePasswordModel.errorCodeMessage == 'LM500411' || this.changePasswordModel.errorCodeMessage == 'LM500412' || this.changePasswordModel.errorCodeMessage == 'LM500499') {
                this.changePasswordModel.passwordFieldErr = true;
            } else {
                this.changePasswordModel.passwordFieldErr = false;
            }
            if (this.changePasswordModel.errorCodeMessage == 'LM500407' || this.changePasswordModel.errorCodeMessage == 'E07' || this.changePasswordModel.errorCodeMessage == 'LM500401' ||
              this.changePasswordModel.errorCodeMessage == 'LM500413' || this.changePasswordModel.errorCodeMessage == 'LM500414' || this.changePasswordModel.errorCodeMessage == 'LM500415' || this.changePasswordModel.errorCodeMessage == 'LM500416' ||
              this.changePasswordModel.errorCodeMessage == 'LM500417' || this.changePasswordModel.errorCodeMessage == 'E08' || this.changePasswordModel.errorCodeMessage == 'LM500409' ||
              this.changePasswordModel.errorCodeMessage == 'LM500410' || this.changePasswordModel.errorCodeMessage == 'LM500411' ||
              this.changePasswordModel.errorCodeMessage == 'LM500412' || this.changePasswordModel.errorCodeMessage == 'LM500499') {
              this.changePasswordModel.confirmPasswordFieldErr = true;
            } else {
              this.changePasswordModel.confirmPasswordFieldErr = false;
            }
            console.log(this.changePasswordModel)
            // if (data['errorCode'] == 'LM500209') {
            //   this.changePasswordModel.date = data['message'];
            // }
          }

          // }
        });


    }
  }


  getAnnouncemnetDetails() {
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let url = `${this.baseUrl.ecustomer.retrieveAnnounceMent}/${loggedUser['userName']}`;
    return this.cService['getData'](url);
  }

  onClickContact() {
    this.getAnnouncemnetDetails().subscribe((data) => {
      if (data && data.length > 0) {
        this.commonService.setDetail('announceMentDetail', data);
        this.router.navigate(['./announcement']);
      } else {
        this.getMenuDetails();
      }
    },
      (error: Error) => {
        this.getMenuDetails();
      });
  }

  getMenuDetails() {
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let clientID = loggedUser.clientId ? loggedUser.clientId : null;
    sessionStorage.setItem('loginOperationType', 'login');
    this.menuItemService.menuItemApi(clientID, 'login').subscribe((data) => {
      this.commonService.setDetail('menuItemList', data);
      sessionStorage.setItem('menuItemList', JSON.stringify(data));
      this.menuItemService.navigationBasedOnRole(data);
    },
      (error: Error) => {
        //this.router.navigate(['./homepage']);
      });
  }


  navigateToLogoutPage() {
    const userInfo = sessionStorage.getItem('loggedInUserInfo'),
      userdetail = JSON.parse(userInfo);

    let logoutRequest = {
      "userLogin": userdetail.userName,
      "systemType": "eCustomer",
      "processName": "LOGOUT",
      "logType ": "REASON_STANDARD_LOGOUT",
      "logMessage": "REASON_STANDARD_LOGOUT",
      "clientId ": ""
    }
    let logoutUrl = this.baseUrl.ecustomer.logoutUrl;
    this.cService.postData(logoutUrl, logoutRequest, '')
      .subscribe(data => {

        // sessionStorage.clear();
        // this.router.navigate(['/logout']);
        this.clearSessionStorage();
      },
        (error: Error) => {
          this.clearSessionStorage();
        });
  }

  clearSessionStorage() {
    const countryCode = sessionStorage.getItem('countryCode'),
      defaultLangugae = sessionStorage.getItem('defaultLanguage');
    sessionStorage.clear();
    //this.sharedService.setDetail('menuItemList', null);
    //this.sharedService.setcurrentUserLoggedIn([]);
    sessionStorage.setItem("defaultLanguage", defaultLangugae);
    sessionStorage.setItem("countryCode", countryCode);
    //this.idle.stop();
    this.router.navigate(['/logout']);
  }

  restrictPaste() {
    if (this.countryCode === 'ro') {
      this.dialog.openDialog(AlertDialogComponent, { 'heading': this.translate.instant("eCustomer.loginData.Alert"), 'body': this.translate.instant("eCustomer.loginData.copyPasteDisabled") });
      return false
    }
  }
  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

  // checkPwd()
  // {
  //   let pwd = this.changePasswordForm.value.Password;
  //   let ConfirmPassword = this.changePasswordForm.value.ConfirmPassword;
  //   let oldpwd = this.changePasswordForm.value.oldPassword;
  //   if(oldpwd != pwd)
  //   {
  //     if(this.changePasswordForm.controls['Password'].getError('pwd')) {
  //       this.changePasswordForm.controls['Password'].setErrors(null) 
  //     }    
  //   }
  //   if(oldpwd == pwd)
  //   {
  //     if(this.changePasswordForm.controls['Password'].errors == null)
  //     {
  //       this.changePasswordForm.controls['Password'].setErrors({'pwd':true})
  //     }      
  //   }
  //   else
  //   {
  //     if(ConfirmPassword != pwd)
  //     {
  //       if(this.f.ConfirmPassword.errors == null)
  //       {
  //         this.changePasswordForm.controls['ConfirmPassword'].setErrors({'cfpwd':true})
  //       }    
  //     }
  //     else
  //     {
  //       if(this.changePasswordForm.controls['ConfirmPassword'].getError('cfpwd'))
  //       {
  //         this.changePasswordForm.controls['ConfirmPassword'].setErrors(null)
  //       }      
  //     }
  //   }
  // }
}
