import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from '../app.module';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { HttpCommonService } from '../shared/services/http-common.service';

import { ChangePasswordComponent } from './change-password.component';

describe('ChangePasswordComponent', () => {
  let component: ChangePasswordComponent;
  let fixture: ComponentFixture<ChangePasswordComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  let menuItemService: MenuItemsService,
    httpCommonService: HttpCommonService;
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'changePasswordConfig': host + '/api/v1/users/change-password'
      }
    }
  };
  const userInfo = {
    authorizedApplicationCode: "eCustomer",
    clientId: "121212",
    creationDate: "Wed Jan 06 14:42:24 CET 2021",
    customerPasswordExprationCode: "1",
    daysSincePwdNotChanged: null,
    email: "osama.khalid@metlife.com",
    employeeNumber: null,
    failedLoginCounts: "0",
    firstName: "Osama",
    lastName: "Mo",
    passwordStatusCode: "ACTIVE",
    passwordType: "STANDARD",
    preferredLanguage: "en",
    pwdChangeDate: null,
    pwdExpirationDate: "Fri Mar 19 14:42:24 CET 2021",
    pwdExpired: "Active",
    requesterId: "-1",
    requesterRole: "3033",
    roleInfo: [{ roleId: "3033", name: "rSuperUser", description: "RSuperUser" }],
    route: "Home",
    securityPolicyId: "12345",
    temporaryLockDate: null,
    tokenExpirationDate: "Fri Sep 18 17:03:50 CEST 2020",
    userCheck: true,
    userDn: "ou=People,o=affiliates,c=Poland,o=metlife,dc=metlife,dc=com",
    userName: "OsamaAdmin"
  };
  const userToken = {
    token: "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJPc2FtYUFkbWluIiwidXNlciI6eyJ1c2VyTmFtZSI6Ik9zYW1hQWRtaW4iLCJmaXJzdE5hbWUiOiJPc2FtYSIsImxhc3ROYW1lIjoiTW8iLCJlbWFpbCI6Im9zYW1hLmtoYWxpZEBtZXRsaWZlLmNvbSIsInByZWZlcnJlZExhbmd1YWdlIjoiZW4iLCJjcmVhdGlvbkRhdGUiOiJXZWQgSmFuIDA2IDE0OjQyOjI0IENFVCAyMDIxIiwicGFzc3dvcmRUeXBlIjoiU1RBTkRBUkQiLCJjdXN0b21lclBhc3N3b3JkRXhwcmF0aW9uQ29kZSI6IjEiLCJwYXNzd29yZFN0YXR1c0NvZGUiOiJBQ1RJVkUiLCJzZWN1cml0eVBvbGljeUlkIjoiMTIzNDUiLCJ0b2tlbkV4cGlyYXRpb25EYXRlIjoiRnJpIFNlcCAxOCAxNzowMzo1MCBDRVNUIDIwMjAiLCJlbXBsb3llZU51bWJlciI6bnVsbCwicHdkRXhwaXJhdGlvbkRhdGUiOiJGcmkgTWFyIDE5IDE0OjQyOjI0IENFVCAyMDIxIiwiZmFpbGVkTG9naW5Db3VudHMiOiIwIiwiYXV0aG9yaXplZEFwcGxpY2F0aW9uQ29kZSI6ImVDdXN0b21lciIsInRlbXBvcmFyeUxvY2tEYXRlIjpudWxsLCJyb3V0ZSI6bnVsbCwicHdkRXhwaXJlZCI6bnVsbCwiZGF5c1NpbmNlUHdkTm90Q2hhbmdlZCI6bnVsbCwicHdkQ2hhbmdlRGF0ZSI6bnVsbCwicm9sZUluZm8iOlt7InJvbGVJZCI6IjMwMzMiLCJuYW1lIjoiclN1cGVyVXNlciIsImRlc2NyaXB0aW9uIjoiUlN1cGVyVXNlciJ9LHsicm9sZUlkIjoiMzAzNCIsIm5hbWUiOiJyQWRtaW5pc3RyYXRvciIsImRlc2NyaXB0aW9uIjoiU3lzdGVtQWRtaW5pc3RyYXRvciJ9XSwiY2xpZW50SWQiOm51bGwsInJlcXVlc3RlcklkIjpudWxsLCJyZXF1ZXN0ZXJSb2xlIjpudWxsLCJ1c2VyRG4iOiJvdT1QZW9wbGUsbz1hZmZpbGlhdGVzLGM9UG9sYW5kLG89bWV0bGlmZSxkYz1tZXRsaWZlLGRjPWNvbSIsInVzZXJDaGVjayI6dHJ1ZX0sImlhdCI6MTYxMjMzNzA1NCwiZXhwIjoxNjEyMzgwMjU0fQ.DF3cfAMA1Z0BLYN_k5yrqtWDcq1ed9z1Vu5EkIgj_x0",
    userName: "OsamaAdmin"
  };
  const menuList = {
    activeContractDetails: null,
    billingRecipent: null,
    callRetrievePolicies: false,
    callRetriveClientData: false,
    callRetriveClientOffers: false,
    ccDBAddressDTO: {
      ccdbFullAddress: "https://10.112.202.48/ccdb-web/",
      ccdbAddressPart2: ""
    },
    claimList: null,
    clientAdministration: true,
    clientId: "",
    clientIdList: [],
    clientIdbillControlList: [],
    clientLoginId: null,
    clientRoleIds: "3033|3034",
    clientRoleNames: "rSuperUser|rAdmnistrator",
    contractList: null,
    documentsList: null,
    eClaimsURL: "https://qa.eclaim.metlife.pl?countryCode=pl&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460e22ab4a70a2b886995e3826482fec79fa890f1f92293e6961ccd91c419c3efe9642d615c7d69b2a7",
    fundPriceDetails: null,
    menuItems: [{ menuId: "2", accessSpec: "RW", menuName: "Clients Administration", parentMenu: "Administration" }],
    offerResponse: null,
    orderHistory: null,
    personalInformationDTO: null,
    renderClaims: false,
    renderDocuments: false,
    renderFundPriceMonitoring: false,
    renderMyCompany: false,
    renderMyContract: false,
    renderMyData: false,
    renderOffers: false,
    renderOrderReview: false,
    renderUserAcctAdministration: true,
    route: "DisplayClientSearch",
    searchFlag: false,
    wardenRoleCheck: false
  };
  beforeEach(() => {
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userInfo));
    window.sessionStorage.setItem('userToken', JSON.stringify(userToken));
    window.sessionStorage.setItem('menuItemList', JSON.stringify(menuList));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HttpClientTestingModule],

      declarations: [],
      providers: [TranslateService]
    })
      .compileComponents();
    window['__env'].environmentConstURLs = environmentConstURL;

    fixture = TestBed.createComponent(ChangePasswordComponent);
    menuItemService = TestBed.get(MenuItemsService);
    httpCommonService = TestBed.get(HttpCommonService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {

  // });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call toggleFieldTextType', () => {
    component.toggleFieldTextType(true);
  });

  it('should call getAnnouncemnetDetails', () => {
    component.getAnnouncemnetDetails()
  });

  it('should call onClickContact', () => {
    const response = [{
      announceType: 'personal',
      titleCode: 'ATR',
      documents: 'asa',
      acceptanceCode: 'adasd',
      announceId: 'sdsd'
    }];
    spyOn(component, 'getAnnouncemnetDetails').and.returnValue(of(response));
    component.onClickContact();
  });

  it('should call onClickContact', () => {
    const response = [];
    spyOn(component, 'getAnnouncemnetDetails').and.returnValue(of(response));
    component.onClickContact();
  });

  it('should call getMenuDetails', () => {
    const menuList = {
      activeContractDetails: null,
      billingRecipent: null,
      callRetrievePolicies: false,
      callRetriveClientData: false,
      callRetriveClientOffers: false,
      ccDBAddressDTO: {
        ccdbFullAddress: "https://10.112.202.48/ccdb-web/",
        ccdbAddressPart2: ""
      },
      claimList: null,
      clientAdministration: true,
      clientId: "",
      clientIdList: [],
      clientIdbillControlList: [],
      clientLoginId: null,
      clientRoleIds: "3033|3034",
      clientRoleNames: "rSuperUser|rAdmnistrator",
      contractList: null,
      documentsList: null,
      eClaimsURL: "https://qa.eclaim.metlife.pl?countryCode=pl&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460e22ab4a70a2b886995e3826482fec79fa890f1f92293e6961ccd91c419c3efe9642d615c7d69b2a7",
      fundPriceDetails: null,
      menuItems: [{ menuId: "2", accessSpec: "RW", menuName: "Clients Administration", parentMenu: "Administration" }],
      offerResponse: null,
      orderHistory: null,
      personalInformationDTO: null,
      renderClaims: false,
      renderDocuments: false,
      renderFundPriceMonitoring: false,
      renderMyCompany: false,
      renderMyContract: false,
      renderMyData: false,
      renderOffers: false,
      renderOrderReview: false,
      renderUserAcctAdministration: true,
      route: "DisplayClientSearch",
      searchFlag: false,
      wardenRoleCheck: false
    };
    spyOn(menuItemService, 'menuItemApi').and.returnValue(of(menuList));

    component.getMenuDetails();
  });

  it('should call navigateToLogoutPage', () => {
    const test = true;
    spyOn(httpCommonService, 'postData').and.returnValue(of(test));
    component.navigateToLogoutPage();
  });

  it('should call clearSessionStorage', () => {
    component.clearSessionStorage();
  });

  it('should call gotoHome', () => {
    component.gotoHome();
  });

  it('should call restrictPaste', () => {
    const countryCode = "ro";
    window.sessionStorage.setItem('countryCode', (countryCode));
    component.restrictPaste();
  });
  it('should call onSubmit', () => {
    const response = {
      'errorCode': "LM500408"
    };
    spyOn(httpCommonService, 'postData').and.returnValue(of(response));

    component.onSubmit();
  });
});
