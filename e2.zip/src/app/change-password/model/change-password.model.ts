import { FormGroup } from '@angular/forms';


export class ChangePasswordModel {
    changePasswordForm: FormGroup;
    submitted = false;
    successChangePassword: boolean;
    currentPasswordFieldTextType: boolean;
    newPasswordFieldTextType: boolean;
    confirmPasswordFieldTextType: boolean;
    errorCodeMessage: string;
    date: string;
    passwordFieldErr: boolean;
    confirmPasswordFieldErr: boolean;
    constructor() {
        this.successChangePassword = false;
        this.submitted = false;
        this.confirmPasswordFieldTextType = false;
        this.newPasswordFieldTextType = false;
        this.currentPasswordFieldTextType = false;
        this.date = '';
        this.passwordFieldErr = false;
        this.confirmPasswordFieldErr = false;
    }

}