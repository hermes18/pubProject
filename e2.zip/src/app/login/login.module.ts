import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule } from '@angular/forms';

import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';
import { AuthenticationService } from './service/authentication.service';
import { SharedModule } from '../shared/shared.module';
// import { MatCheckboxModule } from '@angular/material';

@NgModule({
  declarations: [LoginComponent],
  imports: [
    CommonModule,
    TranslateModule,
    LoginRoutingModule,
    SharedModule,
    // MatCheckboxModule,
    ReactiveFormsModule

  ],
  providers: [AuthenticationService]
})
export class LoginModule { }
