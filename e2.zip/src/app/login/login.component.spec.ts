import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from '../app.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { LoginComponent } from './login.component';
import { LoginModule } from './login.module';
import { TranslateService } from '@ngx-translate/core';

import { AuthenticationService } from './service/authentication.service';
import { AppConfig } from 'src/config/app.config';
import { of, throwError } from 'rxjs';
import { MenuItemsService } from '../shared-service/menu-items.service';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let authService: AuthenticationService;
  let menuService: MenuItemsService;
  let fixture: ComponentFixture<LoginComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'usersMainUrl': host + '/api/v1/users'
      }
    }
  };
  const userImfo =
    { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" }
  window['__env'].environmentConstURLs = environmentConstURL;
  console.log(window)
  let appConfig: AppConfig = AppConfig.getConfig();
  // baseUrl = appConfig['api'];
  let globalObjectService: jasmine.SpyObj<AppConfig>;

  // window['__env'].environmentConstURLs = {
  //   api: {
  //     'ecustomer': {
  //       'usersMainUrl': host + '/api/v1/users'
  //     }
  //   }
  // };

  beforeEach(() => {
    globalObjectService = jasmine.createSpyObj('AppConfig', ['getConfig']);
    sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    window.sessionStorage.setItem("defaultLanguage", "pl_pl");

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, LoginModule, HttpClientTestingModule],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, AuthenticationService, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(LoginComponent);
    authService = TestBed.get(AuthenticationService);
    menuService = TestBed.get(MenuItemsService);


    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(LoginComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('login component should create', () => {
    component.countryCode = "ro";

    // globalObjectService.getConfig.and.returnValue(
    //    {
    //     api: {
    //       'ecustomer': {
    //         'usersMainUrl': host + '/api/v1/users',
    // });

    // console.log(baseUrl)
    expect(component).toBeTruthy();
  });

  it('should call submit method', () => {
    component.onSubmit();

  });

  it('should call submit method else part', () => {
    component.loginCompModel.loginFormGroup.invalid == false;
    const response = {
      token: "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ",
      userName: "jdaniel_ro"
    };
    spyOn(authService, 'loginTo').and.returnValue(of(response));
    window.sessionStorage.setItem('userToken', JSON.stringify(response));
    component.onSubmit();

  });


  it('should call contact method', () => {
    component.contact();
  });

  it('should call contact method for Pl_en language', () => {
    window.sessionStorage.setItem("defaultLanguage", "pl_en");
    component.contact();
  });

  it('should call contact method for ro_ro language', () => {
    window.sessionStorage.setItem("defaultLanguage", "ro_ro");
    component.contact();
  });
  it('should call contact method for ro_en language', () => {
    window.sessionStorage.setItem("defaultLanguage", "ro_en");
    component.contact();
  });


  xit('should call navigateTobasedonRole method', () => {
    let userinfo = {
      authorizedApplicationCode: "eCustomer",
      clientId: "",
      creationDate: "Thu Apr 08 10:11:07 CEST 2021",
      customerPasswordExprationCode: "1",
      daysSincePwdNotChanged: null,
      email: "osama.khalid@metlife.com",
      employeeNumber: "",
      failedLoginCounts: "0",
      firstName: "Osama",
      lastName: "M",
      passwordStatusCode: "ACTIVE",
      passwordType: "STANDARD",
      preferredLanguage: "pl",
      pwdChangeDate: null,
      pwdExpirationDate: "Wed Jul 07 10:11:07 CEST 2021",
      pwdExpirationDelay: "30",
      pwdExpired: "Active",
      requesterId: "-1",
      requesterRole: "3033",
      roleInfo: [{ roleId: "3033", name: "rSuperUser", description: "RSuperUser" }],
      route: "Home",
      securityPolicyId: "12345",
      temporaryLockDate: null,
      tokenExpirationDate: "Mon Nov 02 11:38:56 CET 2020",
      tokenParam: null,
      userCheck: true,
      userDn: "ou=People,o=affiliates,c=Poland,o=metlife,dc=metlife,dc=com",
      userName: "osamaAdmin2",
    };
    component.navigateToBasedOnRole(userinfo);
  });

  it('should call navigateTobasedonRole method changepassword route', () => {
    let userinfo = {
      authorizedApplicationCode: "eCustomer",
      clientId: "",
      creationDate: "Thu Apr 08 10:11:07 CEST 2021",
      customerPasswordExprationCode: "1",
      daysSincePwdNotChanged: null,
      email: "osama.khalid@metlife.com",
      employeeNumber: "",
      failedLoginCounts: "0",
      firstName: "Osama",
      lastName: "M",
      passwordStatusCode: "ACTIVE",
      passwordType: "STANDARD",
      preferredLanguage: "pl",
      pwdChangeDate: null,
      pwdExpirationDate: "Wed Jul 07 10:11:07 CEST 2021",
      pwdExpirationDelay: "30",
      pwdExpired: "Active",
      requesterId: "-1",
      requesterRole: "3033",
      roleInfo: [{ roleId: "3033", name: "rSuperUser", description: "RSuperUser" }],
      route: "changepassword",
      securityPolicyId: "12345",
      temporaryLockDate: null,
      tokenExpirationDate: "Mon Nov 02 11:38:56 CET 2020",
      tokenParam: null,
      userCheck: true,
      userDn: "ou=People,o=affiliates,c=Poland,o=metlife,dc=metlife,dc=com",
      userName: "osamaAdmin2",
    };
    component.navigateToBasedOnRole(userinfo);
  });

  it('should call navigateTobasedonRole method default case', () => {
    let userinfo = {
      authorizedApplicationCode: "eCustomer",
      clientId: "",
      creationDate: "Thu Apr 08 10:11:07 CEST 2021",
      customerPasswordExprationCode: "1",
      daysSincePwdNotChanged: null,
      email: "osama.khalid@metlife.com",
      employeeNumber: "",
      failedLoginCounts: "0",
      firstName: "Osama",
      lastName: "M",
      passwordStatusCode: "ACTIVE",
      passwordType: "STANDARD",
      preferredLanguage: "pl",
      pwdChangeDate: null,
      pwdExpirationDate: "Wed Jul 07 10:11:07 CEST 2021",
      pwdExpirationDelay: "30",
      pwdExpired: "Active",
      requesterId: "-1",
      requesterRole: "3033",
      roleInfo: [{ roleId: "3033", name: "rSuperUser", description: "RSuperUser" }],
      route: "test",
      securityPolicyId: "12345",
      temporaryLockDate: null,
      tokenExpirationDate: "Mon Nov 02 11:38:56 CET 2020",
      tokenParam: null,
      userCheck: true,
      userDn: "ou=People,o=affiliates,c=Poland,o=metlife,dc=metlife,dc=com",
      userName: "osamaAdmin2",
    };
    component.navigateToBasedOnRole(userinfo);
  });


  it('should call toggleFieldTextType method', () => {
    component.toggleFieldTextType();
  });

  it('should call getAnnouncementScreen method', () => {
    const response = [{
      announceType: 'yuwe',
      titleCode: 'ATR',
      documents: 'asa',
      acceptanceCode: 'adasd'
    }]
    spyOn(authService, 'getAnnouncemnetDetails').and.returnValue(of(response));
    component.getAnnouncementScreen();
  });

  it('should call getAnnouncementScreen method else method', () => {
    const response = [];
    spyOn(authService, 'getAnnouncemnetDetails').and.returnValue(of(response));
    component.getAnnouncementScreen();
  });

  it('should call getAnnouncementScreen method error part', () => {
    const error = {
      error: {
        errors: [{
          'errorMessage': 'sdfsd'
        }]
      }
    };
    spyOn(authService, 'getAnnouncemnetDetails').and.returnValue(throwError(error));
    component.getAnnouncementScreen();
  });


  it('should call restrictPaste method', () => {
    component.restrictPaste();
  });

  it('should call getMenuDetails method', () => {
    const menuClinetList = {
      "activeContractDetails": null,
      "billingRecipent": null,
      "callRetrievePolicies": false,
      "callRetriveClientData": false,
      "callRetriveClientOffers": false,
      "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
      "claimList": null,
      "clientAdministration": true,
      "clientId": "",
      "clientIdList": [],
      "clientIdbillControlList": [],
      "clientLoginId": null,
      "clientRoleIds": "3032|3033|3034",
      "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
      "contractList": null,
      "documentsList": null,
      "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
      "fundPriceDetails": null,
      "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
      "offerResponse": null,
      "orderHistory": null,
      "personalInformationDTO": null,
      "renderClaims": false,
      "renderDocuments": false,
      "renderFundPriceMonitoring": false,
      "renderMyCompany": false,
      "renderMyContract": false,
      "renderMyData": false,
      "renderOffers": false,
      "renderOrderReview": false,
      "renderUserAcctAdministration": true,
      "route": "DisplayClientSearch",
      "searchFlag": false,
      "wardenRoleCheck": false
    }
    spyOn(menuService, 'menuItemApi').and.returnValue(throwError(menuClinetList));
    sessionStorage.setItem('menuItemList', JSON.stringify(menuClinetList));

    component.getMenuDetails();
  });

  it('should call getUserInfo method', () => {
    spyOn(authService, 'fetchUserInfo').and.returnValue(of(userImfo));
    component.getUserInfo();
  });

  it('should call getUserInfo method error part 500 error code ', () => {
    const error = {
      error: {
        date: 1618914539459,
        errorCode: 500,
        errorDetails: "Init password expired",
        message: "Init password expired",
      }
    };
    spyOn(authService, 'fetchUserInfo').and.returnValue(throwError(error));
    component.getUserInfo();
    expect(component.loginCompModel.isBadCredentialError).toEqual(true);
    expect(component.loginCompModel.submitted).toEqual(false);
    expect(component.loginCompModel.isLDAPIssue).toEqual(false);

  });
  xit('should call getUserInfo method error part 415 error code', () => {
    const error = {
      error: {
        date: 1618914539459,
        errorCode: 415,
        errorDetails: "Exception in LDAP system auth check",
        message: "Exception in LDAP system auth check",
      }
    };
    spyOn(authService, 'fetchUserInfo').and.returnValue(throwError(error));
    expect(component.loginCompModel.isBadCredentialError).toEqual(false);
    expect(component.loginCompModel.submitted).toEqual(true);
    expect(component.loginCompModel.isLDAPIssue).toEqual(false);
    component.getUserInfo();

  });

  it('should call navigateToContact method', () => {
    component.navigateToContact();
  });


  xit('should call routeTo method', () => {
    const response = {
      renderContactAndConsentsScreen: true
    };
    spyOn(authService, 'getContactConsentDetails').and.returnValue(of(response));
    component.routeTo(userImfo);
  });
});
