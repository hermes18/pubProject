import { FormGroup } from '@angular/forms';


export class LoginModel {
    loginFormGroup: FormGroup;
    subscribeFlag: boolean;
    submitted: boolean;
    currentPasswordFieldTextType;
    isBadCredentialError: boolean;
    isLDAPIssue: boolean;
    constructor() {
        this.subscribeFlag = true;
        this.currentPasswordFieldTextType = false;
        this.submitted = false;
        this.isBadCredentialError = false;
        this.isLDAPIssue = false;
    }

}