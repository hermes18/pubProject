import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';

import { HttpCommonService } from '../../shared/services/http-common.service';
import { environment } from 'src/environments/environment';
import { AppConfig } from 'src/config/app.config';

@Injectable()
export class AuthenticationService {

  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(private cService: HttpCommonService) { }

  loginTo(reqParams) {
    // let contactReasonsURL = environment.host + environment.loginconfig.url;
    let headerOptions = {
      headers: new HttpHeaders({
        'accept-language': sessionStorage.getItem('defaultLanguage'),
        'x-tenant-id': sessionStorage.getItem('countryCode'),
        'x-system-id': 'ecustomer'
      })
    };
    return this.cService['postDataWithHeader'](
      this.baseUrl.ecustomer.loginUrl, reqParams, headerOptions);
  }

  fetchUserInfo() {
    const token = JSON.parse(sessionStorage.getItem('userToken'));
    let headerOptions = {
      headers: new HttpHeaders({
        'accept-language': sessionStorage.getItem('defaultLanguage'),
        'x-tenant-id': sessionStorage.getItem('countryCode'),
        'x-system-id': 'ecustomer',
        'Authorization': `Bearer ${token['token']}`
      })
    }
    return this.cService.getHttp(
      this.baseUrl.ecustomer.userInfoUrl, headerOptions);
  }

  getAnnouncemnetDetails() {
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let url = `${this.baseUrl.ecustomer.retrieveAnnounceMent}/${loggedUser['userName']}`;
    return this.cService['getData'](url);
  }

  getContactConsentDetails() {

    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
      param = {
        userId: loggedUser['userName']
      };
    const baseUrl = this.baseUrl.ecustomer.getContactLegalConsentsConfig;

    // const baseUrl = this.baseUrl.ecustomer.getContactLegalConsentsConfig + loggedUser['userName'] + "/";
    return this.cService['postData'](baseUrl, param, '');
  }

}
