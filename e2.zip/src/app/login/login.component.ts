import { Component, HostListener, OnInit } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { takeWhile } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';


import { LoginModel } from './model/login.model';
import { AuthenticationService } from './service/authentication.service';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { HttpCommonService } from '../shared/services/http-common.service';
import { MenuItemsService } from '../shared-service/menu-items.service'
import { AlertDialogComponent } from '../shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from '../shared/services/dialog.service';

import { UtilityService } from './../shared/utilities/utility.service';
@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginCompModel: LoginModel;
  returnUrl: string;
  countryCode: string = sessionStorage.getItem('countryCode');
  constructor(private readonly formBuilder: FormBuilder, private readonly router: Router,
    private readonly authenticationService: AuthenticationService, private route: ActivatedRoute,
    public commonService: SharedServiceService, public httpService: HttpCommonService, private readonly menuItemService: MenuItemsService, public dialog: DialogService, private translate: TranslateService) {
    this.loginCompModel = new LoginModel();
  }

  @HostListener('paste', ['$event']) blockPaste(e: KeyboardEvent) {
    if (e.target['type'] === 'password' && this.countryCode === 'ro') {
      e.preventDefault();
      this.dialog.openDialog(AlertDialogComponent, { 'heading': this.translate.instant("eCustomer.loginData.Alert"), 'body': this.translate.instant("eCustomer.loginData.copyPasteDisabled") });
      // console.log('pastingu')
    }
  }
  ngOnInit() {
    console.log('test', UtilityService.getCountry())
    this.loginCompModel.loginFormGroup = this.formBuilder.group({
      userNameControl: ['', Validators.required],
      passwordControl: ['', Validators.required]
    });

    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.loginCompModel.subscribeFlag = false;
  }


  restrictPaste() {
    if (this.countryCode === 'ro') {
      this.dialog.openDialog(AlertDialogComponent, { 'heading': this.translate.instant("eCustomer.loginData.Alert"), 'body': this.translate.instant("eCustomer.loginData.copyPasteDisabled") });
      return false;
    }
  }



  onSubmit() {
    // For in mid url navigation issue clear storage 
    const countryCode = sessionStorage.getItem('countryCode'),
      defaultLangugae = sessionStorage.getItem('defaultLanguage');
    sessionStorage.clear();
    sessionStorage.setItem("defaultLanguage", defaultLangugae);
    sessionStorage.setItem("countryCode", countryCode);


    let reqParams = {
      "userName": this.loginCompModel.loginFormGroup['controls'].userNameControl.value,
      "password": btoa(this.loginCompModel.loginFormGroup['controls'].passwordControl.value),
      "type": "login"
    },
      // let tokenCallParam = {
      //   "tokenparam": btoa(this.loginCompModel.loginFormGroup['controls'].passwordControl.value)
      // },
      userName = {
        "userName": this.loginCompModel.loginFormGroup['controls'].userNameControl.value,

      }
    //localStorage.setItem('pass', 'test')
    //  sessionStorage.setItem('tokenCallParameters', JSON.stringify(tokenCallParam));
    sessionStorage.setItem('loginFormDetails', JSON.stringify(userName));
    if (this.loginCompModel.loginFormGroup.invalid) {
      this.loginCompModel.isBadCredentialError = false;
      this.loginCompModel.isLDAPIssue = false;
      this.loginCompModel.submitted = true;

      return;
    } else {
      this.authenticationService.loginTo(reqParams).pipe(takeWhile(() => this.loginCompModel.subscribeFlag))
        .subscribe((data) => {
          sessionStorage.setItem('userToken', JSON.stringify(data));
          sessionStorage.setItem('userTokenForTimer', JSON.stringify(data));
          this.loginCompModel.submitted = false;
          this.commonService.setCurrentUserToken(data);
          this.getUserInfo();
        },

          (error: Error) => {
            const errorMessage = error['error'];
            if (errorMessage && (errorMessage.errorCode == 500 || error['error'].errorCode === 415)) {
              this.loginCompModel.isBadCredentialError = true;
              this.loginCompModel.isLDAPIssue = false;
              this.loginCompModel.submitted = false;
            } else if (errorMessage && (error['error'].errorCode === 414 || error['error'].errorDetails == "Exception in LDAP connectivity check")) {
              this.loginCompModel.isBadCredentialError = false;
              this.loginCompModel.isLDAPIssue = true;
              this.loginCompModel.submitted = false;
            }

          });
    }
  }
  contact() {
    let redirectTo = "";
    let language = sessionStorage.getItem("defaultLanguage");
    switch (language) {
      case 'pl_pl': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
        break;
      case 'pl_en': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
        break;
      case 'ro_ro': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
        break;
      case 'ro_en': redirectTo = "https://www.metlife.pl/obsluga_klienta/formularz_ind_i_prac/";
        break;
    }
    window.open(redirectTo, "_blank");
  }

  getUserInfo() {
    this.authenticationService.fetchUserInfo().pipe(takeWhile(() => this.loginCompModel.subscribeFlag))
      .subscribe((userInfo) => {
        sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userInfo));
        sessionStorage.setItem('logedUSerForTimer', JSON.stringify(userInfo));
        this.commonService.setcurrentUserLoggedIn(userInfo);
        this.routeTo(userInfo);
      },
        (error: Error) => {
          if (error['error'].errorCode == 500 && error['error'].errorDetails == 'Init password expired') {
            this.loginCompModel.isBadCredentialError = true;
            this.loginCompModel.submitted = false;
            this.loginCompModel.isLDAPIssue = false;
          } else if (error['error'].errorCode === 415 || error['error'].errorDetails == "Exception in LDAP system auth check") {
            this.loginCompModel.isBadCredentialError = false;
            this.loginCompModel.isLDAPIssue = true;
            this.loginCompModel.submitted = false;
          }
        });
  }

  navigateToContact() {
    this.router.navigate(['/contact-form']);
  }

  routeTo(userInfo) {
    //this.router.navigate(['./announcement']);
    //  this.getMenuDetails();

    //("dfgfdg",userInfo);


    for (let i = 0; i < userInfo.roleInfo.length; i++) {
      if (userInfo.roleInfo[i].roleId == '3031' || userInfo.roleInfo[i].roleId == '3037') {
        this.authenticationService.getContactConsentDetails().subscribe((response) => {
          if (response.renderContactAndConsentsScreen) {
            sessionStorage.setItem('screenName', userInfo.route);
            this.commonService.setscreenName(userInfo.route);
            sessionStorage.setItem('setcontactConsentDetails', JSON.stringify(response));
            this.commonService.setcontactConsentDetails(response);
            this.router.navigate(['./contactdetail']);
          } else {
            this.navigateToBasedOnRole(userInfo);
          }
          this.commonService.setClientId(response.clientId);
        },
          (error: Error) => {
            this.navigateToBasedOnRole(userInfo);
          });
        return;
      }
    }

    this.navigateToBasedOnRole(userInfo);


  }

  navigateToBasedOnRole(userInfo) {
    switch (userInfo.route) {
      case "Home": {
        this.getAnnouncementScreen();
      }
        break;
      case 'changepassword': {
        this.router.navigate(['./changepassword']);
      }
        break;
      default:
        this.router.navigate(['./homepage']);

    }
  }
  getAnnouncementScreen() {
    this.authenticationService.getAnnouncemnetDetails().subscribe((data) => {
      if (data && data.length > 0) {
        this.commonService.setDetail('announceMentDetail', data);
        this.router.navigate(['./announcement']);
      } else {
         this.getMenuDetails();
        // this.router.navigate(['./fakelanding'])

        // setTimeout(() => {
        //   if (this.menuItemList) {
        //     this.menuItemService.navigationBasedOnRole(this.menuItemList);
        //   } else {
        //     let intervalTime = 0;
        //     let menus = setInterval(() => {
        //       intervalTime += 1;
        //       if (this.menuItemList) {
        //         clearInterval(menus);
        //         this.menuItemService.navigationBasedOnRole(this.menuItemList);
        //       }
        //       if (intervalTime > 600) {
        //         clearInterval(menus);
        //         //("Time out service Error");
        //       }
        //     }, 100);
        //   }
        // });


      }
    },
      (error: Error) => {
        // this.router.navigate(['./fakelanding'])

        this.getMenuDetails();
      });
  }

  menuItemList: any = null;
  getMenuDetails() {
    const loggedUser = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let clientID = loggedUser.clientId ? loggedUser.clientId : null;
    sessionStorage.setItem('loginOperationType', 'login');
    this.menuItemService.menuItemApi(clientID, 'login').subscribe((data) => {
      sessionStorage.setItem('menuItemList', JSON.stringify(data));
      this.commonService.setDetail('menuItemList', data);
      this.menuItemService.navigationBasedOnRole(data);
      this.menuItemList = data;
    },
      (error: Error) => {
        this.loginCompModel.isBadCredentialError = false;
        this.loginCompModel.isLDAPIssue = false;
        //this.router.navigate(['/errorPage']);
        // this.router.navigate(['./homepage']);
      });
  }

  toggleFieldTextType() {
    this.loginCompModel.currentPasswordFieldTextType = !this.loginCompModel.currentPasswordFieldTextType;
  }
}
