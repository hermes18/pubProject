import { TestBed } from '@angular/core/testing';

import { FundHistoryService } from './fund-history.service';

describe('FundHistoryService', () => {
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'fundHistory': host + '/api/v1/users/fund-history',
      }
    }
  };

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({})
  });

  it('should be created', () => {
    const service: FundHistoryService = TestBed.get(FundHistoryService);
    expect(service).toBeTruthy();
  });
});
