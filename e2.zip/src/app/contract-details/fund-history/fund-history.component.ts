import { HttpHeaders } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl } from '@angular/forms';
import { DateAdapter, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { StringifyOptions } from 'querystring';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import * as moment from 'moment';
import { environment } from 'src/environments/environment';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { FundHistoryService } from './fund-history.service';
import { AppConfig } from 'src/config/app.config';
import { DatePipe, formatDate } from '@angular/common';
import { Router } from '@angular/router';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { TranslateService } from '@ngx-translate/core';
import { ViewChild } from '@angular/core';
import { DeviceDetectorService } from 'ngx-device-detector';
import { Observable } from 'rxjs'
import { UtilityService } from 'src/app/shared/utilities/utility.service';

export class HistoryData {
  operationDate: string;
  fundNames: String;
  operationType: string;
  noOfUnitsBeforeOperation: number;
  noOfUnitsAfterOperation: number;
  unitPrice: string;
  transactionValue: string;
}
// export class Post {
//   fromDate: Date;
//   toDate: Date;
// }
export class Account {
  fundName: string;
  units: string;
  unitPrice: string;
  fundValue: string;
}
@Component({
  selector: 'fund-history',
  templateUrl: './fund-history.component.html',
  styleUrls: ['./fund-history.component.scss'],
  providers: [DatePipe]
})

export class FundHistoryComponent implements OnInit {
  minDate: Date;
  maxDate: Date;

  // fundUrl = environment.fund.url;
  selectedOption = '1';
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  fundUrl = this.baseUrl.ecustomer.fundHistory;
  search: boolean = false;
  count
  accountDetails: any;
  showPremiumSplit: boolean = false;
  historyRequestDTO: any;
  displayedColumnsOne: string[] = ['fundName', 'quotes', 'units', 'unitPrice', 'fundValue'];
  displayedColumnsTwo: string[] = ['transactionDate', 'fundName', ' ', 'operationType', 'unitsBeforeTransaction', 'unitsAfterTransaction', 'unitPrice', 'transactionValue'];
  dataSourceOne: MatTableDataSource<Account>;
  dataSourceTwo: MatTableDataSource<HistoryData>;
  private paginator: MatPaginator;
  private sort: MatSort;
  private sort1: MatSort;
  accountValue: any;
  premiumSplit: any;
  operationValue: any;
  recordFound: boolean = false;
  operationTypeDropDown: void;
  dropdown;
  searchclick: boolean;
  searchInput: any;
  @Output('setCalenderLanguage') calenderLangugae = new EventEmitter<any>();
  setLocaleDatePicker: any;
  invalidDateError: boolean = false;

  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.dataSourceTwo)
      this.dataSourceTwo.paginator = this.paginator;
  }
  @ViewChild(MatSort, { static: true }) tableOneSort: MatSort;
  // @ViewChild(MatSort, { static: false }) sortCol1: MatSort;
  @ViewChild(MatSort, { static: true }) tableTwoSort: MatSort;

  @ViewChild(MatSort, { static: true }) tableTwoPaginator: MatPaginator;
  //   @ViewChild(MatSort, {static: false}) set content(sort: MatSort) {
  //     this.dataSourceOne.sort = sort;
  // }
  @ViewChild(MatSort, { static: false }) set matSort(mp: MatSort) {
    this.sort = mp;
    if (this.dataSourceOne)
      this.dataSourceOne.sort = this.sort;
  }
  // post: Post = {
  //   fromDate: new Date(new Date().setMonth(new Date().getMonth() - 1)),
  //   toDate: new Date(Date.now())
  // }
  Total = 0;
  clientId;
  fundHistoryRequestDTO;
  investaccnumber: any;
  headers = new HttpHeaders();
  history: any;
  investValuationDate;
  DateError: boolean = false;
  searchValid: boolean = false;
  maxRecord: boolean = false;
  showOperationValue: boolean = false;
  showDetails: boolean
  valueonDateToolTip: boolean
  constructor(public commonService: HttpCommonService, public deviceDetector: DeviceDetectorService, private router: Router, public dialog: DialogService, public translate: TranslateService,
    private dateAdapter: DateAdapter<Date>, public datepipe: DatePipe, public fundHistoryService: FundHistoryService, public sharedService: SharedServiceService, public menuItemService: MenuItemsService, public fb: FormBuilder) {
    this.minDate = new Date(1900, 0, 1);
    this.maxDate = new Date(2050, 0, 1);
    this.dataSourceOne = new MatTableDataSource<Account>();

    this.dataSourceTwo = new MatTableDataSource;
  }
  investAccountNumber = this.sharedService.getterInvestAccNumber();
  investAccountName = this.sharedService.getterInvestAccName();
  investToolTip = this.sharedService.getterInvestAccToolTip();

  fromDateFormat;
  toDateFormat;

  getRequestParam() {
    //("called")
    this.fromDateFormat = moment(this.searchInput.value.fromDate);
    this.toDateFormat = moment(this.searchInput.value.toDate)
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID')),
      loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
      userrole = this.menuItemService.getAllRoles();
    let role = loggedInUserDetail.roleInfo[0] ? loggedInUserDetail.roleInfo[0].name : 'NoRole';
    this.investaccnumber = this.sharedService.getterInvestAccNumber();
    this.clientId = this.fundHistoryService.getClientID(loggedInUserDetail, customerId, userrole);
    this.fundHistoryRequestDTO = {
      operationType: this.searchInput.value.operationType,
      // operationType: ((this.searchInput.value.operationType && this.searchInput.value.operationType!= 1) ? (this.searchInput.value.operationType).trim() : ''),
      // fromDate: (this.searchInput.value.fromDate ? (this.datepipe.transform(this.searchInput.value.fromDate, 'yyyy-MM-dd')) : ''),
      // toDate: (this.searchInput.value.toDate ? (this.datepipe.transform(this.searchInput.value.toDate, 'yyyy-MM-dd')) : ''),
      // fromDate:(this.searchInput.value.fromDate ? this.fromDateFormat.format('DD/MM/YYYY'):null),
      // fromDate: (this.searchInput.value.fromDate ? this.Dob.format("DD/MM/YYYY") : null)
      // toDate: (this.searchInput.value.toDate ? this.toDateFormat.format('DD/MM/YYYY'):null),
      // fromDate:this.searchInput.value.fromDate,
      // toDate: this.searchInput.value.toDate ,
      fromDateUI: (this.searchInput.value.fromDate ? this.fromDateFormat.format('DD/MM/YYYY') : null),
      toDateUI: (this.searchInput.value.toDate ? this.toDateFormat.format('DD/MM/YYYY') : null),

      investAccountNumber: this.investaccnumber,
      clientId: this.clientId,

    }
  }
  onChange(event) {
    // console.log(event)
  }
  country;
  lcode;
  invsetAccountNumberToolTip: boolean = false;
  ngAfterViewInit() {

    this.sharedService.getLangChange().subscribe((data) => {

      const lang = sessionStorage.getItem("defaultLanguage");
      this.lcode = sessionStorage.getItem("defaultLanguage");
      // console.log(this.lcode)
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_gr': 'el',
        'gr_en': 'en',
        'gr': 'el'
      }
      //("after lang change", data);
      const language = data ? data === 'gr' ? dateTranslate[lang] : data : dateTranslate[lang];
      this.dateAdapter.setLocale(language);
    })
    this.calenderLangugae.emit(this.setLocaleDatePicker);

    // this.historyList.sort = this.sort1;
    if (this.dataSourceOne)
      // this.dataSourceOne.sort = this.sort;
      this.dataSourceOne.sort = this.tableOneSort;
    // console.log(this.dataSourceOne.sort)

    if (this.dataSourceTwo)
      this.dataSourceTwo.sort = this.tableTwoSort;
    // console.log(this.dataSourceTwo.sort)
    this.dataSourceTwo.paginator = this.tableTwoPaginator;
    //   this.historyList.paginator = this.paginator
  }
  showAccountDetailTable: boolean = false;
  // investToolTip;

  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    // this.invsetAccountNumberToolTip = true;
    //(this.sharedService.getterInvestAccName())
    this.searchInput = this.fb.group({
      operationType: 1,
      fromDate: '',
      toDate: new Date(),

    });
    this.setDateValue();
    //("report", this.searchInput)
    this.getRequestParam();

    //(this.fundHistoryRequestDTO)
    this.DateError = false;
    this.search = false
    this.searchValid = false;
    this.maxRecord = false;
    this.invalidDateError = false;
    // this.AccountData.sort = this.sort;
    // this.historyList.sort = this.sort1;
    // this.investToolTip = this.sharedService.getterInvestAccToolTip();
    // console.log(this.investToolTip)
    this.investValuationDate = this.sharedService.getInvestValuationDate();
    if (this.dataSourceOne)
      // this.dataSourceOne.sort = this.tableOneSort;
      this.dataSourceOne.sort = this.sort;
    this.commonService['postData'](this.fundUrl, this.fundHistoryRequestDTO, this.headers).subscribe(data => {

      if (data)
        //(data)
        this.accountDetails = data;
      this.accountValue = this.accountDetails.fundAccountValue;
      this.premiumSplit = this.accountDetails.fundPremiumSplit;
      // this.operationValue = this.accountDetails.operationDataVO[0] ? this.accountDetails.operationDataVO[0] : '-';
      this.operationValue = this.accountDetails.operationDataVO ? this.accountDetails.operationDataVO[0] : '-';
      if (this.accountValue && this.accountValue.length != 0) {
        this.showAccountDetailTable = true;
      } else {
        this.showAccountDetailTable = false;
      }
      if (this.accountDetails.operationDataVO) {
        if (this.accountDetails.operationDataVO.length != 0) {
          this.showOperationValue = true
        }
      } else {
        this.showOperationValue = false
      }
      if (this.accountDetails.fundPremiumSplit) {
        if (this.accountDetails.fundPremiumSplit.length != 0) {
          this.showPremiumSplit = true;
        }
      } else {
        this.showPremiumSplit = false;
      }
      //("op", this.operationValue)

      this.dataSourceOne = new MatTableDataSource<Account>();
      this.dataSourceOne.sort = null;
      this.dataSourceOne.data = this.accountValue;
      // this.dataSourceOne.sort = this.sort;
      // this.tableOneSort.disableClear = true;
      this.dataSourceOne.sort = this.tableOneSort;
      this.dataSourceOne.sortingDataAccessor = (item, property) => {

        switch (property) {
          case 'unitPrice': {

            const a = item.unitPrice;
            let val = a.toLocaleString();
            let num = parseFloat(a.trim().replace(',', ''))
            var numeric = Number(num);
            // console.log(numeric);
            return numeric;

          }

          case 'units': {

            const a = item.units;
            let val = a.toLocaleString();
            let num = parseFloat(a.trim().replace(',', ''))
            var numeric = Number(num);
            // console.log("a",numeric);
            return numeric;

          }
          case 'fundValue': {

            const a = item.fundValue;
            let val = a.toLocaleString();
            let num = parseFloat(a.trim().replace(',', ''))
            var numeric = Number(num);
            // console.log(numeric);
            return numeric;

          }
          default: {

            return item[property];
          }
        }
      };
      this.tableOneSort.disableClear = true;
      this.operationTypeDropDown = this.accountDetails.accntTypesList;
      this.dropdown = this.operationTypeDropDown
      this.dropdown.forEach((value, index) => {
        if (value == '0') this.dropdown.splice(index, 1);
      });
      this.Total = this.accountDetails.totalAmount;
      // console.log("11111111111111111111",this.Total)
      // if (this.accountValue) {
      //   this.Total = this.accountValue.reduce(function (prev, cur) {
      //     return prev + cur.fundValue;
      //   }, 0);
      //   //('Total :', this.Total);
      // }
    })

    // this.fundHistorySearch();
    // }

    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.lang = data;
      }
      // console.log("lang",this.lang)
    });
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      //if (this.countryCode == 'pl') {
      this.amountSuffix = 'PLN';
    } else if (this.countryCode == 'ro') {
      this.amountSuffix = 'RON';
    }

  }

  lang: any;
  countryCode = sessionStorage.getItem('countryCode');
  amountSuffix: any;
  setDateValue() {

    let toDate = new Date();
    const fromDateRange = new Date(toDate.setMonth(toDate.getMonth() - 1));
    this.searchInput.patchValue({
      fromDate: fromDateRange
    })
  }
  giveFromDateSelected(event) {
    // console.log("eventfro",event)
  }
  giveToDateSelected(event) {
    //  console.log("eventto",event)
  }

  maximumYearAlert: boolean = false;
  checkDateValidity() {

    let firstDate = moment(this.searchInput.value.fromDate);
    let secondDate = moment(this.searchInput.value.toDate);
    //(firstDate, secondDate)

    const diffInDays = secondDate.diff(firstDate, 'days');

    if ((!firstDate.isValid()) || (!secondDate.isValid())) {
      // if(this.searchInput.invalid ){
      // if(firstDate == null || secondDate == null){
      this.invalidDateError = true;
      this.searchValid = false;
    } else {
      this.invalidDateError = false;
      this.searchValid = true;

    } if (!this.invalidDateError) {

      if (diffInDays >= 366 || diffInDays < 0) {
        this.DateError = true;
        this.searchValid = false;
      }
      else {
        this.DateError = false;
        this.searchValid = true;
        this.searchHistory();
      }
    }
    // else{
    //   this.maximumYearAlert = true;
    // }
  }

  searchHistory() {
    this.DateError = false;
    this.search = true;

    this.getRequestParam();

    // console.log(this.fundHistoryRequestDTO)
    this.commonService['postData'](this.fundUrl, this.fundHistoryRequestDTO, this.headers).subscribe(data => {


      // this.historyList = new MatTableDataSource(this.history)
      if (data.investAccountHistory)
        this.history = data.investAccountHistory;

      //("history", this.history)
      if (this.history) {
        this.dataSourceTwo = new MatTableDataSource<HistoryData>();
        this.paginator = null;
        this.dataSourceTwo.sort = null;
        this.dataSourceTwo.data = this.history
        this.dataSourceTwo.paginator = this.paginator;
        this.dataSourceTwo.sort = this.tableTwoSort;
        this.dataSourceTwo.sortingDataAccessor = (item, property) => {
          // console.log(property)
          switch (property) {
            case 'transactionValue': {
              // console.log(item.transactionValue)
              const a = item.transactionValue;
              let val = a.toLocaleString();
              let num = parseFloat(a.trim().replace(',', ''))
              var numeric = Number(num);
              // console.log(numeric);
              return numeric;

            }

            case 'unitPrice': {
              //  console.log(item.unitPrice)
              const a = item.unitPrice;
              let val = a.toLocaleString();
              let num = parseFloat(a.trim().replace(',', ''))
              var numeric = Number(num);
              // console.log("a",numeric);
              return numeric;

            }

            default: {

              return item[property];
            }
          }
        };
        this.tableTwoSort.disableClear = true;
        //(this.dataSourceTwo.sort)
        this.count = this.history.length;
        //(this.count)
        if (this.history.length != 0) {
          this.recordFound = true;
        }
        else {
          this.recordFound = false;
        }
      } //("rr", this.recordFound)
      if (data.maxRecordSizeExceed) {
        this.maxRecord = true;
      }
      else {
        this.maxRecord = false;
      }
    })



    this.search = false;
    this.history = null;
    this.recordFound = false;
    // this.dataSource1 = null;
    //
  }
  // show() {

  //   window.open(this.accountValue.fundExternalLink)
  // }
  showpremium(link) {

    window.open(link)
  }
  goToFundHistory() {
    this.sharedService.setDetail('checkBoxSelection', true);
    this.router.navigate(['/contract-details/transferFunds'])
    //this.router.navigate(['/contract-details',{ id: 'transferFund' }])
  }
  goToPremiumSplit() {
    this.sharedService.setDetail('checkBoxSelection', true);
    this.router.navigate(['/contract-details/allocationChange'])
  }
  goToAdditionPremium() {
    this.sharedService.setDetail('checkBoxSelection', true);
    this.router.navigate(['/contract-details/additionalPremiumDeposit'])
  }
  goToSinglePremium() {
    this.sharedService.setDetail('checkBoxSelection', true);
    this.router.navigate(['/contract-details/singlePremium'])
  }

  navigateBackToContractValueScreen() {
    const activeTab = {
      contractValue: true
    }
    sessionStorage.setItem('actveTabContractValueSection', JSON.stringify(activeTab));
    this.router.navigate(['contract-details']);
  }
  goIntoDetails() {
    if (!this.showDetails) {
      this.showDetails = true;
      this.valueonDateToolTip = true;
    } else {
      this.showDetails = false;
      this.valueonDateToolTip = false;
    }
  }
  openSite(siteUrl) {
    window.open("//" + siteUrl, '_blank');

  }
}
