import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { ContractDetailsModule } from '../contract-details.module';

import { FundHistoryComponent } from './fund-history.component';
import { of } from 'rxjs';

describe('FundHistoryComponent', () => {
  let component: FundHistoryComponent;
  let fixture: ComponentFixture<FundHistoryComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'fundHistory': host + '/api/v1/users/fund-history'
      }
    }
  };
  let mockvalue = { "fundAccountValue": [{ "fundName": "DYNAMICZNY ", "fundExternalLink": "cee.alico.com / NotowaniaUFK / client / fund.xhtml ? FundID = OLAS003", "units": "413.6705", "unitPrice": "25.76", "fundValue": "10, 656.15" }], "totalAmount": "10, 656.15 PLN", "fundPremiumSplit": [], "operationDataVO": [{ "clientId": "101583", "policyNumber": "21295127", "investAccNumber": "21296303", "allocationChange": "0", "fundTransfer": "1", "depositInvestAccount": "0", "depositNewInvestAcc": "0" }], "investAccountHistoryVO": null, "maxRecordSizeExceed": false, "investAccountHistory": [{ "policyNumber": "21295127", "investAccountNumber": "21296303", "operationType": 42, "fundId": "OLAS | 003", "transactionDate": "2013 - 09 - 16", "unitsBeforeTransaction": "413.9291", "unitsAfterTransaction": "413.6705", "unitPrice": "25.17", "transactionValue": " - 6.51", "sort": 41, "fundName": "DYNAMICZNY ", "fundExternalLink": "http://cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003" }, { "policyNumber": "21295127", "investAccountNumber": "21296303", "operationType": 42, "fundId": "OLAS|003", "transactionDate": "2013-08-16", "unitsBeforeTransaction": "414.1881", "unitsAfterTransaction": "413.9291", "unitPrice": "25.60", "transactionValue": "-6.63", "sort": 40, "fundName": "DYNAMICZNY ", "fundExternalLink": "http://cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003" }, { "policyNumber": "21295127", "investAccountNumber": "21296303", "operationType": 42, "fundId": "OLAS|003", "transactionDate": "2013-07-16", "unitsBeforeTransaction": "414.4472", "unitsAfterTransaction": "414.1881", "unitPrice": "24.28", "transactionValue": "-6.29", "sort": 39, "fundName": "DYNAMICZNY ", "fundExternalLink": "http://cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003" }, { "policyNumber": "21295127", "investAccountNumber": "21296303", "operationType": 42, "fundId": "OLAS|003", "transactionDate": "2013-06-17", "unitsBeforeTransaction": "414.7065", "unitsAfterTransaction": "414.4472", "unitPrice": "25.03", "transactionValue": "-6.49", "sort": 38, "fundName": "DYNAMICZNY ", "fundExternalLink": "http://cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003" }], "valuationDate": "2013-10-01", "accntTypesList": ["41", "47", "55", "56", "48", "57", "49", "50", "51", "52", "53", "42", "43", "44", "45", "46", "44"] };

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    window.sessionStorage.setItem("defaultLanguage", "pl_pl");
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }, HttpCommonService]
    })
      .compileComponents();
    fixture = TestBed.createComponent(FundHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(FundHistoryComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  xit('should create', () => {
    let httpCommonService = TestBed.get(HttpCommonService);
    spyOn(httpCommonService, 'postData').and.returnValue(of(mockvalue));
    expect(component).toBeTruthy();
  });
});
