import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GeneralDataComponent } from './general-data/general-data.component';
import { OrdersInvestComponent } from './orders-invest/orders-invest.component';
import { ContractDetailsComponent } from './contract-details.component';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
//import { FundHistoryComponent } from './fund-history/fund-history.component';
import { ContractValueComponent } from './contract-value/contract-value.component';
import { FundHistoryComponent } from './fund-history/fund-history.component';
import { AllocationChangeComponent } from './allocation-change/allocation-change.component';
import { SelectAccountComponent } from './allocation-change/select-account/select-account.component';
import { SelectFundsComponent } from './allocation-change/select-funds/select-funds.component';
import { SummarySplitScreenComponent } from './allocation-change/summary-split-screen/summary-split-screen.component';
import { ChangePremiumConfirmationComponent } from './allocation-change/change-premium-confirmation/change-premium-confirmation.component';
import { PayAdditionalPremiumComponent } from './pay-additional-premium/pay-additional-premium.component';
import { SelectAccountAdditionalPremiumComponent } from './pay-additional-premium/select-account/select-account.component';
import { AmountAdditionalPremiumComponent } from './pay-additional-premium/amount-additional-premium/amount-additional-premium.component';
import { TransferFundsComponent } from './transfer-funds/transfer-funds.component';
import { SelectAccountFundsComponent } from './transfer-funds/select-account-funds/select-account-funds.component';
import { SourceFundsSplitComponent } from './transfer-funds/source-funds-split/source-funds-split.component';
import { DestinationFundsComponent } from './transfer-funds/destination-funds/destination-funds.component';
import { SummryTransferFundsComponent } from './transfer-funds/summry-transfer-funds/summry-transfer-funds.component';
import { ConfTransferSummaryComponent } from './transfer-funds/conf-transfer-summary/conf-transfer-summary.component';
import { SinglePremiumComponent } from './single-premium/single-premium.component';
import { SelectAccountSinglePremiumComponent } from './single-premium/select-account-single-premium/select-account-single-premium.component';
import { AdditionalContractSinglePremiumComponent } from './single-premium/additional-contract-single-premium/additional-contract-single-premium.component';
import { SingleContractSummaryComponent } from './single-premium/single-contract-summary/single-contract-summary.component';
import { ContractDataDetailComponent } from './contract-data-detail/contract-data-detail.component';
import { IndexationOptionsComponent } from './indexation-options/indexation-options.component';

const routes: Routes = [
  //{path: '/:id', component: ContractDetailsComponent, canDeactivate: [NavigationGuard]},
  {
    path: '', component: ContractDetailsComponent, canDeactivate: [NavigationGuard],

    children: [

      { path: 'generalData', component: GeneralDataComponent, canDeactivate: [NavigationGuard] },
      { path: 'indexationOption', component: IndexationOptionsComponent, canDeactivate: [NavigationGuard] },
      { path: 'contractData', component: ContractDataDetailComponent, canDeactivate: [NavigationGuard] },
      { path: 'orderInvest', component: OrdersInvestComponent, canDeactivate: [NavigationGuard] },
      { path: 'contractValue', component: ContractValueComponent, canDeactivate: [NavigationGuard] },
      { path: 'fund', component: FundHistoryComponent, canDeactivate: [NavigationGuard] },
      {
        path: 'allocationChange', component: AllocationChangeComponent, canDeactivate: [NavigationGuard],
        children: [
          {
            path: 'selectAccountPremiumSplit', component: SelectAccountComponent, canDeactivate: [NavigationGuard]
          },
          {
            path: '', component: SelectFundsComponent, canDeactivate: [NavigationGuard],
          },
          {
            path: '', component: SummarySplitScreenComponent, canDeactivate: [NavigationGuard],
          },
          {
            path: '', component: SummarySplitScreenComponent, canDeactivate: [NavigationGuard],
          }
        ]
      },
      {
        path: 'additionalPremiumDeposit', component: PayAdditionalPremiumComponent, canDeactivate: [NavigationGuard],
        children: [
          {
            path: 'accountSelect', component: SelectAccountAdditionalPremiumComponent, canDeactivate: [NavigationGuard]
          },
          {
            path: '', component: AmountAdditionalPremiumComponent, canDeactivate: [NavigationGuard]
          },
        ]
      },
      {
        path: 'transferFunds', component: TransferFundsComponent, canDeactivate: [NavigationGuard],
        children: [
          {
            path: 'accountSelectTransferFuunds', component: SelectAccountFundsComponent, canDeactivate: [NavigationGuard]
          },
          {
            path: '', component: SourceFundsSplitComponent, canDeactivate: [NavigationGuard]
          },
          {
            path: '', component: DestinationFundsComponent, canDeactivate: [NavigationGuard]
          },
          {
            path: '', component: SummryTransferFundsComponent, canDeactivate: [NavigationGuard]
          },
          {
            path: '', component: ConfTransferSummaryComponent, canDeactivate: [NavigationGuard]
          }
        ]
      },
      {
        path: 'singlePremium', component: SinglePremiumComponent, canDeactivate: [NavigationGuard],
        children: [
          {
            path: 'accountSelectSinglePremium', component: SelectAccountSinglePremiumComponent, canDeactivate: [NavigationGuard]
          },
          {
            path: '', component: AdditionalContractSinglePremiumComponent, canDeactivate: [NavigationGuard]
          },
          {
            path: '', component: SingleContractSummaryComponent, canDeactivate: [NavigationGuard]
          }
        ]
      }

    ]

  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContractDetailsRoutingModule { }
