import { NgModule, Input } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule, MatSidenavModule, MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule, MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatInputModule, MatPaginatorModule, MatSortModule, MatTableModule, MatStepperModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { NgxPaginationModule } from 'ngx-pagination';
import { SharedModule } from './../shared/shared.module';
import { ContractDetailsRoutingModule } from './contract-details-routing.module';
import { ContractDetailsComponent } from './contract-details.component';
import { GeneralDataComponent } from './general-data/general-data.component';
import { OrdersInvestComponent } from './orders-invest/orders-invest.component';
import { ContractDataDetailComponent } from './contract-data-detail/contract-data-detail.component';
import { IndexationOptionsComponent } from './indexation-options/indexation-options.component';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter, MatDatepickerIntl, NativeDateAdapter } from '@angular/material';
import { ContractValueComponent } from './contract-value/contract-value.component';
import { FundHistoryComponent } from './fund-history/fund-history.component';

import { OrderstabModule } from '../orderstab/orderstab.module';
import { AllocationChangeComponent } from './allocation-change/allocation-change.component';
import { SelectAccountComponent } from './allocation-change/select-account/select-account.component';
import { SelectFundsComponent } from './allocation-change/select-funds/select-funds.component';
import { SummarySplitScreenComponent } from './allocation-change/summary-split-screen/summary-split-screen.component';
import { ChangePremiumConfirmationComponent } from './allocation-change/change-premium-confirmation/change-premium-confirmation.component';
import { PayAdditionalPremiumComponent } from './pay-additional-premium/pay-additional-premium.component';
import { SelectAccountAdditionalPremiumComponent } from './pay-additional-premium/select-account/select-account.component'
import { AmountAdditionalPremiumComponent } from './pay-additional-premium/amount-additional-premium/amount-additional-premium.component';
import { SummaryAdditionalPremiumComponent } from './pay-additional-premium/summary-additional-premium/summary-additional-premium.component';
import { SinglePremiumComponent } from './single-premium/single-premium.component';
import { SelectAccountSinglePremiumComponent } from './single-premium/select-account-single-premium/select-account-single-premium.component';
import { AdditionalContractSinglePremiumComponent } from './single-premium/additional-contract-single-premium/additional-contract-single-premium.component';
import { SingleContractSummaryComponent } from './single-premium/single-contract-summary/single-contract-summary.component';
import { TransferFundsComponent } from './transfer-funds/transfer-funds.component';
import { SelectAccountFundsComponent } from './transfer-funds/select-account-funds/select-account-funds.component';
import { SourceFundsSplitComponent } from './transfer-funds/source-funds-split/source-funds-split.component';
import { DestinationFundsComponent } from './transfer-funds/destination-funds/destination-funds.component';
import { SummryTransferFundsComponent } from './transfer-funds/summry-transfer-funds/summry-transfer-funds.component';
import { ConfTransferSummaryComponent } from './transfer-funds/conf-transfer-summary/conf-transfer-summary.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};

export class CustomDatePickerAdapter extends NativeDateAdapter {

  parse(value: any): Date | null {
    ////(value);
    if ((typeof value === 'string') && (value.indexOf('/') > -1)) {
      const str = value.split('/');
      const year = Number(str[2]);
      const month = Number(str[1]) - 1;
      const date = Number(str[0]);
      // //("year, month, date",year, month, date)
      ////("year, month, date",new Date(year, month, date))
      if (year > 0 && month < 12 && date > 0 && date <= 31) {
        return new Date(year, month, date);
      }


    }
    const timestamp = typeof value === 'number' ? value : Date.parse(value);
    ////("timestamp",timestamp)
    return isNaN(timestamp) ? null : new Date(timestamp);
  }

  private _to2digit(n: number) {
    ////("_to2digit",('00' + n).slice(-2))
    return ('00' + n).slice(-2);
  }
  format(date: Date, displayFormat: string): string {
    ////(displayFormat," ------>",date,displayFormat )

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    ////("input",(this._to2digit(day) + '/' + this._to2digit(month) + '/' + year) )
    return this._to2digit(day) + '/' + this._to2digit(month) + '/' + year;

  }
}
const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule, MatStepperModule];
@NgModule({
  declarations: [ContractDetailsComponent, ContractValueComponent, FundHistoryComponent, GeneralDataComponent, OrdersInvestComponent, ContractDataDetailComponent, IndexationOptionsComponent, AllocationChangeComponent,
    SelectAccountComponent,
    SelectFundsComponent,
    SummarySplitScreenComponent,
    ChangePremiumConfirmationComponent,
    PayAdditionalPremiumComponent,
    SelectAccountAdditionalPremiumComponent,
    AmountAdditionalPremiumComponent,
    SummaryAdditionalPremiumComponent,
    SinglePremiumComponent,
    SelectAccountSinglePremiumComponent,
    AdditionalContractSinglePremiumComponent,
    SingleContractSummaryComponent,
    TransferFundsComponent,
    SelectAccountFundsComponent,
    SourceFundsSplitComponent,
    DestinationFundsComponent,
    SummryTransferFundsComponent,
    ConfTransferSummaryComponent,
  ],
  imports: [
    CommonModule,
    ContractDetailsRoutingModule,
    FormsModule,
    OrderstabModule,
    ReactiveFormsModule,
    TranslateModule,
    ...materialModule,
    NgxPaginationModule,
    SharedModule,
  ],
  providers: [{
    provide: DateAdapter,
    useClass: MomentDateAdapter,
    deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
  },
  {
    provide: DateAdapter,
    useClass: CustomDatePickerAdapter

  },


  // { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
    // { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ]
})
export class ContractDetailsModule { }
