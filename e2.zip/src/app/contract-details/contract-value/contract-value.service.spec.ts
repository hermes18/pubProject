import { TestBed } from '@angular/core/testing';

import { ContractValueService } from './contract-value.service';

describe('ContractValueService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ContractValueService = TestBed.get(ContractValueService);
    expect(service).toBeTruthy();
  });
});
