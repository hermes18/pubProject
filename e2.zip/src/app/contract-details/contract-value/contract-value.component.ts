import { HttpHeaders } from '@angular/common/http';
import { Input, Pipe } from '@angular/core';
import { PipeTransform } from '@angular/core';
import { Component, EventEmitter, LOCALE_ID, NgModule, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { element } from 'protractor';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { environment } from 'src/environments/environment';
import { ContractValueService } from './contract-value.service';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { UtilityService } from 'src/app/shared/utilities/utility.service';


@Component({
  selector: 'contract-value',
  templateUrl: './contract-value.component.html',
  styleUrls: ['./contract-value.component.scss'],
  // providers: [
  //   { provide: LOCALE_ID, useValue: 'pl' }
  // ],
})
export class ContractValueComponent implements OnInit {
  settingParamValue = {
    'contractValue': false,
    'fund': false,
  }
  @Input() set contractValueInit(flag) {
    // console.log(flag);
    this.contractValuInitCall = flag;
    if (flag) {
      this.apiCallForContractValue();
    }
  }
  @Output('userAccountValue') valueChange = new EventEmitter<any>();
  contractValueRequestDTO
  clientId;
  contractValuInitCall: boolean;
  headers = new HttpHeaders();
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  contractValueUrl = this.baseUrl.ecustomer.contractValue;
  // contractValueUrl = environment.contractValue.url;
  contractValue
  contractDetail: any;
  policyData
  contractNo
  accountData
  showDetails: boolean;
  valueonDateToolTip: boolean;
  investDateToolTip: boolean;
  invsetAccountNumberToolTip: boolean;
  showContractValue: boolean = false;
  showInvestCapital: boolean = false;
  country: string;


  constructor(public commonService: HttpCommonService, private router: Router, public sharedService: SharedServiceService, public contractValueService: ContractValueService, public menuItemService: MenuItemsService) { }
  lang: any;
  displayPoOption: boolean = false
  lcode
  ngAfterViewInit() {
    this.sharedService.getLangChange().subscribe((data) => {

      const lang = sessionStorage.getItem("defaultLanguage");
      this.lcode = sessionStorage.getItem("defaultLanguage");
      // console.log(this.lcode)
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_gr': 'el',
        'gr_en': 'en',
        'gr': 'el'
      }
      //("after lang change", data);
      const language = data ? data === 'gr' ? dateTranslate[lang] : data : dateTranslate[lang];

    })
  }
  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');

    this.lcode = sessionStorage.getItem("defaultLanguage");
    this.lang = sessionStorage.getItem('defaultLanguage');
    // console.log(this.lang,this.lcode)
    //("oninitlang", this.lang)
    // if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayPoOption = false;
    }
    this.apiCallForContractValue();
    // this.settingParamValue.contractValue = true;
    // const customerId = JSON.parse(sessionStorage.getItem('searcClientID')),
    //   loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
    //   userrole = this.menuItemService.getAllRoles();
    // this.contractDetail = null;
    // this.contractNo = this.sharedService.getContractNo();
    // const contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));
    // //(userrole);

    // // let userdetail = JSON.parse(loggedInUserDetail);
    // let role = loggedInUserDetail.roleInfo[0] ? loggedInUserDetail.roleInfo[0].name : 'NoRole';
    // this.contractNo = this.sharedService.getContractNo();
    // this.clientId = this.contractValueService.getClientID(loggedInUserDetail, customerId, userrole);
    // this.contractValueRequestDTO = {
    //   userId: loggedInUserDetail ? loggedInUserDetail.userName : '',
    //   clientId: this.clientId,
    //   contractNo: contractDetails.contractNumber,
    //   requesterRole: role

    // }
    //("request", this.contractValueRequestDTO)
    // this.commonService['postData'](this.contractValueUrl, this.contractValueRequestDTO, this.headers).subscribe(data => {
    //   this.contractValue = data;
    //   //(this.contractValue)
    //   this.contractValue.policyFinDataVOList.forEach(element => {
    //     element.surrenderValueToolTipOpen = null
    //   })
    //   this.policyData = this.contractValue.policyFinDataVOList;
    //   if (this.policyData.length != 0) {
    //     this.showContractValue = true;
    //   } else { this.showContractValue = false }
    //   this.accountData = this.contractValue.accountDtoList;
    //   if (this.accountData.length != 0) {
    //     this.showInvestCapital = true;
    //     this.sharedService.setInvestValuationDate(this.contractValue.investValuationDate);
    //     //("investDate", this.contractValue.investValuationDate)
    //   } else { this.showInvestCapital = false }
    //   //("contract", this.contractValue)
    //   //("invest", this.accountData)
    // })
    // this.lcode = sessionStorage.getItem("defaultLanguage");
    // // console.log(this.lcode)
    // this.lang = sessionStorage.getItem('countryCode');
    // this.sharedService.getLangChange().subscribe((data) => {
    //   //(data);
    //   if (data) {
    //     this.lang = data;
    //     // console.log("data",data)
    //   }
    // });
  }

  apiCallForContractValue() {
    this.settingParamValue.contractValue = true;
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID')),
      loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
      userrole = this.menuItemService.getAllRoles();
    this.contractDetail = null;
    this.contractNo = this.sharedService.getContractNo();
    const contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));
    //(userrole);

    // let userdetail = JSON.parse(loggedInUserDetail);
    let role = loggedInUserDetail.roleInfo[0] ? loggedInUserDetail.roleInfo[0].name : 'NoRole';
    this.contractNo = this.sharedService.getContractNo();
    this.clientId = this.contractValueService.getClientID(loggedInUserDetail, customerId, userrole);
    this.contractValueRequestDTO = {
      userId: loggedInUserDetail ? loggedInUserDetail.userName : '',
      clientId: this.clientId,
      contractNo: contractDetails.contractNumber,
      requesterRole: role

    }
    this.commonService['postData'](this.contractValueUrl, this.contractValueRequestDTO, this.headers).subscribe(data => {
      this.contractValue = data;
      //(this.contractValue)
      this.contractValue.policyFinDataVOList.forEach(element => {
        element.surrenderValueToolTipOpen = null
      })
      this.policyData = this.contractValue.policyFinDataVOList;
      if (this.policyData.length != 0) {
        this.showContractValue = true;
      } else { this.showContractValue = false }
      this.accountData = this.contractValue.accountDtoList;
      if (this.accountData.length != 0) {
        this.showInvestCapital = true;
        this.sharedService.setInvestValuationDate(this.contractValue.investValuationDate);
        //("investDate", this.contractValue.investValuationDate)
      } else { this.showInvestCapital = false }
      //("contract", this.contractValue)
      //("invest", this.accountData)
    })
    this.lcode = sessionStorage.getItem("defaultLanguage");
    // console.log(this.lcode)
    this.lang = sessionStorage.getItem('countryCode');
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.lang = data;
        // console.log("data",data)
      }
    });
  }

  gotoFundHistory(data, investname, investToolTip) {
    console.log("investAccNumber", investToolTip)
    this.settingParamValue.contractValue = false;

    // this.router.navigate(['contract-details/fund'] );
    this.settingParamValue.fund = true;
    this.sharedService.setterInvestAccNumber(data);
    this.sharedService.setterInvestAccName(investname);
    this.sharedService.setterInvestAccToopTip(investToolTip);
    this.valueChange.emit(this.settingParamValue);
    const activeTab = {
      contractValue: this.settingParamValue.contractValue
      //  userDetails: this.settingParamValue.userDetails
    }
    sessionStorage.setItem('actveTabContractValueSection', JSON.stringify(activeTab));
    sessionStorage.setItem('clickedAccountNumber', JSON.stringify(data));
    this.router.navigate(['contract-details/fund']);
  }

  goIntoDetails() {
    if (!this.showDetails) {
      this.showDetails = true;
      this.valueonDateToolTip = true;
      this.investDateToolTip = true;
      this.invsetAccountNumberToolTip = true;
      this.policyData.forEach(element => {
        if (element.infotip_label != '' || element.infotip_label != null) {
          element.surrenderValueToolTipOpen = true;

        }

      });

    } else {
      this.showDetails = false;
      this.valueonDateToolTip = false;
      this.investDateToolTip = false;
      this.invsetAccountNumberToolTip = false;
      this.policyData.forEach(data => {
        data.surrenderValueToolTipOpen = false;

      });

    }
  }

}


