import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from '../../app.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { TranslateService } from '@ngx-translate/core';
import { GeneralDataComponent } from './general-data.component';
import { ContractDetailsModule } from '../contract-details.module';

describe('GeneralDataComponent', () => {

  let component: GeneralDataComponent;
  let fixture: ComponentFixture<GeneralDataComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'generaldata': host + '/api/v1/users/general-data',
        'downloadDocument': host + '/api/v1/policy/document/'
      }
    }
  };

  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(GeneralDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
