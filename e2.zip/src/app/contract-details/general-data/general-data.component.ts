import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { AppConfig } from 'src/config/app.config';
import * as utils from 'lodash';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { HttpHeaders } from '@angular/common/http';
import { isUndefined } from 'util';
import { TranslateService } from '@ngx-translate/core';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'general-data',
  templateUrl: './general-data.component.html',
  styleUrls: ['./general-data.component.scss']
})
export class GeneralDataComponent implements OnInit {
  constructor(public route: ActivatedRoute, private readonly router: Router,
    public fb: FormBuilder, public menuItemService: MenuItemsService, public translate: TranslateService,
    public sharedService: SharedServiceService, private cService: HttpCommonService,
    @Inject('Window') private window: Window) { }
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  contractListData: any;
  contractNo: any;
  roles: any;
  data: any;
  headers = new HttpHeaders();
  genaralData = this.fb.group({
    uId: '',
    lastName: '',
    Email: ''
  });
  logMessage: any;
  contractDetail: any;
  userInfo: any;
  userrole = this.menuItemService.getAllRoles();
  response: any;
  outstandingPremium: boolean = false;
  premiumIndexation: boolean = false;
  suspendedpremium: boolean = false;
  clientId: any;
  mockjson: any;
  businessRole: any;
  documentId: any;
  paymentMode: any;
  renderOffers: boolean = false;
  renderDownloadfile: boolean = false;
  renderAgent: boolean = false;
  renderBeneficiary: boolean = false;
  suspendedDate: any;
  suspendedpremiumWithDate: boolean = false;
  showDateTooltipBasic: boolean = false;
  showDateTooltipBasic2: boolean = false;
  newList: any = [];
  additionbankLabel: any;
  additionbanktoolTip: any;
  country: any;
  lcode;
  wardenRoleCheck: boolean = false;
  loggedInCountryCheck = UtilityService.getCountry();

  ngAfterViewInit() {
    this.sharedService.getLangChange().subscribe((data) => {

      const lang = sessionStorage.getItem("defaultLanguage");
      this.lcode = sessionStorage.getItem("defaultLanguage");
      //  console.log(this.lcode)
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_gr': 'el',
        'gr_en': 'en'
      }
      //("after lang change", data);
      const language = data ? data : dateTranslate[lang];

    })
  }
  ngOnInit() {
    this.contractDetail = null;
    this.contractNo = this.sharedService.getContractNo();
    this.country = sessionStorage.getItem('countryCode');
    const contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));
    let userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    const contractnumber = JSON.parse(sessionStorage.getItem('contract'));
    const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    const menuItemList2 = JSON.parse(sessionStorage.getItem('menuItemList'));

    if (menuItemList) {
      this.wardenRoleCheck = menuItemList.wardenRoleCheck ? menuItemList.wardenRoleCheck : false;
    } else if (menuItemList2) {
      this.wardenRoleCheck = menuItemList2.wardenRoleCheck ? menuItemList2.wardenRoleCheck : false;
    }

    if (userdetail) {
      this.clientId = userdetail.clientId ? userdetail.clientId : '';
    }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    }
    this.mockjson = "assets/mocks/generaldata.json"
    let contractNo = contractDetails ? (contractDetails.contractNumber ? contractDetails.contractNumber : "") : "";
    if (contractNo == null || contractNo === undefined || contractNo === "") {
      contractNo = contractnumber;

    }
    if (contractNo) {
      let clientLoginId = "";
      let clientRole = "";
      const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
      if (menuItemList) {
        //clientLoginId = menuItemList.clientLoginId  ? menuItemList.clientLoginId : '';
        clientRole = menuItemList.clientRoleIds ? menuItemList.clientRoleIds : '';

      }
      this.contractNo = contractNo;
      this.data = {
        contractNo: contractNo,
        requesterRole: clientRole ? clientRole : (userdetail ? userdetail.requesterRole : ''),
        userId: userdetail.userName,
        clientId: this.clientId ? this.clientId : '',
        requesterId: this.clientId ? this.clientId : ''
      }
      this.cService['postData'](this.baseUrl.ecustomer.generaldata, this.data, this.headers)
        //  this.cService['getData'](this.mockjson)
        .subscribe(data => {
          //(data)
          if (data) {
            this.response = data;
            if (((data.policyDetailsDTO.renderDebtStatus === "true" || data.policyDetailsDTO.renderDebtStatus)) ||
              (data.policyDetailsDTO.renderSuspendStatusWithDate || (data.policyDetailsDTO.renderSuspendStatusWithDate === "true")) ||
              (data.policyDetailsDTO.renderSuspendStaus || (data.policyDetailsDTO.renderSuspendStaus === "true"))) {
              this.outstandingPremium = true;
            }
            if (data.policyDetailsDTO.renderSuspendStaus) {
              this.suspendedpremium = true;
            }
            if (data.policyDetailsDTO.contractStatus) {
              if (this.wardenRoleCheck) {
                this.businessRole = "roleWarden";
              } else {
                this.businessRole = data.policyDetailsDTO.contractStatus;
              }
              // this.role =  this.translate.instant("eCustomer.generaldata."+businessRole);  
              if (this.businessRole === "roleWarden" || (this.wardenRoleCheck)) {
                this.beneficiarySection = false;
              } else {
                this.beneficiarySection = true;
              }
            }

            if (data.policyDetailsDTO.renderAdditionalBankAccount) {
              this.additionbankLabel = data.policyDetailsDTO.additionalBankAccountLabel;
              this.additionbanktoolTip = data.policyDetailsDTO.additionalBankAccountTip;
            }
            if (data.policyDetailsDTO.renderIndexationMsg) {
              this.premiumIndexation = true;
              this.documentId = this.response ? this.response.policyDetailsDTO.indexationDocument : '';
              if (this.documentId) {
                this.renderDownloadfile = true;
              } else {
                this.renderDownloadfile = false;
              }
            }
            if (data.policyDetailsDTO.paymentMode) {
              this.paymentMode = data.policyDetailsDTO.paymentMode
            }
            if (data.offerDetailsDTO && data.offerDetailsDTO.offerId) {
              this.renderOffers = true;
            }
            // if (this.country === 'pl') {
            if (this.loggedInCountryCheck) {
              this.setAgentDetails(data);
            } else if (this.country === 'ro') {
              this.setAgentDetailsRo(data);
            }

            // if (this.country === 'pl') {
            if (this.loggedInCountryCheck) {
              this.setBeneficiarySection(data);
            } else if (this.country === 'ro') {
              this.setBeneficiarySectionRo(data);
            }

            if (data.policyDetailsDTO.renderSuspendStatusWithDate) {
              this.suspendedpremiumWithDate = true;
            } else {
              this.suspendedpremiumWithDate = false;
            }
            this.suspendedDate = data.policyDetailsDTO.renderSuspendStatusWithDate;
            this.setContributionSection();
          }
        });
    }
    this.lang = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if (this.lang == "pl_en") {
      this.lang = "en";
    } else if (this.lang == "pl_pl") {
      this.lang = "pl";
    } else if (this.lang == "ro_en") {
      this.lang = "en";
    } else if (this.lang == "ro_ro") {
      this.lang = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.lang = data;
      }
    });
  }

  setAgentDetailsRo(data: any) {
    if (data.agentDTOList && data.agentDTOList.length > 0) {
      this.renderAgent = true;
    } else {
      this.renderAgent = false;
    }
  }
  setAgentDetails(data: any) {
    if (data.agentDTOList && data.agentDTOList.length > 0) {
      data.agentDTOList.forEach(
        agent => {
          if (agent.agentPhone) {
            this.newList.push(agent);
          }
        })
      if (this.newList && this.newList.length > 0) {
        this.renderAgent = true;
      } else {
        this.renderAgent = false;
      }
    } else {
      this.renderAgent = false;
    }
  }
  setBeneficiarySectionRo(data: any) {
    this.beneficiarySection = true;
    if (data.beneficiaryDataDTOList && data.beneficiaryDataDTOList.length > 0 && (!this.wardenRoleCheck)) {
      this.renderBeneficiary = true;
    } else {
      this.renderBeneficiary = false;
    }
  }
  setBeneficiarySection(data: any) {
    if (data.beneficiaryDataDTOList && data.beneficiaryDataDTOList.length > 0) {
      if (data.policyDetailsDTO.renderBeneficiariesSection && (!this.wardenRoleCheck)) {
        this.beneficiarySection = true;
        this.renderBeneficiary = true;
      } else {
        this.beneficiarySection = false;
      }
    } else {
      if (data.policyDetailsDTO.renderBeneficiariesSection && (!this.wardenRoleCheck)) {
        this.beneficiarySection = true;
        this.renderBeneficiary = false;
      } else {
        this.beneficiarySection = false;
      }
    }
  }
  lang: any;
  beneficiarySection: boolean = false;
  renderContributionSection: boolean = false;
  setContributionSection() {
    const data = this.response;
    if (data.policyDetailsDTO.paymentMode || data.policyDetailsDTO.bankAccount ||
      data.policyDetailsDTO.lastPremiumAmt || data.policyDetailsDTO.premiumAmount || data.policyDetailsDTO.premiumDueDate) {
      this.renderContributionSection = true;
    } else {
      this.renderContributionSection = false;
    }
  }
  contactform(reason) {
    this.sharedService.setContactReason(reason);
    this.router.navigate(['./contact-form']);

  }

  goToOfferList() {
    this.response.offerDetailsDTO.clientId = '';
    this.response.offerDetailsDTO.clientId = this.clientId;
    this.response.offerDetailsDTO.contractNumber = this.contractNo;
    sessionStorage.setItem('offerListSingleItem', JSON.stringify(this.response.offerDetailsDTO));
    //this.router.navigate(['/myOffers'])
    this.router.navigate(['myOffers/offerlist']);
    this.sharedService.setterData('offerList', this.response.offerDetailsDTO);
    const mobileContractView = {
      //'contractDetails': null,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    //sessionStorage.setItem('menuSelectedItem', '');
    this.sharedService.setDetail('contractDetailsOnClick', mobileContractView);
  }
  pdfDataRo: any;
  downloadDocument() {

    let indexationDocumentid = this.response ? this.response.policyDetailsDTO.indexationDocument : '';

    if (indexationDocumentid) {
      let headers = new HttpHeaders();
      //this.cService['postData'](this.baseUrl.ecustomer.generaldata,this.data,this.headers)
      this.cService['postData'](this.baseUrl.ecustomer.downloadDocument, indexationDocumentid, headers)
        .subscribe(data => {
          //(data)

          if ((data && data.document)) {

            const byteCharacters = atob(data.document);

            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);

            let blob = new Blob([byteArray], { type: "application/pdf" });
            if (window.navigator.msSaveOrOpenBlob) {

              window.navigator.msSaveOrOpenBlob(blob);
            }
            else {
              let url = window.URL.createObjectURL(blob);
              window.open(url);
            }
          }
          // else if((data && data.documentLocation) && this.country==='ro'){
          //   this.downloadDocumentRO(data);

          // }

        });
    }
  }
  downloadDocumentRO(data) {
    let indexationDocumentid = this.response ? this.response.policyDetailsDTO.indexationDocument : '';
    //this.pdfDataRo = data.documentLocation;  
    window.open('C:\PDF_Loc\Indeksacja.pdf', null);

  }
}
