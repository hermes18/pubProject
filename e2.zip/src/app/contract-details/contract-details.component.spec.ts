import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from '../app.module';
import { SharedServiceService } from '../shared-service/shared-service.service';

import { ContractDetailsComponent } from './contract-details.component';
import { ContractDetailsModule } from './contract-details.module';

xdescribe('ContractDetailsComponent', () => {
  let component: ContractDetailsComponent;
  let fixture: ComponentFixture<ContractDetailsComponent>;
  let sharedService: SharedServiceService;
  const contractDetails = {
    "benefitType": "SuperKapitał - współubezpieczony 1",
    "businessRoleList": ["owner"],
    "contractDetailsDTO": {
      contractNumber: "21281000", insurer: "INSURER_21281000", insured: "INSURED_21281000", status: 21, paymentMode: "15",
    },
    "contractNumber": "21281000",
    "contractNumberList": null,
    "effectiveDate": "18.11.2009",
    "indexedPremiumAmount": null,
    "insuredName": "INSURED_21281000",
    "premiumAmount": "",
    "premiumAmt": null,
    "premiumAmtType": null,
    "premiumDueDate": null,
    "premiumPaymentMode": "15",
    "premiumType": "15",
    "processingSystem": "OLAS",
    "status": 21
  };
  let data = {
    //'fromPage': 'contractDetails',
    "toPage": 'orderInvest'
  };
  let submenuList = {
    renderContractDetails: true,
    renderContractValue: true,
    renderGeneralData: true,
    renderHistortyOfContractOrders: true,
    renderIndexationBenefits: true,
    renderOrders: true
  };
  const menuItemList = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  }

  beforeEach(() => {
    sessionStorage.setItem('contractDetails', JSON.stringify(contractDetails));
    sessionStorage.setItem('contratSubMenuList', JSON.stringify(submenuList));
    sessionStorage.setItem('menuItemList', JSON.stringify(menuItemList));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, MatInputModule, AppModule, MatFormFieldModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(ContractDetailsComponent);
    sharedService = TestBed.get(SharedServiceService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {

    spyOn(sharedService, 'getDetail').and.returnValue(of(0));
    spyOn(sharedService, 'getPageContent').and.returnValue(of(data));

    expect(component).toBeTruthy();
  });

  xit('should call orderInvestTabClick', () => {
    component.orderInvestTabClick();
  })

  it('should call onTabclick', () => {
    component.onTabclick();
  });

  xit('should call onRouteChange', () => {
    component.onRouteChange();
  });

  it('should call displayArray', () => {
    const test = {
      generalData: true,
      userSearch: true,
      contractValue: true,
      fund: true
    }
    component.displayArray(test);
    expect(component.settingParamValue.generalData).toEqual(test.generalData);
    expect(component.settingParamValue.mycontracts).toEqual(test.userSearch);
    expect(component.settingParamValue.contractValue).toEqual(test.contractValue);
    expect(component.settingParamValue.fund).toEqual(test.fund);
  });
  xit('should call gotoHome', () => {
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    window.sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    component.gotoHome()
  });

  xit('should call onTabChanged', () => {
    component.onTabChanged('contractValue');
  })
});
