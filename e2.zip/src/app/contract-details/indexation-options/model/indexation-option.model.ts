import { FormGroup } from '@angular/forms';


export class IndexationOptionsModel {
    indexationOptionsForm: FormGroup;
    submitted: boolean;
    successPage: boolean;
    renderProposedPremiumSection: boolean;
    lastPremiumAmt: any;
    indexedPremiumAmt: any;
    indexedPremiumAmt2: any;
    anniverseryDueDate: any;
    indexRate1: any;
    indexRate2: any;
    indexationEligible: any;
    indexationOptionSelected: any;
    selectedIndexationOption: any;
    activeOrderErrorRender: boolean;
    orderId: any;
    authorizationErrorRender: boolean;
    orderErrorRender: boolean;
    validationField: boolean;
    constructor() {
        this.submitted = false;
        this.renderProposedPremiumSection = false;
        this.successPage = false;
        this.activeOrderErrorRender = false;
        this.authorizationErrorRender = false;
        this.orderErrorRender = false;
        this.validationField = false;
    }

}