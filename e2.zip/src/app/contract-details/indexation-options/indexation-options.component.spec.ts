import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ContractDetailsModule } from '../contract-details.module';

import { IndexationOptionsComponent } from './indexation-options.component';

describe('IndexationOptionsComponent', () => {
  let component: IndexationOptionsComponent;
  let fixture: ComponentFixture<IndexationOptionsComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'indexationBenefit': host + '/api/v1/users/indexation-benefit',
      }
    }
  };
  const contractDetails = {
    "benefitType": "SuperKapitał - współubezpieczony 1",
    "businessRoleList": ["owner"],
    "contractDetailsDTO": {
      contractNumber: 121212, insurer: "INSURER_21281000", insured: "INSURED_21281000", status: 21, paymentMode: "15",
    },
    "contractNumber": "21281000",
    "contractNumberList": null,
    "effectiveDate": "18.11.2009",
    "indexedPremiumAmount": null,
    "insuredName": "INSURED_21281000",
    "premiumAmount": "",
    "premiumAmt": null,
    "premiumAmtType": null,
    "premiumDueDate": null,
    "premiumPaymentMode": "15",
    "premiumType": "15",
    "processingSystem": "OLAS",
    "status": 21
  }
  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    sessionStorage.setItem('contractDetails', JSON.stringify(contractDetails));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(IndexationOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
