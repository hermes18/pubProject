import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { IndexationOptionsModel } from './model/indexation-option.model';

@Component({
  selector: 'indexation-options',
  templateUrl: './indexation-options.component.html',
  styleUrls: ['./indexation-options.component.scss']
})
export class IndexationOptionsComponent implements OnInit {

  indexationOptionsModel: IndexationOptionsModel;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(public fb: FormBuilder, public commonService: HttpCommonService) {
    this.indexationOptionsModel = new IndexationOptionsModel();
  }

  ngOnInit() {
    this.indexationOptionsModel.indexationOptionsForm = this.fb.group({
      indexOptSelection: ['', Validators.required],
      acceptCondition: ['', Validators.required],
    })
    this.formInit();
  }
  formInit() {
    const contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));

    let url = this.baseUrl.ecustomer.indexationBenefit;

    const reqParam = {
      contractNo: contractDetails.contractNumber
    }
    this.commonService.postData(this.baseUrl.ecustomer.indexationBenefit, reqParam, '').subscribe(data => {

      this.indexationOptionsModel.renderProposedPremiumSection = data.renderProposedPremiumSection;
      this.indexationOptionsModel.lastPremiumAmt = data.lastPremiumAmt;
      this.indexationOptionsModel.indexedPremiumAmt = data.indexedPremiumAmt;
      this.indexationOptionsModel.indexedPremiumAmt2 = data.indexedPremiumAmt2;
      this.indexationOptionsModel.anniverseryDueDate = data.anniverseryDueDate;
      this.indexationOptionsModel.indexRate1 = data.indexRate1;
      this.indexationOptionsModel.indexRate2 = data.indexRate2;
      this.indexationOptionsModel.activeOrderErrorRender = data.activeOrderErrorRender;
      this.indexationOptionsModel.authorizationErrorRender = data.authorizationErrorRender;
      this.indexationOptionsModel.indexationEligible = data.indexationEligible;

    })
  }
  submitData() {
    this.indexationOptionsModel.submitted = true;
    let contractData = JSON.parse(sessionStorage.getItem('contractDetails'));
    let clientData = JSON.parse(sessionStorage.getItem('searcClientID'));
    let defaultLanguage = sessionStorage.getItem('defaultLanguage');
    let countryCode = sessionStorage.getItem('countryCode');
    let loggedInUserInfo = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let customerId = JSON.parse(sessionStorage.getItem('searcClientID')),
      loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    let clientID;
    let clientRole;
    let clientLoginID = '';
    let clientfirstname = '';
    let clientlastName = '';
    let menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    let searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
    if (!this.indexationOptionsModel.activeOrderErrorRender) {
      if (this.indexationOptionsModel.indexationOptionsForm.valid &&
        this.indexationOptionsModel.indexationOptionsForm.controls['acceptCondition'].value != 'false') {
        this.indexationOptionsModel.validationField = false;
        if (menuItemList) {
          clientRole = menuItemList.clientRoleIds ? menuItemList.clientRoleIds : '';
        }
        if (customerId && customerId.opeType == 'search') {
          clientID = customerId.clientID ? customerId.clientID : '';
        } else {
          clientID = loggedInUserDetail.clientId ? loggedInUserDetail.clientId : null;
        }


        if (menuItemList) {
          clientLoginID = menuItemList['clientLoginId'];
        } else {
          clientLoginID = loggedInUserInfo['userName'];
        }
        if (searchedClientDetails) {
          clientfirstname = searchedClientDetails['clientFirstName'];
          clientlastName = searchedClientDetails['clientLastName'];
        } else {
          clientfirstname = loggedInUserInfo['firstName'];
          clientlastName = loggedInUserInfo['lastName'];
        }

        let reqParam = {
          contractNumber: contractData.contractNumber,
          clientId: clientID,
          requesterRole: loggedInUserDetail ? loggedInUserDetail.requesterRole : '',
          userId: loggedInUserInfo.userName,
          clientFirstName: clientfirstname,
          clientLastName: clientlastName,
          clientLoginID: clientLoginID,
          firstName: loggedInUserInfo.firstName,
          lastName: loggedInUserInfo.lastName,
          indexationEligible: this.indexationOptionsModel.indexationEligible ? this.indexationOptionsModel.indexationEligible : null,
          lastPremiumAmt: this.indexationOptionsModel.lastPremiumAmt ? this.indexationOptionsModel.lastPremiumAmt : null,
          anniverseryDueDate: this.indexationOptionsModel.anniverseryDueDate ? this.indexationOptionsModel.anniverseryDueDate : null,
          country: countryCode == 'ro' && defaultLanguage == 'ro_ro' ? 'RO' : 'US',
          language: defaultLanguage == 'ro_ro' ? 'RO' : 'EN',
          selectedIndexationOption: this.indexationOptionsModel.indexationOptionsForm.controls['indexOptSelection'].value,
          termsConditionsCheck: this.indexationOptionsModel.indexationOptionsForm.controls['acceptCondition'].value
        }



        this.commonService.postData(this.baseUrl.ecustomer.indexationOrder, reqParam, '').subscribe(data => {


          this.indexationOptionsModel.orderId = data.orderId;
          this.indexationOptionsModel.activeOrderErrorRender = data.activeOrderErrorRender;
          this.indexationOptionsModel.authorizationErrorRender = data.authorizationErrorRender;
          this.indexationOptionsModel.orderErrorRender = data.orderErrorRender;
          if (data.orderId != null && data.orderId != '') {
            this.indexationOptionsModel.successPage = true;
            this.indexationOptionsModel.orderId = data.orderId;
          } else {
            this.indexationOptionsModel.successPage = false;
          }
        })
      } else {
        this.indexationOptionsModel.validationField = true;
        this.indexationOptionsModel.successPage = false;
      }
    } else {
      this.indexationOptionsModel.successPage = false;
      this.indexationOptionsModel.validationField = false;
    }
  }


  documentConditionFile(isChecked: boolean) {

    if (isChecked) {
      window.open("/assets/mocks/Conditii contractuale - clauza de indexare (L163).pdf");
    }
  }

  performOtherJob() {
    this.indexationOptionsModel.successPage = false;
  }
}
