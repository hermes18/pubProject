import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { AllocationChangeSharedService } from '../../allocation-change/allocation-change-service';
import { ContractDetailsModule } from '../../contract-details.module';

import { ConfTransferSummaryComponent } from './conf-transfer-summary.component';

describe('ConfTransferSummaryComponent', () => {
  let component: ConfTransferSummaryComponent;
  let fixture: ComponentFixture<ConfTransferSummaryComponent>;
  let newPremiumService: AllocationChangeSharedService = new AllocationChangeSharedService();
  let sharedService: SharedServiceService = new SharedServiceService();

  // beforeEach(async(() => {
    beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
  // }));

  // beforeEach(() => {
    fixture = TestBed.createComponent(ConfTransferSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('call navigation to premium split page method', () => {
    let data = {
      //'fromPage': 'transferFunds',
      "toPage":'orderInvest'
    }
    sharedService.setPageContent(data);
    spyOn(component, 'gotoPremiumSplitPage').and.callThrough();
    component.gotoPremiumSplitPage();
    expect(component.gotoPremiumSplitPage).toHaveBeenCalled();
  });

  it('call navigation to allocation chnnage page method', () => {    
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    spyOn(component, 'goToAllocationChange').and.callThrough();
    component.goToAllocationChange();
    expect(component.goToAllocationChange).toHaveBeenCalled();
  });

  it('call render premium split page method', () => {
    let data = {
      //'fromPage': 'transferFunds',
      "toPage":'allocationChange'
    }
    sharedService.setPageContent(data);
    spyOn(component, 'renderPremiumSplitPage').and.callThrough();
    component.renderPremiumSplitPage();
    expect(component.renderPremiumSplitPage).toHaveBeenCalled();
  });
});
