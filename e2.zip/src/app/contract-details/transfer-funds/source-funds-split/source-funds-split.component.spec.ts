import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatInputModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ContractDetailsModule } from '../../contract-details.module';

import { SourceFundsSplitComponent } from './source-funds-split.component';

describe('SourceFundsSplitComponent', () => {
  let component: SourceFundsSplitComponent;
  let fixture: ComponentFixture<SourceFundsSplitComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, MatInputModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    // }));

    // beforeEach(() => {
    fixture = TestBed.createComponent(SourceFundsSplitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
