import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../../allocation-change/allocation-change-service';


export interface FundSummaryDataBfre {
  fundName: String;
  unitPricePastLink: String;
  pastSplit: String;
}
export interface FundSummaryData {
  fundName: String;
  unitPriceNewLink: String;
  keyLink: String;
  newSplit: String;
}

@Component({
  selector: 'summry-transfer-funds',
  templateUrl: './summry-transfer-funds.component.html',
  styleUrls: ['./summry-transfer-funds.component.scss']
})
export class SummryTransferFundsComponent implements OnInit {

  displayedColumnsBfreTransferSummary: String[] = [
    'fundName',
    //'unitPrice',
    'unitPricePastLink', 'pastSplit'];
  displayedColumnsBfreTransferSummaryMob: String[] = [
    'fundName', 'pastSplit',
    'unitPricePastLink'];
  displayedColumnsAfterTransferSummary: String[] = ['fundName',
    'unitPriceNewLink',
    //'unitPrice',
    'keyLink',
    'newSplit'];
  displayedColumnsAfterTransferSummaryMob: String[] = ['fundName', 'newSplit',
    'unitPriceNewLink',
    'keyLink',
  ];
  dataSourceFundDetailsBfre: MatTableDataSource<FundSummaryDataBfre>;
  dataSourceFundDetails: MatTableDataSource<FundSummaryData>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  summaryDetBfre: any;
  summaryDetAfter: any;
  valuesSelectedArray: any;
  fundDataArr: any;
  sourceFundListResponse: any[];
  country: string;
  lang: string;
  @Output() flagValueChange = new EventEmitter();
  loggedInCountry: boolean;
  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private newPremiumService: AllocationChangeSharedService) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    this.loggedInCountry = UtilityService.getCountry();
    this.newPremiumService.getSourceFund().subscribe((data) => {
      this.sourceFundListResponse = [];
      this.sourceFundListResponse = data;
    })
    this.newPremiumService.getTransferFundSummary().subscribe((arr) => {
      this.fundDataArr = arr;
      if (this.fundDataArr != null) {
        this.callApi(arr);
      }
    });
  }

  callApi(data) {
    // const reqParam = {
    //   "processingSystem": "OLAS",
    //   "totalNewlyAllocatedPercentage": "100",
    //   "fundSwitchDTOs": this.fundDataArr
    // }
    // this.commonService.postData(this.baseUrl.ecustomer.allocationChangeSummary, reqParam, '').subscribe(data => {
    this.dataSourceFundDetailsBfre = new MatTableDataSource(data.sourceFunds);
    this.dataSourceFundDetails = new MatTableDataSource(data.targetFunds);
    //this.newPremiumService.setConfReqData(data);
    //})
  }

  checkClickedStatus(row) {
    row.keyLinkClicked = true;
    this.flagValueChange.emit(row);
    //console.log(row);
  }

}
