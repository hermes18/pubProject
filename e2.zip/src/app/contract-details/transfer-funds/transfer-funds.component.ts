import { Component, OnInit, ViewChild, AfterViewInit, ViewEncapsulation, ViewChildren, QueryList, Output, EventEmitter } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormGroup, FormControl, FormArray, NgForm, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material';
import { HttpCommonService } from '../../shared/services/http-common.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import * as utils from 'lodash';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../allocation-change/allocation-change-service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { SelectAccountFundsComponent } from './select-account-funds/select-account-funds.component';
import { SourceFundsSplitComponent } from './source-funds-split/source-funds-split.component';
import { DestinationFundsComponent } from './destination-funds/destination-funds.component';
import { SummryTransferFundsComponent } from './summry-transfer-funds/summry-transfer-funds.component';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'transfer-funds',
  templateUrl: './transfer-funds.component.html',
  styleUrls: ['./transfer-funds.component.scss']
})
export class TransferFundsComponent implements OnInit {
  confirmationPage: boolean = false;
  previouslySelectedstep = [];
  isStepInteracted = false;
  selectAccountForm: FormGroup;
  sourceFundStepForm: FormGroup;
  responseActiveOrder: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  FundAccountEmpty: boolean = false;
  totalShareError: boolean = false;
  selectAccountSecError: boolean = false;
  showOrderProcessingErr: boolean;
  selectedFundTotalErr: boolean;
  sourceFundFormErr: boolean;
  valuesSelectedArray: any[];
  fundDataArr: any;
  noChangeOfAllocationErrorRender: any;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  userrole: string;
  clientId: any;
  arraySelectedUnique: any;
  contractDetail: any;
  targetFunds: any;
  destinationFundForm: FormGroup;
  summaryTransferFund: any;
  confirmationData: any;
  userdetail: any;
  sourceFundList: any;
  minimumFundAllocationerr: boolean;
  renderSingleFundMesage: boolean;
  authorizationFlag: boolean;
  arraySelectedDestUnique: any;
  sourceUpdatedListEmpty: boolean;
  orderGeneratedError: boolean;
  step2Completed: boolean;
  step3Completed: boolean;
  keyLinkNotClicked: boolean;
  langChange: string;
  currencyType: string;
  destRefFundEmptyCnt: number = 0;
  destRefMinFundCnt: number = 0;
  srcRefMinFundCnt: number = 0;
  srcRefFundEmptyCnt: number = 0;
  fundTotalExceedsErr: boolean;
  step1Completed: any;
  destRefFundExceedsCnt: number;
  addPreviousFund: any;
  tempCalculatedPercent: number;
  searchedClientDetails: any;

  constructor(private translate: TranslateService, private _formBuilder: FormBuilder,
    private httpService: HttpCommonService, private router: Router,
    private route: ActivatedRoute,
    private newPremiumService: AllocationChangeSharedService,
    private sharedService: SharedServiceService,
    private menuItemService: MenuItemsService,
    private dialog: DialogService,
    public deviceDetector: DeviceDetectorService
  ) { }

  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.selectAccountForm = this._formBuilder.group({
    });
    this.sourceFundStepForm = this._formBuilder.group({
    });
    this.destinationFundForm = this._formBuilder.group({
    });
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
      this.currencyType = 'PLN';
    }
    else {
      this.displayRoOption = true;
      this.currencyType = 'RON';
    }
    this.userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    this.userrole = this.menuItemService.getAllRoles();
    // if (this.userrole === "rClient") {
    //   this.clientId = this.userdetail.clientID;
    // } else {
    //   this.clientId = customerId.clientID;
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (this.userdetail) {
      this.clientId = this.userdetail.clientId ? this.userdetail.clientId : '';
    }
    this.contractDetail = JSON.parse(sessionStorage.getItem('contractDetails'));
    this.searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
    ////console.log(this.searchedClientDetails)
    this.langChange = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if (this.langChange == "pl_en") {
      this.langChange = "en";
    } else if (this.langChange == "pl_pl") {
      this.langChange = "pl";
    } else if (this.langChange == "ro_en") {
      this.langChange = "en";
    } else if (this.langChange == "ro_ro") {
      this.langChange = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.langChange = data;
      }
    });
    if (this.isMobile && this.step == 0) {
      this.setFocus('selectAccountFormDiv');
    } else {
      //window.scroll(0,0);
    }
  }

  step = 0;
  @ViewChild(SelectAccountFundsComponent, { static: false }) selectAccRefComp: SelectAccountFundsComponent;
  @ViewChild(SourceFundsSplitComponent, { static: false }) selectFundRefComp: SourceFundsSplitComponent;
  @ViewChild(DestinationFundsComponent, { static: false }) destFundRefComp: DestinationFundsComponent;
  @ViewChild(SummryTransferFundsComponent, { static: false }) summaryRefComp: SummryTransferFundsComponent;

  setStep(index: number) {
    this.step = index;
  }

  nextStep(id) {
    ////("next step");
    //this.stepper.selectedIndex++;
    this.stepper.selected.completed = true;
    this.stepper.selectedIndex = this.stepper.selectedIndex + 1;

    if (this.isMobile) {
      this.setFocus(id);

    } else {
      //window.scroll(0,0);
    }
  }

  prevStep() {
    this.step--;
  }
  setFocus(id) {
    let targetElem = document.getElementById(id);

    // targetElem.scrollIntoView();
    //targetElem.focus();
    setTimeout(function waitTargetElem() {
      if (targetElem) {
        targetElem.scrollIntoView();
      } else {
        setTimeout(waitTargetElem, 100);
      }
    }, 100);
  }
  stepChangeDetection: boolean = false;
  onStepChange(event) {
    // if (event.previouslySelectedStep.completed) {
    //   this.stepChangeDetection = true;
    // }
    this.checkStepCompletionStatus(this.stepper['_selectedIndex']);
    if (event.selectedIndex == 0) {
      this.step1Completed = false;
      this.minimumFundAllocationerr = false;
      this.selectedFundTotalErr = false;
      this.sourceUpdatedListEmpty = false;
      this.fundTotalExceedsErr = false;
      this.renderSingleFundMesage = false;
      this.srcRefFundEmptyCnt = 0;
      this.srcRefMinFundCnt = 0;
      this.destRefFundEmptyCnt = 0;
      this.destRefMinFundCnt = 0;
      this.orderGeneratedError = false;
      this.authorizationFlag = false;
    } else if (event.selectedIndex == 1) {
      this.step2Completed = false;
      this.minimumFundAllocationerr = false;
      this.selectedFundTotalErr = false;
      this.sourceUpdatedListEmpty = false;
      this.fundTotalExceedsErr = false;
      this.renderSingleFundMesage = false;
      this.srcRefFundEmptyCnt = 0;
      this.srcRefMinFundCnt = 0;
      this.destRefFundEmptyCnt = 0;
      this.destRefMinFundCnt = 0;
      this.orderGeneratedError = false;
      this.authorizationFlag = false;
    } else if (event.selectedIndex == 2) {
      this.step3Completed = false;
      this.srcRefFundEmptyCnt = 0;
      this.srcRefMinFundCnt = 0;
      this.destRefFundEmptyCnt = 0;
      this.destRefMinFundCnt = 0;
      this.orderGeneratedError = false;
      this.authorizationFlag = false;
    } else { }
  }

  checkStepCompletionStatus(index) {
    if (this.stepper && this.stepper._steps['_results'][index].completed) {
      this.stepper['_elementRef'].nativeElement.querySelectorAll('.mat-step')[index].setAttribute('ariaChecked', true)
      return 'test';
    }
    // if (this.selectAccRefComp && this.selectAccRefComp.selectAccountForm.valid && this.selectAccRefComp.selectedRow
    //   && this.responseActiveOrder && !this.responseActiveOrder.activeOrderErrorRender) {
    //   return 'test';
    // }
  }



  @ViewChild('stepper', { static: false }) stepper: MatStepper;
  headers = new HttpHeaders();


  gotoStep(step) {
    this.stepper.selectedIndex = step;
  }

  changeSelection() {
    if (this.previouslySelectedstep.indexOf(0) && this.stepper && this.stepper['_selectedIndex'] !== 0) {
      return true;
    }
    return false;
  }

  validateSelectAccount(id) {
    //(this.selectAccRefComp.selectAccountForm)
    this.step1Completed = false;
    this.selectAccRefComp.submitSelectedAccount();
    if (this.selectAccRefComp.selectAccountForm.valid && this.selectAccRefComp.selectedRow) {
      this.FundAccountEmpty = false;
      this.minimumFundAllocationerr = false;
      this.selectedFundTotalErr = false;
      this.sourceUpdatedListEmpty = false;
      this.fundTotalExceedsErr = false;
      this.validateSelectedAccountDetails(this.selectAccRefComp.selectedRow, id);
    } else {
      this.FundAccountEmpty = true;
      this.minimumFundAllocationerr = false;
      this.selectedFundTotalErr = false;
      this.sourceUpdatedListEmpty = false;
      window.scrollTo(0, 0);
    }
  }

  validateSelectedAccountDetails(value, id) {
    const reqParam = {
      "policyNumber": value.policyNumber,//"21295126",
      "selectedInvestmentStrategy": "Fund Transfer",
      "investAccNumber": value.investAccNumber //"21295127"
    }
    this.httpService.postData(this.baseUrl.ecustomer.getActiveOrder, reqParam, this.headers).subscribe(data => {
      this.responseActiveOrder = data;
      if (!this.responseActiveOrder.activeOrderErrorRender) {
        this.showOrderProcessingErr = false;
        this.step1Completed = true;
        this.getFundList(id);
        // this.nextStep();
      } else {
        //error msg display
        this.showOrderProcessingErr = true;
        window.scrollTo(0, 0);
      }
      //this.getFundList();
    })
  }

  validateSelectFund(id) {
    this.step2Completed = false;
    this.stepper.selected.completed = false;
    this.selectFundRefComp.submitSelectedFund();
    this.FundAccountEmpty = false;
    if (this.selectFundRefComp.sourceFundForm.dirty || !this.renderSingleFundMesage) {
      if (((this.selectFundRefComp.sourceFundForm.controls['total'].value != 0))) {
        //  if (this.selectFundRefComp.sourceFundForm.controls['total'].value == '100') {
        let fundDataArr: any[];
        let arraySelected: any[];
        let minAmntCnt = 0;
        let totalCnt = 0;
        this.newPremiumService.getUpdatedSource().subscribe((arr) => {
          fundDataArr = arr;
          minAmntCnt = 0;
          totalCnt = 0;
          arraySelected = [];
          this.arraySelectedUnique = [];
          if (fundDataArr.length > 1) {
            fundDataArr.forEach((data) => {
              if (data.allocationPercentage != "0" && data.allocationPercentage != ""
                && data.allocationPercentage != "00" && data.allocationPercentage != "000") {
                if (arraySelected.length == 0) {
                  arraySelected.push(data);
                } else if (arraySelected.length > 1) {
                  if (arraySelected.includes(data.sort)) {
                    let index = arraySelected.findIndex(data.sort);
                    arraySelected.splice(index, 1);
                    arraySelected.push(data);
                  } else {
                    arraySelected.push(data);
                  }
                  // arraySelected.forEach((val) => {
                  //   if (val.fundId == data.fundId) {
                  //     arraySelected.splice(val, 1);
                  //     arraySelected.push(data);
                  //   } else {
                  //     arraySelected.push(data);
                  //   }
                  // })
                } else if (arraySelected.length == 1) {
                  if (arraySelected[0].fundId != data.fundId) {
                    arraySelected.push(data);
                  }

                }
              }
            });
          } else if (fundDataArr.length == 1) {
            arraySelected = fundDataArr;
          } else { }
          this.arraySelectedUnique = this.getUnique(arraySelected, 'sort')
          this.selectedFundTotalErr = false;
          //(this.arraySelectedUnique)
        });
        if (this.sourceFundList && !this.sourceFundList.sourceAllocationPercentageDisable) {
          if (this.arraySelectedUnique != null && this.arraySelectedUnique.length > 1) {
            // this.newPremiumService.setSummaryReqData(this.arraySelectedUnique);
            this.arraySelectedUnique.forEach((item) => {
              if ((parseFloat(item.remainingFund) != 0) &&
                ((parseFloat(item.remainingFund)) >= this.sourceFundList.minimumAmountPerFund)
                || ((parseFloat(item.allocationPercentage) == 100))) {
                //  minAmntCnt = minAmntCnt + 1;
              } else {
                // minAmntCnt = minAmntCnt > 0 ? minAmntCnt - 1 : 0;
                minAmntCnt = minAmntCnt + 1;
              }
              if ((parseFloat(item.allocationPercentage) <= 100)) {
                // totalCnt = totalCnt + 1;
              } else {
                //totalCnt = totalCnt > 0 ? totalCnt - 1 : 0;
                totalCnt = totalCnt + 1;
              }
            });
          } else {
            if ((parseFloat(this.arraySelectedUnique[0].remainingFund) != 0) && (parseFloat(this.arraySelectedUnique[0].remainingFund) >= this.sourceFundList.minimumAmountPerFund)
              || (parseFloat(this.arraySelectedUnique[0].allocationPercentage) == 100)) {
              // minAmntCnt = minAmntCnt + 1;
            } else {
              // minAmntCnt = minAmntCnt > 0 ? minAmntCnt - 1 : 0;
              minAmntCnt = minAmntCnt + 1;
            }
            if ((parseFloat(this.arraySelectedUnique[0].allocationPercentage) <= 100) || (parseFloat(this.arraySelectedUnique[0].allocationPercentage) <= 100)) {
              // totalCnt = totalCnt + 1;
            } else {
              // totalCnt = totalCnt > 0 ? totalCnt - 1 : 0;
              totalCnt = totalCnt + 1;
            }
          }
          if (minAmntCnt <= 0 && totalCnt <= 0) {//if (minAmntCnt >= 0 && totalCnt >= 0) {
            this.minimumFundAllocationerr = false;
            this.sourceUpdatedListEmpty = false;
            //if (this.selectFundRefComp.sourceFundForm.controls['total'].value <= '100') { total not needed
            this.selectedFundTotalErr = false;
            this.fundTotalExceedsErr = false;
            this.validateSourceFund(id);
            // } else {
            //   this.selectedFundTotalErr = true;
            //   this.minimumFundAllocationerr = false;
            //   this.sourceUpdatedListEmpty = false;
            //   window.scrollTo(0, 0);
            // }
          } else if (minAmntCnt > 0 && totalCnt <= 0) {
            this.minimumFundAllocationerr = true;
            this.selectedFundTotalErr = false;
            this.sourceUpdatedListEmpty = false;
            this.fundTotalExceedsErr = false;
            window.scrollTo(0, 0);
          } else if (minAmntCnt <= 0 && totalCnt > 0) {
            this.minimumFundAllocationerr = false;
            this.selectedFundTotalErr = false;
            this.sourceUpdatedListEmpty = false;
            this.fundTotalExceedsErr = true;
            window.scrollTo(0, 0);
          } else {
            this.minimumFundAllocationerr = false;
            this.selectedFundTotalErr = false;
            this.sourceUpdatedListEmpty = false;
            this.fundTotalExceedsErr = false;
            this.validateSourceFund(id);
          }

        } else {
          this.minimumFundAllocationerr = false;
          this.selectedFundTotalErr = false;
          this.sourceUpdatedListEmpty = false;
          this.fundTotalExceedsErr = false;
          this.validateSourceFund(id);
        }
        //this.nextStep();
      } else {
        this.sourceUpdatedListEmpty = true;
        this.minimumFundAllocationerr = false;
        this.selectedFundTotalErr = false;
        this.fundTotalExceedsErr = false;
        window.scrollTo(0, 0);
        //form empty error
      }
    }
    // } else {
    //   //form empty
    //   this.selectedFundTotalErr = true;
    //   window.scrollTo(0, 0);
    // }
  }

  getUnique(arr, comp) {
    // store the comparison  values in array
    const unique = arr.map(e => e[comp])
      // store the indexes of the unique objects
      .map((e, i, final) => final.indexOf(e) === i && i)
      // eliminate the false indexes & return unique objects
      .filter((e) => arr[e]).map(e => arr[e]);
    return unique;
  }

  validateDestinationSelectedFund(id) {
    this.step3Completed = false;
    this.stepper.selected.completed = false;
    this.destFundRefComp.submitSelectedFund();
    this.FundAccountEmpty = false;
    if (this.destFundRefComp.destinationFundForm.dirty) { // && this.destFundRefComp.destinationFundForm.valid
      if (this.destFundRefComp.destinationFundForm.controls['total'].value != '0') {
        let fundDataArr: any[];
        let arraySelected: any[];
        this.newPremiumService.getUpdatedDestination().subscribe((arr) => {
          fundDataArr = arr;
          arraySelected = [];
          this.arraySelectedDestUnique = [];
          if (fundDataArr.length > 1) {
            fundDataArr.forEach((data) => {
              if (data.allocationPercentage != "0" && data.allocationPercentage != "") {
                if (arraySelected.length == 0) {
                  arraySelected.push(data);
                } else if (arraySelected.length > 1) {
                  if (arraySelected.includes(data.sort)) {
                    let index = arraySelected.findIndex(data.sort);
                    arraySelected.splice(index, 1);
                    arraySelected.push(data);
                  } else {
                    arraySelected.push(data);
                  }
                  // arraySelected.forEach((val) => {
                  //   if (val.sort == data.sort) {
                  //     let index = arraySelected.findIndex(val);
                  //     arraySelected.splice(index, 1);
                  //     arraySelected.push(data);
                  //   } else {
                  //     arraySelected.push(data);
                  //   }
                  // })
                } else if (arraySelected.length == 1) {
                  if (arraySelected[0].sort != data.sort) {
                    arraySelected.push(data);
                  }

                }
              }
            });
          } else if (fundDataArr.length == 1) {
            arraySelected = fundDataArr;
          } else { }
          this.arraySelectedDestUnique = this.getUnique(arraySelected, 'sort')
          this.selectedFundTotalErr = false;
          //(this.arraySelectedDestUnique)
        });

        if (this.arraySelectedDestUnique != null && this.arraySelectedDestUnique.length > 0) {
          // this.newPremiumService.setSummaryReqData(this.arraySelectedUnique);
          this.validateDestinationFunds(id);
        }
        //this.nextStep();
      } else {
        this.selectedFundTotalErr = true;
        window.scrollTo(0, 0);
        //total value error
      }
    } else {
      //form empty
      this.selectedFundTotalErr = true;
      window.scrollTo(0, 0);
    }
  }
  // callApi(arraySelected) {
  //   const reqParam = {
  //     "processingSystem": this.contractDetail ? this.contractDetail.processingSystem : '',
  //     "totalNewlyAllocatedPercentage": "100",
  //     "fundSwitchDTOs": arraySelected//this.fundDataArr
  //   }
  //   this.httpService.postData(this.baseUrl.ecustomer.allocationChangeSummary, reqParam, '').subscribe(data => {
  //     // this.dataSourceFundDetailsBfre = new MatTableDataSource(data.fundsPriorToChange);
  //     // this.dataSourceFundDetails = new MatTableDataSource(data.fundsAfterChange);
  //     this.newPremiumService.setConfReqData(data);
  //     this.noChangeOfAllocationErrorRender = data.noChangeOfAllocationErrorRender;
  //     if (data != null && !data.noChangeOfAllocationErrorRender && !this.selectedFundTotalErr) {
  //       this.nextStep();
  //     }
  //   })
  // }
  gotoPremiumSplitPage() {
    // this.gotoPremiumSplit = true;
    //this.valueChange.emit('allocationChange');
    //this.sharedService.setPageContent('singlePremium');
    let data = {
      //'fromPage': 'transferFunds',
      "toPage": 'orderInvest'
    }
    this.sharedService.setPageContent(data);
  }

  getFundList(id) {
    const reqParam = {
      "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295126",
      "clientId": this.clientId,//"101583",
      "selectedInvestmentStrategy": "Fund Transfer",
      "processingSystem": this.contractDetail ? this.contractDetail.processingSystem : '',
      "investmentData": {
        "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,// "21295126",
        "investAccType": this.selectAccRefComp.selectedRow.investAccType, //1,
        "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295126",
        "effectiveDate": this.selectAccRefComp.selectedRow.effectiveDate,//1276626600000,
        "status": this.selectAccRefComp.selectedRow.status,//23,
        "investValue": this.selectAccRefComp.selectedRow.investValue,//2864.17,
        "productPlan": this.selectAccRefComp.selectedRow.productPlan,//"UB2B000K3",
        //"bankAccount": this.selectAccRefComp.selectedRow.bankAccount,//"59 1030 1944 9000 0500 2129 5126",
        "valuationDt": this.selectAccRefComp.selectedRow.valuationDt,//1332268200000
        "activeOrderErrorRender": this.responseActiveOrder.activeOrderErrorRender,//false,
        "authorizationErrorRender": false,//this.responseActiveOrder.authorizationErrorRender,//false,
        "orderErrorRender": false//this.responseActiveOrder.orderErrorRender//false
      }
    }
    this.httpService.postData(this.baseUrl.ecustomer.sourceFund, reqParam, '').subscribe(data => {
      if (data != null) {
        this.sourceFundList = [];
        this.sourceFundList = data;
        this.newPremiumService.setSourceFund(this.sourceFundList);
        // if (!data.activeOrderErrorRender) {
        //   this.nextStep();
        // } else {
        //   this.showOrderProcessingErr = true;
        //   window.scrollTo(0, 0);
        // }
        this.nextStep(id);
        if (this.isMobile && this.step1Completed) {
          this.setFocus("selectAccountFormDiv");

        } else {
          //window.scroll(0,0);
        }
      }
    });
  }

  validateSourceFund(id) {
    //  if (this.selectFundRefComp.sourceFundForm.controls['total'].value <= '100') {
    const reqParam = {
      "sourceFunds": this.arraySelectedUnique,
      "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295126",
      "clientId": this.clientId,//"101583",
      "selectedInvestmentStrategy": "Fund Transfer",
      "processingSystem": this.contractDetail.processingSystem,//"OLAS",
      "totalSourceFundTransferAmount": this.selectFundRefComp.sourceFundForm.controls['totalSourceFundTransferAmount'].value,//100,
      "minimumAllocationPerFund": this.selectFundRefComp.sourceFundForm.controls['minimumAmountPerFund'].value,//100,
      "renderSingleFundMesage": this.sourceFundList.renderSingleFundMesage,
      "investmentData": {
        "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,//"21295126",
        "investAccType": this.selectAccRefComp.selectedRow.investAccType,//2,
        "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21296299",
        "effectiveDate": this.selectAccRefComp.selectedRow.effectiveDate,
        "status": this.selectAccRefComp.selectedRow.status,//23,
        "investValue": this.selectAccRefComp.selectedRow.investValue,//9772.71,
        "productPlan": this.selectAccRefComp.selectedRow.productPlan,//"UB2B000K3",
        //"bankAccount": this.selectAccRefComp.selectedRow.bankAccount,//"10 1030 1944 9000 0500 2129 6299",
        "valuationDt": this.selectAccRefComp.selectedRow.valuationDt,//1332268200000,
        "activeOrderErrorRender": this.responseActiveOrder.activeOrderErrorRender,//false,
        "authorizationErrorRender": this.responseActiveOrder.authorizationErrorRender,//false,
        "orderErrorRender": this.responseActiveOrder.orderErrorRender,//false
      }
    }
    this.httpService.postData(this.baseUrl.ecustomer.targetFund, reqParam, this.headers).subscribe(data => {
      this.targetFunds = data;
      this.newPremiumService.setDestinationFund(data);
      this.step2Completed = true;
      this.stepper.selected.completed = true;
      this.minimumFundAllocationerr = false;
      this.selectedFundTotalErr = false;
      this.renderSingleFundMesage = false;
      this.nextStep(id);
    });
    // } else {
    //   this.selectedFundTotalErr = true;
    //   window.scrollTo(0, 0);
    //   //total value error
    // }
  }

  validateDestinationFunds(id) {
    let cnt = 0;
    let singleCnt = 0;
    //if (this.destFundRefComp.destinationFundForm.controls['totalAmnt'].value >= this.sourceFundList.minimumAmountPerFund) {
    if (!this.targetFunds.renderSingleFundMesage) {
      this.destFundRefComp.destinationFundForm.controls['fundListArray'].value.forEach((item) => {
        if (item.allocationPercentage != 0 && item.addedPreviousFundTotal != item.fundValue &&
          item.minimumAmountPerFund != null && (parseFloat(item.addedPreviousFundTotal) < parseFloat(item.minimumAmountPerFund))) {
          //this.minimumFundAllocationerr = true;
          cnt = cnt + 1;
        } else {
          //cnt = cnt - 1;
          // this.minimumFundAllocationerr = false;
        }
      })
      this.minimumFundAllocationerr = cnt > 0 ? true : false;
      if (!this.minimumFundAllocationerr) {
        if (this.destFundRefComp.destinationFundForm.controls['total'].value == 100) {
          const reqParam = {
            "investmentData": {
              //"policyNumber": this.selectAccRefComp.selectedRow.policyNumber,//"21295126",
              "investAccType": this.selectAccRefComp.selectedRow.investAccType,//2,
              //"investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21296299",
              "effectiveDate": this.selectAccRefComp.selectedRow.effectiveDate,
              "status": this.selectAccRefComp.selectedRow.status,//23,
              "investValue": this.selectAccRefComp.selectedRow.investValue,//9772.71,
              "productPlan": this.selectAccRefComp.selectedRow.productPlan,//"UB2B000K3",
              //"bankAccount": this.selectAccRefComp.selectedRow.bankAccount,//"10 1030 1944 9000 0500 2129 6299",
              "valuationDt": this.selectAccRefComp.selectedRow.valuationDt,//1332268200000,
              "activeOrderErrorRender": this.responseActiveOrder.activeOrderErrorRender,//false,
              "authorizationErrorRender": this.responseActiveOrder.authorizationErrorRender,//false,
              "orderErrorRender": this.responseActiveOrder.orderErrorRender//false
            },
            //"investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295126",
            "clientId": this.clientId,//"101583",
            "selectedInvestmentStrategy": "Fund Transfer",
            "processingSystem": this.contractDetail.processingSystem,//"OLAS",
            "totalTargetPercentage": 100,
            "targetFunds": this.arraySelectedDestUnique,//this.destFundRefComp.destinationFundForm.controls['fundListArray'].value,
            "sourceFunds": this.arraySelectedUnique//this.selectFundRefComp.sourceFundForm.controls['fundListArray'].value

          }
          this.httpService.postData(this.baseUrl.ecustomer.fundTransferSummary, reqParam, this.headers).subscribe(data => {
            this.summaryTransferFund = data;
            this.newPremiumService.setTransferFundSummary(data);
            this.selectedFundTotalErr = false;
            this.minimumFundAllocationerr = false;
            this.renderSingleFundMesage = false;
            this.step3Completed = true;
            this.stepper.selected.completed = true;
            this.nextStep(id);
          });
        } else {
          this.selectedFundTotalErr = true;
          window.scroll(0, 0);
          //total value error
        }
      } else {
        this.minimumFundAllocationerr = true;
        window.scrollTo(0, 0);
      }
    } else {
      //render flag err
      this.destFundRefComp.destinationFundForm.controls['fundListArray'].value.forEach((item) => {
        if (item.allocationPercentage != 0 && item.allocationPercentage != 100) {
          singleCnt = singleCnt + 1;
        } else {
          //singleCnt = singleCnt + -1;
        }
      })
      this.renderSingleFundMesage = singleCnt > 0 ? true : false;
      if (!this.renderSingleFundMesage) {
        if (this.destFundRefComp.destinationFundForm.controls['total'].value == 100) {
          const reqParam = {
            "investmentData": {
              // "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,//"21295126",
              "investAccType": this.selectAccRefComp.selectedRow.investAccType,//2,
              // "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21296299",
              "effectiveDate": this.selectAccRefComp.selectedRow.effectiveDate,
              "status": this.selectAccRefComp.selectedRow.status,//23,
              "investValue": this.selectAccRefComp.selectedRow.investValue,//9772.71,
              "productPlan": this.selectAccRefComp.selectedRow.productPlan,//"UB2B000K3",
              // "bankAccount": this.selectAccRefComp.selectedRow.bankAccount,//"10 1030 1944 9000 0500 2129 6299",
              "valuationDt": this.selectAccRefComp.selectedRow.valuationDt,//1332268200000,
              "activeOrderErrorRender": this.responseActiveOrder.activeOrderErrorRender,//false,
              "authorizationErrorRender": this.responseActiveOrder.authorizationErrorRender,//false,
              "orderErrorRender": this.responseActiveOrder.orderErrorRender//false
            },
            //"investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295126",
            "clientId": this.clientId,//"101583",
            "selectedInvestmentStrategy": "Fund Transfer",
            "processingSystem": this.contractDetail.processingSystem,//"OLAS",
            "totalTargetPercentage": 100,
            "targetFunds": this.arraySelectedDestUnique,//this.destFundRefComp.destinationFundForm.controls['fundListArray'].value,
            "sourceFunds": this.arraySelectedUnique//this.selectFundRefComp.sourceFundForm.controls['fundListArray'].value

          }
          this.httpService.postData(this.baseUrl.ecustomer.fundTransferSummary, reqParam, this.headers).subscribe(data => {
            this.summaryTransferFund = data;
            this.newPremiumService.setTransferFundSummary(data);
            this.selectedFundTotalErr = false;
            this.minimumFundAllocationerr = false;
            this.renderSingleFundMesage = false;
            this.step3Completed = true;
            this.stepper.selected.completed = true;
            this.nextStep(id);
          });
        } else {
          this.selectedFundTotalErr = true;
          window.scrollTo(0, 0);
          //total value error
        }
      } else {
        this.renderSingleFundMesage = true;
        window.scrollTo(0, 0);
      }
    }
    // } else {
    //   this.minimumFundAllocationerr = true;
    //   window.scrollTo(0, 0);
    // }
  }

  callConfirmationApi() {
    if (this.country === 'ro') {
      let clickedCnt = 0;
      let clickedIds = [];
      if (this.summaryTransferFund.targetFunds.length > 1) {
        this.summaryTransferFund.targetFunds.forEach(val => {
          if (val.keyLinkClicked && val.keyLinkClicked == true) {
            clickedCnt = clickedCnt + 1;
          } else { }
        })
      } else {
        if (this.summaryTransferFund.targetFunds[0].keyLinkClicked &&
          this.summaryTransferFund.targetFunds[0].keyLinkClicked == true) {
          clickedCnt = clickedCnt + 1;
        } else { }
      }
      if (clickedCnt == this.summaryTransferFund.targetFunds.length) {
        this.executeConfirmationApi();
      } else {
        //console.log('display alert');
        this.dialog.openDialog(AlertDialogComponent, { 'heading': '', 'body': this.translate.instant("eCustomer.orderInvest.readKidAnnexErrMsg") });
        return false
      }
    } else { this.executeConfirmationApi(); }
  }

  executeConfirmationApi() {
    let request = {
      "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,//"21295126",
      "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295127",
      "investAccType": this.selectAccRefComp.selectedRow.investAccType,//"1",
      "productPlan": this.selectAccRefComp.selectedRow.productPlan,
      "processingSystem": this.contractDetail ? this.contractDetail.processingSystem : '',
      "firstName": this.userdetail.firstName, //"fname",
      "lastName": this.userdetail.lastName,//"lastName",
      "userName": this.userdetail.userName,//"Testuser210",
      "country": this.country,//"pl",
      "language": this.lang,//"en",
      "userRole": this.userrole ? this.userrole : 'NoRole',//"rAdvisor",
      "clientId": this.clientId,
      "clientFirstName": this.searchedClientDetails ? this.searchedClientDetails.clientFirstName : this.userdetail.firstName,
      "clientLastName": this.searchedClientDetails ? this.searchedClientDetails.clientLastName : this.userdetail.lastName,
      "clientUserName": this.userrole == 'rClient' ? this.userdetail.userName : null,
      "selectedInvestmentStrategy": "Fund Transfer",
      "totalTargetPercentage": this.summaryTransferFund.totalTargetPercentage,//100,
      "sourceAllocationPercentageDisable": this.summaryTransferFund.sourceAllocationPercentageDisable,//false,
      "investmentData": {
        "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,//"21295126",
        "investAccType": this.selectAccRefComp.selectedRow.investAccType,//2,
        "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21296299",
        "effectiveDate": this.selectAccRefComp.selectedRow.effectiveDate,
        "status": this.selectAccRefComp.selectedRow.status,//23,
        "investValue": this.selectAccRefComp.selectedRow.investValue,//9772.71,
        "productPlan": this.selectAccRefComp.selectedRow.productPlan,//"UB2B000K3",
        "bankAccount": this.selectAccRefComp.selectedRow.bankAccount,//"10 1030 1944 9000 0500 2129 6299",
        "valuationDt": this.selectAccRefComp.selectedRow.valuationDt,//1332268200000,
        "activeOrderErrorRender": this.responseActiveOrder.activeOrderErrorRender,//false,
        "authorizationErrorRender": this.responseActiveOrder.authorizationErrorRender,//false,
        "orderErrorRender": this.responseActiveOrder.orderErrorRender//false
      },
      "debitedSourceFunds": this.summaryTransferFund.sourceFunds,
      "noSourcePercentageAllocationError": this.summaryTransferFund ? this.summaryTransferFund.noSourcePercentageAllocationError : false,
      "targetAllocationPercentageDisable": this.summaryTransferFund ? this.summaryTransferFund.noSourcePercentageAllocationError : false,
      "creditedTargetFunds": this.summaryTransferFund.targetFunds,
      "orderCutOffMessageRender": this.summaryTransferFund.orderCutOffMessageRender//false
    }
    //console.log('call confirmation api');
    this.httpService.postData(this.baseUrl.ecustomer.fundTransferConfirmation, request, '').subscribe(data => {
      if (data.hasOwnProperty('activeUser') && (data.activeUser == false)) {
        this.router.navigate(['/logout']);
      } else {
        if (!data.authorizationErrorRender) {
          this.authorizationFlag = false;
          this.confirmationData = data;
          if (this.confirmationData != null && this.confirmationData.orderId != null && !this.confirmationData.activeOrderErrorRender) {
            this.confirmationPage = true;
            this.orderGeneratedError = false;
            this.newPremiumService.setTransferFundConfRes(this.confirmationData);
            if (this.isMobile && this.confirmationPage) {
              this.setFocus('confirmationFundFormDiv');
              window.scroll(0, 0);
            } else {
              //window.scroll(0,0);
            }
          } else { this.confirmationPage = false; this.orderGeneratedError = true; }
        } else {
          this.authorizationFlag = true;
          this.confirmationPage = false;
          this.orderGeneratedError = false;
          window.scrollTo(0, 0);
        }
      }
    });
  }

  getSrcFlagValue(evt) {
    //console.log('setOutput', evt)
    if (evt) {
      if (evt.get('totalExceedsErr').value) {
        this.selectedFundTotalErr = false;
        this.minimumFundAllocationerr = false;
        this.sourceUpdatedListEmpty = false;
        this.fundTotalExceedsErr = true;
        this.checkSourceArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('minFundErr').value) {
        this.minimumFundAllocationerr = true;
        this.selectedFundTotalErr = false;
        this.sourceUpdatedListEmpty = false;
        this.fundTotalExceedsErr = false;
        this.checkSourceArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('sourceFundEmptyErr').value) {
        this.selectedFundTotalErr = false;
        this.minimumFundAllocationerr = false;
        this.sourceUpdatedListEmpty = true;
        this.fundTotalExceedsErr = false;
        //this.checkSourceArrayValidations();
        window.scrollTo(0, 0);
      } else {
        this.minimumFundAllocationerr = false;
        this.selectedFundTotalErr = false;
        this.sourceUpdatedListEmpty = false;
        this.fundTotalExceedsErr = false;
        this.checkSourceArrayValidations();
      }
    } else {
      this.minimumFundAllocationerr = false;
      this.selectedFundTotalErr = false;
      this.sourceUpdatedListEmpty = false;
      this.fundTotalExceedsErr = false;
      this.checkSourceArrayValidations();
    }
  }

  checkSourceArrayValidations() {
    this.srcRefMinFundCnt = 0;
    this.srcRefFundEmptyCnt = 0;
    this.selectFundRefComp.sourceFundForm['controls'].fundListArray['controls'].forEach(element => {
      if (parseFloat(element.get('allocationPercentage').value) != 0) {
        if (element.get('minFundErr').value == true) {
          // element.fundEmptyErr =false;
          // element.minFundErr = true;
          element.get('totalExceedsErr').setValue(false);
          element.get('minFundErr').setValue(true);
          this.srcRefMinFundCnt = this.srcRefMinFundCnt + 1;
        } else {
          //element.minFundErr = true;
          element.get('minFundErr').setValue(false);
          this.srcRefMinFundCnt = element.get('minFundErr').value && this.srcRefMinFundCnt > 0 ? this.srcRefMinFundCnt - 1 : this.srcRefMinFundCnt;
          if (parseFloat(element.get('allocationPercentage').value) > 100) {
            element.get('totalExceedsErr').setValue(true);
            this.srcRefFundEmptyCnt = this.srcRefFundEmptyCnt + 1;
          }
        }
      } else {
        element.get('totalExceedsErr').setValue(false);
        element.get('minFundErr').setValue(false);
        // this.srcRefFundEmptyCnt = (element.get('totalExceedsErr').value && this.srcRefFundEmptyCnt > 0) ? this.srcRefFundEmptyCnt - 1 : 0;
        this.srcRefMinFundCnt = (element.get('minFundErr').value && this.srcRefMinFundCnt > 0) ? this.srcRefMinFundCnt - 1 : this.srcRefMinFundCnt;
      }
    });
    if ((this.srcRefMinFundCnt > 0 || this.minimumFundAllocationerr == true) && (this.selectFundRefComp.sourceFundForm.controls['total'].value != 0)) {
      this.minimumFundAllocationerr = true;
    } else {
      this.minimumFundAllocationerr = false;
    }
    if (this.srcRefFundEmptyCnt > 0 && (this.selectFundRefComp.sourceFundForm.controls['total'].value != 0)) {
      // this.selectedFundTotalErr = true;
      this.fundTotalExceedsErr = true;
    } else {
      this.fundTotalExceedsErr = false;
    }
  }

  getDestFlagValue(evt) {
    //console.log('setOutput', evt)
    if (evt) {
      if (evt.get('fundEmptyErr').value) {
        this.selectedFundTotalErr = true;
        this.minimumFundAllocationerr = false;
        this.renderSingleFundMesage = false;
        this.sourceUpdatedListEmpty = false;
        this.fundTotalExceedsErr = false;
        this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('minFundErr').value) {
        this.minimumFundAllocationerr = true;
        this.selectedFundTotalErr = false;
        this.renderSingleFundMesage = false;
        this.fundTotalExceedsErr = false;
        this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('singleFundErr').value) {
        this.minimumFundAllocationerr = false;
        this.selectedFundTotalErr = false;
        this.renderSingleFundMesage = true;
        this.fundTotalExceedsErr = false;
        this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('minFundErr').value && evt.get('fundEmptyErr').value) {
        this.minimumFundAllocationerr = true;
        this.selectedFundTotalErr = true;
        this.renderSingleFundMesage = false;
        this.fundTotalExceedsErr = false;
        this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('totalExceedsErr').value) {
        this.minimumFundAllocationerr = false;
        this.selectedFundTotalErr = false;
        this.renderSingleFundMesage = false;
        this.fundTotalExceedsErr = true;
        this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else {
        this.minimumFundAllocationerr = false;
        this.selectedFundTotalErr = false;
        this.renderSingleFundMesage = false;
        this.fundTotalExceedsErr = false;
        this.checkArrayValidations();
      }
    } else {
      this.minimumFundAllocationerr = false;
      this.selectedFundTotalErr = false;
      this.renderSingleFundMesage = false;
      this.fundTotalExceedsErr = false;
      this.checkArrayValidations();
    }
  }

  checkArrayValidations() {
    this.destRefFundEmptyCnt = 0;
    this.destRefMinFundCnt = 0;
    this.destRefFundExceedsCnt = 0;
    this.destFundRefComp.destinationFundForm['controls'].fundListArray['controls'].forEach(element => {
      if (parseFloat(element.get('allocationPercentage').value) != 0 && (element.get('allocationPercentage').value != "")) {
        this.tempCalculatedPercent = (parseFloat(element.get('allocationPercentage').value) / 100) * (this.destFundRefComp.destinationFundResponse.totalSourceFundTransferAmount);
        this.addPreviousFund = element.get('fundValue').value + this.tempCalculatedPercent;
        if (element.get('minFundErr').value == true || (this.addPreviousFund < element.get('minimumAmountPerFund').value)) {
          if (this.destFundRefComp.totalTempData > 100 && parseFloat(element.get('allocationPercentage').value) < 100 && element.get('allocationPercentage').value != '') {
            // element.fundEmptyErr =true;
            element.minFundErr = true;
            if ((this.destFundRefComp.totalTempData - parseFloat(element.get('allocationPercentage').value) <= 100)) {
              element.get('fundEmptyErr').setValue(true);
              element.get('minFundErr').setValue(false);
              this.destRefFundEmptyCnt = this.destRefFundEmptyCnt + 1;
              // this.destRefMinFundCnt = this.destRefMinFundCnt + 1;
            } else {
              element.get('fundEmptyErr').setValue(false);
              element.get('minFundErr').setValue(true);
              element.get('totalExceedsErr').setValue(true);
              this.destRefFundExceedsCnt = this.destRefFundExceedsCnt + 1;
              this.destRefMinFundCnt = this.destRefMinFundCnt + 1;
            }
          } else if (this.destFundRefComp.totalTempData > 100 && parseFloat(element.get('allocationPercentage').value) == 100 && element.get('allocationPercentage').value != '') {
            // element.fundEmptyErr =true;
            // element.minFundErr = true;
            if (this.destRefFundExceedsCnt <= 0) {
              element.get('fundEmptyErr').setValue(true);
              element.get('minFundErr').setValue(false);
              this.destRefFundEmptyCnt = this.destRefFundEmptyCnt + 1;
              // this.destRefMinFundCnt = this.destRefMinFundCnt + 1;
            } else {
              element.get('fundEmptyErr').setValue(false);
              element.get('minFundErr').setValue(true);
              element.get('totalExceedsErr').setValue(true);
              this.destRefFundExceedsCnt = this.destRefFundExceedsCnt + 1;
              this.destRefMinFundCnt = this.destRefMinFundCnt + 1;
            }
          } else {
            // element.fundEmptyErr =false;
            // element.minFundErr = true;
            if (parseFloat(element.get('allocationPercentage').value) == 100 && this.destFundRefComp.totalTempData == 100) {
              element.get('fundEmptyErr').setValue(false);
              element.get('minFundErr').setValue(false);
              this.destRefFundEmptyCnt = (parseFloat(element.get('allocationPercentage').value) != 0 && !element.get('fundEmptyErr').value && this.destRefFundEmptyCnt > 0) ? this.destRefFundEmptyCnt - 1 : this.destRefFundEmptyCnt;
              this.destRefMinFundCnt = (!element.get('minFundErr').value && this.destRefMinFundCnt > 0) ? this.destRefMinFundCnt - 1 : this.destRefMinFundCnt;
            } else {
              if ((element.get('minFundErr').value == true) || (this.addPreviousFund != 0 && this.destFundRefComp.totalTempData < 100 && this.addPreviousFund < element.get('minimumAmountPerFund').value)) {
                element.get('fundEmptyErr').setValue(false);
                element.get('minFundErr').setValue(true);
                this.destRefMinFundCnt = this.destRefMinFundCnt + 1;
              }
              if (this.destFundRefComp.totalTempData > 100 && parseFloat(element.get('allocationPercentage').value) > 100) {
                element.get('totalExceedsErr').setValue(true);
                this.destRefFundExceedsCnt = this.destRefFundExceedsCnt + 1;
              } else {
                element.get('totalExceedsErr').setValue(false);
                this.destRefFundExceedsCnt = (parseFloat(element.get('allocationPercentage').value) != 0 && !element.get('totalExceedsErr').value && this.destRefFundExceedsCnt > 0) ? this.destRefFundExceedsCnt - 1 : this.destRefFundExceedsCnt;
              }
            }
          }
        } else {
          //this.destRefMinFundCnt = (!element.get('minFundErr').value && this.destRefMinFundCnt > 0) ? this.destRefMinFundCnt - 1 : this.destRefMinFundCnt;
          //element.minFundErr = true;
          // element.get('minFundErr').setValue(false);
          // this.destRefMinFundCnt = this.destRefMinFundCnt - 1;
          if (this.destFundRefComp.totalTempData > 100 && parseFloat(element.get('allocationPercentage').value) <= 100 && element.get('allocationPercentage').value != '') {
            // element.fundEmptyErr =true;
            // element.minFundErr = true;
            // element.get('fundEmptyErr').setValue(true);
            // this.destRefFundEmptyCnt = this.destRefFundEmptyCnt + 1;
            if (this.destRefFundExceedsCnt <= 0) {
              element.get('fundEmptyErr').setValue(true);
              element.get('minFundErr').setValue(false);
              this.destRefFundEmptyCnt = this.destRefFundEmptyCnt + 1;
              // this.destRefMinFundCnt = this.destRefMinFundCnt + 1;
            } else {
              element.get('fundEmptyErr').setValue(false);
              element.get('minFundErr').setValue(false);
              element.get('totalExceedsErr').setValue(true);
              this.destRefFundExceedsCnt = this.destRefFundExceedsCnt + 1;
            }
          } else {
            if (this.destFundRefComp.totalTempData > 100 && parseFloat(element.get('allocationPercentage').value) > 100) {
              element.get('totalExceedsErr').setValue(true);
              element.get('fundEmptyErr').setValue(false);
              element.get('minFundErr').setValue(false);
              this.destRefFundExceedsCnt = this.destRefFundExceedsCnt + 1;
              this.destRefFundEmptyCnt = (parseFloat(element.get('allocationPercentage').value) != 0 && !element.get('fundEmptyErr').value && this.destRefFundEmptyCnt > 0) ? this.destRefFundEmptyCnt - 1 : this.destRefFundEmptyCnt;
            } else {
              element.get('totalExceedsErr').setValue(false);
              if ((element.get('minFundErr').value == true) || (this.addPreviousFund != 0 && this.destFundRefComp.totalTempData <= 100 && this.addPreviousFund < element.get('minimumAmountPerFund').value)) {
                element.get('minFundErr').setValue(true);
                this.destRefMinFundCnt = this.destRefMinFundCnt + 1;
              } else {
                element.get('minFundErr').setValue(false);
              }
              this.destRefFundExceedsCnt = (parseFloat(element.get('allocationPercentage').value) != 0 && !element.get('totalExceedsErr').value && this.destRefFundExceedsCnt > 0) ? this.destRefFundExceedsCnt - 1 : this.destRefFundExceedsCnt;
            }
            // element.fundEmptyErr =false;
            // element.minFundErr = true;
            this.destRefFundEmptyCnt = (parseFloat(element.get('allocationPercentage').value) != 0 && !element.get('fundEmptyErr').value && this.destRefFundEmptyCnt > 0) ? this.destRefFundEmptyCnt - 1 : this.destRefFundEmptyCnt;
            element.get('fundEmptyErr').setValue(false);
          }
        }
      } else {
        if (element.get('allocationPercentage').value == "" || parseFloat(element.get('allocationPercentage').value) != 0) {
          element.get('fundEmptyErr').setValue(false);
          element.get('minFundErr').setValue(false);
          element.get('totalExceedsErr').setValue(false);
        } else {
          this.destRefMinFundCnt = (parseFloat(element.get('allocationPercentage').value) != 0 && !element.get('minFundErr').value && this.destRefMinFundCnt > 0) ? this.destRefMinFundCnt - 1 : this.destRefMinFundCnt;
          this.destRefFundEmptyCnt = (parseFloat(element.get('allocationPercentage').value) != 0 && !element.get('fundEmptyErr').value && this.destRefFundEmptyCnt > 0) ? this.destRefFundEmptyCnt - 1 : this.destRefFundEmptyCnt;
          element.get('fundEmptyErr').setValue(false);
          element.get('minFundErr').setValue(false);
          element.get('totalExceedsErr').setValue(false);
          this.destRefFundExceedsCnt = (parseFloat(element.get('allocationPercentage').value) != 0 && !element.get('totalExceedsErr').value && this.destRefFundExceedsCnt > 0) ? this.destRefFundExceedsCnt - 1 : this.destRefFundExceedsCnt;
          // this.destRefFundEmptyCnt = this.destRefFundEmptyCnt - 1;
          // this.destRefMinFundCnt = this.destRefMinFundCnt - 1;
        }
      }
    });
    if (this.destRefMinFundCnt > 0) {
      this.minimumFundAllocationerr = true;
    } else {
      this.minimumFundAllocationerr = false;
    }
    if (this.destRefFundEmptyCnt > 0) {
      this.selectedFundTotalErr = true;
      this.minimumFundAllocationerr = false;
    } else {
      this.selectedFundTotalErr = false;
    }
    if (this.destRefFundExceedsCnt > 0) {
      this.fundTotalExceedsErr = true;
      this.selectedFundTotalErr = false;
    } else {
      this.fundTotalExceedsErr = false;
    }
  }

  getSummaryFlagValue(event) {
    if (this.summaryTransferFund.targetFunds.length > 1) {
      this.summaryTransferFund.targetFunds.forEach(element => {
        if (element.fundId == event.fundId) {
          element.keyLinkClicked = true;
        } else { }
      });
    } else {
      if (this.summaryTransferFund.targetFunds[0].fundId == event.fundId) {
        this.summaryTransferFund.targetFunds[0].keyLinkClicked = true;
      } else { }
    }
  }

}
