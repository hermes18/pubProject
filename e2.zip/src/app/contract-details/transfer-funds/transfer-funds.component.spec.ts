import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule, httpTranslateLoader } from 'src/app/app.module';
import { AuthenticationService } from 'src/app/login/service/authentication.service';
import { ContractDetailsModule } from '../contract-details.module';
import { TransferFundsComponent } from './transfer-funds.component';
import { MatStepperModule } from '@angular/material';
import { AllocationChangeSharedService } from '../allocation-change/allocation-change-service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';


describe('TransferFundsComponent', () => {
  let component: TransferFundsComponent;
  let fixture: ComponentFixture<TransferFundsComponent>;

  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'targetFund': host + '/api/v1/order/target-fund',
        'sourceFund': host + '/api/v1/order/source-fund',
        'fundTransferSummary': host + '/api/v1/order/fund-transfer-summary',
        'fundTransferConfirmation': host + '/api/v1/order/fund-transfer-confirmation',
        'accountList': host + '/api/v1/order/change-premium-spilt'

      }
    }
  };
  const userImfo =
    { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" }
  const serachClient =
    { "clientID": 1234, "opeType": "search" };
  // beforeEach(async(() => {
  //   window['__env'].environmentConstURLs = environmentConstURL;

  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
  //     providers: [HttpClient, { provide: 'Window', useFactory: () => window }, { provide: APP_BASE_HREF, useValue: '/' }, TranslateService, MatStepperModule, AllocationChangeSharedService, SharedServiceService],
  //     declarations: []
  //   })
  //     .compileComponents();
  // }));
  let commonService;
  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    window.sessionStorage.setItem("defaultLanguage", "pl_pl");
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, HttpClientTestingModule, HttpClientModule, ContractDetailsModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: httpTranslateLoader,
            deps: [HttpClient]
          }
        })],
      providers: [SharedServiceService, { provide: 'Window', useFactory: () => window }, { provide: APP_BASE_HREF, useValue: '/' }, TranslateService, MatStepperModule, AllocationChangeSharedService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(TransferFundsComponent);
    commonService = TestBed.get(SharedServiceService);

    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 7000;

    const test = "pl_en";
    // commonService.getLangChange();
    spyOn(SharedServiceService.prototype, 'getLangChange').and.returnValue(of(test));
    // commonService.getLangChange();
    expect(component).toBeTruthy();
  });
});
