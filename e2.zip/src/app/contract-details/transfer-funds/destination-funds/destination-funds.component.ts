import { ChangeDetectorRef, Component, EventEmitter, OnInit, ViewEncapsulation, Output } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { Observable, Subscription } from 'rxjs';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { TransformPipe } from 'src/app/shared/pipe/transform.pipe';
import { CreateFormService } from 'src/app/shared/services/create-form.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../../allocation-change/allocation-change-service';


export interface FundDataList {
  contact: FundData[];
}
export interface FundData {
  fundName: String;
  //nooOfUnits: String;
  // unitPrice:String;
  //accountValue: String;
  quotesLink: String;
  newSlip: String;
  estimatedAmount: String;
  equalto: String
}
@Component({
  selector: 'destination-funds',
  templateUrl: './destination-funds.component.html',
  styleUrls: ['./destination-funds.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DestinationFundsComponent implements OnInit {

  displayedColumns: String[] = ['fundName', //'unitPrice', //'nooOfUnits', 'accountValue', 
    'quotesLink', 'newSlip', 'equalto', 'estimatedAmount'];
  // 'unitPrice',  
  dataSourceFundDetails: MatTableDataSource<FundDataList>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  accountDet: any;
  destinationFundForm: FormGroup;
  externalPartiesForm: FormGroup;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  fundDetails: any;
  total: any = 0;
  subscription: Subscription;
  shareLeft: number;
  accountDetails: any;
  userrole: string;
  clientId: any;
  destinationFundResponse: any;
  totalEnteredAmnt: any = 0;
  sourceFunds: any[];
  sourceFundsRes: any;
  currencyType: string;
  langChange: string;
  inputUpdated: boolean;
  minSrcFundAllocationErr: boolean;
  @Output() flagValueChange = new EventEmitter();
  addPreviousFund: any;
  tempCalculatedPercent: number;
  defaultValue: number = 0.00;
  totalTempData: any;
  shareLeftReset: boolean;

  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private fb: FormBuilder,
    private menuItemService: MenuItemsService,
    private ref: ChangeDetectorRef,
    private newPremiumService: AllocationChangeSharedService,
    private transform: TransformPipe) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    //if (this.country == 'pl') {
      let loggedInCountryCheck = UtilityService.getCountry();
      if (loggedInCountryCheck) {
      this.displayPoOption = true;
      this.currencyType = 'PLN';
    }
    else {
      this.displayRoOption = true;
      this.currencyType = 'RON';
    }
    this.langChange = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if (this.langChange == "pl_en") {
      this.langChange = "en";
    } else if (this.langChange == "pl_pl") {
      this.langChange = "pl";
    } else if (this.langChange == "ro_en") {
      this.langChange = "en";
    } else if (this.langChange == "ro_ro") {
      this.langChange = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.langChange = data;
      }
    });
    let userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    // if (this.userrole === "rClient") {
    //   this.clientId = userdetail.clientID;
    // } else {
    //   this.clientId = customerId.clientID;
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (userdetail) {
      this.clientId = userdetail.clientId ? userdetail.clientId : '';
    }
    this.createForm();
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = [];
      this.accountDetails = data;
    })
    this.newPremiumService.getSourceFund().subscribe((data) => {
      this.sourceFundsRes = data;
    })
    this.newPremiumService.getDestinationFund().subscribe((data) => {
      this.accountDet = [];
      this.accountDet = data;
      if (this.accountDetails != null && this.accountDet != null) {
        this.getFundList(this.accountDet);
      }
    })
    this.subscription = this.fundListArray.valueChanges.subscribe(data => {
      //  let enterValue = this.destinationFundForm.controls['amountField'].value;
      data.forEach((val) => {
        //if (this.destinationFundForm.controls['amountField'].value != '') {
        if (val.estimatedAmount != 0) {
          val.estimatedAmount = (((val.allocationPercentage) / 100) * (this.destinationFundForm.controls['totalSourceFundTransferAmount'].value));
          // //console.log(val.totalAmtCurrent);
        }
        let tempFundSplitted;
        let addedPreviousFund;
        tempFundSplitted = ((val.allocationPercentage * this.destinationFundForm.controls['totalSourceFundTransferAmount'].value) / 100);
        addedPreviousFund = val.fundValue != 0 ? (val.fundValue + tempFundSplitted) : tempFundSplitted;
        val.addedPreviousFundTotal = addedPreviousFund;
        if (addedPreviousFund != 0 && (addedPreviousFund > this.sourceFundsRes.minimumAmountPerFund)) {
          val.estimatedAmount = tempFundSplitted;
          //this.total = this.total <= 100 ? data.reduce((a, b) => a + +b.allocationPercentage, 0) : 0;
          // } else if (addedPreviousFund == 0) {
          //   val.estimatedAmount = val.fundValue + (((val.allocationPercentage) * this.destinationFundForm.controls['totalSourceFundTransferAmount'].value) / 100);
        } else {
          val.estimatedAmount = 0;
          this.total = 0;
        }
        //}
      })
      if (this.destinationFundResponse && !this.destinationFundResponse.targetAllocationPercentageDisable) {
        this.total = this.total <= 100 ? data.reduce((a, b) => a + +(b.allocationPercentage != 0
          && (!b.singleFundErr && !b.minFundErr && !b.fundEmptyErr) ? b.allocationPercentage : 0), 0) : 0;
        this.totalTempData = data.reduce((a, b) => a + +b.allocationPercentage, 0);
        this.totalEnteredAmnt = data.reduce((a, b) => a + +b.estimatedAmount, 0);
        //(this.totalEnteredAmnt)
        if (this.total <= 100) {
          this.destinationFundForm['controls'].total.setValue(!this.shareLeftReset ? this.total : 0);
          this.destinationFundForm['controls'].totalAmnt.setValue(!this.shareLeftReset ? data.reduce((a, b) => a + +((!b.singleFundErr
            && !b.minFundErr && !b.fundEmptyErr) ? (Math.round((b.estimatedAmount) * 100) / 100)//(b.estimatedAmount).toFixed(2)
            : 0), 0) : 0);
          // this.destinationFundForm['controls'].totalAmnt.setValue(!this.shareLeftReset ? data.reduce((a, b) => a + +((!b.singleFundErr
          //   && !b.minFundErr && !b.fundEmptyErr) ? (b.estimatedAmount).toFixed(2) : 0), 0): 0);
          this.shareLeft = this.destinationFundForm['controls'].total.value <= 100 && !this.shareLeftReset ? 100 - (data.reduce((a, b) => a + +(b.allocationPercentage != 0
            && (!b.singleFundErr && !b.minFundErr && !b.fundEmptyErr) ? b.allocationPercentage : 0), 0)) : 0;
        } else {
          this.destinationFundForm['controls'].total.setValue(0);
          this.destinationFundForm['controls'].totalAmnt.setValue(0);
          this.shareLeft = 0;
        }
      } else if (this.destinationFundResponse && this.destinationFundResponse.targetAllocationPercentageDisable) {
        this.total = 100;
        this.destinationFundForm['controls'].total.setValue(100);
        this.destinationFundForm['controls'].totalAmnt.setValue(parseFloat(this.destinationFundResponse.totalSourceFundTransferAmount.toFixed(2)));
        this.shareLeft = this.destinationFundForm['controls'].total.value <= 100 ? 100 - this.total : 0;
      } else { }
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  createForm() {
    this.destinationFundForm = this.fb.group({
      minimumAmountPerFund: '',
      total: [0, Validators.required],
      totalSourceFundTransferAmount: [0, Validators.required],
      totalAmnt: [0],
      fundListArray: this.fb.array([])
    });
  }

  get fundListArray() {
    return this.destinationFundForm.get('fundListArray') as FormArray;

  }

  getFundList(data) {
    if (data) {
      this.destinationFundForm['controls'].fundListArray['controls'] = [];
      this.destinationFundResponse = data;
      this.fundDetails = data.targetFunds;
      for (var i = 0; i < data.targetFunds.length; i++) {
        this.add(i);
      }
      // //console.log(data);
    } else { }
    this.dataSourceFundDetails = new MatTableDataSource(this.destinationFundForm['controls'].fundListArray['controls']);
    this.destinationFundForm['controls'].totalSourceFundTransferAmount.setValue(this.destinationFundResponse.totalSourceFundTransferAmount);
    this.destinationFundForm['controls'].minimumAmountPerFund.setValue(this.sourceFundsRes.minimumAmountPerFund != null ? this.sourceFundsRes.minimumAmountPerFund : 0);
  }

  add(index) {
    this.fundListArray.push(this.new(index));
  }

  new(index): FormGroup {
    return this.fb.group({
      fundId: this.fundDetails[index].fundId,
      fundName: this.fundDetails[index].fundName,
      unitPrice: [this.fundDetails[index].unitPrice],
      investAccNumber: this.fundDetails[index].investAccNumber,
      sort: this.fundDetails[index].sort,
      externalLink: this.fundDetails[index].externalLink,
      allocationPercentage: [this.fundDetails[index].allocationPercentage],
      dataError: this.fundDetails[index].dataError,
      newAllocationPercentage: this.fundDetails[index].newAllocationPercentage,
      fundValue: this.fundDetails[index].fundValue,
      units: this.fundDetails[index].units,
      investAccType: this.fundDetails[index].investAccType,
      keyInfoLinkForFund: this.fundDetails[index].keyInfoLinkForFund,
      minimumAmountPerFund: this.fundDetails[index].minimumAmountPerFund == null ? this.sourceFundsRes.minimumAmountPerFund : this.fundDetails[index].minimumAmountPerFund,
      singleFundErr: false,
      fundEmptyErr: false,
      minFundErr: false,
      totalExceedsErr: false
    })
  }

  formSubmit() {
    return this.destinationFundForm.valid;
  }

  submitSelectedFund() {
    // if (this.destinationFundForm.dirty) {
    // if (this.destinationFundForm.controls['total'].value == 100) {
    this.newPremiumService.setUpdatedDestination(this.destinationFundForm.controls['fundListArray'].value);
    this.newPremiumService.setParamValue('destinationFundForm', this.destinationFundForm);
    // return this.destinationFundForm.valid;
    // }
    // }  
  }

  numberOnly(event, row, action) {
    // const charCode = (event.which) ? event.which : event.keyCode;
    // if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    //   return false;
    // }
    // return true;
    let pastedText;
    if (action == 'paste') {
      let clipboardData = event.clipboardData;
      pastedText = clipboardData.getData('text');
    } else {
      pastedText = event.target.value;
      // let pastedText = clipboardData.getData('text');
    }
    event.preventDefault();
    let ctrl = row.get('allocationPercentage') as FormControl;
    ctrl.setValue(this.transform.transform(pastedText, this.langChange), { emitEvent: false, emitViewToModelChange: false });
    let checkNumberOnly = (ctrl.value);
    if (checkNumberOnly != null) {
      let numeric = (ctrl.value).toString();
      // if (this.langChange == 'pl' || this.langChange == 'ro') {
      if (numeric.includes(',')) {
        let checkNumeric = numeric.replace(',', '');
        if (checkNumeric.length > 3) {
          ctrl.setValue(checkNumeric.substr(0, 3));
          return false;
        } else {
          ctrl.setValue(checkNumeric.substr(0, 3));
        }
      }
      //  } else {
      if (numeric.includes('.')) {
        let checkNumeric = numeric.replace('.', '');
        if (checkNumeric.length > 3) {
          ctrl.setValue(checkNumeric.substr(0, 3));
          return false;
        } else {
          ctrl.setValue(checkNumeric.substr(0, 3));
        }
      }
      //  }
    }
  }

  numberValue1(event, itemrow) {
    let clipboardData = event.clipboardData;
    let pastedText = clipboardData.getData('text');
    event.preventDefault();
    let ctrl = itemrow.get('allocationPercentage') as FormControl;
    ctrl.setValue(this.transform.transform(pastedText, this.langChange), { emitEvent: false, emitViewToModelChange: false });
  }


  validateSourceInput(evt, row) {
    //console.log(evt);
    if ((row.get('allocationPercentage').value) != "" && this.destinationFundForm.dirty && row.get('allocationPercentage').value != "" && (row.get('allocationPercentage').value != "00"
      && (row.get('allocationPercentage').value != "000"))) {
      if (this.destinationFundResponse.renderSingleFundMesage) {
        if (
          (parseFloat(row.get('allocationPercentage').value) != 0) &&
          (parseFloat(row.get('allocationPercentage').value) != 100)) {
          row.get('singleFundErr').setValue(true);
          this.flagValueChange.emit(row);
        } else {
          row.get('singleFundErr').setValue(false);
          this.tempCalculatedPercent = (parseFloat(row.get('allocationPercentage').value) / 100) * (this.destinationFundResponse.totalSourceFundTransferAmount);
          this.addPreviousFund = row.get('fundValue').value + this.tempCalculatedPercent;
          if (this.addPreviousFund < row.get('minimumAmountPerFund').value) {
            row.get('minFundErr').setValue(true);
            this.shareLeftReset = true;
          } else {
            row.get('minFundErr').setValue(false);
            this.validateOtherRows();
            // }
            if ((parseFloat(row.get('allocationPercentage').value) > parseFloat("100"))) {
              row.get('totalExceedsErr').setValue(true);
              // row.get('fundEmptyErr').setValue(true);
              this.shareLeftReset = true;
              this.flagValueChange.emit(row);
            } else {
              if (this.totalTempData > 100) {
                row.get('fundEmptyErr').setValue(true);
                row.get('totalExceedsErr').setValue(false);
                this.shareLeftReset = true;
                this.flagValueChange.emit(row);
              } else {
                row.get('fundEmptyErr').setValue(false);
                this.validateOtherRows();
              }
            }
          }
        }
      } else { //multifund case
        row.get('singleFundErr').setValue(false);
        if ((row.get('allocationPercentage').value != "0") &&
          (row.get('allocationPercentage').value != "00") &&
          (row.get('allocationPercentage').value != "000")) {
          this.tempCalculatedPercent = (parseFloat(row.get('allocationPercentage').value) / 100) * (this.destinationFundResponse.totalSourceFundTransferAmount);
          this.addPreviousFund = row.get('fundValue').value + this.tempCalculatedPercent;
          if (this.addPreviousFund < row.get('minimumAmountPerFund').value) {
            row.get('totalExceedsErr').setValue(false);
            if (this.totalTempData <= 100) {
              row.get('minFundErr').setValue(true);
              row.get('fundEmptyErr').setValue(false);
              this.shareLeftReset = true;
              this.flagValueChange.emit(row);
            } else {
              if (this.totalTempData > 100 && (parseFloat(row.get('allocationPercentage').value) > 100)) {
                row.get('minFundErr').setValue(true);
                row.get('totalExceedsErr').setValue(true);
                this.shareLeftReset = true;
                this.flagValueChange.emit(row);
                this.validateOtherRows();
              } else {
                row.get('minFundErr').setValue(false);
                row.get('fundEmptyErr').setValue(true);
                this.shareLeftReset = true;
                this.flagValueChange.emit(row);
                this.validateOtherRows();
              }
            }
          } else {
            row.get('minFundErr').setValue(false);
            if ((parseFloat(row.get('allocationPercentage').value) > parseFloat("100"))) {//|| this.total >100
              // row.get('fundEmptyErr').setValue(true);
              row.get('totalExceedsErr').setValue(true);
              row.get('fundEmptyErr').setValue(false);
              this.shareLeftReset = true;
              this.flagValueChange.emit(row);
            } else {
              if (this.totalTempData > 100) {
                let findCurrentRowValue = parseFloat(this.totalTempData) - parseFloat(row.get('allocationPercentage').value);
                if (findCurrentRowValue != 0 && this.totalTempData > 100) {
                  row.get('fundEmptyErr').setValue(false);
                  row.get('totalExceedsErr').setValue(true);
                  //console.log('line no:355',row)
                  this.shareLeftReset = true;
                  if (this.addPreviousFund < row.get('minimumAmountPerFund').value) {
                    row.get('minFundErr').setValue(true);
                    this.shareLeftReset = true;
                  } else {
                    row.get('minFundErr').setValue(false);
                    this.validateOtherRows();
                  }
                  this.flagValueChange.emit(row);
                } else {
                  //   row.get('fundEmptyErr').setValue(false);
                  this.validateOtherRows();
                }
              } else {
                this.validateOtherRows();
              }
            }
          }
        } else {
          //equals 0 means do nothing
          this.validateOtherRows();
        }
      }
    } else {
      //equals 0 || empty means do nothing
      this.validateOtherRows();
    }
  }

  validateOtherRows() {
    this.destinationFundForm['controls'].fundListArray['controls'].forEach(element => {
      this.totalTempData = this.destinationFundForm['controls'].fundListArray.value.reduce((a, b) => a + +b.allocationPercentage, 0);
      this.tempCalculatedPercent = (parseFloat(element.get('allocationPercentage').value) / 100) * (this.destinationFundResponse.totalSourceFundTransferAmount);
      this.addPreviousFund = element.get('fundValue').value + this.tempCalculatedPercent;
      if (element.get('allocationPercentage').value != "") {
        if (this.destinationFundResponse.renderSingleFundMesage) { //single fund
          if ((parseFloat(element.get('allocationPercentage').value) != 0) && (parseFloat(element.get('allocationPercentage').value) != 100)) {
            element.get('singleFundErr').setValue(true);
            this.shareLeftReset = true;
            this.flagValueChange.emit(element);
          } else {
            element.get('singleFundErr').setValue(false);
            this.tempCalculatedPercent = (parseFloat(element.get('allocationPercentage').value) / 100) * (this.destinationFundResponse.totalSourceFundTransferAmount);
            this.addPreviousFund = element.get('fundValue').value + this.tempCalculatedPercent;
            if (this.addPreviousFund < element.get('minimumAmountPerFund').value) {
              element.get('minFundErr').setValue(true);
              this.shareLeftReset = true;
              if (this.totalTempData > 100 && parseFloat(element.get('allocationPercentage').value) <= parseFloat("100")) {
                element.get('fundEmptyErr').setValue(true);
                element.get('minFundErr').setValue(false);
                this.shareLeftReset = true;
                // if (parseFloat(element.get('allocationPercentage').value)!= 0 && parseFloat(element.get('allocationPercentage').value)!= 100){
                //   element.get('singleFundErr').setValue(true);
                // } else {
                //   element.get('singleFundErr').setValue(false);
                // }
              } else {
                element.get('totalExceedsErr').setValue(true);
                element.get('fundEmptyErr').setValue(false);
                this.shareLeftReset = true;
              }
              //element.get('totalExceedsErr').setValue(false);
              this.flagValueChange.emit(element);
            } else if (this.totalTempData > 100) {
              if (parseFloat(element.get('allocationPercentage').value) > parseFloat("100")) {
                // element.get('fundEmptyErr').setValue(true);
                element.get('totalExceedsErr').setValue(true);
                this.shareLeftReset = true;
              } else {
                element.get('totalExceedsErr').setValue(false);
                let findCurrentRowValue = parseFloat(this.totalTempData) - parseFloat(element.get('allocationPercentage').value);
                if (findCurrentRowValue != 0 && this.totalTempData > 100) {
                  element.get('fundEmptyErr').setValue(true);
                  this.shareLeftReset = true;
                } else {
                  element.get('fundEmptyErr').setValue(false);
                  this.shareLeftReset = this.shareLeftReset ? this.shareLeftReset : false;
                }
              }
              this.flagValueChange.emit(element);
            } else {
              element.get('fundEmptyErr').setValue(false);
              element.get('minFundErr').setValue(false);
              element.get('totalExceedsErr').setValue(false);
              this.shareLeftReset = false;
              this.flagValueChange.emit(element);
            }
          }
        } else {
          if (parseFloat(element.get('allocationPercentage').value) != 0 &&
            element.get('allocationPercentage').value != '') { //multi fund
            element.get('totalExceedsErr').setValue(false);
            if (this.addPreviousFund < element.get('minimumAmountPerFund').value) {
              if (this.totalTempData > 100 && parseFloat(element.get('allocationPercentage').value) < 100) {
                element.get('fundEmptyErr').setValue(true);
                element.get('minFundErr').setValue(false);
                this.shareLeftReset = true;
                this.flagValueChange.emit(element);
              } else if (this.totalTempData > 100 && parseFloat(element.get('allocationPercentage').value) == 100 && element.get('allocationPercentage').value != '') {
                element.get('fundEmptyErr').setValue(true);
                element.get('minFundErr').setValue(false);
                this.shareLeftReset = true;
                this.flagValueChange.emit(element);
              } else {
                element.get('fundEmptyErr').setValue(false);
                element.get('minFundErr').setValue(true);
                if (parseFloat(element.get('allocationPercentage').value) > parseFloat("100")) {
                  // element.get('fundEmptyErr').setValue(true);
                  element.get('totalExceedsErr').setValue(true);
                } else {
                  element.get('totalExceedsErr').setValue(false);
                }
                this.shareLeftReset = true;
                this.flagValueChange.emit(element);
              }
            } else if (this.totalTempData > 100) {
              if (parseFloat(element.get('allocationPercentage').value) > parseFloat("100")) {
                element.get('fundEmptyErr').setValue(false);
                element.get('totalExceedsErr').setValue(true);
                this.shareLeftReset = true;
              } else {
                element.get('totalExceedsErr').setValue(false);
                let findCurrentRowValue = parseFloat(this.totalTempData) - parseFloat(element.get('allocationPercentage').value);
                if (findCurrentRowValue != 0 && this.totalTempData > 100) {
                  element.get('fundEmptyErr').setValue(true);
                  this.shareLeftReset = true;
                } else {
                  element.get('fundEmptyErr').setValue(false);
                  this.shareLeftReset = false;
                }
              }
              this.flagValueChange.emit(element);
            } else {
              element.get('fundEmptyErr').setValue(false);
              element.get('minFundErr').setValue(false);
              element.get('totalExceedsErr').setValue(false);
              this.shareLeftReset = false;
              this.flagValueChange.emit(element);
            }
          } else {
            element.get('fundEmptyErr').setValue(false);
            element.get('minFundErr').setValue(false);
            element.get('totalExceedsErr').setValue(false);
            this.shareLeftReset = false;
            this.flagValueChange.emit(element);
          }
        }
      } else {
        element.get('fundEmptyErr').setValue(false);
        element.get('minFundErr').setValue(false);
        element.get('singleFundErr').setValue(false);
        element.get('totalExceedsErr').setValue(false);
        this.shareLeftReset = false;
        this.flagValueChange.emit(element);
      }
    });
  }

  calculateRowTotal(row) {
    return (row.controls.allocationPercentage.value <= 100) &&
      (this.destinationFundForm.controls['total'].value <= 100) && (!row.controls.fundEmptyErr.value
        && !row.controls.minFundErr.value && !row.controls.singleFundErr.value) ?
      ((((
        (row.controls.allocationPercentage.value / 100) *
        this.destinationFundResponse.totalSourceFundTransferAmount) +
        row.controls.fundValue.value) > row.controls.minimumAmountPerFund.value) ?
        ((Math.round((row.controls.allocationPercentage.value / 100) *
          (this.destinationFundResponse.totalSourceFundTransferAmount) * 100)) / 100).toFixed(2) :
        this.defaultValue.toFixed(2)) :
      this.defaultValue.toFixed(2)
  }

  // numberValue1(event, itemrow) {
  //   let clipboardData = event.clipboardData;
  //   let pastedText = clipboardData.getData('text');
  //   event.preventDefault();
  //   let ctrl = itemrow.get('allocationPercentage') as FormControl;
  //   ctrl.setValue(this.transform.transform(pastedText), { emitEvent: false, emitViewToModelChange: false });
  // }
}

