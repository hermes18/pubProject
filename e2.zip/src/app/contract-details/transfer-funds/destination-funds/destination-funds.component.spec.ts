import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ContractDetailsModule } from '../../contract-details.module';

import { DestinationFundsComponent } from './destination-funds.component';

describe('DestinationFundsComponent', () => {
  let component: DestinationFundsComponent;
  let fixture: ComponentFixture<DestinationFundsComponent>;


  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(DestinationFundsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
