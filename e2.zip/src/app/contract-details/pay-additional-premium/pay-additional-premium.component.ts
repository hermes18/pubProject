import { Component, OnInit, ViewChild, AfterViewInit, ViewEncapsulation, ViewChildren, QueryList, Output, EventEmitter, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormGroup, FormControl, FormArray, NgForm, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material';
import { HttpCommonService } from '../../shared/services/http-common.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import * as utils from 'lodash';
import { SelectAccountAdditionalPremiumComponent } from './select-account/select-account.component';
// import { SelectFundsComponent } from './select-funds/select-funds.component';
import { AppConfig } from 'src/config/app.config';
// import { SummarySplitScreenComponent } from './summary-split-screen/summary-split-screen.component';
import { AllocationChangeSharedService } from './../allocation-change/allocation-change-service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { AmountAdditionalPremiumComponent } from './amount-additional-premium/amount-additional-premium.component';
import { SummaryAdditionalPremiumComponent } from './summary-additional-premium/summary-additional-premium.component';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'pay-additional-premium',
  templateUrl: './pay-additional-premium.component.html',
  styleUrls: ['./pay-additional-premium.component.scss']
})
export class PayAdditionalPremiumComponent implements OnInit {
  confirmationPage: boolean = false;
  previouslySelectedstep = [];
  isStepInteracted = false;
  selectAccountForm: FormGroup;
  selectFundForm: FormGroup;
  responseActiveOrder: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  FundAccountEmpty: boolean = false;
  totalShareError: boolean = false;
  selectAccountSecError: boolean = false;
  showOrderProcessingErr: boolean;
  selectedFundTotalErr: boolean;
  selectFundFormErr: boolean;
  valuesSelectedArray: any[];
  selectAdditionalAmountForm: FormGroup;
  amountValueEmptyErr: boolean;
  acceptAckErr: boolean;
  insufficientValueErr: boolean;
  exceedsMaximumValueErr: boolean;
  responseAdditionalPremium: any;
  country: string;
  lang: string;
  displayPoOption: boolean;
  contractDetail: any;
  contractNo: any;
  userrole: string;
  clientId: any;
  responseTransmit: { policyNumber: string; investAccNumber: string; activeOrderErrorRender: boolean; authorizationErrorRender: boolean; orderErrorRender: boolean; clientId: string; userName: string; firstName: string; lastName: string; language: string; country: string; };
  userdetail: any;
  orderErrorRender: boolean;
  authorizationFlag: boolean;
  step2Completed: boolean;
  langChange: string;
  step1Completed: boolean;

  constructor(private translate: TranslateService, private _formBuilder: FormBuilder,
    private httpService: HttpCommonService, private router: Router,
    private route: ActivatedRoute,
    private newPremiumService: AllocationChangeSharedService,
    private sharedService: SharedServiceService,
    public deviceDetector: DeviceDetectorService
  ) { }

  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.selectAccountForm = this._formBuilder.group({
    });
    this.selectAdditionalAmountForm = this._formBuilder.group({
    });
    this.country = sessionStorage.getItem('countryCode');
    this.langChange = sessionStorage.getItem('defaultLanguage');
    // if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayPoOption = true;
    }
    this.contractDetail = null;
    this.contractNo = this.sharedService.getContractNo();
    this.contractDetail = JSON.parse(sessionStorage.getItem('contractDetails'));
    this.userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    const contractnumber = JSON.parse(sessionStorage.getItem('contract'));
    // if (this.userrole === "rClient") {
    //   this.clientId = this.userdetail.clientID;
    // } else {
    //   this.clientId = customerId.clientID;
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (this.userdetail) {
      this.clientId = this.userdetail.clientId ? this.userdetail.clientId : '';
    }
    this.lang = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /* if (this.lang == "pl_en") {
      this.lang = "en";
    } else if (this.lang == "pl_pl") {
      this.lang = "pl";
    } else if (this.lang == "ro_en") {
      this.lang = "en";
    } else if (this.lang == "ro_ro") {
      this.lang = "ro";
    } */
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.lang = data;
        if (this.lang != 'en' && this.selectAdditionalAmntRefComp && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'] && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value != null) {
          this.selectAdditionalAmntRefComp && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].setValue(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.includes('.')
            ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.replace('.', ',') :
            this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value);
        } else {
          this.selectAdditionalAmntRefComp && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].setValue(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.includes(',')
            ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.replace(',', '.') :
            this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value);
        }
      }
    });
  }

  step = 0;
  @ViewChild(SelectAccountAdditionalPremiumComponent, { static: false }) selectAccRefComp: SelectAccountAdditionalPremiumComponent;
  @ViewChild(AmountAdditionalPremiumComponent, { static: false }) selectAdditionalAmntRefComp: AmountAdditionalPremiumComponent;
  @ViewChild(SummaryAdditionalPremiumComponent, { static: false }) summaryRefComp: SummaryAdditionalPremiumComponent;

  setStep(index: number) {
    this.step = index;
  }

  nextStep(id) {
    ////("next step");
    //this.stepper.selectedIndex++;
    this.stepper.selected.completed = true;
    this.stepper.selectedIndex = this.stepper.selectedIndex + 1;
    if (this.isMobile) {
      this.setFocus(id);
    } else {
      // window.scroll(0,0);
    }
  }

  prevStep() {
    this.step--;
  }

  setFocus(id) {
    let targetElem = document.getElementById(id);
    // targetElem.scrollIntoView();
    //targetElem.focus();
    setTimeout(function waitTargetElem() {
      if (targetElem) {
        targetElem.scrollIntoView();
      } else {
        setTimeout(waitTargetElem, 100);
      }
    }, 100);
  }

  onStepChange(event) {
    this.checkStepCompletionStatus(this.stepper['_selectedIndex']);
    if (event.selectedIndex == 0) {
      this.step1Completed = false;
      this.exceedsMaximumValueErr = false;
      this.amountValueEmptyErr = false;
      this.insufficientValueErr = false;
      this.acceptAckErr = false;
      this.orderErrorRender = false;
      this.authorizationFlag = false;
    } else if (event.selectedIndex == 1) {
      this.step2Completed = false;
      this.orderErrorRender = false;
      this.authorizationFlag = false;
    } else { }
  }

  checkStepCompletionStatus(index) {
    if (this.stepper && this.stepper._steps['_results'][index].completed) {
      this.stepper['_elementRef'].nativeElement.querySelectorAll('.mat-step')[index].setAttribute('ariaChecked', true)
      return 'test';
    }
  }


  @ViewChild('stepper', { static: false }) stepper: MatStepper;
  headers = new HttpHeaders();


  gotoStep(step) {
    this.stepper.selectedIndex = step;
  }

  changeSelection() {
    if (this.previouslySelectedstep.indexOf(0) && this.stepper && this.stepper['_selectedIndex'] !== 0) {
      return true;
    }
    return false;
  }

  validateSelectAccount(id) {
    //(this.selectAccRefComp.selectAccountForm)
    this.selectAccRefComp.submitSelectedAccount();
    if (this.selectAccRefComp.selectAccountForm.valid && this.selectAccRefComp.selectedRow) {
      this.FundAccountEmpty = false;
      this.validateSelectedAccountDetails(this.selectAccRefComp.selectedRow, id);
    } else {
      this.FundAccountEmpty = true;
      window.scroll(0, 0);
    }
  }

  validateSelectedAccountDetails(value, id) {
    this.selectAdditionalAmntRefComp ?
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm ?
        this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.dirty ?
          //this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.reset():'':'':'';
          this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].setValue("") : "" : "" : "";
    this.selectAdditionalAmntRefComp ?
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm ?
        this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.dirty ?
          //this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.reset():'':'':'';
          this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].setValue(false) : "" : "" : "";
    this.step2Completed = false;
    this.stepper.selected.completed = false;
    this.newPremiumService.setDeclaredAmount(null);
    const reqParam = {
      "policyNumber": value.policyNumber,//"21295126",
      "selectedInvestmentStrategy": "Deposit to Existing Invest Account",
      "investAccNumber": value.investAccNumber //"21295127"
    }
    this.httpService.postData(this.baseUrl.ecustomer.getActiveOrder, reqParam, this.headers).subscribe(data => {
      this.responseActiveOrder = data;
      if (!this.responseActiveOrder.activeOrderErrorRender) {
        this.showOrderProcessingErr = false;
        this.authorizationFlag = false;
        this.orderErrorRender = false;
        this.exceedsMaximumValueErr = false;
        this.amountValueEmptyErr = false;
        this.insufficientValueErr = false;
        this.acceptAckErr = false;
        this.step1Completed = true;
        this.stepper.selected.completed = true;
        this.callAdditionalPremiumApi(value, id);
      } else {
        //error msg display
        this.showOrderProcessingErr = true;
        window.scrollTo(0, 0);
        this.step1Completed = false;
        this.stepper.selected.completed = false;
      }
      // this.callAdditionalPremiumApi(value);
    })
  }


  callAdditionalPremiumApi(value, id) {
    const req = {
      "policyNumber": value.policyNumber,//"21281278",
      "investAccNumber": value.investAccNumber,//"21281278",
      "clientId": this.clientId,//"2222",
      "userName": this.userdetail.userName,//"333",
      "firstName": this.userdetail.firstName,//"dasdsa",
      "lastName": this.userdetail.lastName,//"asdsadsad",
      "language": this.lang,//"en",
      "country": this.country//"pl"
    }
    this.httpService.postData(this.baseUrl.ecustomer.additionalPremium, req, this.headers).subscribe(data => {
      this.responseAdditionalPremium = data;
      this.authorizationFlag = false;
      this.orderErrorRender = false;
      this.newPremiumService.setSummaryReqData(this.responseAdditionalPremium);
      this.nextStep(id);
    });

  }

  validateEnteredAmount(id) {
    this.step2Completed = false;
    this.stepper.selected.completed = false;
    //(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm);
    this.selectAdditionalAmntRefComp.submitSelectedAccount();
    if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.dirty && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value != "") { //&& this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.valid
      let inputAmount = this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.includes(',')
        ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.replace(',', '.') :
        this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value;
      if (this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount != null && this.responseAdditionalPremium.fundInjectionDTO.maximumDepositAmount == null) {
        // if (this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount == null || this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount == 0) {
        //   // this.insufficientValueErr = false;
        //   // this.exceedsMaximumValueErr = false;
        //   // this.amountValueEmptyErr = true;
        // } else {
        let splitMinimum = this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount.split(' ', 2);
        let minimumValue = splitMinimum[0].replace('/,/g', '');
        // if (parseFloat((this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value)) >= parseFloat(minimumValue.replace(/,/g, ""))) { //working code
        if (inputAmount >= parseFloat(minimumValue.replace(/,/g, ""))) {
          this.insufficientValueErr = false;
          this.exceedsMaximumValueErr = false;
          this.amountValueEmptyErr = false;
        } else {
          this.insufficientValueErr = true;
          this.exceedsMaximumValueErr = false;
          this.amountValueEmptyErr = false;
          window.scrollTo(0, 0);
        }
        // }
        if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == false || this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == '') {
          this.acceptAckErr = true;
          window.scrollTo(0, 0);
        } else {
          this.acceptAckErr = false;
        }
      }
      else if (this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount != null && this.responseAdditionalPremium.fundInjectionDTO.maximumDepositAmount != null) {
        let splitMinimum = this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount.split(' ', 2);
        let splitMaximum = this.responseAdditionalPremium.fundInjectionDTO.maximumDepositAmount.split(' ', 2);
        let minimumValue = splitMinimum[0].replace('/,/g', '');
        let maximumValue = splitMaximum[0].replace('/,/g', '');
        if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.dirty) { // && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.valid
          if (parseFloat(inputAmount) >= parseFloat(minimumValue.replace(/,/g, "")) &&
            (parseFloat(inputAmount) <= parseFloat(maximumValue.replace(/,/g, "")))) {
            this.insufficientValueErr = false;
            this.exceedsMaximumValueErr = false;
            this.amountValueEmptyErr = false;
          } else if (parseFloat(inputAmount) < parseFloat(minimumValue.replace(/,/g, ""))) {
            this.insufficientValueErr = true;
            this.exceedsMaximumValueErr = false;
            this.amountValueEmptyErr = false;
            window.scrollTo(0, 0);
          } else if (parseFloat(inputAmount) > parseFloat(maximumValue.replace(/,/g, ""))) {
            this.exceedsMaximumValueErr = true;
            this.amountValueEmptyErr = false;
            this.insufficientValueErr = false;
            window.scrollTo(0, 0);
          }
          if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == false || this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == '') {
            this.acceptAckErr = true;
            window.scrollTo(0, 0);
          } else {
            this.acceptAckErr = false;
          }
        }
      }
    } else {
      this.amountValueEmptyErr = true;
      // if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == false || this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == '') {
      //   this.acceptAckErr = true;
      window.scrollTo(0, 0);
      // } else {
      //   this.acceptAckErr = false;
      // }
    }
    if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value == '' ||
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value == null) {
      this.amountValueEmptyErr = true;
      this.insufficientValueErr = false;
      this.exceedsMaximumValueErr = false;
      this.acceptAckErr = this.acceptAckErr ? this.acceptAckErr : false;
      window.scrollTo(0, 0);
    } else if (parseFloat(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value) == 0) {
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].setValue(0);
      this.amountValueEmptyErr = true;
      this.insufficientValueErr = true;
      this.acceptAckErr = this.acceptAckErr ? this.acceptAckErr : false;
      //this.exceedsMaximumValueErr = false;
    } else {
      this.amountValueEmptyErr = false;
      //this.insufficientValueErr = false;
      //this.exceedsMaximumValueErr = false;
    }
    if ((this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == '' || this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == null ||
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == false) &&
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value == '' || this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value == null) {
      this.amountValueEmptyErr = true;
      this.acceptAckErr = true;
      window.scrollTo(0, 0);
    } else if ((this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == '' ||
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == false) &&
      parseFloat(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value) == 0) {
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].setValue(0);
      this.amountValueEmptyErr = true;
      this.insufficientValueErr = true;
      //this.exceedsMaximumValueErr = false;
      this.acceptAckErr = true;
    } else {
      this.amountValueEmptyErr = this.amountValueEmptyErr ? this.amountValueEmptyErr : false;
      this.insufficientValueErr = this.insufficientValueErr ? this.insufficientValueErr : false;
      this.exceedsMaximumValueErr = this.exceedsMaximumValueErr ? this.exceedsMaximumValueErr : false;
      this.acceptAckErr = this.acceptAckErr ? this.acceptAckErr : false;
    }

    if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.valid && !this.exceedsMaximumValueErr && !this.amountValueEmptyErr && !this.insufficientValueErr
      && !this.acceptAckErr) {
      this.exceedsMaximumValueErr = false;
      this.amountValueEmptyErr = false;
      this.insufficientValueErr = false;
      this.acceptAckErr = false;
      let inputAmount = (this.lang == 'pl' || this.lang == 'ro' || this.lang == 'gr') ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.replace(',', '.') : this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value;
      this.newPremiumService.setDeclaredAmount(inputAmount);//(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value);
      this.confirmationPage = false;
      this.step2Completed = true;
      this.stepper.selected.completed = true;
      this.authorizationFlag = false;
      this.orderErrorRender = false;
      this.nextStep(id);
      if (this.isMobile && this.step2Completed) {
        this.setFocus('step2AddPremFormDiv');
      } else {
        //window.scroll(0,0);
      }
      //this.executeAdditionalPremium();
    }
  }

  executeAdditionalPremium() {
    let strategy;
    let forStr;
    this.translate.get('eCustomer.orderInvest.Deposit_to_Existing_Invest_Account').subscribe((res) => {
      strategy = res;
    });
    this.translate.get('eCustomer.orderInvest.for').subscribe((result) => { forStr = result; })
    let transferTitle = strategy + '' + forStr + '' + this.selectAccRefComp.selectedRow.policyNumber;
    let inputAmount = this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.includes(',') ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.replace(',', '.') : this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value;
    let request = {
      "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,//"21281278",
      "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21281278",
      "clientId": this.clientId,//"10013",
      "userName": this.userdetail.userName,//"osamaAdmin2",
      "firstName": this.userdetail.firstName,//"sss",
      "lastName": this.userdetail.lastName,//"sss",
      "language": this.lang,//"pl",
      "country": this.country,//"pl",
      "declaredPaymentAmount": this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value ? inputAmount : this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value,
      "investList": [this.selectAccRefComp.selectedRow],
      'transferTitle': transferTitle ? transferTitle : '',
      "processingSystem": this.contractDetail ? this.contractDetail.processingSystem : ''
    }
    this.httpService.postData(this.baseUrl.ecustomer.transmitAdditionalPremium, request, this.headers).subscribe(data => {
      if (data.hasOwnProperty('activeUser') && (data.activeUser == false)) {
        this.router.navigate(['/logout']);
      } else {
        this.responseTransmit = data;
        this.newPremiumService.setConfReqData(data);
        if (data.authorizationErrorRender) {
          this.authorizationFlag = true;
          this.confirmationPage = false;
          window.scrollTo(0, 0);
        } else {
          this.authorizationFlag = false;
          if (!data.orderErrorRender && data.orderId != null) {
            //this.nextStep();
            this.confirmationPage = true;
            this.orderErrorRender = false;
            if (this.isMobile && this.confirmationPage) {
              this.setFocus("confirmationAddPremFormDiv");
              window.scroll(0, 0);
            } else {
              //window.scroll(0,0);
            }
          } else {
            this.orderErrorRender = true;
            this.confirmationPage = false;
            window.scrollTo(0, 0);
          }
        }
      }
    });
  }

  gotoPremiumSplitPage() {
    // this.gotoPremiumSplit = true;
    //this.valueChange.emit('allocationChange');
    //this.sharedService.setPageContent('singlePremium');
    let data = {
      //'fromPage': 'transferFunds',
      "toPage": 'orderInvest'
    }
    this.sharedService.setPageContent(data);
  }
}



