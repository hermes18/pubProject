import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { MatStepperModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AppModule } from 'src/app/app.module';
import { OrderComponent } from 'src/app/order/order.component';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { AllocationChangeSharedService } from '../allocation-change/allocation-change-service';
import { ContractDetailsModule } from '../contract-details.module';

import { PayAdditionalPremiumComponent } from './pay-additional-premium.component';

describe('PayAdditionalPremiumComponent', () => {
  let component: PayAdditionalPremiumComponent;
  let fixture: ComponentFixture<PayAdditionalPremiumComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  let sharedService: SharedServiceService;
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'accountList': host + '/api/v1/order/change-premium-spilt',
        'getActiveOrder': host + '/api/v1/order/active-order',
        'additionalPremium': host + '/api/v1/order/additional-premium',
        'transmitAdditionalPremium': host + '/api/v1/order/transmit-additional-premium',
      }
    }
  };

  // beforeEach(async(() => {

  // }));
  const userDetails = { "userName": "JDaniel_PL", "firstName": "Prabhu", "lastName": "Jaison", "email": "qatestingsample15@gmail.com", "preferredLanguage": "en", "creationDate": "Wed Feb 10 16:50:24 CET 2021", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 30 17:07:29 CET 2020", "employeeNumber": "", "pwdExpirationDate": "Fri Apr 23 16:50:24 CEST 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3032", "name": "rStandardUser", "description": "RStandardUser" }, { "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": "", "requesterId": "-1", "requesterRole": "3032", "userDn": "ou=People,o=affiliates,c=Poland,o=metlife,dc=metlife,dc=com", "pwdExpirationDelay": "30", "userCheck": true, "tokenParam": null }
  const contractDetails = {
    "benefitType": "SuperKapitał - współubezpieczony 1",
    "businessRoleList": ["owner"],
    "contractDetailsDTO": {
      contractNumber: "21281000", insurer: "INSURER_21281000", insured: "INSURED_21281000", status: 21, paymentMode: "15",
    },
    "contractNumber": "21281000",
    "contractNumberList": null,
    "effectiveDate": "18.11.2009",
    "indexedPremiumAmount": null,
    "insuredName": "INSURED_21281000",
    "premiumAmount": "",
    "premiumAmt": null,
    "premiumAmtType": null,
    "premiumDueDate": null,
    "premiumPaymentMode": "15",
    "premiumType": "15",
    "processingSystem": "OLAS",
    "status": 21
  };
  let data = {
    //'fromPage': 'contractDetails',
    "toPage": 'orderInvest'
  };
  let submenuList = {
    renderContractDetails: true,
    renderContractValue: true,
    renderGeneralData: true,
    renderHistortyOfContractOrders: true,
    renderIndexationBenefits: true,
    renderOrders: true
  };
  const menuItemList = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  }

  let newPremiumService: AllocationChangeSharedService = new AllocationChangeSharedService();
  const selectAccRefComp = jasmine.createSpy('SelectAccountAdditionalPremiumComponent');
  const selectAdditionalAmntRefComp = jasmine.createSpy('AmountAdditionalPremiumComponent');
  const summaryRefComp = jasmine.createSpy('SummaryAdditionalPremiumComponent');

  //const responseTransmit: { policyNumber: string; investAccNumber: string; activeOrderErrorRender: boolean; authorizationErrorRender: boolean; orderErrorRender: boolean; clientId: string; userName: string; firstName: string; lastName: string; language: string; country: string; };


  beforeEach(() => {
    sessionStorage.setItem('contractDetails', JSON.stringify(contractDetails));
    sessionStorage.setItem('contratSubMenuList', JSON.stringify(submenuList));
    sessionStorage.setItem('menuItemList', JSON.stringify(menuItemList));
    window['__env'].environmentConstURLs = environmentConstURL;

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, SharedServiceService, TranslateService, MatStepperModule, AllocationChangeSharedService, SharedServiceService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(PayAdditionalPremiumComponent);
    sharedService = TestBed.get(SharedServiceService);
    sharedService['contractNo'] = "12121";
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create payadditionalpremimum', () => {
    const test = "pl_en";
    component.displayPoOption = true;
    sharedService.getContractNo();
    //s sharedService.getLangChange();
    spyOn(SharedServiceService.prototype, 'getLangChange').and.returnValue(of(test));
    component.clientId = "101583";
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 7000;
    //expect(component).toBeTruthy();
  });

  it('should call previous step method', () => {
    component.prevStep();
  });

  it('should call execute additional premium method', () => {
    //component.executeAdditionalPremium();
  });

  it('should call change selection method', () => {
    component.changeSelection();
  });

  it('shovuld call navigation to premium splitpage method', () => {
    component.gotoPremiumSplitPage();
  });

  it('should call validate entered amount method', () => {
    component.validateEnteredAmount('step2AddPremFormDiv');
  });

  it('should call validate select account method', () => {
    component.validateSelectAccount('step1AddPremFormDiv');
    expect(component.FundAccountEmpty).toEqual(false);
    component.validateSelectedAccountDetails(component.selectAccRefComp.selectedRow, 'step1AddPremFormDiv');
  });

  it('should call next step method', () => {
    spyOn(component, 'nextStep').and.callThrough();
    component.nextStep('step1AddPremFormDiv');
    component.isMobile = false;
    component.setFocus('step1AddPremFormDiv')
  })

  it('should call goto step method', () => {
    component.gotoStep('step1AddPremFormDiv');
  });

  it('should call set step method', () => {
    component.setStep(1);
  });

  it('should call set focus method', () => {
    component.setFocus('step1AddPremFormDiv');
  });

  it('should call check completion status method', () => {
    component.checkStepCompletionStatus(1);
  });

  it('should call validate selected account details method if active order false', () => {
    const value = [{ "effectiveDate": 1258498800000, "policyNumber": "21280988", "investAccType": 5, "investAccNumber": "21280988", "status": 23, "investValue": 3350.52, "productPlan": "UB2BTEB07", "bankAccount": "90 1030 1944 9000 0500 2128 0988", "valuationDt": 1380664800000, "investAccNumberTip": "InvestAccountTypeInfoTip5" }]
    component.validateSelectedAccountDetails(value, 'step1AddPremFormDiv');
    component.responseActiveOrder = { "policyNumber": "21280988", "selectedInvestmentStrategy": "Deposit to Existing Invest Account", "investAccNumber": "21280988", "accountNotSelectedErrorRender": false, "activeOrderErrorRender": true }
    expect(component.showOrderProcessingErr).toEqual(false);
    expect(component.authorizationFlag).toEqual(false);
    expect(component.orderErrorRender).toEqual(false);
    expect(component.exceedsMaximumValueErr).toEqual(false);
    expect(component.amountValueEmptyErr).toEqual(false);
    expect(component.insufficientValueErr).toEqual(false);
    expect(component.acceptAckErr).toEqual(false);
    expect(component.step1Completed).toEqual(true);
    expect(component.stepper.selected.completed).toEqual(true);
  });

  it('should call validate selected account details method if active order render true', () => {
    const value = [{ "effectiveDate": 1258498800000, "policyNumber": "21280988", "investAccType": 5, "investAccNumber": "21280988", "status": 23, "investValue": 3350.52, "productPlan": "UB2BTEB07", "bankAccount": "90 1030 1944 9000 0500 2128 0988", "valuationDt": 1380664800000, "investAccNumberTip": "InvestAccountTypeInfoTip5" }]
    component.validateSelectedAccountDetails(value, 'step1AddPremFormDiv');
    component.responseActiveOrder = { "policyNumber": "21280988", "selectedInvestmentStrategy": "Deposit to Existing Invest Account", "investAccNumber": "21280988", "accountNotSelectedErrorRender": false, "activeOrderErrorRender": false }
    expect(component.showOrderProcessingErr).toEqual(true);
    expect(component.authorizationFlag).toEqual(false);
    expect(component.orderErrorRender).toEqual(false);
    expect(component.exceedsMaximumValueErr).toEqual(false);
    expect(component.amountValueEmptyErr).toEqual(false);
    expect(component.insufficientValueErr).toEqual(false);
    expect(component.acceptAckErr).toEqual(false);
    expect(component.step1Completed).toEqual(false);
    expect(component.stepper.selected.completed).toEqual(false);
    window.scrollTo(0, 0);

  });

  it('should call addtional premium api method', () => {
    const value = [{ "effectiveDate": 1258498800000, "policyNumber": "21280988", "investAccType": 5, "investAccNumber": "21280988", "status": 23, "investValue": 3350.52, "productPlan": "UB2BTEB07", "bankAccount": "90 1030 1944 9000 0500 2128 0988", "valuationDt": 1380664800000, "investAccNumberTip": "InvestAccountTypeInfoTip5" }]
    component.callAdditionalPremiumApi(value, 'step1AddPremFormDiv');
    const response = {
      "policyNumber": "21281278",
      "investAccNumber": "21281278",
      "fundInjectionDTO": {
        "sort": null,
        "orderType": null,
        "processingSystem": null,
        "requestingSystem": null,
        "fundCode": null,
        "fundType": null,
        "policyNumber": null,
        "premiumAmount": null,
        "addAmtTopUpUnits": null,
        "totalAmtCurrent": null,
        "addCoverageAmt": null,

        "serviceReqNumber": null,

        "serviceReqType": null,

        "serviceReqTypeDisplay": null,

        "minimumDepositAmount": "700.00 PLN",

        "maximumDepositAmount": "1,470.00 PLN",

        "statementCheck": false,

        "renderStatementUnchecked": false,

        "renderDepositAmtTooBig": false,

        "renderMissingAddTopUpAmt": false,

        "renderDepositAmtTooSmall": false,

        "bankAccountNumber": null,

        "cutOffTime": null,

        "renderUnauthorizedErr": false,

        "renderCutOffMsg": false,

        "productPlan": null,

        "investAcctNumber": null,

        "investAcctNumberTip": null,

        "investAccTipDisplay": null,

        "transerTitle": null,

        "certificatedProductPlan": null,

        "fundLink": null,

        "errorContentStyle": null,

        "allocationPercentage": null,

        "minimumAmountPerFund": null,

        "minimumAllocationPerFund": null,

        "submittedBy": null,

        "orderSubmissionDate": null,

        "orderRealizationDate": null,

        "subject": null,

        "renderContractNumber": false,

        "renderSubject": false,

        "renderRealizationDate": false,

        "renderStatementBtn": false,

        "allocatedFundsList": null,

        "addTopUpLumpSum": null,

        "displayText": null,

        "displayLink": null,

        "addCoverageAmtDisplay": null,

        "newAllocationAmt": null,

        "addTopUpLumpSumDisplay": null,

        "renderAllowedDepositMsg": false,

        "renderDepositBtwnMsg": true,

        "renderMinDepositMsg": false,

        "orderPaymenstDate": "Payments must be made 10 working days"

      },

      "activeOrderErrorRender": false,

      "authorizationErrorRender": false,

      "orderErrorRender": false,

      "clientId": "2222",

      "userName": "333",
      "firstName": "dasdsa",

      "lastName": "asdsadsad",

      "language": "en",

      "country": "pl"
    }
    component.responseAdditionalPremium = response;
    expect(component.authorizationFlag).toEqual(false);
    expect(component.orderErrorRender).toEqual(false);
  });

  it('should check for Pl_en language', () => {
    window.sessionStorage.setItem("defaultLanguage", "pl_en");
    component.lang = "pl_en";
    component.displayPoOption = true;
  });

  it('should  check for ro_ro language', () => {
    window.sessionStorage.setItem("defaultLanguage", "ro_ro");
    component.lang = "ro_ro";
  });
  it('should check for ro_en language', () => {
    window.sessionStorage.setItem("defaultLanguage", "ro_en");
    component.lang = "ro_en"
  });
});
