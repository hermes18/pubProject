import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from './../../allocation-change/allocation-change-service';

export interface AccountData {
  accountSelection: String;
  status: String;
  effectiveDate: String;
  investValue: String;
  //number: String;
}
@Component({
  selector: 'select-account-additional-premium',
  templateUrl: './select-account.component.html',
  styleUrls: ['./select-account.component.scss']
})

export class SelectAccountAdditionalPremiumComponent implements OnInit {
  displayedColumns: string[] = ['accountSelection', 'effectiveDate', 'status', 'investValue'];
  dataSourceAccDetails: MatTableDataSource<AccountData>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  accountDet: any;
  selectAccountForm: FormGroup;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  contractNo: any;
  userrole = this.menuItemService.getAllRoles();
  clientId: any;
  contractDetails: any;
  contractNumber: any;
  selectedRow: any;
  accountListResponse: any;
  currencyType: string;
  langChange: string;
  selectedAccountNumber: any;
  checkBoxSelection: any;
  defaultValue: number = 0.00;

  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private fb: FormBuilder,
    private menuItemService: MenuItemsService,
    private newPremiumService: AllocationChangeSharedService) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
      this.currencyType = 'PLN';
    }
    else {
      this.displayRoOption = true;
      this.currencyType = 'RON';
    }
    let userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    this.contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));
    //('additional premium', this.contractDetails);
    this.contractNumber = this.contractDetails ? this.contractDetails.contractNumber : null;//JSON.parse(sessionStorage.getItem('contract'));
    // if (this.userrole === "rClient") {
    //   this.clientId = userdetail.clientID;
    // } else {
    //   this.clientId = customerId.clientID;
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (userdetail) {
      this.clientId = userdetail.clientId ? userdetail.clientId : '';
    }
    this.selectAccountForm = this.fb.group({
      selectedAccount: this.fb.array([]),//new FormControl('', [Validators.required]),
      // investAccNumber: new FormControl(''),
      // policyNumber: new FormControl(''),
      // investAccType: new FormControl(''),
      // effectiveDate: new FormControl(''),
      // status: new FormControl(''),
      // investValue: new FormControl(''),
      // productPlan:new FormControl(''),
      // bankAccount: new FormControl(''),
      // valuationDt: new FormControl('')
    });
    this.sharedService.getDetail('checkBoxSelection').subscribe((data) => {
      if (data) {
        this.checkBoxSelection = data;
        //(this.checkBoxSelection)

      }
    })
    this.selectedAccountNumber = JSON.parse(sessionStorage.getItem('clickedAccountNumber'));
    this.langChange = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if (this.langChange == "pl_en") {
      this.langChange = "en";
    } else if (this.langChange == "pl_pl") {
      this.langChange = "pl";
    } else if (this.langChange == "ro_en") {
      this.langChange = "en";
    } else if (this.langChange == "ro_ro") {
      this.langChange = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.langChange = data;
      }
    });
    this.getAccounts();
  }

  get selectedAccount() {
    return this.selectAccountForm.get('selectedAccount') as FormArray;

  }

  radiobuttonClick(row) {
    //row.controls['selectedPolicy'].setValue(true);
    this.selectedRow = row;
    //(this.selectedRow)
    // this.selectAccountForm.controls['investAccNumber'].setValue(row.investAccNumber);
    // this.selectAccountForm.controls['policyNumber'].setValue(row.policyNumber);
    // this.selectAccountForm.controls['investAccType'].setValue(row.investAccType);
    // this.selectAccountForm.controls['effectiveDate'].setValue(row.effectiveDate);
    // this.selectAccountForm.controls['status'].setValue(row.status);
    // this.selectAccountForm.controls['investValue'].setValue(row.investValue);
    // this.selectAccountForm.controls['productPlan'].setValue(row.productPlan);
    // this.selectAccountForm.controls['bankAccount'].setValue(row.bankAccount);
    // this.selectAccountForm.controls['valuationDt'].setValue(row.valuationDt);
  }

  getAccounts() {
    let randomVal = (Math.floor((Math.random() * 100000000) + 1)) + '';
    if (document.getElementById('slct_AdditionPrem_component_starts')) {

      let overLay = document.createElement('div');
      overLay.setAttribute("class", 'overLay');
      overLay.setAttribute("id", randomVal);

      let spin = document.createElement('div');

      //spin.setAttribute("bdColor", "grey");

      spin.setAttribute("class", 'loader');
      overLay.appendChild(spin);
      document.getElementById('slct_AdditionPrem_component_starts').appendChild(overLay);
    }
    const reqParam = {
      "contractNumber": this.contractNumber ? this.contractNumber : '',//"21295126",
      "clientId": this.clientId ? this.clientId : null,//"101583",
      "selectedInvestmentStrategy": "Deposit to Existing Invest Account"
    }
    // this.commonService.postData(this.baseUrl.ecustomer.accountList, reqParam, '').subscribe(data => {
    //   this.accountListResponse = data;
    //   this.selectAccountForm['controls'].selectedAccount['controls'] = [];
    //   if (data && data.length > 1) {
    //     for (var i = 0; i < data.length; i++) {
    //       this.add(i);
    //     }
    //   } else if (data.length == 1) {
    //     this.add(0);
    //   }
    this.commonService.postData(this.baseUrl.ecustomer.accountList, reqParam, '').subscribe(data => {
      this.accountListResponse = data;
      this.selectAccountForm['controls'].selectedAccount['controls'] = [];
      if (data && data.length > 1) {
        for (var i = 0; i < data.length; i++) {
          this.add(i);
          if (this.checkBoxSelection == true) {
            if (data[i].investAccNumber == this.selectedAccountNumber) {
              this.selectedRow = data[i];
            }
          }
        }
      } else if (data.length == 1) {
        this.add(0);
        if (this.checkBoxSelection == true) {
          // console.log(data)

          if (data[0].investAccNumber == this.selectedAccountNumber) {

            this.selectedRow = data[0];
          }
        }
      }
      this.dataSourceAccDetails = new MatTableDataSource(data);
      // this.dataSourceAccDetails = new MatTableDataSource(this.selectAccountForm['controls'].selectedAccount['controls']);
      if (document.getElementById(randomVal)) {
        //document.getElementById(randomVal).remove();
        document.getElementById(randomVal).parentElement.removeChild(document.getElementById(randomVal));
      }
    })
  }

  add(index) {
    this.selectedAccount.push(this.new(index));
    //(this.selectedAccount)
  }

  new(index): FormGroup {
    return this.fb.group({
      // selectedPolicy:[false],
      investAccNumber: this.accountListResponse[index].investAccNumber,//new FormControl(''),
      policyNumber: this.accountListResponse[index].policyNumber,
      investAccType: this.accountListResponse[index].investAccType,
      effectiveDate: this.accountListResponse[index].effectiveDate,
      status: this.accountListResponse[index].status,
      investValue: this.accountListResponse[index].investValue,
      productPlan: this.accountListResponse[index].productPlan,
      bankAccount: this.accountListResponse[index].bankAccount,
      valuationDt: this.accountListResponse[index].valuationDt,
      showMsg: false
    })
  }


  formSubmit() {
    return this.selectAccountForm.valid;
  }

  submitSelectedAccount() {
    this.selectAccountForm.markAsTouched();
    //markAsTouched
    this.newPremiumService.setaccountData(this.selectedRow);//this.selectAccountForm.value);
    //this.newPremiumService.setFundData(this.destinationFundForm.controls['fundListArray'].value);
    this.newPremiumService.setParamValue('selectAccountForm', this.selectAccountForm);
  }

  openTooltipMsg(row) {
    if (row.investAccNumberTip == 'InvestAccountTypeInfoTip5') {
      if (!row.showMsg) {
        row.showMsg = true;
      } else {
        row.showMsg = false;
      }
    }
  }
}
