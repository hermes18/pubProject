import { HttpHeaders } from '@angular/common/http';
import { OnInit, Component, Input } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { changePremiumSharedService } from 'src/app/change-premium-split/change-premium-shared-service';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../../allocation-change/allocation-change-service';

@Component({
  selector: 'summary-additional-premium',
  templateUrl: './summary-additional-premium.component.html',
  styleUrls: ['./summary-additional-premium.component.scss']
})
export class SummaryAdditionalPremiumComponent implements OnInit {
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  headers = new HttpHeaders();
  responseAdditionalPremium: any;
  summaryResult: any;
  userrole = this.menuItemService.getAllRoles();
  summaryPage: boolean;
  @Input() confirmationPageDisplay;
  orderId: any;
  declaredAmount: any;
  accountDetails: any;
  country: string;
  displayPoOption: boolean;
  currencyType: string;
  langChange: string;
  showAccNumberValue: any;
  cnpFieldMask: any;
  defaultValue:0.00;
  displayRoOption: boolean;
  showMsg: any;
  constructor(
    private translate: TranslateService, private _formBuilder: FormBuilder,
    private httpService: HttpCommonService, private router: Router,
    private route: ActivatedRoute,
    private newPremiumService: AllocationChangeSharedService,
    private menuItemService: MenuItemsService,
    private sharedService: SharedServiceService
  ) {
    ////(this.confirmationPageDisplay)
  }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
      this.currencyType = 'PLN';
    }
    else {
      this.displayRoOption = true;
      this.currencyType = 'RON';
    }
    this.langChange = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if (this.langChange == "pl_en"){
      this.langChange = "en";
    }else if(this.langChange == "pl_pl"){
      this.langChange = "pl";
    } else if(this.langChange == "ro_en"){
      this.langChange = "en";
    }else if(this.langChange == "ro_ro"){
      this.langChange = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.langChange = data;
      }
    });
    this.newPremiumService.getSummaryReqData().subscribe((val) => {
      this.responseAdditionalPremium = val;
      // this.summaryPage = confirmationPage;      
    })
    this.newPremiumService.getConfReqData().subscribe((val) => {
      this.summaryResult = val;
      if (this.summaryResult != null && this.summaryResult.orderId && !this.summaryResult.activeOrderErrorRender) {
        this.orderId = this.summaryResult.orderId;
        this.newPremiumService.setOrderId(this.summaryResult.orderId);
        sessionStorage.setItem('orderData', this.orderId);
      } else { this.orderId = '' }
      // this.summaryPage = false;
    })
    this.newPremiumService.getDeclaredAmount().subscribe((amnt) => {
      this.declaredAmount = amnt != null ? amnt : 0;
      //(this.declaredAmount)
    });
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = data;
      this.cnpFieldMask = this.accountDetails ? this.accountDetails.bankAccount ? this.MaskDigits(this.accountDetails.bankAccount) : [] : [];
      this.showAccNumberValue = this.accountDetails ? this.accountDetails.bankAccount ? true : false : false;
    })

  }

  private MaskDigits(input) {
    let first2 = input.substring(0, 2);
    let last5 = input.substring(input.length - 5);
    let mask = input.substring(2, input.length - 5).replace(/\d/g, "*");
    return first2 + mask + last5;
  }

  gotoPremiumSplitPage() {
    // this.gotoPremiumSplit = true;
    //this.valueChange.emit('allocationChange');
    //this.sharedService.setPageContent('depositToExistingAccount');
    let data = {
      //'fromPage': 'depositToExistingAccount',
      "toPage": 'orderInvest'
    }
    this.sharedService.setPageContent(data);
  }

  callApi(summary) {
    // const req = {
    //   "policyNumber": "21281278",
    //   "investAccNumber": "21281278",
    //   "clientId": "2222",
    //   "userName": "333",
    //   "firstName": "dasdsa",
    //   "lastName": "asdsadsad",
    //   "language": "en",
    //   "country": "pl"
    // }
    // this.httpService.postData(this.baseUrl.ecustomer.additionalPremium, req, this.headers).subscribe(data => {
    //   this.responseAdditionalPremium = data;
    // });

  }
  goToAllocationChange() {
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    this.sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    let data = {
      'orderNumber': this.orderId
    }
    sessionStorage.setItem('orderData', JSON.stringify(data));
    this.router.navigate(['/orderHistory/singlePremiumSave']);
  }

  toggleFieldTextType() {
    this.showAccNumberValue = !this.showAccNumberValue;
  }

  openTooltipMsg(){
    if(this.accountDetails.investAccNumberTip == 'InvestAccountTypeInfoTip5'){
      if(!this.showMsg){
        this.showMsg = true;
      }else{
        this.showMsg = false;
      }
    }
  }
}
