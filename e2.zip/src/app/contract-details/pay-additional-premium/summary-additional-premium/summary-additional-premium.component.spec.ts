import { APP_BASE_HREF } from '@angular/common';
import { HttpHeaders } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { AppConfig } from 'src/config/app.config';
import { ContractDetailsModule } from '../../contract-details.module';

import { SummaryAdditionalPremiumComponent } from './summary-additional-premium.component';

describe('SummaryAdditionalPremiumComponent', () => {
  let component: SummaryAdditionalPremiumComponent;
  let fixture: ComponentFixture<SummaryAdditionalPremiumComponent>;
  let appConfig: AppConfig = AppConfig.getConfig();
  //let menuItemService: MenuItemsService;
  let baseUrl = appConfig['api'];
  let headers = new HttpHeaders();
  //let userrole = menuItemService.getAllRoles();
  let summary = [];
  let globalObjectService: jasmine.SpyObj<AppConfig>;
  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
  //     providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
  //     declarations: []
  //   })
  //     .compileComponents();
  // }));

  beforeEach(() => {
    globalObjectService = jasmine.createSpyObj('AppConfig', ['getConfig']);
    window.sessionStorage.setItem("defaultLanguage", "pl_pl");
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(SummaryAdditionalPremiumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call navigation to premium split page', () => {
    component.gotoPremiumSplitPage();
  });

  it('should call navigation to allocation change page', () => {
    component.goToAllocationChange();
  });

  it('should call toggle field method', () => {
    component.toggleFieldTextType();
  });

  it('should call open tooltip msg', () => {
    const value = [{ "effectiveDate": 1258498800000, "policyNumber": "21280988", "investAccType": 5, "investAccNumber": "21280988", "status": 23, "investValue": 3350.52, "productPlan": "UB2BTEB07", "bankAccount": "90 1030 1944 9000 0500 2128 0988", "valuationDt": 1380664800000, "investAccNumberTip": "InvestAccountTypeInfoTip5" }]
    component.accountDetails = value;
    component.openTooltipMsg();
   // component.accountDetails.investAccNumberTip == 'InvestAccountTypeInfoTip5'
  });

  it('should call summary api method', () => {
    component.callApi(summary);
  });

  xit('should call mask digits method', () => {
    // component.MaskDigits('1234567890123456');
  });
});

