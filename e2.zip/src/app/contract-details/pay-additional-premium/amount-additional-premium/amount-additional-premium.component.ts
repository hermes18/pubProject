import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { changePremiumSharedService } from 'src/app/change-premium-split/change-premium-shared-service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { TransformPipe } from 'src/app/shared/pipe/transform.pipe';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../../allocation-change/allocation-change-service';

@Component({
  selector: 'amount-additional-premium',
  templateUrl: './amount-additional-premium.component.html',
  styleUrls: ['./amount-additional-premium.component.scss']
})
export class AmountAdditionalPremiumComponent implements OnInit {

  selectAdditionalAmountForm: FormGroup;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  headers = new HttpHeaders();
  responseAdditionalPremium: any;
  country: string;
  displayPoOption: boolean;
  currencyType: string;
  langChange: string;
  defaultValue: 0;
  dotCount: number;
  checkNumberOnly: any;
  checkString: any;
  cdr: any;
  displayRoOption: boolean;
  exceedInputAmount: boolean = false;
  insuffInputAmount: boolean = false;
  accountDetails: any;

  constructor(
    private translate: TranslateService, private _formBuilder: FormBuilder,
    private httpService: HttpCommonService, private router: Router,
    private route: ActivatedRoute,
    private newPremiumService: AllocationChangeSharedService,
    private transform: TransformPipe,
    private sharedService: SharedServiceService
  ) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    //  if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
      this.currencyType = 'PLN';
    }
    else {
      this.displayRoOption = true;
      this.currencyType = 'RON';
    }
    this.langChange = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /* if (this.langChange == "pl_en") {
      this.langChange = "en";
    } else if (this.langChange == "pl_pl") {
      this.langChange = "pl";
    } else if (this.langChange == "ro_en") {
      this.langChange = "en";
    } else if (this.langChange == "ro_ro") {
      this.langChange = "ro";
    } */
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.langChange = data;
        if (this.selectAdditionalAmountForm && this.selectAdditionalAmountForm.controls['amountField'].value != '') {
          if (this.langChange == 'pl' || this.langChange == 'ro' || this.langChange == 'gr') {
            this.selectAdditionalAmountForm.controls['amountField'].setValue((this.selectAdditionalAmountForm.controls['amountField'].value.includes('.') ? this.selectAdditionalAmountForm.controls['amountField'].value.replace('.', ',') : this.selectAdditionalAmountForm.controls['amountField'].value));
          } else {
            this.selectAdditionalAmountForm.controls['amountField'].setValue((this.selectAdditionalAmountForm.controls['amountField'].value.includes(',') ? this.selectAdditionalAmountForm.controls['amountField'].value.replace(',', '.') : this.selectAdditionalAmountForm.controls['amountField'].value));
          }
        }
      }
    });
    this.selectAdditionalAmountForm = this._formBuilder.group({
      amountField: ['', [Validators.required]],
      acknowledge: ['', [Validators.required
      ]
      ]
    });
    this.newPremiumService.getSummaryReqData().subscribe((val) => {
      this.responseAdditionalPremium = val;
      // this.summaryPage = true;
    })
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = data;
    })
    //this.callApi()
  }

  onClickAccept(evt) {
    //()
    this.selectAdditionalAmountForm.controls['acknowledge'].setValue(evt);
  }

  // callApi() {
  //   const req = {
  //     "policyNumber": "21281278",
  //     "investAccNumber": "21281278",
  //     "clientId": "2222",
  //     "userName": "333",
  //     "firstName": "dasdsa",
  //     "lastName": "asdsadsad",
  //     "language": "en",
  //     "country": "pl"
  //   }
  //   this.httpService.postData(this.baseUrl.ecustomer.additionalPremium, req, this.headers).subscribe(data => {
  //     this.responseAdditionalPremium = data;
  //   });

  // }
  formSubmit() {
    return this.selectAdditionalAmountForm.valid;
  }

  submitSelectedAccount() {
    this.selectAdditionalAmountForm.markAsTouched();
    //markAsTouched
    //this.newPremiumService.setaccountData(this.selectAdditionalAmountForm.value);
    this.newPremiumService.setParamValue('amountAdditionalForm', this.selectAdditionalAmountForm);
  }

  numberOnly(event) {
    //event.target.value(/^\d+\.?\d{0,2}/);
    // const charCode = (event.which) ? event.which : event.keyCode;
    // if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    //   return false;
    // }
    // return true;
    if (this.langChange == "pl" || this.langChange == "ro" ||this.langChange == 'gr') {
      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode == 44) {
        this.dotCount += 1;
        this.checkNumberOnly = (event.target.value);
        var numericCheck = (event.target.value).toString();
        if (numericCheck.includes(',')) {
          this.dotCount += 1;
        }
        if (this.dotCount > 1) {
          this.dotCount = 0;
          return false;
        }
      }
      if (charCode > 31 && charCode != 44 && (charCode < 45 || charCode > 57 || charCode == 47 || charCode == 46)) {
        return false;
      }
      this.checkNumberOnly = (event.target.value);
      if (this.checkNumberOnly != null) {
        var numeric = (event.target.value).toString();
        if (numeric.includes(',')) {
          var checkNumeric = numeric.split(',');
          if (checkNumeric.length > 2) {
            return false;
          }
          this.checkString = checkNumeric[1].split('');
          if (this.checkString.length > 1) {
            // this.toastrService.warning("Invalid value", "Warning");
            return false;
          }
        }

      }
      this.dotCount = 0;
      //this.cdr.detectChanges();
      return true;
    } else if (this.langChange == "en") {
      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode == 46) {
        this.dotCount += 1;
        this.checkNumberOnly = (event.target.value);
        var numericCheck = (event.target.value).toString();
        if (numericCheck.includes('.')) {
          this.dotCount += 1;
        }
        if (this.dotCount > 1) {
          this.dotCount = 0;
          return false;
        }
      }
      if (charCode > 31 && (charCode < 45 || charCode > 57 || charCode == 47)) {
        return false;
      }
      this.checkNumberOnly = (event.target.value);
      if (this.checkNumberOnly != null) {
        var numeric = (event.target.value).toString();
        if (numeric.includes('.')) {
          var checkNumeric = numeric.split('.');
          if (checkNumeric.length > 2) {
            return false;
          }
          this.checkString = checkNumeric[1].split('');
          if (this.checkString.length > 1) {
            // this.toastrService.warning("Invalid value", "Warning");
            return false;
          }
        }

      }
      this.dotCount = 0;
      //this.cdr.detectChanges();
      return true;
    }
  }

  numberValueAmnt(event, action) {
    let pastedText;
    if (action == 'paste') {
      let clipboardData = event.clipboardData;
      pastedText = clipboardData.getData('text');
    } else {
      pastedText = event.target.value;
      // let pastedText = clipboardData.getData('text');
    }
    event.preventDefault();
    let ctrl = this.selectAdditionalAmountForm.get('amountField') as FormControl;
    ctrl.setValue(this.transform.transform(pastedText, this.langChange), { emitEvent: false, emitViewToModelChange: false });
    this.checkNumberOnly = (ctrl.value);
    if (this.checkNumberOnly != null) {
      let numeric = (ctrl.value).toString();
      if (this.langChange == 'pl' || this.langChange == 'ro' || this.langChange == 'gr') {
        if (numeric.includes(',')) {
          let checkNumeric = numeric.split(',');
          if (checkNumeric.length > 2) {
            ctrl.setValue(checkNumeric[0].substr(0, 8) + ',' + checkNumeric[1].substr(0, 2));
            return false;
          }
          this.checkString = checkNumeric[1].split('');
          if (this.checkString.length <= 2) {
            ctrl.setValue(checkNumeric[0].substr(0, 8) + ',' + checkNumeric[1].substr(0, 2));
            // this.toastrService.warning("Invalid value", "Warning");
            // return false;
          } else {
            let afterDot = checkNumeric[1].substr(0, 2);
            ctrl.setValue(checkNumeric[0].substr(0, 8) + ',' + afterDot);
            // return true;
          }
        } else {
          ctrl.setValue(numeric.substr(0, 8));
        }
      } else {
        if (numeric.includes('.')) {
          let checkNumeric = numeric.split('.');
          if (checkNumeric.length > 2) {
            ctrl.setValue(checkNumeric[0].substr(0, 8) + '.' + checkNumeric[1].substr(0, 2));
            return false;
          }
          this.checkString = checkNumeric[1].split('');
          if (this.checkString.length <= 2) {
            ctrl.setValue(checkNumeric[0].substr(0, 8) + '.' + checkNumeric[1].substr(0, 2));
            // this.toastrService.warning("Invalid value", "Warning");
            // return false;
          } else {
            let afterDot = checkNumeric[1].substr(0, 2);
            ctrl.setValue(checkNumeric[0].substr(0, 8) + '.' + afterDot);
            //return true;
          }
        } else {
          ctrl.setValue(numeric.substr(0, 8));
        }
      }
      let reg1Str;
      let temp = ctrl.value;//obj.value;
      let decimalValue;
      if (this.langChange == 'en') {
        decimalValue = '.';
      }
      else {
        decimalValue = ',';
      }

      let decimalPlaces = 2;
      let reg0Str = '[0-9]*';
      if (decimalPlaces > 0) {
        if (this.langChange == 'en') {
          reg0Str += '\\.?[0-9]{0.' + decimalPlaces + '}';
        }
        else {
          reg0Str += '\\,?[0-9]{0,' + decimalPlaces + '}';
        }
      } else if (decimalPlaces < 0) {
        if (this.langChange == 'en') {
          reg0Str += '\\.?[0-9]*';
        }
        else {
          reg0Str += '\\,?[0-9]*';
        }
      }
      if (decimalPlaces != 0) {
        let reg3;
        if (this.langChange == 'en') {
          reg3 = /\./g;
        }
        else {
          reg3 = /\,/g;
        }
        let reg3Array = reg3.exec(temp);
        if (reg3Array != null) {
          // keep only first occurrence of .
          //  and the number of places specified by decimalPlaces or the entire string if 

          decimalPlaces < 0
          let reg3Right = temp.substring(reg3Array.index + reg3Array[0].length);
          reg3Right = reg3Right.replace(reg3, '');
          reg3Right = decimalPlaces > 0 ? reg3Right.substring(0, decimalPlaces) : reg3Right;
          temp = temp.substring(0, reg3Array.index) + decimalValue + reg3Right;
        }
      }

      // obj.value = temp;
      ctrl.setValue(temp);
      return true;
    }
  }

  validateInputAmount(event) {
    let inputAmount = this.selectAdditionalAmountForm.controls['amountField'].value;//event.target.value;
    if (this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount != null && this.responseAdditionalPremium.fundInjectionDTO.maximumDepositAmount != null) {
      let splitMinimum = this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount.split(' ', 2);
      let splitMaximum = this.responseAdditionalPremium.fundInjectionDTO.maximumDepositAmount.split(' ', 2);
      let minimumValue = splitMinimum[0].replace('/,/g', '');
      let maximumValue = splitMaximum[0].replace('/,/g', '');
      if (event.target.value != "" || event.target.value != 0) {
        if (parseFloat(inputAmount) < parseFloat(minimumValue.replace(/,/g, ""))) {
          this.insuffInputAmount = true;
        } else if (parseFloat(inputAmount) > parseFloat(maximumValue.replace(/,/g, ""))) {
          this.exceedInputAmount = true;
        } else {
          this.insuffInputAmount = false;
          this.exceedInputAmount = false;
        }
      }
    } else if (this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount != null && this.responseAdditionalPremium.fundInjectionDTO.maximumDepositAmount == null) {
      let splitMinimum = this.responseAdditionalPremium.fundInjectionDTO.minimumDepositAmount.split(' ', 2);
      let minimumValue = splitMinimum[0].replace('/,/g', '');
      if (event.target.value != "" || event.target.value != 0) {
        if (parseFloat(inputAmount) < parseFloat(minimumValue.replace(/,/g, ""))) {
          this.insuffInputAmount = true;
        } else {
          this.insuffInputAmount = false;
          this.exceedInputAmount = false;
        }
      }
    } else { }
  }

}
