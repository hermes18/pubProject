import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ContractDetailsModule } from '../../contract-details.module';

import { AmountAdditionalPremiumComponent } from './amount-additional-premium.component';

describe('AmountAdditionalPremiumComponent', () => {
  let component: AmountAdditionalPremiumComponent;
  let fixture: ComponentFixture<AmountAdditionalPremiumComponent>;

  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(AmountAdditionalPremiumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call form submit', () => {
    component.formSubmit();
  });

  it('should call selected account', () => {
    component.submitSelectedAccount();
  });

  it('should call onClick event', () => {
    component.onClickAccept(true);
  });

  it('should check for Pl_en language', () => {
    window.sessionStorage.setItem("defaultLanguage", "pl_en");
    component.langChange = "pl_en";
    component.displayPoOption = true;
    component.currencyType = 'PLN';
    expect(component.displayPoOption).toBe(true);
  });

  it('should  check for ro_ro language', () => {
    window.sessionStorage.setItem("defaultLanguage", "ro_ro");
    component.langChange = "ro_ro";
    component.displayRoOption = true;
    component.currencyType = 'RON';
    expect(component.displayRoOption).toBe(true);
  });
  it('should check for ro_en language', () => {
    window.sessionStorage.setItem("defaultLanguage", "ro_en");
    component.langChange = "ro_en"
    component.displayRoOption = true;
    component.currencyType = 'RON';
    expect(component.displayRoOption).toBe(true);

  });});
