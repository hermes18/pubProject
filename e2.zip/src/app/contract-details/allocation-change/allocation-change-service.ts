import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { observable, Subject, Observable } from 'rxjs';

@Injectable({providedIn:'root'})
export class AllocationChangeSharedService {

    private accountDetails:  BehaviorSubject<any>;
    private selectedFundDetails: BehaviorSubject<any>;
    private summaryReqDetails: BehaviorSubject<any>;
    private confReqDetails: BehaviorSubject<any>;
    private reviewReqDetails: BehaviorSubject<any>;
    private fundListArray: BehaviorSubject<any>;
    private orderId: BehaviorSubject<any>;
    private declaredAmount: BehaviorSubject<any>;
    private singlePremiumFunds: BehaviorSubject<any>;
    private singlePremiumSummary: BehaviorSubject<any>;
    private destinationFund:BehaviorSubject<any>;
    private sourceFund: BehaviorSubject<any>;
    private fundSummaryData: BehaviorSubject<any>;
    private fundConfData: BehaviorSubject<any>;
    private allocationConfResData: BehaviorSubject<any>;
    private destUpdated:BehaviorSubject<any>;
    private sourceUpdated: BehaviorSubject<any>;
    private singlefunds: BehaviorSubject<any>;
    constructor() {
        this.selectedFundDetails = new BehaviorSubject(null);
        this.accountDetails = new BehaviorSubject(null);
        this.summaryReqDetails = new BehaviorSubject(null);
        this.confReqDetails = new BehaviorSubject(null);
        this.reviewReqDetails = new BehaviorSubject(null);
        this.fundListArray = new BehaviorSubject(null);
        this.orderId = new BehaviorSubject(null);
        this.declaredAmount = new BehaviorSubject(null);
        this.singlePremiumFunds = new BehaviorSubject(null);
        this.singlePremiumSummary = new BehaviorSubject(null);
        this.destinationFund= new BehaviorSubject(null);
        this.sourceFund = new BehaviorSubject(null);
        this.fundSummaryData = new BehaviorSubject(null);
        this.fundConfData = new BehaviorSubject(null);
        this.allocationConfResData = new BehaviorSubject(null);
        this.destUpdated = new BehaviorSubject(null);
        this.sourceUpdated = new BehaviorSubject(null);
        this.singlefunds = new BehaviorSubject(null);
    }
    
    setaccountData(data: any) {
        this.accountDetails.next(data);
    }

    getaccountData(): any {
        return this.accountDetails.asObservable();
    }

    getParamValue(param) {
        return this[param];
    }
    setParamValue(param, value) {
        this[param] = value;
    }

    setFundData(data: any) {
        this.selectedFundDetails.next(data);
    }

    getFundData(): any {
        return this.selectedFundDetails.asObservable();
    }

    setSummaryReqData(data: any) {
        this.summaryReqDetails.next(data);
    }

    getSummaryReqData(): any {
        return this.summaryReqDetails.asObservable();
    }

    setConfReqData(data: any) {
        this.confReqDetails.next(data);
    }

    getConfReqData(): any {
        return this.confReqDetails.asObservable();
    }

    setReviewReqData(data: any) {
        this.reviewReqDetails.next(data);
    }

    getReviewReqData(): any {
        return this.reviewReqDetails.asObservable();
    }

    setFundListResponse(data):any{
        this.fundListArray.next(data);
    }

    getFundListResponse(): any {
        return this.fundListArray.asObservable();
    }

    setOrderId(data):any{
        this.orderId.next(data);
    }

    getOrderId(): any {
        return this.orderId.asObservable();
    }    

    setDeclaredAmount(data):any{
        this.declaredAmount.next(data);
    }

    getDeclaredAmount(): any {
        return this.declaredAmount.asObservable();
    }  
    setSinglePremiumFunds(data):any{
        this.singlePremiumFunds.next(data);
    }

    getSinglePremiumFunds(): any {
        return this.singlePremiumFunds.asObservable();
    } 

    setSinglePremiumSummary(data):any{
        this.singlePremiumSummary.next(data);
    }

    getSinglePremiumSummry(): any {
        return this.singlePremiumSummary.asObservable();
    } 

    setSourceFund(data):any{
        this.sourceFund.next(data);
    }

    getSourceFund(): any {
        return this.sourceFund.asObservable();
    } 

    setDestinationFund(data):any{
        this.destinationFund.next(data);
    }

    getDestinationFund(): any {
        return this.destinationFund.asObservable();
    } 

    setTransferFundSummary(data):any{
        this.fundSummaryData.next(data);
    }

    getTransferFundSummary(): any {
        return this.fundSummaryData.asObservable();
    }

    setTransferFundConfRes(data):any{
        this.fundConfData.next(data);
    }

    getTransferFundConfRes(): any {
        return this.fundConfData.asObservable();
    }

    setAllocationChangeConfRes(data):any{
        this.allocationConfResData.next(data);
    }

    getAllocationChangeConfRes(): any {
        return this.allocationConfResData.asObservable();
    }
    setUpdatedSource(data):any{
        this.sourceUpdated.next(data);
    }

    getUpdatedSource(): any {
        return this.sourceUpdated.asObservable();
    }
    setUpdatedDestination(data):any{
        this.destUpdated.next(data);
    }

    getUpdatedDestination(): any {
        return this.destUpdated.asObservable();
    }
    setSingleFundListResponse(data):any{
        this.singlefunds.next(data);
    }

    getSingleFundListResponse(): any {
        return this.singlefunds.asObservable();
    }

}