import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatStepperModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { ContractDetailsModule } from '../contract-details.module';
import { AllocationChangeSharedService } from './allocation-change-service';

import { AllocationChangeComponent } from './allocation-change.component';

describe('AllocationChangeComponent', () => {
  let component: AllocationChangeComponent;
  let fixture: ComponentFixture<AllocationChangeComponent>;
  const userImfo =
    { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" }
  const serachClient =
    { "clientId": 1234, "opeType": "search" };
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'accountList': host + '/api/v1/order/change-premium-spilt',
        'getActiveOrder': host + '/api/v1/order/active-order',
        'allocationChange': host + '/api/v1/order/allocation-change',
        'allocationChangeSummary': host + '/api/v1/order/allocation-change-summary',
        'allocationChangeConfirmation': host + '/api/v1/order/allocation-change-confirmation',
      }
    }
  };
  let country = sessionStorage.getItem('countryCode');
  let lang = sessionStorage.getItem('defaultLanguage');
  const userDetails = { "userName": "JDaniel_PL", "firstName": "Prabhu", "lastName": "Jaison", "email": "qatestingsample15@gmail.com", "preferredLanguage": "en", "creationDate": "Wed Feb 10 16:50:24 CET 2021", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 30 17:07:29 CET 2020", "employeeNumber": "", "pwdExpirationDate": "Fri Apr 23 16:50:24 CEST 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3032", "name": "rStandardUser", "description": "RStandardUser" }, { "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": "", "requesterId": "-1", "requesterRole": "3032", "userDn": "ou=People,o=affiliates,c=Poland,o=metlife,dc=metlife,dc=com", "pwdExpirationDelay": "30", "userCheck": true, "tokenParam": null }
  const contractDetails = {
    "benefitType": "SuperKapitał - współubezpieczony 1",
    "businessRoleList": ["owner"],
    "contractDetailsDTO": {
      contractNumber: "21281000", insurer: "INSURER_21281000", insured: "INSURED_21281000", status: 21, paymentMode: "15",
    },
    "contractNumber": "21281000",
    "contractNumberList": null,
    "effectiveDate": "18.11.2009",
    "indexedPremiumAmount": null,
    "insuredName": "INSURED_21281000",
    "premiumAmount": "",
    "premiumAmt": null,
    "premiumAmtType": null,
    "premiumDueDate": null,
    "premiumPaymentMode": "15",
    "premiumType": "15",
    "processingSystem": "OLAS",
    "status": 21
  };
  let data = {
    //'fromPage': 'contractDetails',
    "toPage": 'orderInvest'
  };
  let submenuList = {
    renderContractDetails: true,
    renderContractValue: true,
    renderGeneralData: true,
    renderHistortyOfContractOrders: true,
    renderIndexationBenefits: true,
    renderOrders: true
  };
  const menuItemList = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  }

  // newPremiumService: AllocationChangeSharedService = new AllocationChangeSharedService();
  // let sharedService = TestBed.get(SharedServiceService);
  // const selectAccRefComp = jasmine.createSpy('SelectAccountComponent');
  // const selectFundRefComp = jasmine.createSpy('SelectFundsComponent');
  // const summaryRefComp = jasmine.createSpy('SummarySplitScreenComponent');

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;

    window.sessionStorage.setItem("defaultLanguage", "pl_pl");
    window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));
    window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, MatStepperModule, AllocationChangeSharedService, SharedServiceService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(AllocationChangeComponent);
    component = fixture.componentInstance;
    let sharedService = TestBed.get(SharedServiceService);
    
  let newPremiumService: AllocationChangeSharedService = new AllocationChangeSharedService();
  const selectAccRefComp = jasmine.createSpy('SelectAccountComponent');
  const selectFundRefComp = jasmine.createSpy('SelectFundsComponent');
  const summaryRefComp = jasmine.createSpy('SummarySplitScreenComponent');
    sharedService['contractNo'] = "12121";
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(AllocationChangeComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call set step', () => {
    component.setStep(0);
  });

  it('should call set step', () => {
    component.nextStep('step1AllocatChngFormDiv');
  });

  it('should call previous step', () => {
    component.prevStep()
  });

  it('should call set step', () => {
    component.setFocus('step1AllocatChngFormDiv');
  });

  it('should check step completion status', () => {
    component.checkStepCompletionStatus(0);
  });

  it('should goto step', () => {
    component.gotoStep(1);
  });

  it('should call change selection method', () => {
    component.changeSelection();
  });

  it('should validate select account', () => {
    component.validateSelectAccount('step1AllocatChngFormDiv');
  });

  it('should check step completion status', () => {
    const value = [{ "effectiveDate": 1258498800000, "policyNumber": "21280988", "investAccType": 5, "investAccNumber": "21280988", "status": 23, "investValue": 3350.52, "productPlan": "UB2BTEB07", "bankAccount": "90 1030 1944 9000 0500 2128 0988", "valuationDt": 1380664800000, "investAccNumberTip": "InvestAccountTypeInfoTip5" }]
    component.validateSelectedAccountDetails(value, 'step1AllocatChngFormDiv');
  });

  it('should check step completion status', () => {
    component.validateSelectAccount('step2AllocatChngFormDiv');
  });

  xit('should get unique value', () => {
    let arr = null;
    let comp = null
    //component.getUnique(arr, comp)
  });

  it('should call api', () => {
    let arr = null;
    let comp = null
    //component.callApi(arr, 'step2AllocatChngFormDiv')
  });

  
  it('should execute confirmation api', () => {
    component.executeConfirmationApi();
  });

  it('should call confirmation api', () => {
    //component.callConfirmationApi();
  });

  it('should goto premium split page', () => {
    component.gotoPremiumSplitPage();
  });

  it('should getFundList', () => {
  component.getFundList('step1AllocatChngFormDiv');
  });

  it('should check array validations', () => {
  component.checkArrayValidations();
  });
});
