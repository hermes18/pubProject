import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../allocation-change-service';

@Component({
  selector: 'change-premium-confirmation',
  templateUrl: './change-premium-confirmation.component.html',
  styleUrls: ['./change-premium-confirmation.component.scss']
})
export class ChangePremiumConfirmationComponent implements OnInit {

  confirmationData: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  accountDetails: any;
  summaryResult: any;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  clientId: any;
  contractDetail: any;
  contractNo: any;
  userrole = this.menuItemService.getAllRoles();
  userdetail: any;
  orderId: any;
  showMsg: any;
  ordersTabResponse: any;

  constructor(private commonService: HttpCommonService, private router: Router, private sharedService: SharedServiceService,
    private newPremiumService: AllocationChangeSharedService,
    private menuItemService: MenuItemsService) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    // if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }
    this.contractDetail = null;
    this.contractNo = this.sharedService.getContractNo();
    this.contractDetail = JSON.parse(sessionStorage.getItem('contractDetails'));
    this.userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    const contractnumber = JSON.parse(sessionStorage.getItem('contract'));
    this.userrole = this.menuItemService.getAllRoles();
    // if (this.userrole === "rClient") {
    //   this.clientId = this.userdetail.clientID;
    // } else {
    //   this.clientId = customerId.clientID;
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (this.userdetail) {
      this.clientId = this.userdetail.clientId ? this.userdetail.clientId : '';
    }
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = [];
      this.accountDetails = data;
    })
    this.newPremiumService.getConfReqData().subscribe((val) => {
      this.summaryResult = [];
      this.summaryResult = val;
      // if (this.accountDetails != null && this.summaryResult != null) {
      //   this.callApi();
      // }
    })
    this.newPremiumService.getAllocationChangeConfRes().subscribe((val) => {
      this.confirmationData = [];
      this.confirmationData = val;
      if (this.accountDetails != null && this.summaryResult != null && this.confirmationData != null) {
        this.callApi(val);
      }
    });
    this.ordersTabResponse = this.sharedService.getOrdersTabResponse();
  }

  callApi(data) {
    // let request = {
    //   "policyNumber": this.accountDetails.policyNumber,//"21295126",
    //   "investAccNumber": this.accountDetails.investAccNumber,//"21295127",
    //   "investAccType": this.accountDetails.investAccType,//"1",
    //   "productPlan": this.accountDetails.productPlan,
    //   "processingSystem":this.contractDetail ? this.contractDetail.processingSystem : '',
    //   "firstName": this.userdetail.firstName, //"fname",
    //   "lastName": this.userdetail.lastName,//"lastName",
    //   "userName": this.userdetail.userName,//"Testuser210",
    //   "country": this.country,//"pl",
    //   "language": this.lang,//"en",
    //   "userRole": this.userrole,//"rAdvisor",
    //   "clientId":this.clientId,
    //   "investmentData":this.accountDetails,
    //   "fundsPriorToChange": this.summaryResult.fundsPriorToChange,
    //   "fundsAfterChange": this.summaryResult.fundsAfterChange
    // }
    // this.commonService.postData(this.baseUrl.ecustomer.allocationChangeConfirmation, request, '').subscribe(data => {
    this.confirmationData = data;
    if (this.confirmationData != null && this.confirmationData.orderId && !this.confirmationData.activeOrderErrorRender) {
      this.orderId = this.confirmationData.orderId;
      this.newPremiumService.setOrderId(this.confirmationData.orderId);
      sessionStorage.setItem('orderData', this.orderId);
    } else { this.orderId = '' }
    // });
  }

  gotoPremiumSplitPage() {
    // this.gotoPremiumSplit = true;
    //this.valueChange.emit('allocationChange');
    let data = {
      //'fromPage': 'allocationChange',
      "toPage": 'orderInvest'
    }
    this.sharedService.setPageContent(data);
  }

  goToAllocationChange() {
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    this.sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    let data = {
      'orderNumber': this.confirmationData.orderId
    }
    sessionStorage.setItem('orderData', JSON.stringify(data));
    this.router.navigate(['/orderHistory/allocationChange']);
  }

  goToTransferFunds() {
    let data = {
      //'fromPage': 'allocationChange',
      "toPage": 'transferFunds'
    }
    this.sharedService.setPageContent(data);
    this.router.navigate(['/contract-details/transferFunds'])
  }

  openTooltipMsg() {
    if (this.accountDetails.investAccNumberTip == 'InvestAccountTypeInfoTip5') {
      if (!this.showMsg) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
      }
    }
  }

}
