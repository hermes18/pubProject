import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { APP_BASE_HREF } from '@angular/common';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';

import { ChangePremiumConfirmationComponent } from './change-premium-confirmation.component';
import { ContractDetailsModule } from '../../contract-details.module';
import { AppConfig } from 'src/config/app.config';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';

describe('ChangePremiumConfirmationComponent', () => {
  let component: ChangePremiumConfirmationComponent;
  let fixture: ComponentFixture<ChangePremiumConfirmationComponent>;
  let menuService: MenuItemsService;
  let sharedService: SharedServiceService;
  let appConfig: AppConfig = AppConfig.getConfig();
  let globalObjectService: jasmine.SpyObj<AppConfig>;
  const userImfo =
    { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" }
  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    globalObjectService = jasmine.createSpyObj('AppConfig', ['getConfig']);
    sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    window.sessionStorage.setItem("defaultLanguage", "pl_pl");
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(ChangePremiumConfirmationComponent);
    component = fixture.componentInstance;
    menuService = TestBed.get(MenuItemsService);
    sharedService = TestBed.get(SharedServiceService);
    fixture.detectChanges();
  });

  it('should create', () => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 7000;
    expect(component).toBeTruthy();
  });

  it('should call nav to premium split page', () => {
    let data = {
      //'fromPage': 'allocationChange',
      "toPage": 'orderInvest'
    }
    component.gotoPremiumSplitPage();
  });

  it('should call nav to allocation change page', () => {
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    // let data = {
    //   'orderNumber': component.confirmationData.orderId
    // }
    // sessionStorage.setItem('orderData', JSON.stringify(data));
    //component.goToAllocationChange();
  });

  it('should call nav to transfer funds change page', () => {
    let data = {
      //'fromPage': 'allocationChange',
      "toPage": 'transferFunds'
    }
    sharedService.setPageContent(data);
    component.goToTransferFunds();
  });

  xit('should call open tooltip msg', () => {
    component.openTooltipMsg();
  });

});
