import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../allocation-change-service';


export interface FundSummaryDataBfre {
  fundName: String;
  pastSplit: String;
  unitPricePastLink: String;
}
export interface FundSummaryData {
  fundName: String;
  unitPriceNewLink: String;
  keyLink: String;
  newSplit: String;
}

@Component({
  selector: 'summary-split-screen',
  templateUrl: './summary-split-screen.component.html',
  styleUrls: ['./summary-split-screen.component.scss']
})

export class SummarySplitScreenComponent implements OnInit {

  displayedColumnsBfre: String[] = [
    'fundName',
    'unitPricePastLink',
    'pastSplit'
  ];
  displayedColumnsBfreMob: String[] = [
    'fundName',
    'pastSplit',
    'unitPricePastLink'
  ];
  displayedColumns: String[] = ['fundName',
    'unitPriceNewLink',
    'keyLink',
    'newSplit'];
  displayedColumnsMob: String[] = ['fundName',
    'newSplit',
    'unitPriceNewLink',
    'keyLink'
  ];
  dataSourceFundDetailsBfre: MatTableDataSource<FundSummaryDataBfre>;
  dataSourceFundDetails: MatTableDataSource<FundSummaryData>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  summaryDetBfre: any;
  summaryDetAfter: any;
  valuesSelectedArray: any;
  fundDataArr: any;
  summaryResult: any;
  country: string;
  @Output() flagValueChange = new EventEmitter();
  loggedInCountryCheck: boolean;
  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private newPremiumService: AllocationChangeSharedService) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    //if (this.country == 'pl') {
    this.loggedInCountryCheck = UtilityService.getCountry();
    this.newPremiumService.getFundData().subscribe((arr) => {
      this.fundDataArr = arr;
    });
    this.newPremiumService.getConfReqData().subscribe((val) => {
      this.summaryResult = [];
      this.summaryResult = val;
      if (this.summaryResult != null && this.fundDataArr != null && this.fundDataArr.length > 0) {
        this.callApi(this.summaryResult);
      }
    })
  }

  callApi(data) {
    //this.dataSourceFundDetailsBfre = new MatTableDataSource(data.fundsPriorToChange);
    this.dataSourceFundDetails = new MatTableDataSource(data.fundsAfterChange);
    if (this.fundDataArr.length > 0) {
      let fundsPriorToChange = [];
      this.fundDataArr.forEach((val) => {
        if (val.allocationPercentage != "0" && val.allocationPercentage != "") {
          fundsPriorToChange.push(val);
        }
      });
      this.dataSourceFundDetailsBfre = new MatTableDataSource(fundsPriorToChange);
    }
  }

  checkClickedStatus(row) {
    row.keyLinkClicked = true;
    this.flagValueChange.emit(row);
    // console.log(row);
  }
}
