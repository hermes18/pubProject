import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ContractDetailsModule } from '../../contract-details.module';

import { SelectAccountComponent } from './select-account.component';

describe('SelectAccountComponent', () => {
  let component: SelectAccountComponent;
  let fixture: ComponentFixture<SelectAccountComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'accountList': host + '/api/v1/order/change-premium-spilt'
      }
    }
  };

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;

    let userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = //JSON.parse(sessionStorage.getItem('searcClientID'));
   { "clientID": 1234,
"opeType": "search" }
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    // }));

    // beforeEach(() => {
    fixture = TestBed.createComponent(SelectAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('shound get formArray fields', () => {
    component.selectedAccount;
  })

  it('shound get account', () => {
    component.getAccounts();
  });

  it('shound call form submit method', () => {
    component.formSubmit();
  });

  it('shound call submit selected account method', () => {
    component.submitSelectedAccount();
  });
});
