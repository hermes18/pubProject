import { ChangeDetectorRef, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { Observable, Subscription } from 'rxjs';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { TransformPipe } from 'src/app/shared/pipe/transform.pipe';
import { CreateFormService } from 'src/app/shared/services/create-form.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from './../allocation-change-service';

export interface FundDataList {
  contact: FundData[];
}
export interface FundData {
  fundName: String;
  quotesLink: String;
  // keyLink: string;
  currentSlip: String;
  newSlip: String;
}

@Component({
  selector: 'select-funds',
  templateUrl: './select-funds.component.html',
  styleUrls: ['./select-funds.component.scss']
})
export class SelectFundsComponent implements OnInit {

  displayedColumns: String[] = ['fundName', 'quotesLink',
    // 'keyLink', 
    'currentSlip', 'newSlip'];
  dataSourceFundDetails: MatTableDataSource<FundDataList>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  accountDet: any;
  selectFundForm: FormGroup;
  externalPartiesForm: FormGroup;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  fundDetails: any;
  total: 0;
  subscription: Subscription;
  shareLeft: number;
  accountDetails: any;
  userrole: string;
  clientId: any;
  @Output() flagValueChange = new EventEmitter();
  totalTempData: any;
  langChange: string;

  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService,
    private fb: FormBuilder,
    private menuItemService: MenuItemsService,
    private ref: ChangeDetectorRef,
    private newPremiumService: AllocationChangeSharedService,
    private transform: TransformPipe) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }
    this.langChange = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /* if (this.langChange == "pl_en") {
      this.langChange = "en";
    } else if (this.langChange == "pl_pl") {
      this.langChange = "pl";
    } else if (this.langChange == "ro_en") {
      this.langChange = "en";
    } else if (this.langChange == "ro_ro") {
      this.langChange = "ro";
    } */
    let userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    // if (this.userrole === "rClient") {
    //   this.clientId = userdetail.clientID;
    // } else {
    //   this.clientId = customerId.clientID;
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (userdetail) {
      this.clientId = userdetail.clientId ? userdetail.clientId : '';
    }
    this.createForm();
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = [];
      this.accountDetails = data;
      // if (this.accountDetails != null) {
      //   this.getFundList();
      // }
    })
    this.newPremiumService.getFundListResponse().subscribe((data) => {
      this.accountDet = [];
      this.accountDet = data;
      if (this.accountDetails != null && this.accountDet != null) {
        this.getFundList(this.accountDet);
      }
    })
    this.subscription = this.fundListArray.valueChanges.subscribe(data => {
      this.total = this.total <= 100 ? data.reduce((a, b) => a + +((!b.minFundErr && !b.fundEmptyErr) ? b.newAllocationPercentage : 0), 0) : 0;
      this.totalTempData = data.reduce((a, b) => a + +b.newAllocationPercentage, 0);
      if (this.total <= 100) {
        this.selectFundForm.get('total').setValue(this.total);
        this.shareLeft = this.selectFundForm.get('total').value <= '100' ? 100 - this.total : 100;
        // console.log((data.reduce((a, b) => a + +(!b.minFundErr
        //   && !b.fundEmptyErr) ? b.newAllocationPercentage: 0)))
      } else {
        this.selectFundForm.get('total').setValue(0);
        this.shareLeft = 100;
      }
    })
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  createForm() {
    this.selectFundForm = this.fb.group({
      total: [0, Validators.required],
      fundListArray: this.fb.array([])
    });
  }

  get fundListArray() {
    return this.selectFundForm.get('fundListArray') as FormArray;

  }

  // fundListArray(): FormArray {
  //   return this.selectFundForm.get('fundListArray') as FormArray;
  // }  

  getFundList(data) {
    // const reqParam = {
    //   "investAccNumber": this.accountDetails.investAccNumber,//"21295126",
    //   "clientId": this.clientId,//"101583",
    //   "selectedInvestmentStrategy": "Allocation Change"
    // }
    // this.commonService.postData(this.baseUrl.ecustomer.allocationChange, reqParam, '').subscribe(data => {
    //   // this.dataSourceFundDetails = new MatTableDataSource(data);
    //   this.accountDet = data;
    if (data) {
      this.selectFundForm['controls'].fundListArray['controls'] = [];
      this.fundDetails = data;
      for (var i = 0; i < data.length; i++) {
        this.add(i);
      }
      //(data);
    } else {
      //
    }
    this.dataSourceFundDetails = new MatTableDataSource(this.selectFundForm['controls'].fundListArray['controls']);
    // });
  }

  add(index) {
    this.fundListArray.push(this.new(index));
  }

  new(index): FormGroup {
    return this.fb.group({
      fundId: this.fundDetails[index].fundId,
      fundName: this.fundDetails[index].fundName,
      unitPrice: this.fundDetails[index].unitPrice,
      investAccNumber: this.fundDetails[index].investAccNumber,
      sort: this.fundDetails[index].sort,
      externalLink: this.fundDetails[index].externalLink,
      allocationPercentage: this.fundDetails[index].allocationPercentage,
      dataError: this.fundDetails[index].dataError,
      newSplitErr: false,
      newAllocationPercentage: [this.fundDetails[index].newAllocationPercentage],
      keyInfoLinkForFund: this.fundDetails[index].keyInfoLinkForFund,
      minimumAmountPerFund: this.fundDetails[index].minimumAmountPerFund,
      fundEmptyErr: false,
      minFundErr: false,
      sameAllocationErr: false,
      totalExceedsErr: false
    })
  }

  formSubmit() {
    return this.selectFundForm.valid;
  }

  submitSelectedFund() {
    //this.selectFundForm['controls'].fundListArray.markAsTouched()
    if (this.selectFundForm.dirty) {
      //if (this.selectFundForm.controls['total'].value == 100) {      
      // this.newPremiumService.setFundData([]);
      this.newPremiumService.setFundData(this.selectFundForm.controls['fundListArray'].value);
      this.newPremiumService.setParamValue('selectFundForm', this.selectFundForm);
      return this.selectFundForm.valid;
      // }
    }

  }

  numberOnly(event, row, action) {
    // const charCode = (event.which) ? event.which : event.keyCode;
    // if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    //   return false;
    // }
    // return true;
    let pastedText;
    if (action == 'paste') {
      let clipboardData = event.clipboardData;
      pastedText = clipboardData.getData('text');
    } else {
      pastedText = event.target.value;
      // let pastedText = clipboardData.getData('text');
    }
    event.preventDefault();
    let ctrl = row.get('newAllocationPercentage') as FormControl;
    ctrl.setValue(this.transform.transform(pastedText, this.langChange), { emitEvent: false, emitViewToModelChange: false });
    let checkNumberOnly = (ctrl.value);
    if (checkNumberOnly != null) {
      let numeric = (ctrl.value).toString();
      // if (this.langChange == 'pl' || this.langChange == 'ro') {
      if (numeric.includes(',')) {
        let checkNumeric = numeric.replace(',', '');
        if (checkNumeric.length > 3) {
          ctrl.setValue(checkNumeric.substr(0, 3));
          return false;
        } else {
          ctrl.setValue(checkNumeric.substr(0, 3));
        }
      }
      //  } else {
      if (numeric.includes('.')) {
        let checkNumeric = numeric.replace('.', '');
        if (checkNumeric.length > 3) {
          ctrl.setValue(checkNumeric.substr(0, 3));
          return false;
        } else {
          ctrl.setValue(checkNumeric.substr(0, 3));
        }
      }
      //  }
    }
  }

  numberValue1(event, itemrow) {
    let clipboardData = event.clipboardData;
    let pastedText = clipboardData.getData('text');
    event.preventDefault();
    let ctrl = itemrow.get('newAllocationPercentage') as FormControl;
    ctrl.setValue(this.transform.transform(pastedText, this.lang), { emitEvent: false, emitViewToModelChange: false });
  }

  validateSourceInput(evt, row) {
    //  console.log(evt);
    if (this.selectFundForm.dirty) {
      if ((row.get('newAllocationPercentage').value != "0") &&
        (row.get('newAllocationPercentage').value != "00") &&
        (row.get('newAllocationPercentage').value != "000") && (row.get('newAllocationPercentage').value != "")) {
        if (row.get('newAllocationPercentage').value < row.get('minimumAmountPerFund').value) {
          row.get('minFundErr').setValue(true);
          // row.get('fundEmptyErr').setValue(true);
          // if (this.totalTempData <= 100) {
          //   row.get('minFundErr').setValue(true);
          this.flagValueChange.emit(row);
          // } else {
          //   this.validateOtherRows();
          // }
        } else {
          if (row.get('newAllocationPercentage').value != "") {
            row.get('minFundErr').setValue(false);
            //this.validateOtherRows();
            if ((parseFloat(row.get('newAllocationPercentage').value) > parseFloat("100"))) {//|| this.total >100
              row.get('fundEmptyErr').setValue(true);
              this.flagValueChange.emit(row);
            } else {
              if (this.totalTempData > 100) {
                let findCurrentRowValue = parseFloat(this.totalTempData) - parseFloat(row.get('newAllocationPercentage').value);
                if (findCurrentRowValue != 0 && this.totalTempData > 100) {
                  row.get('totalExceedsErr').setValue(true);
                  this.flagValueChange.emit(row);
                } else {
                  row.get('totalExceedsErr').setValue(false);
                  row.get('fundEmptyErr').setValue(false);
                  row.get('sameAllocationErr').setValue(false);
                  this.validateOtherRows();
                }
              } else {
                //this.validateOtherRows();
                // if ((this.totalTempData == 100)){
                if ((row.get('newAllocationPercentage').value == '100') && (row.get('allocationPercentage').value == '100')) {
                  row.get('fundEmptyErr').setValue(false);
                  row.get('sameAllocationErr').setValue(true);
                  row.get('totalExceedsErr').setValue(false);
                  this.flagValueChange.emit(row);
                } else {
                  //   row.get('fundEmptyErr').setValue(false);
                  row.get('fundEmptyErr').setValue(false);
                  row.get('sameAllocationErr').setValue(false);
                  row.get('totalExceedsErr').setValue(false);
                  this.validateOtherRows();
                }
                // } else{
                //     row.get('fundEmptyErr').setValue(false);
                //     row.get('sameAllocationErr').setValue(false);
                //     this.validateOtherRows();
                //   }
              }
            }
          } else {
            row.get('minFundErr').setValue(false);
            row.get('fundEmptyErr').setValue(false);
            row.get('sameAllocationErr').setValue(false);
            row.get('totalExceedsErr').setValue(false);
            this.validateOtherRows();
          }
        }
      } else {
        //equals 0 means do nothing
        this.validateOtherRows();
      }
    }
  }

  validateOtherRows() {
    this.selectFundForm['controls'].fundListArray['controls'].forEach(element => {
      if (parseFloat(element.get('newAllocationPercentage').value) != 0 &&
        element.get('newAllocationPercentage').value != "") { //multi fund
        if (parseFloat(element.get('newAllocationPercentage').value) < element.get('minimumAmountPerFund').value) {
          // if (this.totalTempData > 100) {
          //   element.get('fundEmptyErr').setValue(true);
          //   element.get('minFundErr').setValue(true);
          //   this.flagValueChange.emit(element);
          // } else {
          //   element.get('fundEmptyErr').setValue(false);
          //   element.get('minFundErr').setValue(true);
          //   this.flagValueChange.emit(element);
          // }
          element.get('fundEmptyErr').setValue(false);
          element.get('minFundErr').setValue(true);
          element.get('totalExceedsErr').setValue(false);
          this.flagValueChange.emit(element);
        } else {
          element.get('fundEmptyErr').setValue(false);
          element.get('minFundErr').setValue(false);
          element.get('totalExceedsErr').setValue(false);
          // this.flagValueChange.emit(element);
          if (this.totalTempData > 100) {
            if (parseFloat(element.get('newAllocationPercentage').value) > parseFloat("100")) {
              element.get('fundEmptyErr').setValue(true);
              this.flagValueChange.emit(element);
            } else {
              let findCurrentRowValue = parseFloat(this.totalTempData) - parseFloat(element.get('newAllocationPercentage').value);
              if (findCurrentRowValue != 0 && this.totalTempData > 100) {
                element.get('totalExceedsErr').setValue(true);
              } else {
                element.get('totalExceedsErr').setValue(false);
              }
              this.flagValueChange.emit(element);
            }
          } else {
            element.get('fundEmptyErr').setValue(false);
            //if ((this.totalTempData == 100)){
            if ((element.get('newAllocationPercentage').value == '100') && (element.get('allocationPercentage').value == '100')) {
              element.get('sameAllocationErr').setValue(true);
              this.flagValueChange.emit(element);
            } else {
              element.get('sameAllocationErr').setValue(false);
              this.flagValueChange.emit(element);
            }
            // } else{
            //     element.get('sameAllocationErr').setValue(false);
            //     this.flagValueChange.emit(element);
            //   }
          }
        }
      } else {
        element.get('sameAllocationErr').setValue(false);
        element.get('fundEmptyErr').setValue(false);
        element.get('minFundErr').setValue(false);
        element.get('totalExceedsErr').setValue(false);
        this.flagValueChange.emit(element);
      }
    });
  }

}
