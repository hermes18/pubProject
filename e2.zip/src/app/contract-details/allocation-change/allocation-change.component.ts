import { Component, OnInit, ViewChild, AfterViewInit, ViewEncapsulation, ViewChildren, QueryList, Output, EventEmitter } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormGroup, FormControl, FormArray, NgForm, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material';
import { HttpCommonService } from '../../shared/services/http-common.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import * as utils from 'lodash';
import { SelectAccountComponent } from './select-account/select-account.component';
import { SelectFundsComponent } from './select-funds/select-funds.component';
import { AppConfig } from 'src/config/app.config';
import { SummarySplitScreenComponent } from './summary-split-screen/summary-split-screen.component';
import { AllocationChangeSharedService } from './allocation-change-service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { AlertDialogComponent } from 'src/app/shared/dialog/alert-dialog/alert-dialog.component';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'allocation-change',
  templateUrl: './allocation-change.component.html',
  styleUrls: ['./allocation-change.component.scss']
})
export class AllocationChangeComponent implements OnInit {
  confirmationPage: boolean = false;
  previouslySelectedstep = [];
  isStepInteracted = false;
  selectAccountForm: FormGroup;
  selectFundForm: FormGroup;
  responseActiveOrder: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  FundAccountEmpty: boolean = false;
  totalShareError: boolean = false;
  selectAccountSecError: boolean = false;
  showOrderProcessingErr: boolean;
  selectedFundTotalErr: boolean;
  selectFundFormErr: boolean;
  valuesSelectedArray: any[];
  fundDataArr: any;
  noChangeOfAllocationErrorRender: any;
  country: string;
  lang: string;
  displayPoOption: boolean;
  displayRoOption: boolean;
  userrole: string;
  clientId: any;
  arraySelectedUnique: any;
  contractDetail: any;
  authorizationErrFlag: boolean;
  userdetail: any;
  summaryResult: any;
  confirmationData: any;
  minimumFundAllocationError: boolean;
  minimumFund: any;
  step2Completed: boolean;
  orderGeneratedError: boolean;
  destRefFundEmptyCnt: number = 0;
  destRefMinFundCnt: number = 0;
  step1Completed: boolean;
  searchedClientDetails: any;

  constructor(private translate: TranslateService, private _formBuilder: FormBuilder,
    private httpService: HttpCommonService, private router: Router,
    private route: ActivatedRoute,
    private newPremiumService: AllocationChangeSharedService,
    private sharedService: SharedServiceService,
    private menuItemService: MenuItemsService,
    private dialog: DialogService,
    public deviceDetector: DeviceDetectorService
  ) { }

  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.selectAccountForm = this._formBuilder.group({
    });
    this.selectFundForm = this._formBuilder.group({
    });
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    // if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayRoOption = true;
    }
    this.userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    this.userrole = this.menuItemService.getAllRoles();
    // if (this.userrole === "rClient") {
    //   this.clientId = this.userdetail.clientID;
    // } else {
    //   this.clientId = customerId.clientID;
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (this.userdetail) {
      this.clientId = this.userdetail.clientId ? this.userdetail.clientId : '';
    }
    this.contractDetail = JSON.parse(sessionStorage.getItem('contractDetails'));
    this.searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
  }

  step = 0;
  @ViewChild(SelectAccountComponent, { static: false }) selectAccRefComp: SelectAccountComponent;
  @ViewChild(SelectFundsComponent, { static: false }) selectFundRefComp: SelectFundsComponent;
  @ViewChild(SummarySplitScreenComponent, { static: false }) summaryRefComp: SummarySplitScreenComponent;

  setStep(index: number) {
    this.step = index;
  }

  nextStep(id) {
    ////("next step");
    //this.stepper.selectedIndex++;
    this.stepper.selected.completed = true;
    this.stepper.selectedIndex = this.stepper.selectedIndex + 1;
    if (this.isMobile) {
      this.setFocus(id);
    } else {
      //window.scroll(0,0);
    }
  }

  prevStep() {
    this.step--;
  }

  setFocus(id) {
    let targetElem = document.getElementById(id);
    // targetElem.scrollIntoView();
    //targetElem.focus();
    setTimeout(function waitTargetElem() {
      if (targetElem) {
        targetElem.scrollIntoView();
      } else {
        setTimeout(waitTargetElem, 100);
      }
    }, 100);
  }

  onStepChange(event) {
    this.checkStepCompletionStatus(this.stepper['_selectedIndex']);
    if (event.selectedIndex == 0) {
      this.step1Completed = false;
      this.FundAccountEmpty = false;
      this.noChangeOfAllocationErrorRender = false;
      this.minimumFundAllocationError = false;
      this.selectedFundTotalErr = false;
      this.orderGeneratedError = false;
      this.authorizationErrFlag = false;
    } else if (event.selectedIndex == 1) {
      this.step2Completed = false;
      this.orderGeneratedError = false;
      this.authorizationErrFlag = false;
    } else { }
  }

  checkStepCompletionStatus(index) {
    if (this.stepper && this.stepper._steps['_results'][index].completed) {
      this.stepper['_elementRef'].nativeElement.querySelectorAll('.mat-step')[index].setAttribute('ariaChecked', true)
      return 'test';
    }
  }




  @ViewChild('stepper', { static: false }) stepper: MatStepper;
  headers = new HttpHeaders();


  gotoStep(step) {
    this.stepper.selectedIndex = step;
  }

  changeSelection() {
    if (this.previouslySelectedstep.indexOf(0) && this.stepper && this.stepper['_selectedIndex'] !== 0) {
      return true;
    }
    return false;
  }

  validateSelectAccount(id) {
    //(this.selectAccRefComp.selectAccountForm)
    this.step1Completed = false;
    this.selectAccRefComp.submitSelectedAccount();
    if (this.selectAccRefComp.selectAccountForm.valid && this.selectAccRefComp.selectedRow) {
      this.FundAccountEmpty = false;
      this.validateSelectedAccountDetails(this.selectAccRefComp.selectedRow, id);
      this.noChangeOfAllocationErrorRender = false;
      this.minimumFundAllocationError = false;
      this.selectedFundTotalErr = false;
    } else {
      this.FundAccountEmpty = true;
      window.scrollTo(0, 0);
    }
  }

  validateSelectedAccountDetails(value, id) {
    const reqParam = {
      "policyNumber": value.policyNumber,//"21295126",
      "selectedInvestmentStrategy": "Allocation Change",
      "investAccNumber": value.investAccNumber //"21295127"
    }
    this.httpService.postData(this.baseUrl.ecustomer.getActiveOrder, reqParam, this.headers).subscribe(data => {
      this.responseActiveOrder = data;
      if (!this.responseActiveOrder.activeOrderErrorRender) {
        this.showOrderProcessingErr = false;
        this.step1Completed = true;
        this.getFundList(id);
        // this.nextStep();
      } else {
        //error msg display
        this.showOrderProcessingErr = true;
        window.scrollTo(0, 0);
      }
    })
  }

  validateSelectFund(id) {
    this.step2Completed = false;
    this.stepper.selected.completed = false;
    this.selectFundRefComp.submitSelectedFund();
    this.FundAccountEmpty = false;
    this.noChangeOfAllocationErrorRender = false;
    this.minimumFundAllocationError = false;
    this.selectedFundTotalErr = false;
    if (this.selectFundRefComp.selectFundForm.dirty && this.selectFundRefComp.selectFundForm.valid) {
      // if (this.selectFundRefComp.selectFundForm.controls['total'].value == '100') {
      let fundDataArr: any[];
      let arraySelected = [];
      let minFundCnt = 0;
      this.newPremiumService.getFundData().subscribe((arr) => {
        fundDataArr = arr;
        arraySelected = [];
        fundDataArr.forEach((data) => {
          if (data.newAllocationPercentage != "0" && data.newAllocationPercentage != "" || (data.allocationPercentage != "0" && data.allocationPercentage != "")) {
            if (arraySelected.length == 0) {
              arraySelected.push(data);
            } else if (arraySelected.length > 1) {
              arraySelected.forEach((val) => {
                if (val.fundId == data.fundId) {
                  arraySelected.splice(val, 1);
                  arraySelected.push(data);
                } else {
                  arraySelected.push(data);
                }
              })
            } else if (arraySelected.length == 1) {
              if (arraySelected[0].fundId != data.fundId) {
                arraySelected.push(data);
              }

            }
          }
        });
        this.arraySelectedUnique = this.getUnique(arraySelected, 'sort')
        this.selectedFundTotalErr = false;
        this.noChangeOfAllocationErrorRender = false;
        //(this.arraySelectedUnique)
      });
      if (this.arraySelectedUnique != null && this.arraySelectedUnique.length > 0) {
        this.arraySelectedUnique.forEach((val) => {
          if (val.newAllocationPercentage != 0 && val.newAllocationPercentage < val.minimumAmountPerFund) {
            minFundCnt = minFundCnt + 1;
          } else {
            //do nothing
          }
          if (val.newAllocationPercentage == "" || val.newAllocationPercentage == null) {
            val.newAllocationPercentage = 0;
          }
        });
        if (minFundCnt > 0) {
          this.minimumFundAllocationError = true;
          window.scrollTo(0, 0);
        } else {
          this.minimumFundAllocationError = false;
          if (this.selectFundRefComp.selectFundForm.controls['total'].value == '100') {
            this.newPremiumService.setSummaryReqData(this.arraySelectedUnique);
            this.callApi(this.arraySelectedUnique, id);
          } else {
            this.selectedFundTotalErr = true;
            this.noChangeOfAllocationErrorRender = false;
            window.scrollTo(0, 0);
            //total value error
          }
        }
      }
      //this.nextStep();
      // } else {
      //   this.selectedFundTotalErr = true;
      //   this.noChangeOfAllocationErrorRender = false;
      //   window.scrollTo(0, 0);
      //   //total value error
      // }
    } else {
      //form empty
      this.selectedFundTotalErr = true;
      window.scrollTo(0, 0);
    }
  }

  getUnique(arr, comp) {

    // store the comparison  values in array
    const unique = arr.map(e => e[comp])

      // store the indexes of the unique objects
      .map((e, i, final) => final.indexOf(e) === i && i)

      // eliminate the false indexes & return unique objects
      .filter((e) => arr[e]).map(e => arr[e]);

    return unique;
  }

  callApi(arraySelected, id) {
    const reqParam = {
      "processingSystem": this.contractDetail ? this.contractDetail.processingSystem : '',
      //"investmentData": this.selectAccRefComp.selectedRow,
      "investmentData": {
        // "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,//"21295126",
        "investAccType": this.selectAccRefComp.selectedRow.investAccType,//2,
        // "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21296299",
        "effectiveDate": this.selectAccRefComp.selectedRow.effectiveDate,
        "status": this.selectAccRefComp.selectedRow.status,//23,
        "investValue": this.selectAccRefComp.selectedRow.investValue,//9772.71,
        "productPlan": this.selectAccRefComp.selectedRow.productPlan,//"UB2B000K3",
        // "bankAccount": this.selectAccRefComp.selectedRow.bankAccount,//"10 1030 1944 9000 0500 2129 6299",
        "valuationDt": this.selectAccRefComp.selectedRow.valuationDt,//1332268200000,
        "activeOrderErrorRender": this.responseActiveOrder.activeOrderErrorRender,//false,
        "authorizationErrorRender": this.responseActiveOrder.authorizationErrorRender,//false,
        "orderErrorRender": this.responseActiveOrder.orderErrorRender//false
      },
      "totalNewlyAllocatedPercentage": "100",
      "fundSwitchDTOs": arraySelected//this.fundDataArr
    }
    this.httpService.postData(this.baseUrl.ecustomer.allocationChangeSummary, reqParam, '').subscribe(data => {
      // this.dataSourceFundDetailsBfre = new MatTableDataSource(data.fundsPriorToChange);
      // this.dataSourceFundDetails = new MatTableDataSource(data.fundsAfterChange);
      this.summaryResult = data;
      this.newPremiumService.setConfReqData(data);
      this.noChangeOfAllocationErrorRender = data.noChangeOfAllocationErrorRender;
      if (this.noChangeOfAllocationErrorRender) { window.scrollTo(0, 0); }
      if (data != null && !data.noChangeOfAllocationErrorRender && !this.selectedFundTotalErr && !data.authorizationErrorRender) {
        this.step2Completed = true;
        this.stepper.selected.completed = true;
        this.nextStep(id);
        if (this.isMobile && this.step2Completed) {
          this.setFocus("step2AllocatChngFormDiv");

        } else {
          //window.scroll(0,0);
        }
        this.authorizationErrFlag = false;
      } else if (data.authorizationErrorRender) {
        this.authorizationErrFlag = true;
        window.scrollTo(0, 0);
      }
    })
  }

  getSummaryFlagValue(event) {
    if (this.summaryResult.fundsAfterChange.length > 1) {
      this.summaryResult.fundsAfterChange.forEach(element => {
        if (element.fundId == event.fundId) {
          element.keyLinkClicked = true;
        } else { }
      });
    } else {
      if (this.summaryResult.fundsAfterChange[0].fundId == event.fundId) {
        this.summaryResult.fundsAfterChange[0].keyLinkClicked = true;
      } else { }
    }
  }

  executeConfirmationApi() {
    let request = {
      "selectedInvestmentStrategy": "Allocation Change",
      "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,//"21295126",
      "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295127",
      "investAccType": this.selectAccRefComp.selectedRow.investAccType,//"1",
      "productPlan": this.selectAccRefComp.selectedRow.productPlan,
      "processingSystem": this.contractDetail ? this.contractDetail.processingSystem : '',
      "firstName": this.userdetail.firstName, //"fname",
      "lastName": this.userdetail.lastName,//"lastName",
      "userName": this.userdetail.userName,//"Testuser210",
      "country": this.country,//"pl",
      "language": this.lang,//"en",
      "userRole": this.userrole,//"rAdvisor",
      "clientId": this.clientId,
      "clientFirstName": this.searchedClientDetails ? this.searchedClientDetails.clientFirstName : this.userdetail.firstName,
      "clientLastName": this.searchedClientDetails ? this.searchedClientDetails.clientLastName : this.userdetail.lastName,
      "clientUserName": this.userrole == 'rClient' ? this.userdetail.userName : null,
      "investmentData": this.selectAccRefComp.selectedRow,//this.accountDetails,
      "fundsPriorToChange": this.summaryResult.fundsPriorToChange,
      "fundsAfterChange": this.summaryResult.fundsAfterChange
    }
    this.httpService.postData(this.baseUrl.ecustomer.allocationChangeConfirmation, request, '').subscribe(data => {
      if (data.hasOwnProperty('activeUser') && (data.activeUser == false)) {
        this.router.navigate(['/logout']);
      } else {
        this.confirmationData = data;
        this.newPremiumService.setAllocationChangeConfRes(data);
        if (!data.authorizationErrorRender && data.orderId != null) {
          this.confirmationPage = true;
          this.authorizationErrFlag = false;
          this.orderGeneratedError = false;
          if (this.isMobile && this.confirmationPage) {
            this.setFocus("confirmationAllocationFormDiv");
            window.scroll(0, 0);
          } else {
            //window.scroll(0,0);
          }
        } else {
          if (data.authorizationErrorRender && data.orderId == null) {
            this.authorizationErrFlag = true;
            this.confirmationPage = false;
            this.orderGeneratedError = false;
            window.scrollTo(0, 0);
          } else if (!data.authorizationErrorRender && data.orderId == null) {
            this.authorizationErrFlag = false;
            this.confirmationPage = false;
            this.orderGeneratedError = true;
            window.scrollTo(0, 0);
          }
        }
      }
    });
  }

  callConfirmationApi() {
    if (this.country === 'ro') {
      let clickedCnt = 0;
      let clickedIds = [];
      if (this.summaryResult.fundsAfterChange.length > 1) {
        this.summaryResult.fundsAfterChange.forEach(val => {
          if (val.keyLinkClicked && val.keyLinkClicked == true) {
            clickedCnt = clickedCnt + 1;
          } else { }
        })
      } else {
        if (this.summaryResult.fundsAfterChange[0].keyLinkClicked &&
          this.summaryResult.fundsAfterChange[0].keyLinkClicked == true) {
          clickedCnt = clickedCnt + 1;
        } else { }
      }
      if (clickedCnt == this.summaryResult.fundsAfterChange.length) {
        //  console.log('confirmation api call');
        this.executeConfirmationApi();
      } else {
        // console.log('display alert');
        this.dialog.openDialog(AlertDialogComponent, { 'heading': '', 'body': this.translate.instant("eCustomer.orderInvest.readKidAnnexErrMsg") });
        return false
      }
    } else { this.executeConfirmationApi(); }
  }

  gotoPremiumSplitPage() {
    // this.gotoPremiumSplit = true;
    //this.valueChange.emit('allocationChange');
    //this.sharedService.setPageContent('singlePremium');
    let data = {
      //'fromPage': 'transferFunds',
      "toPage": 'orderInvest'
    }
    this.sharedService.setPageContent(data);
  }

  getFundList(id) {
    const reqParam = {
      "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295126",
      "clientId": this.clientId,//"101583",
      "selectedInvestmentStrategy": "Allocation Change",
      "investmentData": {
        "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,// "21295126",
        "investAccType": this.selectAccRefComp.selectedRow.investAccType, //1,
        "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295126",
        "effectiveDate": this.selectAccRefComp.selectedRow.effectiveDate,//1276626600000,
        "status": this.selectAccRefComp.selectedRow.status,//23,
        "investValue": this.selectAccRefComp.selectedRow.investValue,//2864.17,
        "productPlan": this.selectAccRefComp.selectedRow.productPlan,//"UB2B000K3",
        //"bankAccount": this.selectAccRefComp.selectedRow.bankAccount,//"59 1030 1944 9000 0500 2129 5126",
        "valuationDt": this.selectAccRefComp.selectedRow.valuationDt,//1332268200000
      }
    }
    this.httpService.postData(this.baseUrl.ecustomer.allocationChange, reqParam, '').subscribe(data => {
      if (data != null) {
        let fundListRes = [];
        //this.newPremiumService.setFundListResponse(fundListRes);
        fundListRes = data;
        this.minimumFund = data.length > 0 ? data[0].minimumAmountPerFund : 0;
        this.newPremiumService.setFundListResponse(fundListRes);
        if (!data.activeOrderErrorRender) {
          this.nextStep(id);
        } else {
          this.showOrderProcessingErr = true;
          window.scrollTo(0, 0);
        }
      }
    });
  }

  getSrcFlagValue(evt) {
    // console.log('setOutput', evt)
    if (evt) {
      if (evt.get('minFundErr').value) {
        this.minimumFundAllocationError = true;
        this.selectedFundTotalErr = false;
        this.noChangeOfAllocationErrorRender = false;
        // this.selectFundRefComp.shareLeft = 100;
        // this.selectFundRefComp.total = 0;
        //this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('fundEmptyErr').value) {
        this.selectedFundTotalErr = true;
        this.minimumFundAllocationError = false;
        this.noChangeOfAllocationErrorRender = false;
        // this.selectFundRefComp.shareLeft = 100;
        // this.selectFundRefComp.total = 0;
        //this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('sameAllocationErr').value) {
        // this.minimumFundAllocationError = false;
        // this.selectedFundTotalErr = false;
        // this.noChangeOfAllocationErrorRender = true;
        // //this.checkArrayValidations();
        // window.scrollTo(0, 0);
      } else if (evt.get('totalExceedsErr').value) {
        this.minimumFundAllocationError = false;
        this.selectedFundTotalErr = true;
        this.noChangeOfAllocationErrorRender = false;
        // //this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else {
        this.minimumFundAllocationError = false;
        this.selectedFundTotalErr = false;
        this.noChangeOfAllocationErrorRender = false;
        this.checkArrayValidations()
      }
    } else {
      this.minimumFundAllocationError = false;
      this.selectedFundTotalErr = false;
      this.noChangeOfAllocationErrorRender = false;
      this.checkArrayValidations();
    }
  }

  checkArrayValidations() {
    this.selectFundRefComp.selectFundForm['controls'].fundListArray['controls'].forEach(element => {
      if (parseFloat(element.get('newAllocationPercentage').value) != 0 && element.get('newAllocationPercentage').value != '' && element.get('allocationPercentage').value != null) {
        if (element.get('newAllocationPercentage').value < element.get('minimumAmountPerFund').value) {
          if (this.selectFundRefComp.totalTempData > 100 &&
            parseFloat(element.get('newAllocationPercentage').value) != 0 &&
            element.get('newAllocationPercentage').value != '') {
            // element.fundEmptyErr =true;
            // element.minFundErr = true;
            element.get('fundEmptyErr').setValue(true);
            element.get('minFundErr').setValue(true);
            this.minimumFundAllocationError = true;
            this.selectedFundTotalErr = true;
            // this.selectFundRefComp.shareLeft = 100;
            // this.selectFundRefComp.total = 0;
          } else {
            // element.fundEmptyErr =false;
            // element.minFundErr = true;
            element.get('fundEmptyErr').setValue(false);
            element.get('minFundErr').setValue(true);
            this.minimumFundAllocationError = true;
            this.selectedFundTotalErr = false;
            // this.selectFundRefComp.shareLeft = 100;
            // this.selectFundRefComp.total = 0;
          }
        } else {
          //element.minFundErr = true;
          element.get('minFundErr').setValue(false);
          this.minimumFundAllocationError = this.minimumFundAllocationError ? this.minimumFundAllocationError : false;
          if (this.selectFundRefComp.totalTempData > 100 &&
            parseFloat(element.get('newAllocationPercentage').value) != 0 &&
            element.get('newAllocationPercentage').value != '' && element.get('newAllocationPercentage').value > 100) {
            // element.fundEmptyErr =true;
            // element.minFundErr = true;
            // element.get('fundEmptyErr').setValue(true);
            element.get('totalExceedsErr').setValue(true);
            this.selectedFundTotalErr = true;
            // this.selectFundRefComp.shareLeft = 100;
            // this.selectFundRefComp.total = 0;
          } else {
            // element.fundEmptyErr =false;
            // element.minFundErr = true;
            element.get('fundEmptyErr').setValue(false);
            this.selectedFundTotalErr = false;
            if (
              (element.get('newAllocationPercentage').value == '100') &&
              (element.get('allocationPercentage').value == '100')) {
              // element.get('sameAllocationErr').value = true;
            } else {
              element.get('sameAllocationErr').value = false;
            }
          }
        }
      } else {
        element.get('fundEmptyErr').setValue(false);
        element.get('minFundErr').setValue(false);
        this.selectedFundTotalErr = false;
        this.minimumFundAllocationError = this.minimumFundAllocationError ? this.minimumFundAllocationError : false;
        // this.destRefFundEmptyCnt = this.destRefFundEmptyCnt - 1;
        // this.destRefMinFundCnt = this.destRefMinFundCnt - 1;
      }
    });
    // if (this.destRefMinFundCnt > 0) {
    //   this.minimumFundAllocationError = true;
    // }
    // if (this.destRefFundEmptyCnt > 0) {
    //   this.selectedFundTotalErr = true;
    // }
  }


}


