import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from '../../../app.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { TranslateService } from '@ngx-translate/core';
import { SingleContractSummaryComponent } from './single-contract-summary.component';
import { ContractDetailsModule } from '../../contract-details.module';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { AppConfig } from 'src/config/app.config';

describe('SingleContractSummaryComponent', () => {
  let component: SingleContractSummaryComponent;
  let fixture: ComponentFixture<SingleContractSummaryComponent>;
  let menuService: MenuItemsService;
  let sharedService: SharedServiceService;
  let appConfig: AppConfig = AppConfig.getConfig();
  let globalObjectService: jasmine.SpyObj<AppConfig>;
  const userImfo =
    { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": null, "requesterId": "-1", "requesterRole": "3033" }
  const customerId = sessionStorage.getItem('userData');
  const countryCode = sessionStorage.getItem('countryCode'),
    defaultLangugae = sessionStorage.getItem('defaultLanguage');
  sessionStorage.setItem("defaultLanguage", defaultLangugae);
  window.sessionStorage.setItem('countryCode', JSON.stringify(countryCode));
  window.sessionStorage.setItem('defaultLanguage', JSON.stringify(defaultLangugae));
  window.sessionStorage.setItem('userData', customerId)

  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
  //     declarations: [],
  //     providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
  //   })
  //     .compileComponents();
  // }));

  beforeEach(() => {    
    globalObjectService = jasmine.createSpyObj('AppConfig', ['getConfig']);
    sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
    window.sessionStorage.setItem("defaultLanguage", "pl_pl");
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(SingleContractSummaryComponent);
    menuService = TestBed.get(MenuItemsService);
    sharedService = TestBed.get(SharedServiceService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 7000;
    expect(component).toBeTruthy();
  });

  it('should call toggeleTextFiledType', ()=>{
    component.toggleFieldTextType();
  });
  
  it('should call toggeleTextFiledType', ()=>{
    component.toggleFieldTextType();
  });

  it('should call premium split navigation', ()=>{
    let data = {
      //'fromPage': 'singlePremium',
      "toPage": 'orderInvest'
    }
    sharedService.setPageContent(data);
  component.gotoPremiumSplitPage();
  });

  
});
