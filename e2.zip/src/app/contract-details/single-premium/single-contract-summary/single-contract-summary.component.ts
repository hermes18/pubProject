import { HttpHeaders } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../../allocation-change/allocation-change-service';


export interface FundSummaryDataBfre {
  fundName: String;
  pastSplit: String;
  unitPricePastLink: String;
}
export interface FundSummaryData {
  fundName: String;
  unitPriceNewLink: String;
  // keyLink: String;
  newSplit: String;
}

@Component({
  selector: 'single-contract-summary',
  templateUrl: './single-contract-summary.component.html',
  styleUrls: ['./single-contract-summary.component.scss']
})
export class SingleContractSummaryComponent implements OnInit {
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  headers = new HttpHeaders();
  responseAdditionalPremium: any;
  summaryResult: any;
  userrole = this.menuItemService.getAllRoles();
  summaryPage: boolean;
  @Input() confirmationPageDisplay;
  orderId: any;
  accountDetails: any;
  declaredAmount: any;
  displayedColumns: String[] = ['fundName',
    'unitPriceNewLink',
    // 'keyLink',
    'newSplit'];
  dataSourceFundDetails: MatTableDataSource<FundSummaryData>;
  country: string;
  displayPoOption: boolean;
  currencyType: string;
  langChange: string;
  cnpFieldMask: any;
  showAccNumberValue: boolean;
  defaultValue: 0.00;
  displayRoOption: boolean;
  showMsg: any;

  constructor(
    private translate: TranslateService, private _formBuilder: FormBuilder,
    private httpService: HttpCommonService, private router: Router,
    private route: ActivatedRoute,
    private newPremiumService: AllocationChangeSharedService,
    private menuItemService: MenuItemsService,
    private sharedService: SharedServiceService
  ) {
    //(this.confirmationPageDisplay)
  }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
      this.currencyType = 'PLN';
    }
    else {
      this.displayRoOption = true;
      this.currencyType = 'RON';
    }
    this.langChange = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if (this.langChange == "pl_en") {
      this.langChange = "en";
    }else if(this.langChange == "pl_pl"){
      this.langChange = "pl";
    } else if(this.langChange == "ro_en"){
      this.langChange = "en";
    }else if(this.langChange == "ro_ro"){
      this.langChange = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.langChange = data;
      }
    });
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = data;
      this.cnpFieldMask = this.accountDetails ? this.accountDetails.bankAccount ? this.MaskDigits(this.accountDetails.bankAccount) : [] : [];
      this.showAccNumberValue = this.accountDetails ? this.accountDetails.bankAccount ? true : false : false;
    })
    this.newPremiumService.getSinglePremiumSummry().subscribe((res) => {
      this.responseAdditionalPremium = res;
      if (res != null) {
        this.callApi(res);
      }
      // this.summaryPage = true;
    })

    this.newPremiumService.getConfReqData().subscribe((val) => {
      this.summaryResult = val;
      if (this.summaryResult != null && this.summaryResult.orderId && !this.summaryResult.activeOrderErrorRender) {
        this.orderId = this.summaryResult.orderId;
        this.newPremiumService.setOrderId(this.summaryResult.orderId);
        sessionStorage.setItem('orderData', this.orderId);
      } else { this.orderId = '' }
      // this.summaryPage = false;
    })

    this.newPremiumService.getDeclaredAmount().subscribe((amnt) => {
      this.declaredAmount = amnt;
    });
  }

  private MaskDigits(input) {
    let first2 = input.substring(0, 2);
    let last5 = input.substring(input.length - 5);
    let mask = input.substring(2, input.length - 5).replace(/\d/g, "*");
    return first2 + mask + last5;
  }


  gotoPremiumSplitPage() {
    // this.gotoPremiumSplit = true;
    //this.valueChange.emit('allocationChange');
    //this.sharedService.setPageContent('singlePremium');
    let data = {
      //'fromPage': 'singlePremium',
      "toPage": 'orderInvest'
    }
    this.sharedService.setPageContent(data);
  }

  callApi(data) {
    let updatedArray = [];
    if (data.fundsList.length > 1) {
      data.fundsList.forEach((val) => {
        if (val.newAllocationAmt != 0) {
          updatedArray.push(val);
        }
      })
      this.dataSourceFundDetails = new MatTableDataSource(updatedArray);
    } else if (data.fundsList.length == 1) {
      this.dataSourceFundDetails = new MatTableDataSource(data.fundsList);
    }
  }

  goToAllocationChange() {
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    this.sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    let data = {
      'orderNumber': this.orderId
    }
    sessionStorage.setItem('orderData', JSON.stringify(data));
    this.router.navigate(['/orderHistory/additionalContributionSave']);
  }

  toggleFieldTextType() {
    this.showAccNumberValue = !this.showAccNumberValue;
  }

  openTooltipMsg(){
    if(this.accountDetails.investAccNumberTip == 'InvestAccountTypeInfoTip5'){
      if(!this.showMsg){
        this.showMsg = true;
      }else{
        this.showMsg = false;
      }
    }
  }
}
