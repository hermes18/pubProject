import { Component, OnInit, ViewChild, AfterViewInit, ViewEncapsulation, ViewChildren, QueryList, Output, EventEmitter, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormGroup, FormControl, FormArray, NgForm, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material';
import { HttpCommonService } from '../../shared/services/http-common.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import * as utils from 'lodash';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from './../allocation-change/allocation-change-service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { SelectAccountSinglePremiumComponent } from './select-account-single-premium/select-account-single-premium.component';
import { AdditionalContractSinglePremiumComponent } from './additional-contract-single-premium/additional-contract-single-premium.component';
import { SingleContractSummaryComponent } from './single-contract-summary/single-contract-summary.component';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UtilityService } from 'src/app/shared/utilities/utility.service';

@Component({
  selector: 'single-premium',
  templateUrl: './single-premium.component.html',
  styleUrls: ['./single-premium.component.scss']
})
export class SinglePremiumComponent implements OnInit {
  confirmationPage: boolean = false;
  previouslySelectedstep = [];
  isStepInteracted = false;
  selectAccountForm: FormGroup;
  selectFundForm: FormGroup;
  responseActiveOrder: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  FundAccountEmpty: boolean = false;
  totalShareError: boolean = false;
  selectAccountSecError: boolean = false;
  showOrderProcessingErr: boolean;
  selectedFundTotalErr: boolean;
  selectFundFormErr: boolean;
  valuesSelectedArray: any[];
  selectAdditionalAmountForm: FormGroup;
  amountValueEmptyErr: boolean;
  acceptAckErr: boolean;
  insufficientValueErr: boolean;
  exceedsMaximumValueErr: boolean;
  country: string;
  lang: string;
  displayPoOption: boolean;
  contractDetail: any;
  contractNo: any;
  userrole: string;
  clientId: any;
  responseTransmit: { policyNumber: string; investAccNumber: string; activeOrderErrorRender: boolean; authorizationErrorRender: boolean; orderErrorRender: boolean; clientId: string; userName: string; firstName: string; lastName: string; language: string; country: string; };
  responseSinglePremium: any;
  responseSummary: any;
  userdetail: any;
  arraySelectedUnique: any;
  noChangeOfAllocationErrorRender: boolean = false;
  authorizationFlag: boolean;
  step2Completed: boolean;
  langChange: string;
  orderGeneratedError: boolean;
  minimumFundAllocationError: boolean;
  step1Completed: boolean;
  searchedClientDetails: any;

  constructor(private translate: TranslateService, private _formBuilder: FormBuilder,
    private httpService: HttpCommonService, private router: Router,
    private route: ActivatedRoute,
    private newPremiumService: AllocationChangeSharedService,
    private sharedService: SharedServiceService,
    private menuItemService: MenuItemsService,
    public deviceDetector: DeviceDetectorService
  ) { }

  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.selectAccountForm = this._formBuilder.group({
    });
    this.selectAdditionalAmountForm = this._formBuilder.group({
    });
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
    }
    else {
      this.displayPoOption = true;
    }
    this.contractDetail = null;
    this.contractNo = this.sharedService.getContractNo();
    this.contractDetail = JSON.parse(sessionStorage.getItem('contractDetails'));
    this.userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    const contractnumber = JSON.parse(sessionStorage.getItem('contract'));
    this.userrole = this.menuItemService.getAllRoles();
    this.searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
    //(this.userrole)
    // if (this.userrole === "rClient") {
    //   this.clientId = this.userdetail.clientID;
    // } else {
    //   this.clientId = customerId.clientID;
    // }
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (this.userdetail) {
      this.clientId = this.userdetail.clientId ? this.userdetail.clientId : '';
    }
    this.langChange = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if (this.langChange == "pl_en") {
      this.langChange = "en";
    } else if (this.langChange == "pl_pl") {
      this.langChange = "pl";
    } else if (this.langChange == "ro_en") {
      this.langChange = "en";
    } else if (this.langChange == "ro_ro") {
      this.langChange = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.langChange = data;
        this.lang = data;
        if (this.lang != 'en' && this.selectAdditionalAmntRefComp && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm &&
          this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'] && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value != null) {
          this.selectAdditionalAmntRefComp ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].setValue(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.includes('.')
            ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.replace('.', ',') :
            this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value) : '';
        } else {
          this.selectAdditionalAmntRefComp ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm && this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].setValue(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.includes(',')
            ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.replace(',', '.') :
            this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value) : '';
        }
      }
    });
  }

  step = 0;
  @ViewChild(SelectAccountSinglePremiumComponent, { static: false }) selectAccRefComp: SelectAccountSinglePremiumComponent;
  @ViewChild(AdditionalContractSinglePremiumComponent, { static: false }) selectAdditionalAmntRefComp: AdditionalContractSinglePremiumComponent;
  @ViewChild(SingleContractSummaryComponent, { static: false }) summaryRefComp: SingleContractSummaryComponent;

  setStep(index: number) {
    this.step = index;
  }

  nextStep(id) {
    ////("next step");
    //this.stepper.selectedIndex++;
    this.stepper.selected.completed = true;
    this.stepper.selectedIndex = this.stepper.selectedIndex + 1;
    if (this.isMobile) {
      this.setFocus(id);
    } else {
      //window.scroll(0,0);
    }
  }

  prevStep() {
    this.step--;
  }
  setFocus(id) {
    let targetElem = document.getElementById(id);
    // targetElem.scrollIntoView();
    //targetElem.focus();
    setTimeout(function waitTargetElem() {
      if (targetElem) {
        targetElem.scrollIntoView();
      } else {
        setTimeout(waitTargetElem, 100);
      }
    }, 100);
  }

  onStepChange(event) {
    this.checkStepCompletionStatus(this.stepper['_selectedIndex']);
    if (event.selectedIndex == 0) {
      this.step1Completed = false;
      this.insufficientValueErr = false;
      this.exceedsMaximumValueErr = false;
      this.amountValueEmptyErr = false;
      this.acceptAckErr = false;
      this.orderGeneratedError = false;
      this.authorizationFlag = false;
      this.selectedFundTotalErr = false;
    } else if (event.selectedIndex == 1) {
      this.step2Completed = false;
      this.orderGeneratedError = false;
      this.authorizationFlag = false;
    } else { }
  }

  checkStepCompletionStatus(index) {
    if (this.stepper && this.stepper._steps['_results'][index].completed) {
      this.stepper['_elementRef'].nativeElement.querySelectorAll('.mat-step')[index].setAttribute('ariaChecked', true)
      return 'test';
    }
  }



  @ViewChild('stepper', { static: false }) stepper: MatStepper;
  headers = new HttpHeaders();


  gotoStep(step) {
    this.stepper.selectedIndex = step;
  }

  changeSelection() {
    if (this.previouslySelectedstep.indexOf(0) && this.stepper && this.stepper['_selectedIndex'] !== 0) {
      return true;
    }
    return false;
  }

  validateSelectAccount(id) {
    //(this.selectAccRefComp.selectAccountForm)
    this.step1Completed = false;
    this.selectAccRefComp.submitSelectedAccount();
    if (this.selectAccRefComp.selectedRow) {//selectAccountForm.valid
      this.FundAccountEmpty = false;
      this.validateSelectedAccountDetails(this.selectAccRefComp.selectedRow, id);//selectAccountForm.value
    } else {
      this.FundAccountEmpty = true;
      window.scroll(0, 0);
    }
  }

  validateSelectedAccountDetails(value, id) {
    const reqParam = {
      "policyNumber": value.policyNumber,//"21295126",
      "selectedInvestmentStrategy": "Deposit As New Invest Account",
      "investAccNumber": value.investAccNumber //"21295127"
    }
    this.httpService.postData(this.baseUrl.ecustomer.getActiveOrder, reqParam, this.headers).subscribe(data => {
      this.responseActiveOrder = data;
      if (!this.responseActiveOrder.activeOrderErrorRender) {
        this.showOrderProcessingErr = false;
        this.step1Completed = true;
        this.callfundDistributionApi(value, id);
      } else {
        //error msg display
        this.showOrderProcessingErr = true;
        window.scrollTo(0, 0);
      }
      //this.callfundDistributionApi(value);
    })
  }


  callfundDistributionApi(value, id) {
    const req = {
      "investAccNumber": value.investAccNumber,//"21295126",
      "clientId": value.clientId ? value.clientId : this.clientId,//"101583",
      "selectedInvestmentStrategy": "Deposit As New Invest Account",
      "processingSystem": this.contractDetail ? this.contractDetail.processingSystem : '',
      "investmentData": {
        "policyNumber": value.policyNumber,//"21295126",
        "investAccType": value.investAccType,//1,
        "investAccNumber": value.investAccNumber,//"21295126",
        "effectiveDate": value.effectiveDate,//1276626600000,
        "status": value.status,//23,
        "investValue": value.investValue,//2864.17,
        "productPlan": value.productPlan,//"UB2B000K3",
        //"bankAccount": value.bankAccount,//"59 1030 1944 9000 0500 2129 5126",
        "valuationDt": value.valuationDt//1332268200000
      }
    }
    this.httpService.postData(this.baseUrl.ecustomer.additionalContribution, req, this.headers).subscribe(data => {
      this.responseSinglePremium = data;
      this.newPremiumService.setSingleFundListResponse(data);
      this.insufficientValueErr = false;
      this.exceedsMaximumValueErr = false;
      this.amountValueEmptyErr = false;
      this.acceptAckErr = false;
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].setValue(false);
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].setValue('');
      this.nextStep(id);
    });

  }

  validateEnteredAmount(id) {
    this.step2Completed = false;
    this.stepper.selected.completed = false;
    //(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm);
    this.selectAdditionalAmntRefComp.submitSelectedAccount();
    if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.dirty) {
      this.amountValueEmptyErr = false;
      this.insufficientValueErr = false;
      this.exceedsMaximumValueErr = false;
      this.acceptAckErr = false;
      let inputAmount = this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.includes(',')
        ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value.replace(',', '.') :
        this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value;
      if (this.responseSinglePremium.minimumDepositAmount != 0 && this.responseSinglePremium.maximumDepositAmount == 0) {
        if ((this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value == '')) {
          this.insufficientValueErr = false;
          this.exceedsMaximumValueErr = false;
          this.amountValueEmptyErr = true;
          window.scrollTo(0, 0);
        } else {
          // let splitMinimum = this.responseSinglePremium.minimumDepositAmount.split(' ', 2);
          // let minimumValue = splitMinimum[0].replace('/,/g', '');
          if (parseFloat(inputAmount) >= parseFloat(this.responseSinglePremium.minimumDepositAmount)) {
            this.insufficientValueErr = false;
            this.exceedsMaximumValueErr = false;
            this.amountValueEmptyErr = false;
          } else {
            this.insufficientValueErr = true;
            this.exceedsMaximumValueErr = false;
            this.amountValueEmptyErr = false;
            window.scrollTo(0, 0);
          }
        }
        if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == false || this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == '') {
          this.acceptAckErr = true;
          window.scrollTo(0, 0);
        } else {
          this.acceptAckErr = false;
        }
      }
      else if (this.responseSinglePremium.minimumDepositAmount != 0 && this.responseSinglePremium.maximumDepositAmount != 0) {
        // let splitMinimum = this.responseSinglePremium.minimumDepositAmount.split(' ', 2);
        // let splitMaximum = this.responseSinglePremium.maximumDepositAmount.split(' ', 2);
        // let minimumValue = splitMinimum[0].replace('/,/g', '');
        // let maximumValue = splitMaximum[0].replace('/,/g', '');
        if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.dirty) {
          if (parseFloat(inputAmount) >= parseFloat(this.responseSinglePremium.minimumDepositAmount) &&
            (parseFloat(inputAmount) <= parseFloat(this.responseSinglePremium.maximumDepositAmount))) {
            this.insufficientValueErr = false;
            this.exceedsMaximumValueErr = false;
            this.amountValueEmptyErr = false;
          } else if (parseFloat(inputAmount) < parseFloat(this.responseSinglePremium.minimumDepositAmount)) {
            this.insufficientValueErr = true;
            this.exceedsMaximumValueErr = false;
            this.amountValueEmptyErr = false;
            window.scrollTo(0, 0);
          } else if (parseFloat(inputAmount) > parseFloat(this.responseSinglePremium.maximumDepositAmount)) {
            this.exceedsMaximumValueErr = true;
            this.amountValueEmptyErr = false;
            this.insufficientValueErr = false;
            window.scrollTo(0, 0);
          }
          if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == false || this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == '') {
            this.acceptAckErr = true;
            window.scrollTo(0, 0);
          } else {
            this.acceptAckErr = false;
          }
        }
      }
    } else {
      if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == false || this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == '') {
        this.acceptAckErr = true;
        window.scrollTo(0, 0);
      } else {
        this.acceptAckErr = false;
      }
    }
    if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value == '') {
      this.amountValueEmptyErr = true;
      this.insufficientValueErr = false;
      this.exceedsMaximumValueErr = false;
      window.scrollTo(0, 0);
    } else {
      this.amountValueEmptyErr = false;
    }
    if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['acknowledge'].value == '' &&
      this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value == '') {
      this.amountValueEmptyErr = true;
      this.acceptAckErr = true;
      window.scrollTo(0, 0);
    }

    // if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.valid && !this.exceedsMaximumValueErr && !this.amountValueEmptyErr && !this.insufficientValueErr
    //   && !this.acceptAckErr) {
    //   this.newPremiumService.setDeclaredAmount(this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['amountField'].value);
    //   this.confirmationPage = false;
    //   this.executeAdditionalPremium();
    // }

    // if (this.selectFundRefComp.selectFundForm.dirty && this.selectFundRefComp.selectFundForm.valid) {
    if (this.selectAdditionalAmntRefComp.total == '100') {
      let fundDataArr: any[];
      let arraySelected = [];
      this.newPremiumService.getSinglePremiumFunds().subscribe((arr) => {
        fundDataArr = [];
        fundDataArr = arr;
        arraySelected = [];
        this.arraySelectedUnique = [];
        fundDataArr.forEach((data) => {
          if (data.newAllocationAmt != "0" && data.newAllocationAmt != "") {
            if (arraySelected.length == 0) {
              arraySelected.push(data);
            } else if (arraySelected.length > 1) {
              arraySelected.forEach((val) => {
                if (val.sort == data.sort) {
                  arraySelected.splice(val, 1);
                  arraySelected.push(data);
                } else {
                  arraySelected.push(data);
                }
              })
            } else if (arraySelected.length == 1) {
              if (arraySelected[0].sort != data.sort) {
                arraySelected.push(data);
              } else {
                arraySelected.splice(arraySelected[0], 1);
                arraySelected.push(data);
              }

            }
          }
        });
        this.arraySelectedUnique = this.getUnique(arraySelected, 'sort')
        this.selectedFundTotalErr = false;
        //(this.arraySelectedUnique)
      });
      //this.nextStep();
    } else {
      this.selectedFundTotalErr = true;
      window.scroll(0, 0);
      //total value error
    }
    if (this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.valid && !this.exceedsMaximumValueErr && !this.amountValueEmptyErr && !this.insufficientValueErr
      && !this.acceptAckErr && !this.selectedFundTotalErr) {
      let minFundCnt = 0;
      if (this.arraySelectedUnique != null && this.arraySelectedUnique.length > 0) {
        this.arraySelectedUnique.forEach((val) => {
          if (val.newAllocationAmt != 0 && val.newAllocationAmt < val.minimumAllocationPerFund) {
            minFundCnt = minFundCnt + 1;
          } else {
            //do nothing
          }
        });
        if (minFundCnt > 0) {
          this.minimumFundAllocationError = true;
          window.scrollTo(0, 0);
        } else {
          this.minimumFundAllocationError = false;
          this.callSummaryApi(this.arraySelectedUnique, id);
        }
      }
    } else {
      //form empty
      // this.selectedFundTotalErr = true;
      // window.scroll(0, 0);
    }
  }


  getUnique(arr, comp) {

    // store the comparison  values in array
    const unique = arr.map(e => e[comp])

      // store the indexes of the unique objects
      .map((e, i, final) => final.indexOf(e) === i && i)

      // eliminate the false indexes & return unique objects
      .filter((e) => arr[e]).map(e => arr[e]);

    return unique;
  }

  executeAdditionalPremium() {
    let request = {
      "selectedInvestmentStrategy": "Deposit As New Invest Account",
      "policyNumber": this.responseSinglePremium.investmentData.policyNumber,//"21295126",
      "investAccNumber": this.responseSummary.investAccNumber,//"21295127",
      "processingSystem": this.contractDetail ? this.contractDetail.processingSystem : '',
      "firstName": this.userdetail ? this.userdetail.firstName : '',//"FirstN21",
      "lastName": this.userdetail ? this.userdetail.lastName : '',//"LastN21",
      "userName": this.userdetail ? this.userdetail.userName : '',//"Testuser210",
      "country": this.country,//"pl",
      "language": this.lang,//"en",
      "userRole": this.userrole ? this.userrole : 'NoRole',//"rAdvisor",
      "addCoverageAmt": this.responseSummary ? this.responseSummary.addCoverageAmt : 0,//"100",
      "orderCutOffTime": this.responseSummary.orderCutOffTime,//"6",
      "clientId": this.clientId ? this.clientId : null,//"101583",
      "clientFirstName": this.searchedClientDetails ? this.searchedClientDetails.clientFirstName : this.userdetail.firstName,
      "clientLastName": this.searchedClientDetails ? this.searchedClientDetails.clientLastName : this.userdetail.lastName,
      "clientUserName": this.userrole == 'rClient' ? this.userdetail.userName : null,
      "investmentData": {
        "policyNumber": this.selectAccRefComp.selectedRow.policyNumber,//this.responseSinglePremium.investmentData.policyNumber,//"21295126",
        "investAccType": this.selectAccRefComp.selectedRow.investAccType,//1,
        "investAccNumber": this.selectAccRefComp.selectedRow.investAccNumber,//"21295126",
        "effectiveDate": this.selectAccRefComp.selectedRow.effectiveDate,//1276626600000,
        "status": this.selectAccRefComp.selectedRow.status,//23,
        "investValue": this.selectAccRefComp.selectedRow.investValue,//2864.17,
        "productPlan": this.selectAccRefComp.selectedRow.productPlan, //"UB2B000K3",
        "bankAccount": this.selectAccRefComp.selectedRow.bankAccount,// "59 1030 1944 9000 0500 2129 5126",
        "valuationDt": this.selectAccRefComp.selectedRow.valuationDt,//1332268200000
      },
      "fundsListWithAllocation": this.responseSummary.fundsList//this.arraySelectedUnique
    }
    this.httpService.postData(this.baseUrl.ecustomer.additionalContributionConfirmation, request, this.headers).subscribe(data => {
      if (data.hasOwnProperty('activeUser') && (data.activeUser == false)) {
        this.router.navigate(['/logout']);
      } else {
        if (!data.renderUnauthorizedErr && data.orderId != null) {
          this.responseTransmit = data;
          this.newPremiumService.setConfReqData(data);
          this.confirmationPage = true;
          this.authorizationFlag = false;
          this.orderGeneratedError = false;
          if (this.isMobile && this.confirmationPage) {
            this.setFocus("confirmationSinglePremFormDiv");
            window.scroll(0, 0);
          } else {
            //window.scroll(0,0);
          }
        } else {
          if (!data.renderUnauthorizedErr && data.orderId == null) {
            this.confirmationPage = false;
            this.authorizationFlag = false;
            this.orderGeneratedError = true;
            window.scrollTo(0, 0);
          }
          if (data.renderUnauthorizedErr && data.orderId == null) {
            this.confirmationPage = false;
            this.authorizationFlag = true;
            this.orderGeneratedError = false;
            window.scrollTo(0, 0);
          }
        }
      }
    });
  }

  callSummaryApi(arraySelected, id) {
    let inputAmount = (this.langChange == 'pl' || this.langChange == 'ro' || this.langChange == 'gr') ? this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.value.amountField.replace(',', '.') : this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.value.amountField
    let request = {
      //"investAccNumber": this.responseSinglePremium.investmentData.investAccNumber,//"21295126",
      "clientId": this.responseSinglePremium.clientId ? this.responseSinglePremium.clientId : this.clientId,//"101583",
      "selectedInvestmentStrategy": "Deposit As New Invest Account",
      "processingSystem": this.contractDetail ? this.contractDetail.processingSystem : '',
      "totalNewlyAllocatedPercentage": this.selectAdditionalAmntRefComp.total,//this.responseSinglePremium.totalNewlyAllocatedPercentage,//"100",
      "statementCheck": true,//this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.value.acceptAckErr
      "addCoverageAmt": this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.value.amountField ? inputAmount : this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.value.amountField,// : 0,
      "fundsList": this.arraySelectedUnique//this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['fundListArray'].value//arraySelected//this.selectAdditionalAmntRefComp.selectAdditionalAmountForm.controls['fundListArray'].value
    }
    this.httpService.postData(this.baseUrl.ecustomer.additionalContributionDetailsSummary, request, this.headers).subscribe(data => {

      this.responseSummary = data;
      //this.noChangeOfAllocationErrorRender = data.noChangeOfAllocationErrorRender;
      if (data != null && data.validationSuccess && !this.selectedFundTotalErr) {
        this.step2Completed = true;
        this.stepper.selected.completed = true;
        this.nextStep(id);
        if (this.isMobile && this.step2Completed) {
          this.setFocus('step2SinglePremFormDiv');
        } else {
          //window.scroll(0,0);
        }
      }
      this.newPremiumService.setSinglePremiumSummary(data);
      this.confirmationPage = false;

    });

  }

  gotoPremiumSplitPage() {
    // this.gotoPremiumSplit = true;
    //this.valueChange.emit('allocationChange');
    //this.sharedService.setPageContent('singlePremium');
    let data = {
      //'fromPage': 'transferFunds',
      "toPage": 'orderInvest'
    }
    this.sharedService.setPageContent(data);
  }

  getSrcFlagValue(evt) {
    //console.log('setOutput', evt)
    if (evt) {
      if (evt.get('fundEmptyErr').value) {
        this.selectedFundTotalErr = true;
        this.minimumFundAllocationError = false;
        // this.sourceUpdatedListEmpty = false;
        // this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('minFundErr').value) {
        this.minimumFundAllocationError = true;
        this.selectedFundTotalErr = false;
        // this.sourceUpdatedListEmpty = false;
        // this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else if (evt.get('sourceFundEmptyErr').value) {
        this.selectedFundTotalErr = false;
        this.minimumFundAllocationError = false;
        // this.sourceUpdatedListEmpty = true;
        // this.checkArrayValidations();
        window.scrollTo(0, 0);
      } else {
        this.minimumFundAllocationError = false;
        this.selectedFundTotalErr = false;
        // this.sourceUpdatedListEmpty = false;
        this.checkArrayValidations();
      }
    } else {
      this.minimumFundAllocationError = false;
      this.selectedFundTotalErr = false;
      this.amountValueEmptyErr = false;
      this.insufficientValueErr = false;
      this.exceedsMaximumValueErr = false;
      this.acceptAckErr = false;
      //this.sourceUpdatedListEmpty = false;
      this.checkArrayValidations();
    }
  }

  checkArrayValidations() {
    this.selectAdditionalAmntRefComp.selectAdditionalAmountForm['controls'].fundListArray['controls'].forEach(element => {
      if (parseFloat(element.get('newAllocationAmt').value) != 0 && element.get('newAllocationAmt').value != '') {
        if (element.get('newAllocationAmt').value < element.get('minimumAllocationPerFund').value) {
          if (this.selectAdditionalAmntRefComp.totalTemp > 100 &&
            parseFloat(element.get('newAllocationAmt').value) != 0 &&
            element.get('newAllocationAmt').value != '') {
            element.get('fundEmptyErr').setValue(true);
            element.get('minFundErr').setValue(true);
            this.minimumFundAllocationError = true;
            this.selectedFundTotalErr = true;
            // this.selectFundRefComp.shareLeft = 100;
            // this.selectFundRefComp.total = 0;
          } else {
            // element.fundEmptyErr =false;
            // element.minFundErr = true;
            element.get('fundEmptyErr').setValue(false);
            element.get('minFundErr').setValue(true);
            this.minimumFundAllocationError = true;
            this.selectedFundTotalErr = false;
            // this.selectFundRefComp.shareLeft = 100;
            // this.selectFundRefComp.total = 0;
          }
        } else {
          //element.minFundErr = true;
          element.get('minFundErr').setValue(false);
          this.minimumFundAllocationError = this.minimumFundAllocationError ? this.minimumFundAllocationError : false;
          if (this.selectAdditionalAmntRefComp.totalTemp > 100 &&
            parseFloat(element.get('newAllocationAmt').value) != 0 &&
            element.get('newAllocationAmt').value != '' && element.get('newAllocationAmt').value > 100) {
            // element.fundEmptyErr =true;
            // element.minFundErr = true;
            element.get('fundEmptyErr').setValue(true);
            //element.get('totalExceedsErr').setValue(true);
            this.selectedFundTotalErr = true;
            // this.selectFundRefComp.shareLeft = 100;
            // this.selectFundRefComp.total = 0;
          } else {
            // element.fundEmptyErr =false;
            // element.minFundErr = true;
            element.get('fundEmptyErr').setValue(false);
            this.selectedFundTotalErr = false;
          }
        }
      } else {
        element.get('fundEmptyErr').setValue(false);
        element.get('minFundErr').setValue(false);
        this.selectedFundTotalErr = false;
        this.minimumFundAllocationError = this.minimumFundAllocationError ? this.minimumFundAllocationError : false;
      }
    });

  }
}

