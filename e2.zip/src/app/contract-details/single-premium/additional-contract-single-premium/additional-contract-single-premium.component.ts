import { HttpHeaders } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTable, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { changePremiumSharedService } from 'src/app/change-premium-split/change-premium-shared-service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { TransformPipe } from 'src/app/shared/pipe/transform.pipe';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
import { AppConfig } from 'src/config/app.config';
import { AllocationChangeSharedService } from '../../allocation-change/allocation-change-service';

export interface FundDataList {
  contact: FundData[];
}
export interface FundData {
  fundName: String;
  quotesLink: String;
  newSlip: String;
  newSlipPercentage: String;
  equalto: String;
}

@Component({
  selector: 'additional-contract-single-premium',
  templateUrl: './additional-contract-single-premium.component.html',
  styleUrls: ['./additional-contract-single-premium.component.scss']
})
export class AdditionalContractSinglePremiumComponent implements OnInit {

  selectAdditionalAmountForm: FormGroup;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  headers = new HttpHeaders();
  responseAdditionalPremium: any;
  accountDet: any;
  accountDetails: any;
  subscription: any;
  // fundListArray: any;
  total: any = 0;
  shareLeft: number;
  fundDetails: any;
  displayedColumns: String[] = ['fundName', 'quotesLink',
    'newSlip', 'equalto', 'newSlipPercentage',];
  dataSourceFundDetails: MatTableDataSource<FundDataList>;
  @ViewChild(MatTable, { static: false }) _matTable: MatTable<any>;
  amntFieldSubscription: any;
  country: string;
  displayPoOption: boolean;
  currencyType: string;
  langChange: string;
  defaultValue: number = 0.00;
  dotCount: number;
  checkString: any;
  checkNumberOnly: any;
  displayRoOption: boolean;
  @Output() flagValueChange = new EventEmitter();
  formSubmitted: boolean = false;
  rowValueChanged: boolean = false;
  amountChanged: boolean = false;
  totalTemp: any;
  arrayNotUpadted: boolean;
  shareLeftReset: boolean;
  constructor(
    private translate: TranslateService, private fb: FormBuilder,
    private httpService: HttpCommonService, private router: Router,
    private route: ActivatedRoute,
    private newPremiumService: AllocationChangeSharedService,
    private transform: TransformPipe,
    private sharedService: SharedServiceService
  ) { }

  ngOnInit() {
    this.country = sessionStorage.getItem('countryCode');
    //if (this.country == 'pl') {
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      this.displayPoOption = true;
      this.currencyType = 'PLN';
    }
    else {
      this.displayRoOption = true;
      this.currencyType = 'RON';
    }
    this.langChange = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if (this.langChange == "pl_en") {
      this.langChange = "en";
    } else if (this.langChange == "pl_pl") {
      this.langChange = "pl";
    } else if (this.langChange == "ro_en") {
      this.langChange = "en";
    } else if (this.langChange == "ro_ro") {
      this.langChange = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.langChange = data;
        if (this.selectAdditionalAmountForm && this.selectAdditionalAmountForm.controls['amountField'].value != '') {
          if (this.langChange == 'pl' || this.langChange == 'ro' || this.langChange == 'gr') {
            this.selectAdditionalAmountForm.controls['amountField'].setValue((this.selectAdditionalAmountForm.controls['amountField'].value.includes('.') ? this.selectAdditionalAmountForm.controls['amountField'].value.replace('.', ',') : this.selectAdditionalAmountForm.controls['amountField'].value));
          } else {
            this.selectAdditionalAmountForm.controls['amountField'].setValue((this.selectAdditionalAmountForm.controls['amountField'].value.includes(',') ? this.selectAdditionalAmountForm.controls['amountField'].value.replace(',', '.') : this.selectAdditionalAmountForm.controls['amountField'].value));
          }
        }
      }
    });
    this.createForm();
    // this.newPremiumService.getFundData().subscribe((val) => {
    //   this.responseAdditionalPremium = val;
    //   // this.summaryPage = true;
    // })
    this.newPremiumService.getaccountData().subscribe((data) => {
      this.accountDetails = data;
    })
    this.newPremiumService.getSingleFundListResponse().subscribe((data) => {
      this.responseAdditionalPremium = data;
      if (this.accountDetails != null && this.responseAdditionalPremium != null) {
        this.getFundList(this.responseAdditionalPremium);
        // this.selectAdditionalAmountForm.reset();
      }
    })
    //this.amntFieldSubscription = this.selectAdditionalAmountForm.controls['amountField'].valueChanges.subscribe(data => {
    // this.fundListArray.value.forEach(item =>{
    //   for(let i=0;i<this.fundListArray.value.length;i++){
    //   if (this.selectAdditionalAmountForm.controls['fundListArray'].value[i].newAllocationAmt != 0) {
    //     this.selectAdditionalAmountForm.controls['fundListArray'].value[i].newAllocationAmt.setValue(0);
    //     this.selectAdditionalAmountForm.controls['fundListArray'].value[i].allocationPercentage.setValue(0);
    //   }
    // }
    // this.getFundList(this.responseAdditionalPremium);
    // this.flagValueChange.emit(null);
    // //this.validateSourceInput('',this.selectAdditionalAmountForm.controls['fundListArray'].value? this.selectAdditionalAmountForm.controls['fundListArray'].value[0].value: '')
    // this.selectAdditionalAmountForm.get('total').setValue(0);
    // this.selectAdditionalAmountForm.get('totalAmntSplitted').setValue(0);
    // this.shareLeft = 0;
    //})
    this.subscription = this.fundListArray.valueChanges.subscribe(data => {
      let enterValue = this.selectAdditionalAmountForm.controls['amountField'].value;
      if (this.selectAdditionalAmountForm.controls['amountField'].value != "" && this.selectAdditionalAmountForm.controls['amountField'].value != '') {
        data.forEach((val) => {
          let inputAmount;
          if (this.langChange == 'pl' || this.langChange == 'ro' || this.langChange == 'gr') {
            inputAmount = (this.selectAdditionalAmountForm.controls['amountField'].value.includes(',') ? this.selectAdditionalAmountForm.controls['amountField'].value.replace(',', '.') : this.selectAdditionalAmountForm.controls['amountField'].value);
          } else {
            inputAmount = this.selectAdditionalAmountForm.controls['amountField'].value;
          }
          if (val.newAllocationAmt != 0) {
            val.totalAmtCurrent = ((parseFloat(val.newAllocationAmt) * parseFloat(inputAmount)) / 100);
            //(val.totalAmtCurrent);
          }

        })
        this.total = !this.shareLeftReset && this.total <= 100 ? data.reduce((a, b) => a + +(b.totalAmtCurrent != 0
          && (!b.minFundErr && !b.fundEmptyErr && b.newAllocationAmt <= 100) ? b.newAllocationAmt : 0), 0) : 0;
        this.totalTemp = data.reduce((a, b) => a + +b.newAllocationAmt, 0);
        this.responseAdditionalPremium.totalNewlyAllocatedPercentage = data.reduce((a, b) => a + +b.totalAmtCurrent, 0);
        // this.total = data.reduce((a, b) => a + +b.newAllocationAmt, 0);
        // this.responseAdditionalPremium.totalNewlyAllocatedPercentage = data.reduce((a, b) => a + +b.totalAmtCurrent, 0);
        if (this.total <= 100) {
          this.selectAdditionalAmountForm.get('total').setValue(this.total);
          this.selectAdditionalAmountForm.get('totalAmntSplitted').setValue(!this.shareLeftReset && this.total != 0 ? data.reduce((a, b) => a + +((
            !b.minFundErr && !b.fundEmptyErr && b.totalAmtCurrent != 0) ? b.totalAmtCurrent : 0), 0) : 0);
        } else {
          this.selectAdditionalAmountForm.get('total').setValue(0);
          this.selectAdditionalAmountForm.get('totalAmntSplitted').setValue(0);
        }
      }
      this.shareLeft = this.selectAdditionalAmountForm.get('total').value <= '100' ? 100 - this.total : 100;
      //   // this._matTable.renderRows();
      //   // this.selectAdditionalAmountForm.get('fundListArray').setValue(data);
      //   // //(this.selectAdditionalAmountForm.get('fundListArray').value)
    })
  }

  valueonArrayInputChange(evt, row) {
    // row.get('rowValueChanged').value = true;
    // let enterValue = this.selectAdditionalAmountForm.controls['amountField'].value;
    //   if (this.selectAdditionalAmountForm.controls['amountField'].value != "" && this.selectAdditionalAmountForm.controls['amountField'].value != '') {
    //     this.fundListArray.value.forEach((val) => {
    //     let inputAmount;
    //       if (this.langChange == 'pl' || this.langChange == 'ro') {
    //         inputAmount = (this.selectAdditionalAmountForm.controls['amountField'].value.includes(',') ? this.selectAdditionalAmountForm.controls['amountField'].value.replace(',','.'):this.selectAdditionalAmountForm.controls['amountField'].value);
    //       }
    //       if (val.newAllocationAmt != 0) {
    //         val.totalAmtCurrent = (((val.newAllocationAmt) / 100) * (inputAmount));
    //        // val.get('totalAmtCurrent').setValue(val.totalAmtCurrent);
    //         //console.log(val.get('totalAmtCurrent').setValue(val.totalAmtCurrent));
    //         //(val.totalAmtCurrent);
    //       }

    //   })
    //   // this.total = this.total <= 100 ? this.fundListArray.value.reduce((a, b) => a + +(b.totalAmtCurrent!=0 ? b.newAllocationAmt : 0), 0) : 0;
    //   // this.responseAdditionalPremium.totalNewlyAllocatedPercentage = this.fundListArray.value.reduce((a, b) => a + +b.totalAmtCurrent, 0);
    //   this.total = this.fundListArray.value.reduce((a, b) => a + +b.newAllocationAmt, 0);
    //   this.responseAdditionalPremium.totalNewlyAllocatedPercentage = this.fundListArray.value.reduce((a, b) => a + +b.totalAmtCurrent, 0);
    //   if (this.total <= 100) {
    //   this.selectAdditionalAmountForm.get('total').setValue(this.total);
    //   this.selectAdditionalAmountForm.get('totalAmntSplitted').setValue(this.fundListArray.value.reduce((a, b) => a + +b.totalAmtCurrent, 0));
    //   }else{
    //     this.selectAdditionalAmountForm.get('total').setValue(0);
    //     this.selectAdditionalAmountForm.get('totalAmntSplitted').setValue(0);
    //   }
    //   this.shareLeft = 100 - this.total;
    // }
  }

  onClickAccept(evt) {
    //()
    this.selectAdditionalAmountForm.controls['acknowledge'].setValue(evt);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    //this.amntFieldSubscription.unsubscribe();
  }

  createForm() {
    this.selectAdditionalAmountForm = this.fb.group({
      amountField: ['', [Validators.required]],
      acknowledge: ['', [Validators.required]],
      total: [0, Validators.required],
      totalAmntSplitted: [0, Validators.required],
      fundListArray: this.fb.array([])
    });
  }

  get fundListArray() {
    return this.selectAdditionalAmountForm.get('fundListArray') as FormArray;

  }

  // fundListArray(): FormArray {
  //   return this.selectFundForm.get('fundListArray') as FormArray;
  // }  

  getFundList(data) {
    if (data) {
      this.fundDetails = data.fundsList;
      this.selectAdditionalAmountForm['controls'].fundListArray['controls'] = [];
      for (let i = 0; i < data.fundsList.length; i++) {
        data.fundsList[i].minimumAllocationPerFund = data.minimumAllocationPercentage;
        this.add(i);
      }
      //(data);
    } else {
      //
    }
    this.dataSourceFundDetails = new MatTableDataSource(this.selectAdditionalAmountForm['controls'].fundListArray['controls']);
    // });
  }

  add(index) {
    this.fundListArray.push(this.new(index));
  }

  new(index): FormGroup {
    return this.fb.group({
      fundCode: this.fundDetails[index].fundCode,
      fundId: this.fundDetails[index].fundId,
      fundType: this.fundDetails[index].fundType,
      unitPrice: this.fundDetails[index].unitPrice,
      investAccNumber: this.fundDetails[index].investAccNumber,
      sort: this.fundDetails[index].sort,
      fundLink: this.fundDetails[index].fundLink,
      externalLink: this.fundDetails[index].externalLink,
      allocationPercentage: [this.fundDetails[index].allocationPercentage],
      dataError: this.fundDetails[index].dataError,
      newSplitErr: false,
      newAllocationAmt: [this.fundDetails[index].newAllocationAmt],
      totalAmtCurrent: [this.fundDetails[index].totalAmtCurrent],
      fundEmptyErr: false,
      minFundErr: false,
      sourceFundEmptyErr: false,
      minimumAllocationPerFund: this.fundDetails[index].minimumAllocationPerFund,
      rowValueChanged: false
    })
  }

  formSubmit() {
    return this.selectAdditionalAmountForm.valid;
  }

  submitSelectedAccount() {
    this.formSubmitted = true;
    //if (this.selectAdditionalAmountForm.dirty || this.formSubmitted) {
    if (this.selectAdditionalAmountForm.controls['total'].value == 0) {
      if (this.selectAdditionalAmountForm.controls['fundListArray'].value.length > 0) {
        this.arrayNotUpadted = true;
        this.fundListArray.controls.forEach(row => {
          row.get('fundEmptyErr').setValue(true);
          this.shareLeftReset = true;
          // row.fundEmptyErr = true;
          this.flagValueChange.emit(row);
        });
      }
    }
    this.newPremiumService.setDeclaredAmount(this.selectAdditionalAmountForm.controls['amountField'].value);
    //this.newPremiumService.setFundData(this.selectAdditionalAmountForm.value);
    // if(this.selectAdditionalAmountForm.controls['fundListArray'].value.length > 0){
    //   this.selectAdditionalAmountForm.controls['fundListArray'].value.forEach(row => {
    //     this.validateSourceInput('',row);
    //   });
    // }
    this.newPremiumService.setSinglePremiumFunds(this.selectAdditionalAmountForm.controls['fundListArray'].value);
    this.newPremiumService.setParamValue('selectAdditionalAmountForm', this.selectAdditionalAmountForm);
    return this.selectAdditionalAmountForm.valid;
    // }
    // }
  }

  resetFormArrayValues() {
    this.getFundList(this.responseAdditionalPremium);
    this.arrayNotUpadted = false;
    this.flagValueChange.emit(null);
    this.total = 0;
    this.responseAdditionalPremium.totalNewlyAllocatedPercentage = 0;
    //this.validateSourceInput('',this.selectAdditionalAmountForm.controls['fundListArray'].value? this.selectAdditionalAmountForm.controls['fundListArray'].value[0].value: '')
    this.selectAdditionalAmountForm.get('total').setValue(0);
    this.selectAdditionalAmountForm.get('totalAmntSplitted').setValue(0);
    this.shareLeft = 100 - this.total;
  }

  numberOnly(event, row, action) {
    let pastedText;
    if (action == 'paste') {
      let clipboardData = event.clipboardData;
      pastedText = clipboardData.getData('text');
    } else {
      pastedText = event.target.value;
      // let pastedText = clipboardData.getData('text');
    }
    event.preventDefault();
    let ctrl = row.get('newAllocationAmt') as FormControl;
    ctrl.setValue(this.transform.transform(pastedText, this.langChange), { emitEvent: false, emitViewToModelChange: false });
    let checkNumberOnly = (ctrl.value);
    if (checkNumberOnly != null) {
      let numeric = (ctrl.value).toString();
      // if (this.langChange == 'pl' || this.langChange == 'ro') {
      if (numeric.includes(',')) {
        let checkNumeric = numeric.replace(',', '');
        if (checkNumeric.length > 3) {
          ctrl.setValue(checkNumeric.substr(0, 3));
          return false;
        } else {
          ctrl.setValue(checkNumeric.substr(0, 3));
        }
      }
      //  } else {
      if (numeric.includes('.')) {
        let checkNumeric = numeric.replace('.', '');
        if (checkNumeric.length > 3) {
          ctrl.setValue(checkNumeric.substr(0, 3));
          return false;
        } else {
          ctrl.setValue(checkNumeric.substr(0, 3));
        }
      }
      //  }
    }
    /*
    if (this.langChange == "pl" || this.langChange == "ro") {
      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode == 44) {
        this.dotCount += 1;
        this.checkNumberOnly = (event.target.value);
        let numericCheck = (event.target.value).toString();
        if (numericCheck.includes(',')) {
          this.dotCount += 1;
        }
        if (this.dotCount > 1) {
          this.dotCount = 0;
          return false;
        }
      }
      if (charCode > 31 && charCode != 44 && (charCode < 45 || charCode > 57 || charCode == 47 || charCode == 46)) {
        return false;
      }
      this.checkNumberOnly = (event.target.value);
      if (this.checkNumberOnly != null) {
        let numeric = (event.target.value).toString();
        if (numeric.includes(',')) {
          let checkNumeric = numeric.split(',');
          if (checkNumeric.length > 2) {
            return false;
          }
          this.checkString = checkNumeric[1].split('');
          if (this.checkString.length > 1) {
            // this.toastrService.warning("Invalid value", "Warning");
            return false;
          }
        }

      }
      this.dotCount = 0;
      //this.cdr.detectChanges();
      return true;
    } else if (this.langChange == "en") {
      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode == 46) {
        this.dotCount += 1;
        this.checkNumberOnly = (event.target.value);
        let numericCheck = (event.target.value).toString();
        if (numericCheck.includes('.')) {
          this.dotCount += 1;
        }
        if (this.dotCount > 1) {
          this.dotCount = 0;
          return false;
        }
      }
      if (charCode > 31 && (charCode < 45 || charCode > 57 || charCode == 47)) {
        return false;
      }
      this.checkNumberOnly = (event.target.value);
      if (this.checkNumberOnly != null) {
        let numeric = (event.target.value).toString();
        if (numeric.includes('.')) {
          let checkNumeric = numeric.split('.');
          if (checkNumeric.length > 2) {
            return false;
          }
          this.checkString = checkNumeric[1].split('');
          if (this.checkString.length > 1) {
            // this.toastrService.warning("Invalid value", "Warning");
            return false;
          }
        }

      }
      this.dotCount = 0;
      //this.cdr.detectChanges();
      return true;
    }*/
  }

  numberValue1(event, itemrow) {
    let clipboardData = event.clipboardData;
    let pastedText = clipboardData.getData('text');
    event.preventDefault();
    let ctrl = itemrow.get('newAllocationAmt') as FormControl;
    ctrl.setValue(this.transform.transform(pastedText, this.langChange), { emitEvent: false, emitViewToModelChange: false });
  }

  numberValueAmnt(event, itemrow, action) {
    let pastedText;
    if (action == 'paste') {
      let clipboardData = event.clipboardData;
      pastedText = clipboardData.getData('text');
    } else {
      pastedText = event.target.value;
      // let pastedText = clipboardData.getData('text');
    }
    event.preventDefault();
    let ctrl = this.selectAdditionalAmountForm.get('amountField') as FormControl;
    ctrl.setValue(this.transform.transform(pastedText, this.langChange), { emitEvent: false, emitViewToModelChange: false });
    this.checkNumberOnly = (ctrl.value);
    if (this.checkNumberOnly != null) {
      let numeric = (ctrl.value).toString();
      if (this.langChange == 'pl' || this.langChange == 'ro' || this.langChange == 'gr') {
        if (numeric.includes(',')) {
          let checkNumeric = numeric.split(',');
          if (checkNumeric.length > 2) {
            ctrl.setValue(checkNumeric[0].substr(0, 8) + ',' + checkNumeric[1].substr(0, 2));
            return false;
          }
          this.checkString = checkNumeric[1].split('');
          if (this.checkString.length <= 2) {
            ctrl.setValue(checkNumeric[0].substr(0, 8) + ',' + checkNumeric[1].substr(0, 2));
            // this.toastrService.warning("Invalid value", "Warning");
            // return false;
          } else {
            let afterDot = checkNumeric[1].substr(0, 2);
            ctrl.setValue(checkNumeric[0].substr(0, 8) + ',' + afterDot);
            // return true;
          }
        } else {
          ctrl.setValue(numeric.substr(0, 8));
        }
      } else {
        if (numeric.includes('.')) {
          let checkNumeric = numeric.split('.');
          if (checkNumeric.length > 2) {
            ctrl.setValue(checkNumeric[0].substr(0, 8) + '.' + checkNumeric[1].substr(0, 2));
            return false;
          }
          this.checkString = checkNumeric[1].split('');
          if (this.checkString.length <= 2) {
            ctrl.setValue(checkNumeric[0].substr(0, 8) + '.' + checkNumeric[1].substr(0, 2));
            // this.toastrService.warning("Invalid value", "Warning");
            // return false;
          } else {
            let afterDot = checkNumeric[1].substr(0, 2);
            ctrl.setValue(checkNumeric[0].substr(0, 8) + '.' + afterDot);
            //return true;
          }
        } else {
          ctrl.setValue(numeric.substr(0, 8));
        }
      }
      let reg1Str;
      let temp = ctrl.value;//obj.value;
      let decimalValue;
      if (this.langChange == 'en') {
        decimalValue = '.';
      }
      else {
        decimalValue = ',';
      }

      let decimalPlaces = 2;
      let reg0Str = '[0-9]*';
      if (decimalPlaces > 0) {
        if (this.langChange == 'en') {
          reg0Str += '\\.?[0-9]{0.' + decimalPlaces + '}';
        }
        else {
          reg0Str += '\\,?[0-9]{0,' + decimalPlaces + '}';
        }
      } else if (decimalPlaces < 0) {
        if (this.langChange == 'en') {
          reg0Str += '\\.?[0-9]*';
        }
        else {
          reg0Str += '\\,?[0-9]*';
        }
      }
      if (decimalPlaces != 0) {
        let reg3;
        if (this.langChange == 'en') {
          reg3 = /\./g;
        }
        else {
          reg3 = /\,/g;
        }
        let reg3Array = reg3.exec(temp);
        if (reg3Array != null) {
          // keep only first occurrence of .
          //  and the number of places specified by decimalPlaces or the entire string if 

          decimalPlaces < 0
          let reg3Right = temp.substring(reg3Array.index + reg3Array[0].length);
          reg3Right = reg3Right.replace(reg3, '');
          reg3Right = decimalPlaces > 0 ? reg3Right.substring(0, decimalPlaces) : reg3Right;
          temp = temp.substring(0, reg3Array.index) + decimalValue + reg3Right;
        }
      }

      // obj.value = temp;
      ctrl.setValue(temp);
      return true;
    }
    //ctrl.setValue(ctrl.value.substr(0, 8));
  }

  validateSourceInput(evt, row) {
    // console.log(evt);
    if (this.selectAdditionalAmountForm.dirty && (row.get('newAllocationAmt').value != "0") &&
      (row.get('newAllocationAmt').value != "00") && (row.get('newAllocationAmt').value != "000")) {
      this.arrayNotUpadted = false;
      this.fundListArray.controls.forEach(row => {
        row.get('fundEmptyErr').setValue(false);
        this.shareLeftReset = false;
        // row.fundEmptyErr = true;
        this.flagValueChange.emit(row);
      });
      if (row.get('newAllocationAmt').value != "" && row.get('newAllocationAmt').value != null) {
        row.get('sourceFundEmptyErr').setValue(false);
        if ((parseFloat(row.get('newAllocationAmt').value) > parseFloat("100"))) {
          row.get('fundEmptyErr').setValue(true);
          this.shareLeftReset = true;
          this.flagValueChange.emit(row);
        } else {
          if (this.totalTemp > 100) {
            let findCurrentRowValue = parseFloat(this.totalTemp) - parseFloat(row.get('newAllocationAmt').value);
            if (findCurrentRowValue != 0 && this.totalTemp > 100) {
              row.get('fundEmptyErr').setValue(true);
              this.shareLeftReset = true;
              this.flagValueChange.emit(row);
            } else {
              row.get('fundEmptyErr').setValue(false);
              this.flagValueChange.emit(row);
              this.validateOtherRows();
              if (parseFloat(row.get('newAllocationAmt').value) != 0) {
                if ((row.get('newAllocationAmt').value) < (row.get('minimumAllocationPerFund').value)) {
                  row.get('minFundErr').setValue(true);
                  this.shareLeftReset = true;
                  this.flagValueChange.emit(row);
                } else {
                  row.get('minFundErr').setValue(false);
                  this.shareLeftReset = false;
                  this.flagValueChange.emit(row);
                  this.validateOtherRows();
                }
              } else {
                row.get('minFundErr').setValue(false);
                row.get('fundEmptyErr').setValue(false);
                this.shareLeftReset = false;
                this.flagValueChange.emit(row);
                this.validateOtherRows();
              }
            }
          } else {
            row.get('fundEmptyErr').setValue(false);
            this.flagValueChange.emit(row);
            this.validateOtherRows();
            if ((row.get('newAllocationAmt').value != "0") && (row.get('newAllocationAmt').value != "00") && (row.get('newAllocationAmt').value != "000")) {
              if ((row.get('newAllocationAmt').value) < (row.get('minimumAllocationPerFund').value)) {
                row.get('minFundErr').setValue(true);
                this.shareLeftReset = true;
                this.flagValueChange.emit(row);
              } else {
                row.get('minFundErr').setValue(false);
                this.shareLeftReset = false;
                this.flagValueChange.emit(row);
                this.validateOtherRows();
              }
            } else {
              row.get('minFundErr').setValue(false);
              row.get('fundEmptyErr').setValue(false);
              this.shareLeftReset = false;
              this.flagValueChange.emit(row);
              this.validateOtherRows();
            }
          }
        }
      } else {
        row.get('minFundErr').setValue(false);
        row.get('sourceFundEmptyErr').setValue(false);
        row.get('fundEmptyErr').setValue(false);
        this.shareLeftReset = false;
        this.flagValueChange.emit(row);
        this.validateOtherRows();
      }
    } else {
      row.get('minFundErr').setValue(false);
      row.get('sourceFundEmptyErr').setValue(false);
      row.get('fundEmptyErr').setValue(false);
      this.shareLeftReset = false;
      this.flagValueChange.emit(row);
      this.validateOtherRows();
    }
  }

  validateOtherRows() {
    this.selectAdditionalAmountForm['controls'].fundListArray['controls'].forEach(row => {
      if (this.selectAdditionalAmountForm.dirty && (row.get('newAllocationAmt').value != "0") &&
        (row.get('newAllocationAmt').value != "00") && (row.get('newAllocationAmt').value != "000")) {
        this.arrayNotUpadted = false;
        this.fundListArray.controls.forEach(row => {
          row.get('fundEmptyErr').setValue(false);
          this.shareLeftReset = false;
          // row.fundEmptyErr = true;
          this.flagValueChange.emit(row);
        });
        if (row.get('newAllocationAmt').value != "" && row.get('newAllocationAmt').value != null) {
          row.get('sourceFundEmptyErr').setValue(false);
          if ((parseFloat(row.get('newAllocationAmt').value) > parseFloat("100"))) {
            row.get('fundEmptyErr').setValue(true);
            this.shareLeftReset = true;
            this.flagValueChange.emit(row);
          } else {
            if (this.totalTemp > 100) {
              let findCurrentRowValue = parseFloat(this.totalTemp) - parseFloat(row.get('newAllocationAmt').value);
              if (findCurrentRowValue != 0 && this.totalTemp > 100) {
                row.get('fundEmptyErr').setValue(true);
                this.shareLeftReset = true;
                this.flagValueChange.emit(row);
              } else {
                row.get('fundEmptyErr').setValue(false);
                this.flagValueChange.emit(row);
                if (parseFloat(row.get('newAllocationAmt').value) != 0) {
                  if ((row.get('newAllocationAmt').value) < (row.get('minimumAllocationPerFund').value)) {
                    row.get('minFundErr').setValue(true);
                    this.shareLeftReset = true;
                    this.flagValueChange.emit(row);
                  } else {
                    row.get('minFundErr').setValue(false);
                    this.shareLeftReset = false;
                    this.flagValueChange.emit(row);
                  }
                } else {
                  row.get('minFundErr').setValue(false);
                  row.get('fundEmptyErr').setValue(false);
                  this.shareLeftReset = false;
                  this.flagValueChange.emit(row);
                }
              }
            } else {
              row.get('fundEmptyErr').setValue(false);
              this.flagValueChange.emit(row);
              if ((row.get('newAllocationAmt').value != "0") && (row.get('newAllocationAmt').value != "00") && (row.get('newAllocationAmt').value != "000")) {
                if ((row.get('newAllocationAmt').value) < (row.get('minimumAllocationPerFund').value)) {
                  row.get('minFundErr').setValue(true);
                  this.shareLeftReset = true;
                  this.flagValueChange.emit(row);
                } else {
                  row.get('minFundErr').setValue(false);
                  this.shareLeftReset = false;
                  this.flagValueChange.emit(row);
                }
              } else {
                row.get('minFundErr').setValue(false);
                row.get('fundEmptyErr').setValue(false);
                this.shareLeftReset = false;
                this.flagValueChange.emit(row);
              }
            }
          }
        } else {
          row.get('minFundErr').setValue(false);
          row.get('sourceFundEmptyErr').setValue(false);
          row.get('fundEmptyErr').setValue(false);
          this.shareLeftReset = false;
          this.flagValueChange.emit(row);
        }
      } else {
        row.get('minFundErr').setValue(false);
        row.get('sourceFundEmptyErr').setValue(false);
        row.get('fundEmptyErr').setValue(false);
        this.shareLeftReset = false;
        this.flagValueChange.emit(row);
      }
    });
  }

  downloadPdf(documentId) {
    let url = this.baseUrl.ecustomer.downloadOffersPdf + documentId;
    this.httpService.downloadPDF(url).subscribe(data => {
      this.downloadFile(data);
    });
  }

  downloadFile(data) {
    let blob = new Blob([data], { type: "application/pdf" });
    if (window.navigator.msSaveOrOpenBlob) {
      //IE11 & Edge
      window.navigator.msSaveOrOpenBlob(blob);
    } else {
      let url = window.URL.createObjectURL(blob);
      window.open(url);
    }
  }

}

