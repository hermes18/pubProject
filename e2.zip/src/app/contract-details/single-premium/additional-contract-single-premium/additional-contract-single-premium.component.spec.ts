import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { AllocationChangeSharedService } from '../../allocation-change/allocation-change-service';
import { ContractDetailsModule } from '../../contract-details.module';

import { AdditionalContractSinglePremiumComponent } from './additional-contract-single-premium.component';

describe('AdditionalContractSinglePremiumComponent', () => {
  let component: AdditionalContractSinglePremiumComponent;
  let fixture: ComponentFixture<AdditionalContractSinglePremiumComponent>;
  const userDetails = { "userName": "JDaniel_PL", "firstName": "Prabhu", "lastName": "Jaison", "email": "qatestingsample15@gmail.com", "preferredLanguage": "en", "creationDate": "Wed Feb 10 16:50:24 CET 2021", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 30 17:07:29 CET 2020", "employeeNumber": "", "pwdExpirationDate": "Fri Apr 23 16:50:24 CEST 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3032", "name": "rStandardUser", "description": "RStandardUser" }, { "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], "clientId": "", "requesterId": "-1", "requesterRole": "3032", "userDn": "ou=People,o=affiliates,c=Poland,o=metlife,dc=metlife,dc=com", "pwdExpirationDelay": "30", "userCheck": true, "tokenParam": null }
  const contractDetails = {
    "benefitType": "SuperKapitał - współubezpieczony 1",
    "businessRoleList": ["owner"],
    "contractDetailsDTO": {
      contractNumber: "21281000", insurer: "INSURER_21281000", insured: "INSURED_21281000", status: 21, paymentMode: "15",
    },
    "contractNumber": "21281000",
    "contractNumberList": null,
    "effectiveDate": "18.11.2009",
    "indexedPremiumAmount": null,
    "insuredName": "INSURED_21281000",
    "premiumAmount": "",
    "premiumAmt": null,
    "premiumAmtType": null,
    "premiumDueDate": null,
    "premiumPaymentMode": "15",
    "premiumType": "15",
    "processingSystem": "OLAS",
    "status": 21
  };
  let data = {
    //'fromPage': 'contractDetails',
    "toPage": 'orderInvest'
  };
  let submenuList = {
    renderContractDetails: true,
    renderContractValue: true,
    renderGeneralData: true,
    renderHistortyOfContractOrders: true,
    renderIndexationBenefits: true,
    renderOrders: true
  };
  const menuItemList = {
    "activeContractDetails": null,
    "billingRecipent": null,
    "callRetrievePolicies": false,
    "callRetriveClientData": false,
    "callRetriveClientOffers": false,
    "ccDBAddressDTO": { ccdbFullAddress: "https://10.112.202.48/ccdb-web/" },
    "claimList": null,
    "clientAdministration": true,
    "clientId": "",
    "clientIdList": [],
    "clientIdbillControlList": [],
    "clientLoginId": null,
    "clientRoleIds": "3032|3033|3034",
    "clientRoleNames": "rStandardUser|rSuperUser|rAdministrator",
    "contractList": [{
      "benefitType": "SuperKapitał",
      "businessRoleList": ["insured", "owner"],
      "contractDetailsDTO": { contractNumber: null, insurer: "INSURER_21223250", insured: "INSURED_21223250", status: 22 },
      "contractNumber": "21223250",
      "contractNumberList": null,
      "effectiveDate": "28.11.2007",
      "indexedPremiumAmount": null,
      "insuredName": "INSURED_21223250",
      "premiumAmount": null,
      "premiumAmt": null,
      "premiumAmtType": "17",
      "premiumDueDate": null,
      "premiumPaymentMode": null,
      "premiumType": "17",
      "processingSystem": "OLAS",
      "status": 22
    }],
    "personalInformationDTO": {
      "dateOfBirth": null,
      "emailBasic": "cosmin.misici@gmail.com",
      "emailSecondary": null,
      "firstName": "COSMIN ADRIAN",
      "flagOfCapabilityOfChangeData": "true",
      "gender": null,
      "identifier": null,
      "identifierType": null,
      "lastName": "MISICI",
      "marketingConsentList": [{ status: null, type: null, recievedOn: null }],
      "mobile": null,
      "mobilePhone": "0723347690",
      "officeFax": null,
      "policyNumber": null,
      "postalCode": null,
      "residenceFax": null,
      "residenceTelephone": "",
      "safePhone": null,
      "updatedEmailBasic": null,
      "updatedEmailSecondary": null,
      "updatedMobile": null,
      "updatedResidenceTelephone": null,
      "updatedSafePhone": null,
      "updatedmarketingConsentList": null,
      "versionMarker": "2020-12-22T12:13:17.867"
    },
    "documentsList": null,
    "eClaimsURL": "https://qa.eclaim.metropolitanlife.ro?countryCode=ro&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460723ab632cc8c50d34fae046b1bcf48ffa890f1f92293e6961ccd91c419c3efe9fe87449c19b1237b",
    "fundPriceDetails": null,
    "menuItems": [{ menuId: "startBuyDTO", accessSpec: "$4", menuName: "$3", parentMenu: "$2" }],
    "offerResponse": null,
    "orderHistory": null,
    "renderClaims": false,
    "renderDocuments": false,
    "renderFundPriceMonitoring": false,
    "renderMyCompany": false,
    "renderMyContract": false,
    "renderMyData": false,
    "renderOffers": false,
    "renderOrderReview": false,
    "renderUserAcctAdministration": true,
    "route": "DisplayClientSearch",
    "searchFlag": false,
    "wardenRoleCheck": false
  }
  const userToken = {
    "token" : "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJPc2FtYUFkbWluIiwidXNlciI6eyJ1c2VyTmFtZSI6Ik9zYW1hQWRtaW4iLCJmaXJzdE5hbWUiOiJPc2FtYSIsImxhc3ROYW1lIjoiTW8iLCJlbWFpbCI6Im9zYW1hLmtoYWxpZEBtZXRsaWZlLmNvbSIsInByZWZlcnJlZExhbmd1YWdlIjoiZW4iLCJjcmVhdGlvbkRhdGUiOiJUaHUgQXByIDA4IDA5OjExOjA3IENFU1QgMjAyMSIsInBhc3N3b3JkVHlwZSI6IlNUQU5EQVJEIiwiY3VzdG9tZXJQYXNzd29yZEV4cHJhdGlvbkNvZGUiOiIxIiwicGFzc3dvcmRTdGF0dXNDb2RlIjoiQUNUSVZFIiwic2VjdXJpdHlQb2xpY3lJZCI6IjEyMzQ1IiwidG9rZW5FeHBpcmF0aW9uRGF0ZSI6IkZyaSBTZXAgMTggMTc6MDM6NTAgQ0VTVCAyMDIwIiwiZW1wbG95ZWVOdW1iZXIiOm51bGwsInB3ZEV4cGlyYXRpb25EYXRlIjoiV2VkIEp1bCAwNyAwOToxMTowNyBDRVNUIDIwMjEiLCJmYWlsZWRMb2dpbkNvdW50cyI6IjAiLCJhdXRob3JpemVkQXBwbGljYXRpb25Db2RlIjoiZUN1c3RvbWVyIiwidGVtcG9yYXJ5TG9ja0RhdGUiOm51bGwsInJvdXRlIjpudWxsLCJwd2RFeHBpcmVkIjpudWxsLCJkYXlzU2luY2VQd2ROb3RDaGFuZ2VkIjpudWxsLCJwd2RDaGFuZ2VEYXRlIjpudWxsLCJyb2xlSW5mbyI6W3sicm9sZUlkIjoiMzAzMyIsIm5hbWUiOiJyU3VwZXJVc2VyIiwiZGVzY3JpcHRpb24iOiJSU3VwZXJVc2VyIn0seyJyb2xlSWQiOiIzMDM0IiwibmFtZSI6InJBZG1pbmlzdHJhdG9yIiwiZGVzY3JpcHRpb24iOiJTeXN0ZW1BZG1pbmlzdHJhdG9yIn1dLCJjbGllbnRJZCI6IiIsInJlcXVlc3RlcklkIjpudWxsLCJyZXF1ZXN0ZXJSb2xlIjpudWxsLCJ1c2VyRG4iOiJvdT1QZW9wbGUsbz1hZmZpbGlhdGVzLGM9UG9sYW5kLG89bWV0bGlmZSxkYz1tZXRsaWZlLGRjPWNvbSIsInB3ZEV4cGlyYXRpb25EZWxheSI6IjMwIiwidXNlckNoZWNrIjp0cnVlLCJ0b2tlblBhcmFtIjoiNDdiMDRiY2NkMzlmYmIyOTAzMDgyNjU3NjI2OTU1YmQifSwiaWF0IjoxNjE5NDQzODExLCJleHAiOjE2MTk0NDU2MTF9.r1X4Cy72GHWqTBNcZBNwHScyUsGb4BLIbIDBkFNWI2U",
    "userName":"OsamaAdmin"
  };
  let response = {
    "selectedInvestmentStrategy": "Deposit As New Invest Account",
    "investAccNumber": "21295126", "clientId": "101583", "generalConditions": "100100", "investmentData": { "effectiveDate": 1276639200000, "policyNumber": "21295126", "investAccType": 1, "investAccNumber": "21295126", "status": 23, "investValue": 5620.17, "productPlan": "UB2B000K3", "valuationDt": 1380664800000 }, "totalNewlyAllocatedPercentage": 0, "totalRemaininigPercentage": 100, "sourceAllocationPercentageDisable": false, "renderSingleFundMsg": false, "fundsList": [{ "sort": "32", "orderType": null, "processingSystem": null, "requestingSystem": null, "fundCode": "OLAS|001", "fundType": "OBLIGACYJNY ", "policyNumber": null, "premiumAmount": null, "addAmtTopUpUnits": null, "totalAmtCurrent": null, "addCoverageAmt": null, "serviceReqNumber": null, "serviceReqType": null, "serviceReqTypeDisplay": null, "minimumDepositAmount": null, "maximumDepositAmount": null, "statementCheck": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "bankAccountNumber": null, "cutOffTime": null, "renderUnauthorizedErr": false, "renderCutOffMsg": false, "productPlan": null, "investAcctNumber": null, "investAcctNumberTip": null, "investAccTipDisplay": null, "transerTitle": null, "certificatedProductPlan": null, "fundLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS001", "errorContentStyle": null, "allocationPercentage": "0", "minimumAmountPerFund": null, "minimumAllocationPerFund": null, "submittedBy": null, "orderSubmissionDate": null, "orderRealizationDate": null, "subject": null, "renderContractNumber": false, "renderSubject": false, "renderRealizationDate": false, "renderStatementBtn": false, "addTopUpLumpSum": null, "displayText": null, "displayLink": null, "addCoverageAmtDisplay": null, "newAllocationAmt": 0, "addTopUpLumpSumDisplay": null, "renderAllowedDepositMsg": false, "renderDepositBtwnMsg": false, "renderMinDepositMsg": false, "orderPaymenstDate": null }, { "sort": "33", "orderType": null, "processingSystem": null, "requestingSystem": null, "fundCode": "OLAS|002", "fundType": "FUNDUSZ ZRÓWNOWAŻONEGO WZROSTU ", "policyNumber": null, "premiumAmount": null, "addAmtTopUpUnits": null, "totalAmtCurrent": null, "addCoverageAmt": null, "serviceReqNumber": null, "serviceReqType": null, "serviceReqTypeDisplay": null, "minimumDepositAmount": null, "maximumDepositAmount": null, "statementCheck": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "bankAccountNumber": null, "cutOffTime": null, "renderUnauthorizedErr": false, "renderCutOffMsg": false, "productPlan": null, "investAcctNumber": null, "investAcctNumberTip": null, "investAccTipDisplay": null, "transerTitle": null, "certificatedProductPlan": null, "fundLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS002", "errorContentStyle": null, "allocationPercentage": "0", "minimumAmountPerFund": null, "minimumAllocationPerFund": null, "submittedBy": null, "orderSubmissionDate": null, "orderRealizationDate": null, "subject": null, "renderContractNumber": false, "renderSubject": false, "renderRealizationDate": false, "renderStatementBtn": false, "addTopUpLumpSum": null, "displayText": null, "displayLink": null, "addCoverageAmtDisplay": null, "newAllocationAmt": 0, "addTopUpLumpSumDisplay": null, "renderAllowedDepositMsg": false, "renderDepositBtwnMsg": false, "renderMinDepositMsg": false, "orderPaymenstDate": null }, { "sort": "34", "orderType": null, "processingSystem": null, "requestingSystem": null, "fundCode": "OLAS|003", "fundType": "DYNAMICZNY ", "policyNumber": null, "premiumAmount": null, "addAmtTopUpUnits": null, "totalAmtCurrent": null, "addCoverageAmt": null, "serviceReqNumber": null, "serviceReqType": null, "serviceReqTypeDisplay": null, "minimumDepositAmount": null, "maximumDepositAmount": null, "statementCheck": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "bankAccountNumber": null, "cutOffTime": null, "renderUnauthorizedErr": false, "renderCutOffMsg": false, "productPlan": null, "investAcctNumber": null, "investAcctNumberTip": null, "investAccTipDisplay": null, "transerTitle": null, "certificatedProductPlan": null, "fundLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS003", "errorContentStyle": null, "allocationPercentage": "0", "minimumAmountPerFund": null, "minimumAllocationPerFund": null, "submittedBy": null, "orderSubmissionDate": null, "orderRealizationDate": null, "subject": null, "renderContractNumber": false, "renderSubject": false, "renderRealizationDate": false, "renderStatementBtn": false, "addTopUpLumpSum": null, "displayText": null, "displayLink": null, "addCoverageAmtDisplay": null, "newAllocationAmt": 0, "addTopUpLumpSumDisplay": null, "renderAllowedDepositMsg": false, "renderDepositBtwnMsg": false, "renderMinDepositMsg": false, "orderPaymenstDate": null }, { "sort": "63", "orderType": null, "processingSystem": null, "requestingSystem": null, "fundCode": "OLAS|037", "fundType": "AFK AKCJI Typ jednostki B", "policyNumber": null, "premiumAmount": null, "addAmtTopUpUnits": null, "totalAmtCurrent": null, "addCoverageAmt": null, "serviceReqNumber": null, "serviceReqType": null, "serviceReqTypeDisplay": null, "minimumDepositAmount": null, "maximumDepositAmount": null, "statementCheck": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "bankAccountNumber": null, "cutOffTime": null, "renderUnauthorizedErr": false, "renderCutOffMsg": false, "productPlan": null, "investAcctNumber": null, "investAcctNumberTip": null, "investAccTipDisplay": null, "transerTitle": null, "certificatedProductPlan": null, "fundLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS029", "errorContentStyle": null, "allocationPercentage": "0", "minimumAmountPerFund": null, "minimumAllocationPerFund": null, "submittedBy": null, "orderSubmissionDate": null, "orderRealizationDate": null, "subject": null, "renderContractNumber": false, "renderSubject": false, "renderRealizationDate": false, "renderStatementBtn": false, "addTopUpLumpSum": null, "displayText": null, "displayLink": null, "addCoverageAmtDisplay": null, "newAllocationAmt": 0, "addTopUpLumpSumDisplay": null, "renderAllowedDepositMsg": false, "renderDepositBtwnMsg": false, "renderMinDepositMsg": false, "orderPaymenstDate": null }, { "sort": "64", "orderType": null, "processingSystem": null, "requestingSystem": null, "fundCode": "OLAS|038", "fundType": "AFK ZRÓWNOWAŻONY NOWA EUROPA Typ jednostki B", "policyNumber": null, "premiumAmount": null, "addAmtTopUpUnits": null, "totalAmtCurrent": null, "addCoverageAmt": null, "serviceReqNumber": null, "serviceReqType": null, "serviceReqTypeDisplay": null, "minimumDepositAmount": null, "maximumDepositAmount": null, "statementCheck": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "bankAccountNumber": null, "cutOffTime": null, "renderUnauthorizedErr": false, "renderCutOffMsg": false, "productPlan": null, "investAcctNumber": null, "investAcctNumberTip": null, "investAccTipDisplay": null, "transerTitle": null, "certificatedProductPlan": null, "fundLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS030", "errorContentStyle": null, "allocationPercentage": "0", "minimumAmountPerFund": null, "minimumAllocationPerFund": null, "submittedBy": null, "orderSubmissionDate": null, "orderRealizationDate": null, "subject": null, "renderContractNumber": false, "renderSubject": false, "renderRealizationDate": false, "renderStatementBtn": false, "addTopUpLumpSum": null, "displayText": null, "displayLink": null, "addCoverageAmtDisplay": null, "newAllocationAmt": 0, "addTopUpLumpSumDisplay": null, "renderAllowedDepositMsg": false, "renderDepositBtwnMsg": false, "renderMinDepositMsg": false, "orderPaymenstDate": null }, { "sort": "65", "orderType": null, "processingSystem": null, "requestingSystem": null, "fundCode": "OLAS|039", "fundType": "METLIFE PIENIĘŻNY Typ jednostki B", "policyNumber": null, "premiumAmount": null, "addAmtTopUpUnits": null, "totalAmtCurrent": null, "addCoverageAmt": null, "serviceReqNumber": null, "serviceReqType": null, "serviceReqTypeDisplay": null, "minimumDepositAmount": null, "maximumDepositAmount": null, "statementCheck": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "bankAccountNumber": null, "cutOffTime": null, "renderUnauthorizedErr": false, "renderCutOffMsg": false, "productPlan": null, "investAcctNumber": null, "investAcctNumberTip": null, "investAccTipDisplay": null, "transerTitle": null, "certificatedProductPlan": null, "fundLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS031", "errorContentStyle": null, "allocationPercentage": "0", "minimumAmountPerFund": null, "minimumAllocationPerFund": null, "submittedBy": null, "orderSubmissionDate": null, "orderRealizationDate": null, "subject": null, "renderContractNumber": false, "renderSubject": false, "renderRealizationDate": false, "renderStatementBtn": false, "addTopUpLumpSum": null, "displayText": null, "displayLink": null, "addCoverageAmtDisplay": null, "newAllocationAmt": 0, "addTopUpLumpSumDisplay": null, "renderAllowedDepositMsg": false, "renderDepositBtwnMsg": false, "renderMinDepositMsg": false, "orderPaymenstDate": null }, {
      "sort": "66", "orderType": null, "processingSystem": null, "requestingSystem": null, "fundCode": "OLAS|040", "fundType": "AFK OBLIGACJI ŚWIATOWYCH Typ jednostki B", "policyNumber": null, "premiumAmount": null, "addAmtTopUpUnits": null, "totalAmtCurrent": null, "addCoverageAmt": null, "serviceReqNumber": null, "serviceReqType": null, "serviceReqTypeDisplay": null, "minimumDepositAmount": null, "maximumDepositAmount": null, "statementCheck": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "bankAccountNumber": null, "cutOffTime": null, "renderUnauthorizedErr": false, "renderCutOffMsg": false, "productPlan": null, "investAcctNumber": null, "investAcctNumberTip": null, "investAccTipDisplay": null, "transerTitle": null, "certificatedProductPlan": null, "fundLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS032", "errorContentStyle": null, "allocationPercentage": "0", "minimumAmountPerFund": null, "minimumAllocationPerFund": null,
      "submittedBy": null, "orderSubmissionDate": null, "orderRealizationDate": null, "subject": null, "renderContractNumber": false, "renderSubject": false, "renderRealizationDate": false, "renderStatementBtn": false, "addTopUpLumpSum": null, "displayText": null, "displayLink": null, "addCoverageAmtDisplay": null, "newAllocationAmt": 0, "addTopUpLumpSumDisplay": null, "renderAllowedDepositMsg": false, "renderDepositBtwnMsg": false, "renderMinDepositMsg": false, "orderPaymenstDate": null
    }, { "sort": "69", "orderType": null, "processingSystem": null, "requestingSystem": null, "fundCode": "OLAS|043", "fundType": "AFK AKCJI CHIŃSKICH I AZJAT. Typ jednostki B", "policyNumber": null, "premiumAmount": null, "addAmtTopUpUnits": null, "totalAmtCurrent": null, "addCoverageAmt": null, "serviceReqNumber": null, "serviceReqType": null, "serviceReqTypeDisplay": null, "minimumDepositAmount": null, "maximumDepositAmount": null, "statementCheck": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "bankAccountNumber": null, "cutOffTime": null, "renderUnauthorizedErr": false, "renderCutOffMsg": false, "productPlan": null, "investAcctNumber": null, "investAcctNumberTip": null, "investAccTipDisplay": null, "transerTitle": null, "certificatedProductPlan": null, "fundLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS035", "errorContentStyle": null, "allocationPercentage": "0", "minimumAmountPerFund": null, "minimumAllocationPerFund": null, "submittedBy": null, "orderSubmissionDate": null, "orderRealizationDate": null, "subject": null, "renderContractNumber": false, "renderSubject": false, "renderRealizationDate": false, "renderStatementBtn": false, "addTopUpLumpSum": null, "displayText": null, "displayLink": null, "addCoverageAmtDisplay": null, "newAllocationAmt": 0, "addTopUpLumpSumDisplay": null, "renderAllowedDepositMsg": false, "renderDepositBtwnMsg": false, "renderMinDepositMsg": false, "orderPaymenstDate": null }, { "sort": "70", "orderType": null, "processingSystem": null, "requestingSystem": null, "fundCode": "OLAS|044", "fundType": "AFK AKCJI RYNKÓW WSCHODZĄCYCH Typ jednostki B", "policyNumber": null, "premiumAmount": null, "addAmtTopUpUnits": null, "totalAmtCurrent": null, "addCoverageAmt": null, "serviceReqNumber": null, "serviceReqType": null, "serviceReqTypeDisplay": null, "minimumDepositAmount": null, "maximumDepositAmount": null, "statementCheck": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "bankAccountNumber": null, "cutOffTime": null, "renderUnauthorizedErr": false, "renderCutOffMsg": false, "productPlan": null, "investAcctNumber": null, "investAcctNumberTip": null, "investAccTipDisplay": null, "transerTitle": null, "certificatedProductPlan": null, "fundLink": "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS036", "errorContentStyle": null, "allocationPercentage": "0", "minimumAmountPerFund": null, "minimumAllocationPerFund": null, "submittedBy": null, "orderSubmissionDate": null, "orderRealizationDate": null, "subject": null, "renderContractNumber": false, "renderSubject": false, "renderRealizationDate": false, "renderStatementBtn": false, "addTopUpLumpSum": null, "displayText": null, "displayLink": null, "addCoverageAmtDisplay": null, "newAllocationAmt": 0, "addTopUpLumpSumDisplay": null, "renderAllowedDepositMsg": false, "renderDepositBtwnMsg": false, "renderMinDepositMsg": false, "orderPaymenstDate": null }], "processingSystem": "OLAS", "incorrectAllocationErrorRender": false, "renderMissingAddTopUpAmt": false, "renderDepositAmtTooSmall": false, "renderStatementUnchecked": false, "renderDepositAmtTooBig": false, "minimumDepositAmount": 12345.00, "maximumDepositAmount": 12346.00, "statementCheck": false, "sourceMinimumFundValueError": false, "validationSuccess": false, "renderCutOffMsg": false, "minimumAmountPerFund": 1000.00, "minimumAllocationPercentage": 10.00
  }
  let fundListItem = {
    addAmtTopUpUnits: null,
    addCoverageAmt: null,
    addCoverageAmtDisplay: null,
    addTopUpLumpSum: null,
    addTopUpLumpSumDisplay: null,
    allocationPercentage: "0",
    bankAccountNumber: null,
    certificatedProductPlan: null,
    cutOffTime: null,
    displayLink: null,
    displayText: null,
    errorContentStyle: null,
    fundCode: "OLAS|001",
    fundLink: "cee.alico.com/NotowaniaUFK/client/fund.xhtml?FundID=OLAS001",
    fundType: "OBLIGACYJNY ",
    investAccTipDisplay: null,
    investAcctNumber: null,
    investAcctNumberTip: null,
    maximumDepositAmount: null,
    minimumAllocationPerFund: null,
    minimumAmountPerFund: null,
    minimumDepositAmount: null,
    newAllocationAmt: 0,
    orderPaymenstDate: null,
    orderRealizationDate: null,
    orderSubmissionDate: null,
    orderType: null,
    policyNumber: null,
    premiumAmount: null,
    processingSystem: null,
    productPlan: null,
    renderAllowedDepositMsg: false,
    renderContractNumber: false,
    renderCutOffMsg: false,
    renderDepositAmtTooBig: false,
    renderDepositAmtTooSmall: false,
    renderDepositBtwnMsg: false,
    renderMinDepositMsg: false,
    renderMissingAddTopUpAmt: false,
    renderRealizationDate: false,
    renderStatementBtn: false,
    renderStatementUnchecked: false,
    renderSubject: false,
    renderUnauthorizedErr: false,
    requestingSystem: null,
    serviceReqNumber: null,
    serviceReqType: null,
    serviceReqTypeDisplay: null,
    sort: "32",
    statementCheck: false,
    subject: null,
    submittedBy: null,
    totalAmtCurrent: null,
    transerTitle: null
  }
  const accountDetails = {"contractNumber":"21295126","clientId":"101583","selectedInvestmentStrategy":"Deposit As New Invest Account"}
  //beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
  //     providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
  //     declarations: []
  //   })
  //     .compileComponents();
  // }));

  let newPremiumService: AllocationChangeSharedService = new AllocationChangeSharedService();
  beforeEach(() => {
    sessionStorage.setItem('contractDetails', JSON.stringify(contractDetails));
    sessionStorage.setItem('contratSubMenuList', JSON.stringify(submenuList));
    sessionStorage.setItem('menuItemList', JSON.stringify(menuItemList));
    window.sessionStorage.setItem('userToken', JSON.stringify(userToken));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(AdditionalContractSinglePremiumComponent);
    newPremiumService.setaccountData(accountDetails);
    newPremiumService.setSingleFundListResponse(response);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create form', () => {
    spyOn(component, 'createForm').and.callThrough();
    component.createForm();
    expect(component.createForm).toHaveBeenCalled();
  });

  it('call add method', () => {
    // spyOn(component, 'add').and.callThrough();
    // component.add(fundListItem);
    // expect(component.add).toHaveBeenCalled();
  });

  it('call new form group creation method', () => {
    // spyOn(component, 'new').and.callThrough();
    // component.new(fundListItem);
    // expect(component.new).toHaveBeenCalled();
  });

  it('call form submit method', () => {
    spyOn(component, 'formSubmit').and.callThrough();
    component.formSubmit();
    expect(component.formSubmit).toHaveBeenCalled();
  });

  it('call submit method', () => {
    spyOn(component, 'submitSelectedAccount').and.callThrough();
    component.submitSelectedAccount();
    expect(component.submitSelectedAccount).toHaveBeenCalled();
  });

  it('call reset form array values method', () => {
    component.responseAdditionalPremium = response;
    component.responseAdditionalPremium.totalNewlyAllocatedPercentage = 0;
    spyOn(component, 'resetFormArrayValues').and.callThrough();
    component.resetFormArrayValues();
    expect(component.resetFormArrayValues).toHaveBeenCalled();
  });

  it('call validate other rows method', () => {
    //spyOn(component, 'validateOtherRows').and.callThrough();
    component.validateOtherRows();
    //expect(component.validateOtherRows).toHaveBeenCalled();
  });

  it('call validate other rows method', () => {
    spyOn(component, 'downloadPdf').and.callThrough();
    component.downloadPdf('100100');
    expect(component.downloadPdf).toHaveBeenCalled();
  });
});
