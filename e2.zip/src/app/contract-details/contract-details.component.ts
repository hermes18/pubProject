import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedServiceService } from '../shared-service/shared-service.service';
import * as utils from 'lodash';
import { HttpCommonService } from '../shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import { NavigationEnd, Router, RouterEvent, ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { ChangePremiumSplitComponent } from '../change-premium-split/change-premium-split.component';
import { OrdersInvestComponent } from './orders-invest/orders-invest.component'
import { Subject } from 'rxjs';
import { MatTabGroup } from '@angular/material';

@Component({
  selector: 'contract-details',
  templateUrl: './contract-details.component.html',
  styleUrls: ['./contract-details.component.scss']
})
export class ContractDetailsComponent implements OnInit {
  matSelectedTabIndex: any = 0;
  settingParamValue = {
    'generalData': false,
    'mycontracts': false,
    'contractValue': true,
    'fund': false
    // 'contractDetails': false,
    // 'contarctValue': false,
    // 'orders': false,
    // 'historyOfContractOrders':false,

  };
  isHistoryContract;
  settingTabIndex;
  settingTabList = {
    'generalData': false,
    'contractDetails': true,
    'contractvalue': false,
    'fund': false,
    'orders': true,
    'historyofOrders': false
  };
  loadPage: any;
  constructor(public sharedService: SharedServiceService, public router: Router, private cService: HttpCommonService,
    private menuItemService: MenuItemsService, public route: ActivatedRoute) { }
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  contractListData;
  flagtest = "assets/mocks/contractList.json";
  contractSubMenuList: any;
  contractDetails: any;
  @ViewChild(OrdersInvestComponent, { static: false }) orderInvestRef: OrdersInvestComponent;

  @ViewChild("contractDetailsTabRef", { static: false }) contractDetailsTabRef: MatTabGroup;
  @ViewChild("orderInvestLabel", { static: false }) orderInvestLabel;


  ngOnInit() {
    this.sharedService.getDetail('submenuSelectedIndex').subscribe((data) => {
      this.matSelectedTabIndex = data;
    });
    //this.route.snapshot.paramMap.get('id');

    this.router.events.pipe(filter((event: RouterEvent) => event instanceof NavigationEnd)
    ).subscribe(() => {
      let routeId = this.route.snapshot.paramMap.get('id');
      //("test events", event, routeId);
      /*   if(routeId ==  'transferFund'){
           this.matSelectedTabIndex = 3;
           this.isOrderInvestTabClicked.next(routeId);
         }*/
      const backFromContractSecreen = JSON.parse(sessionStorage.getItem('actveTabContractValueSection'));
      // to make the user seach component display when navigate form other route
      if (backFromContractSecreen) {
        this.settingParamValue.contractValue = backFromContractSecreen.contractValue;
        //sthis.settingParamValue.userDetails = backFromSearchScreen.userDetails;
      }
      // //(JSON.parse(sessionStorage.getItem('activeTabInAdminBackButton')));
      // const backFromSearchScreen = JSON.parse(sessionStorage.getItem('activeTabInAdminBackButton'))
      // this.settingParamValue.userSearch = backFromSearchScreen.userSearch;
      // this.settingParamValue.userDetails = backFromSearchScreen.userDetails;

    });
    // this.sharedService.getDetail('menuItemList').subscribe((data) => {
    //   //(data);
    //   const menuListInAdminn = utils.filter(data.menuItems, obj => {
    //     if (obj.parentMenu && obj.parentMenu == "My Contract") return obj;
    //   });
    //   menuListInAdminn.forEach(menu => {
    //     if (menu.menuName === "Agent Details") {
    //       this.settingTabList.generalData = true;
    //     }
    //     if (menu.menuName === 'Individual Contract Details')
    //       this.settingTabList.contractDetails = true;
    //     if (menu.menuName === 'Individual Contract Benefits')
    //       this.settingTabList.contractvalue = true;
    //     if (menu.menuName === 'Review Of Orders')
    //       this.settingTabList.orders = true;
    //     if (menu.menuName === 'Order History Review')
    //       this.settingTabList.historyofOrders = true;
    //   });
    // });

    // this.settingTabList.generalData = true;
    // this.settingTabList.contractDetails = true;
    // this.settingTabList.contractvalue = true;
    // this.settingTabList.orders = true;
    // this.settingTabList.historyofOrders = true;
    // this.settingParamValue.mycontracts = true;
    this.contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));
    this.isHistoryContract = {
      displayField: true,
      contractNumber: this.contractDetails ? this.contractDetails.contractNumber : null
    }

    const subMenuList = JSON.parse(sessionStorage.getItem('contratSubMenuList'));
    if (subMenuList) {
      this.contractSubMenuList = subMenuList;
    }
    const mobileContractView = {
      'contractDetails': this.contractDetails,
      'showSubMenu': true
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    this.sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    this.sharedService.getPageContent().subscribe((val) => {
      this.loadPage = val;
    })
  }

  displayArray(theArray) {
    this.settingParamValue.generalData = theArray.generalData;
    this.settingParamValue.mycontracts = theArray.userSearch;
    this.settingParamValue.contractValue = theArray.contractValue;
    this.settingParamValue.fund = theArray.fund;
    // this.settingParamValue.userDetails = theArray.userDetails;
    // this.settingParamValue.newaccountError = theArray.newaccountError;
    // this.settingParamValue.uId = theArray.uId;
    // this.settingParamValue.customerId = theArray.customerId;
    // this.currentItem = theArray.uId;
    // this.customerId = theArray.customerId;
    //("setting component", this.settingParamValue)
  }
  selectContractValue: boolean = false;
  onTabChanged(ev) {
    this.settingParamValue.mycontracts = true;
    this.settingParamValue.generalData = false;
    this.settingParamValue.contractValue = true;
    this.settingParamValue.fund = false;
    if (ev && ev == 'contractValue') {
      this.selectContractValue = true;
    } else {
      this.selectContractValue = false;
    }
    const activeTab = {
      contractValue: this.settingParamValue.contractValue
      //  userDetails: this.settingParamValue.userDetails
    }
    sessionStorage.setItem('actveTabContractValueSection', JSON.stringify(activeTab));
    this.router.navigate(['contract-details']);
  }

  gotoHome() {
    const mobileContractView = {
      //'contractDetails': contractDetailsValues.contractDetails,
      'showSubMenu': false
    }
    sessionStorage.setItem('contractDetailsOnClick', JSON.stringify(mobileContractView));
    this.sharedService.setDetail('contractDetailsOnClick', mobileContractView);
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

  // setFundTransferPage(evt) {
  //   this.loadPage = evt;
  // }
  // @ViewChild('OrdersInvestComponent', { static: false }) orderInvest:OrdersInvestComponent;

  isOrderInvestTabClicked: Subject<any> = new Subject();

  orderInvestTabClick() {

    this.isOrderInvestTabClicked.next(true);
    let data = {
      //'fromPage': 'contractDetails',
      "toPage": 'orderInvest'
    }
    this.sharedService.setPageContent(data);
    //this.orderInvest.ngOnInit();
  }
  onTabclick(value?) {
    this.router.navigate(['contract-details']);
    this.onTabChanged(value);
  }

  allocationChange: boolean = false;
  onRouteChange() {
    if (window.location.href.indexOf('allocationChange') != -1 && this.orderInvestLabel) {

      // this.matSelectedTabIndex = 3;
      this.orderInvestLabel.nativeElement.click();
      setTimeout(() => {
        if (this.orderInvestRef.gotoPremiumSplitPage) {
          this.allocationChange = true;
          this.orderInvestLabel.nativeElement
          this.orderInvestRef.gotoPremiumSplitPage(true);
        }
      })
    }
    if (window.location.href.indexOf('transferFund') != -1 && this.orderInvestLabel) {
      //(this.orderInvestLabel, "orderInvestLabel");
      this.orderInvestLabel.nativeElement.click();
      //this.matSelectedTabIndex = 3;
      setTimeout(() => {
        if (this.orderInvestRef.gotoTransferFundPage) {
          this.orderInvestRef.gotoTransferFundPage(true);
        }

      })
    }
    if (window.location.href.indexOf('additionalPremiumDeposit') != -1 && this.orderInvestLabel) {
      //(this.orderInvestLabel, "orderInvestLabel");
      this.orderInvestLabel.nativeElement.click();
      //this.matSelectedTabIndex = 3;
      setTimeout(() => {
        if (this.orderInvestRef.additionalPremiumBtnClick) {
          this.orderInvestRef.additionalPremiumBtnClick(true);
        }

      })
    }
    if (window.location.href.indexOf('singlePremium') != -1 && this.orderInvestLabel) {
      //(this.orderInvestLabel, "orderInvestLabel");
      this.orderInvestLabel.nativeElement.click();
      //this.matSelectedTabIndex = 3;
      setTimeout(() => {
        if (this.orderInvestRef.singlePremiumBtnClick) {
          this.orderInvestRef.singlePremiumBtnClick(true);
        }

      })
    }


    //("route changed");
  }

}
