import { Injectable } from '@angular/core';

import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';

@Injectable({
  providedIn: 'root'
})
export class OrderInvestService {
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  constructor(private cService: HttpCommonService) { }

  getOrderInvestStrtegy(contractNumber) {
    let clientID;
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID')),
      loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    if (customerId && customerId.opeType == 'search') {
      clientID = customerId.clientID ? customerId.clientID : '';
    } else {
      clientID = loggedInUserDetail.clientId ? loggedInUserDetail.clientId : null;
    }
    // let url = `${this.baseUrl.ecustomer.investStrtegy}/${clientID}/${contractNumber}`;
    let url = this.baseUrl.ecustomer.investStrtegy;
    let reqParam = {
      clientId: clientID,
      policyNumber: contractNumber
    }
    // return this.cService['getData'](url);
    return this.cService['postData'](url, reqParam, '');
  }

}
