import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppModule } from 'src/app/app.module';
import { ContactFormService } from 'src/app/contact-form/service/contact-form.service';
import { ContractDetailsModule } from '../../contract-details.module';

import { OrderInvestService } from './order-invest.service';

xdescribe('OrderInvestService', () => {
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        "investStrtegy": host + '/api/v1/policy/invest-strategy-change'
      }
    }
  };
  window['__env'].environmentConstURLs = environmentConstURL;
  beforeEach(() => TestBed.configureTestingModule({
    imports: [RouterTestingModule, AppModule, ContractDetailsModule],
    providers: [ContactFormService]
  }));

  it('should be created', () => {
    const service: OrderInvestService = TestBed.get(OrderInvestService);
    expect(service).toBeTruthy();
  });
});
