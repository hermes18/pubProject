import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { OrderInvestModel } from './model/order-invest.model';
import { OrderInvestService } from './service/order-invest.service';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { takeWhile } from 'rxjs/operators';
import { Router } from '@angular/router';
import { observable, Subject, Observable } from 'rxjs';

@Component({
  selector: 'orders-invest',
  templateUrl: './orders-invest.component.html',
  styleUrls: ['./orders-invest.component.scss']
})
export class OrdersInvestComponent implements OnInit {
  orderInvestModel: OrderInvestModel;

  @Output('orderInvestValue') valueChange = new EventEmitter<any>();
  // inOrderTabMenu = {
  //   displayField: 'allocationChange',

  // }
  gotoPremiumSplit = false;
  gotoAdditionalPremium: boolean;
  gotoSinglePremium: boolean;
  gotoTransferFunds: boolean;
  orderPage: boolean;
  // @Input() set inOrderTab(flag) {
  //   //(flag)
  //   this.inOrderTabMenu = flag;

  // }

  constructor(private orderService: OrderInvestService, public sharedService: SharedServiceService,
    private router: Router) {
    this.orderInvestModel = new OrderInvestModel();
  }

  ngOnInit() {
    this.initMethod();
    this.changingTab.subscribe(data => {
      this.orderInvestTabClicked();
      //this.initMethod(data);

    });
  }
  @Input() changingTab: Subject<any>;

  orderInvestTabClicked() {
    this.gotoPremiumSplit = false;
    this.gotoAdditionalPremium = false;
    this.gotoSinglePremium = false;
    this.gotoTransferFunds = false;
    this.orderPage = true;
  }

  initMethod(routeVal?: any) {


    const contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));
    //this.sharedService.getPramaValue('individualContractDetails');
    //(contractDetails);
    this.orderService.getOrderInvestStrtegy(contractDetails.contractNumber)
      .pipe(takeWhile(() => this.orderInvestModel.subscribeFlag)).subscribe((data) => {
        //(data);
        this.orderInvestModel.orderInvestResponse = data;
        this.sharedService.setOrdersTabResponse(data);
      })
    this.sharedService.getPageContent().subscribe((val) => {
      if (routeVal == 'transferFund') {
        this.gotoTransferFundPage();
      }
      else {
        if (val != null) {
          if (val.toPage == 'orderInvest') {
            this.orderInvestTabClicked();
          } else if (val.toPage == 'transferFunds') {
            this.gotoTransferFundPage();
          } else if (val.toPage == 'allocationChange') {
            this.gotoPremiumSplitPage();
          } else if (val.toPage == 'depositToExistingAccount') {
            this.additionalPremiumBtnClick();
          } else if (val.toPage == 'singlePremium') {
            this.singlePremiumBtnClick();
          } else {
            //this.orderInvestTabClicked();
          }
        } else {
          this.orderInvestTabClicked();
        }

      }

    });
  }


  gotoPremiumSplitPage(data?: boolean) {
    if (!data) {
      this.sharedService.setDetail('checkBoxSelection', false);
    }
    this.gotoPremiumSplit = true;
    this.gotoAdditionalPremium = false;
    this.gotoTransferFunds = false;
    this.orderPage = false;
    this.gotoSinglePremium = false;
    // this.valueChange.emit(this.inOrderTabMenu);
    // this.sharedService.setPageContent('allocationChange');
    // this.router.navigate(['/change-premium-split']);
  }

  additionalPremiumBtnClick(data?: boolean) {
    if (!data) {
      this.sharedService.setDetail('checkBoxSelection', false);
    }
    this.gotoAdditionalPremium = true;
    this.gotoPremiumSplit = false;
    this.gotoTransferFunds = false;
    this.orderPage = false;
    this.gotoSinglePremium = false;
    //('additional premium btn clciked')
  }


  singlePremiumBtnClick(data?: boolean) {
    if (!data) {
      this.sharedService.setDetail('checkBoxSelection', false);
    }
    this.gotoSinglePremium = true;
    this.gotoPremiumSplit = false;
    this.gotoTransferFunds = false;
    this.orderPage = false;
    this.gotoAdditionalPremium = false;
    //('single premium btn clciked')
  }

  gotoTransferFundPage(data?: boolean) {
    if (!data) {
      this.sharedService.setDetail('checkBoxSelection', false);
    }
    this.gotoSinglePremium = false;
    this.gotoPremiumSplit = false;
    this.gotoTransferFunds = true;
    this.orderPage = false;
    this.gotoAdditionalPremium = false;
    //('transfer funds btn clciked')
  }

  ngOnDestroy() {
    this.orderInvestModel.subscribeFlag = false;
  }

}