export class OrderInvestModel {
    subscribeFlag: boolean;
    orderInvestResponse: any;
    constructor() {
        this.subscribeFlag = true;

    }
}