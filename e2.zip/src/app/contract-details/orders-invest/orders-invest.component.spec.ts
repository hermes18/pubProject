import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, ComponentFixtureAutoDetect, inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { Observable, of, Subject } from 'rxjs';
import { AppModule } from 'src/app/app.module';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { ContractDetailsModule } from '../contract-details.module';

import { OrdersInvestComponent } from './orders-invest.component';
import { OrderInvestService } from './service/order-invest.service';

describe('OrdersInvestComponent', () => {
  let component: OrdersInvestComponent;
  let fixture: ComponentFixture<OrdersInvestComponent>;
  let sharedService: SharedServiceService;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        "investStrtegy": host + '/api/v1/policy/invest-strategy-change'
      }
    }
  };

  const userImfo =
    { "userName": "Finson_Admin2", "firstName": "Finson", "lastName": "Francis", "email": "finson.francis1@metlife.com", "preferredLanguage": "en", "creationDate": "Mon Nov 09 14:20:54 CET 2020", "passwordType": "STANDARD", "customerPasswordExprationCode": "1", "passwordStatusCode": "ACTIVE", "securityPolicyId": "12345", "tokenExpirationDate": "Mon Nov 09 14:20:54 CET 2020", "employeeNumber": "3470451", "pwdExpirationDate": "Wed Jan 20 14:20:54 CET 2021", "failedLoginCounts": "0", "authorizedApplicationCode": "eCustomer", "temporaryLockDate": null, "route": "Home", "pwdExpired": "Active", "daysSincePwdNotChanged": null, "pwdChangeDate": null, "roleInfo": [{ "roleId": "3033", "name": "rSuperUser", "description": "RSuperUser" }, { "roleId": "3034", "name": "rAdministrator", "description": "SystemAdministrator" }, { "roleId": "3036", "name": "rUserAccountManager", "description": "RUserAccountManager" }], clientId: "78787", "requesterId": "-1", "requesterRole": "3033" }
  const serachClient =
    { clientId: "1234", opeType: "search" }
  window.sessionStorage.setItem('searcClientID', JSON.stringify(serachClient));
  window.sessionStorage.setItem('loggedInUserInfo', JSON.stringify(userImfo));
  const contractDetails = {
    "benefitType": "SuperKapitał - współubezpieczony 1",
    "businessRoleList": ["owner"],
    "contractDetailsDTO": {
      contractNumber: 121212, insurer: "INSURER_21281000", insured: "INSURED_21281000", status: 21, paymentMode: "15",
    },
    "contractNumber": "21281000",
    "contractNumberList": null,
    "effectiveDate": "18.11.2009",
    "indexedPremiumAmount": null,
    "insuredName": "INSURED_21281000",
    "premiumAmount": "",
    "premiumAmt": null,
    "premiumAmtType": null,
    "premiumDueDate": null,
    "premiumPaymentMode": "15",
    "premiumType": "15",
    "processingSystem": "OLAS",
    "status": 21
  }


  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    sessionStorage.setItem('contractDetails', JSON.stringify(contractDetails));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, OrderInvestService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    fixture = TestBed.createComponent(OrdersInvestComponent);
    sharedService = TestBed.get(SharedServiceService);
    component = fixture.componentInstance;
    component.changingTab = new Subject();

    fixture.detectChanges();
  });

  it('should create', () => {



    component.changingTab.next(true);
    //expect(component.changingTab).toHaveBeenCalledTimes(1);
    fixture.detectChanges();
    component.initMethod();
    expect(component).toBeTruthy();
  });
  it('should create initMethod', () => {
    const response = {
      clientId: "11088615",
      investmentDataList: null,
      operationsList: [],
      policyNumber: "10295785",
      renderAllocationChange: false,
      renderDepositSection: false,
      renderDepositToExistInvestAccount: false,
      renderDepositToNewInvestAccount: false,
      renderFundTransfer: true,
      renderInvestStrategyChange: true
    };
    let data = {
      //'fromPage': 'contractDetails',
      "toPage": 'orderInvest'
    }
    spyOn(OrderInvestService.prototype, 'getOrderInvestStrtegy').and.returnValue(of(response));
    spyOn(SharedServiceService.prototype, 'getPageContent').and.returnValue(of(data));
    component.initMethod();
  });

  it('should create initMethod case "transferFunds"', () => {
    const response = {
      clientId: "11088615",
      investmentDataList: null,
      operationsList: [],
      policyNumber: "10295785",
      renderAllocationChange: false,
      renderDepositSection: false,
      renderDepositToExistInvestAccount: false,
      renderDepositToNewInvestAccount: false,
      renderFundTransfer: true,
      renderInvestStrategyChange: true
    };
    let data = {
      //'fromPage': 'contractDetails',
      "toPage": 'transferFunds'
    }
    spyOn(OrderInvestService.prototype, 'getOrderInvestStrtegy').and.returnValue(of(response));
    spyOn(SharedServiceService.prototype, 'getPageContent').and.returnValue(of(data));
    component.initMethod();
  });

  it('should create initMethod case "allocationChange"', () => {
    const response = {
      clientId: "11088615",
      investmentDataList: null,
      operationsList: [],
      policyNumber: "10295785",
      renderAllocationChange: false,
      renderDepositSection: false,
      renderDepositToExistInvestAccount: false,
      renderDepositToNewInvestAccount: false,
      renderFundTransfer: true,
      renderInvestStrategyChange: true
    };
    let data = {
      //'fromPage': 'contractDetails',
      "toPage": 'allocationChange'
    }
    spyOn(OrderInvestService.prototype, 'getOrderInvestStrtegy').and.returnValue(of(response));
    spyOn(SharedServiceService.prototype, 'getPageContent').and.returnValue(of(data));
    component.initMethod();
  });

  it('should create initMethod case "depositToExistingAccount"', () => {
    const response = {
      clientId: "11088615",
      investmentDataList: null,
      operationsList: [],
      policyNumber: "10295785",
      renderAllocationChange: false,
      renderDepositSection: false,
      renderDepositToExistInvestAccount: false,
      renderDepositToNewInvestAccount: false,
      renderFundTransfer: true,
      renderInvestStrategyChange: true
    };
    let data = {
      //'fromPage': 'contractDetails',
      "toPage": 'depositToExistingAccount'
    }
    spyOn(OrderInvestService.prototype, 'getOrderInvestStrtegy').and.returnValue(of(response));
    spyOn(SharedServiceService.prototype, 'getPageContent').and.returnValue(of(data));
    component.initMethod();
  });

  it('should create initMethod case "singlePremium"', () => {
    const response = {
      clientId: "11088615",
      investmentDataList: null,
      operationsList: [],
      policyNumber: "10295785",
      renderAllocationChange: false,
      renderDepositSection: false,
      renderDepositToExistInvestAccount: false,
      renderDepositToNewInvestAccount: false,
      renderFundTransfer: true,
      renderInvestStrategyChange: true
    };
    let data = {
      //'fromPage': 'contractDetails',
      "toPage": 'singlePremium'
    }
    spyOn(OrderInvestService.prototype, 'getOrderInvestStrtegy').and.returnValue(of(response));
    spyOn(SharedServiceService.prototype, 'getPageContent').and.returnValue(of(data));
    component.initMethod();
  });


  it('should call gotoPremiumSplitPage', () => {
    const test = true;
    component.gotoPremiumSplitPage(test);
  })
});


