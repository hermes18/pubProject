import { Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { MatTableDataSource, MatTooltip } from '@angular/material';
import { SharedServiceService } from 'src/app/shared-service/shared-service.service';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { AppConfig } from 'src/config/app.config';
import * as utils from 'lodash';
import { MenuItemsService } from 'src/app/shared-service/menu-items.service';
import { UtilityService } from 'src/app/shared/utilities/utility.service';
export interface UserData {

  agreementNo: string;
  benefitsSort: string;
  productname: string;
  clause1: string;
  owuName: string;
  clause2: string;
  benefitName: string;
  clause3: string;
  benefitAmt: string;
  effectiveDate: string;
  expirationDate: string;
  premium: string;
  status: string;
  contractNumber: string;
  documentListId: string;
  coveredEntityNo: string;
  coveredEntity: string;
  contractBenefitType: string;
  documentDTOList: any;

}
@Component({
  selector: 'contract-data-detail',
  templateUrl: './contract-data-detail.component.html',
  styleUrls: ['./contract-data-detail.component.scss']
})
export class ContractDataDetailComponent implements OnInit {
  displayedColumns: string[] = ['benefitName', 'benefitAmt', 'effectiveDate', 'expirationDate', 'premium', 'status'];
  exampleColumn = ['agreementNo', 'status']
  dataSourceBasic: MatTableDataSource<any>;
  dataSourceAdditional: MatTableDataSource<UserData>;
  dataSourceBasicGroup: MatTableDataSource<any>;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  basicContract: any = [];
  additionalContract: any = [];
  basicContractGroup: any = [];
  additionalContractGroup: any = [];
  showDetails: any;
  showDateTooltipAdditional: boolean;
  showDateTooltipBasic: boolean;
  country: string;
  loggedInCountryCheck: any;
  constructor(private commonService: HttpCommonService, private sharedService: SharedServiceService, private menuItemService: MenuItemsService) { }
  // @ViewChild('tooltip1', { static: false }) tooltip1;
  // @ViewChild('tooltip1', { static: false }) manualTooltip: MatTooltip;
  lang: any;
  currencyType: any;
  ngOnInit() {

    this.country = sessionStorage.getItem('countryCode');
    //if (this.country == 'pl') {
    this.loggedInCountryCheck = UtilityService.getCountry();
    if (this.loggedInCountryCheck) {
      this.currencyType = 'PLN';
    }
    else {
      this.currencyType = 'RON';
    }
    this.basicContract = [];
    this.additionalContract = [];
    const contractDetails = JSON.parse(sessionStorage.getItem('contractDetails'));
    // this.sharedService.getPramaValue('individualContractDetails');
    let url = this.baseUrl.ecustomer.contractData + '/' + contractDetails.contractNumber;

    const reqParam = {
      contractNo: contractDetails.contractNumber
    }
    this.commonService.postData(this.baseUrl.ecustomer.contractData, reqParam, '').subscribe(data => {


      for (let i = 0; i < data.length; i++) {
        if (data[i].contractBenefitType === 'Basic Contract') {
          // data[i].clause1 = 'basic tooltip1';
          // data[i].clause2 = 'basic tooltip2';
          // data[i].clause3 = 'basic tooltip3';
          data[i].isBasicTooltip1Open = null;
          data[i].isBasicTooltip2Open = null;
          data[i].isBasicTooltip3Open = null;
          this.basicContract.push(data[i]);
        }
        if (data[i].contractBenefitType === 'Additional Contract') {
          // data[i].clause1 = 'additional tooltip1';
          // data[i].clause2 = 'additional tooltip2';
          // data[i].clause3 = 'additional tooltip3';
          data[i].isTooltipOpenClause1 = null;
          data[i].isTooltipOpenClause2 = null;
          data[i].isTooltipOpenClause3 = null;
          this.additionalContract.push(data[i]);
        }
      }




      this.dataSourceBasic = new MatTableDataSource(this.basicContract);
      this.dataSourceAdditional = new MatTableDataSource(this.additionalContract);
    })

    this.lang = UtilityService.getDefaultLanguage();//sessionStorage.getItem('defaultLanguage');
    /*if (this.lang == "pl_en") {
      this.lang = "en";
    } else if (this.lang == "pl_pl") {
      this.lang = "pl";
    } else if (this.lang == "ro_en") {
      this.lang = "en";
    } else if (this.lang == "ro_ro") {
      this.lang = "ro";
    }*/
    this.sharedService.getLangChange().subscribe((data) => {
      //(data);
      if (data) {
        this.lang = data;
      }
    });
  }

  downloadOffersDoc(document) {

    let url = this.baseUrl.ecustomer.downloadOffersPdf + document.documentId;
    this.commonService.downloadPDF(url).subscribe(data => {
      this.downloadFile(data);
    });
  }

  downloadFile(data) {
    let blob = new Blob([data], { type: "application/pdf" });
    if (window.navigator.msSaveOrOpenBlob) {
      //IE11 & Edge
      window.navigator.msSaveOrOpenBlob(blob);
    } else {
      let url = window.URL.createObjectURL(blob);
      window.open(url);
    }
  }

  goIntoDetails() {
    if (!this.showDetails) {
      this.showDetails = true;
      this.showDateTooltipAdditional = true;
      this.showDateTooltipBasic = true;
      if (this.basicContract) {

        this.basicContract.forEach(element => {
          if (element.clause1 != '' || element.clause1 != null) {
            element.isBasicTooltip1Open = true;
          }
          if (element.clause2 != '' || element.clause2 != null) {
            element.isBasicTooltip2Open = true;
          }
          if (element.clause3 != '' || element.clause3 != null) {
            element.isBasicTooltip3Open = true;
          }
          element.showDateTooltipBasic = true;
        });
      }
      if (this.additionalContract) {
        this.additionalContract.forEach(element => {
          if (element.clause1 != '' || element.clause1 != null) {
            element.isTooltipOpenClause1 = true;
          }
          if (element.clause2 != '' || element.clause2 != null) {
            element.isTooltipOpenClause2 = true;
          }
          if (element.clause3 != '' || element.clause3 != null) {
            element.isTooltipOpenClause3 = true;
          }
          element.showDateTooltipAdditional = true;
        });
      }
    } else {
      this.showDetails = false;
      this.showDateTooltipAdditional = false;
      this.showDateTooltipBasic = false;
      if (this.basicContract) {
        this.basicContract.forEach(data => {
          data.isBasicTooltip1Open = false;
          data.isBasicTooltip2Open = false;
          data.isBasicTooltip3Open = false;
          data.showDateTooltipBasic = false;
        });
      }
      if (this.additionalContract) {
        this.additionalContract.forEach(element => {
          element.isTooltipOpenClause1 = false;
          element.isTooltipOpenClause2 = false;
          element.isTooltipOpenClause3 = false;
          element.showDateTooltipAdditional = false;
        });
      }
    }
  }



  previousRow;
  displayActiveness(row, i) {

    if (i == 0) {
      this.previousRow = row;
    }
    if (this.previousRow.agreementNo === row.agreementNo && i < this.additionalContract.length - 1) {
      return 'borderBotNone';
    } else {
      this.previousRow = row;
      // return 'borderTop'
      return i === this.additionalContract.length - 1 ? '' : 'borderTop mt-3 pt-3 borderBotNone';

    }
  }

  basicContractPreviousRow;
  displayBorder(row, i) {

    if (i == 0) {
      this.basicContractPreviousRow = row;
    }
    if (this.basicContractPreviousRow.agreementNo === row.agreementNo && i < this.basicContract.length - 1) {
      return 'borderBotNone';
    } else {
      this.basicContractPreviousRow = row;
      // return 'borderTop'
      return i === this.basicContract.length - 1 ? '' : 'borderTop mt-3 pt-3 borderBotNone';

    }
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }
}
