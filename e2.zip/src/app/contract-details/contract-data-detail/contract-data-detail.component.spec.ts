import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { AppModule } from 'src/app/app.module';
import { ContractDetailsModule } from '../contract-details.module';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { ContractDataDetailComponent } from './contract-data-detail.component';
import { HttpCommonService } from 'src/app/shared/services/http-common.service';
import { of } from 'rxjs';

describe('ContractDataDetailComponent', () => {
  let component: ContractDataDetailComponent;
  let fixture: ComponentFixture<ContractDataDetailComponent>;
  let commonService: HttpCommonService;
  const contractDetails = {
    "benefitType": "SuperKapitał - współubezpieczony 1",
    "businessRoleList": ["owner"],
    "contractDetailsDTO": {
      contractNumber: "21281000", insurer: "INSURER_21281000", insured: "INSURED_21281000", status: 21, paymentMode: "15",
    },
    "contractNumber": "21281000",
    "contractNumberList": null,
    "effectiveDate": "18.11.2009",
    "indexedPremiumAmount": null,
    "insuredName": "INSURED_21281000",
    "premiumAmount": "",
    "premiumAmt": null,
    "premiumAmtType": null,
    "premiumDueDate": null,
    "premiumPaymentMode": "15",
    "premiumType": "15",
    "processingSystem": "OLAS",
    "status": 21
  }
  //
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'contractData': host + '/api/v1/users/contract-benefits' + '/' + contractDetails.contractNumber
      }
    }
  };

  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;
    sessionStorage.setItem('contractDetails', JSON.stringify(contractDetails));

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, ContractDetailsModule, HttpClientTestingModule],
      declarations: [],
      providers: [TranslateService, { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    // }));

    // beforeEach(() => {
    fixture = TestBed.createComponent(ContractDataDetailComponent);
    commonService = TestBed.get(HttpCommonService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    //jasmine.DEFAULT_TIMEOUT_INTERVAL = 7000;
    const response = [{
      agreementNo: 1,
      benefitAmt: null,
      benefitName: null,
      benefitsSort: 1,
      clause1: null,
      clause2: null,
      clause3: null,
      contractBenefitType: "Basic Contract",
      contractNumber: "21295127",
      coveredEntity: "",
      coveredEntityNo: null,
      documentDTOList: null,
      documentListId: null,
      effectiveDate: null,
      expirationDate: null,
      owuName: null,
      premium: "153,67 PLN",
      productname: "SuperKapitał S",
      rendercoveredEntity: false
    }]
    spyOn(commonService, 'postData').and.returnValue(of(response));

    expect(component).toBeTruthy();
  });
});
