import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from '../app.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { DocumentsModule } from './documents.module';
import { DocumentData, DocumentsComponent } from './documents.component';
import { MatTableDataSource } from '@angular/material';

describe('DocumentsComponent', () => {
  let component: DocumentsComponent;
  let fixture: ComponentFixture<DocumentsComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const userToken = {
    token: "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJPc2FtYUFkbWluIiwidXNlciI6eyJ1c2VyTmFtZSI6Ik9zYW1hQWRtaW4iLCJmaXJzdE5hbWUiOiJPc2FtYSIsImxhc3ROYW1lIjoiTW8iLCJlbWFpbCI6Im9zYW1hLmtoYWxpZEBtZXRsaWZlLmNvbSIsInByZWZlcnJlZExhbmd1YWdlIjoiZW4iLCJjcmVhdGlvbkRhdGUiOiJXZWQgSmFuIDA2IDE0OjQyOjI0IENFVCAyMDIxIiwicGFzc3dvcmRUeXBlIjoiU1RBTkRBUkQiLCJjdXN0b21lclBhc3N3b3JkRXhwcmF0aW9uQ29kZSI6IjEiLCJwYXNzd29yZFN0YXR1c0NvZGUiOiJBQ1RJVkUiLCJzZWN1cml0eVBvbGljeUlkIjoiMTIzNDUiLCJ0b2tlbkV4cGlyYXRpb25EYXRlIjoiRnJpIFNlcCAxOCAxNzowMzo1MCBDRVNUIDIwMjAiLCJlbXBsb3llZU51bWJlciI6bnVsbCwicHdkRXhwaXJhdGlvbkRhdGUiOiJGcmkgTWFyIDE5IDE0OjQyOjI0IENFVCAyMDIxIiwiZmFpbGVkTG9naW5Db3VudHMiOiIwIiwiYXV0aG9yaXplZEFwcGxpY2F0aW9uQ29kZSI6ImVDdXN0b21lciIsInRlbXBvcmFyeUxvY2tEYXRlIjpudWxsLCJyb3V0ZSI6bnVsbCwicHdkRXhwaXJlZCI6bnVsbCwiZGF5c1NpbmNlUHdkTm90Q2hhbmdlZCI6bnVsbCwicHdkQ2hhbmdlRGF0ZSI6bnVsbCwicm9sZUluZm8iOlt7InJvbGVJZCI6IjMwMzMiLCJuYW1lIjoiclN1cGVyVXNlciIsImRlc2NyaXB0aW9uIjoiUlN1cGVyVXNlciJ9LHsicm9sZUlkIjoiMzAzNCIsIm5hbWUiOiJyQWRtaW5pc3RyYXRvciIsImRlc2NyaXB0aW9uIjoiU3lzdGVtQWRtaW5pc3RyYXRvciJ9XSwiY2xpZW50SWQiOm51bGwsInJlcXVlc3RlcklkIjpudWxsLCJyZXF1ZXN0ZXJSb2xlIjpudWxsLCJ1c2VyRG4iOiJvdT1QZW9wbGUsbz1hZmZpbGlhdGVzLGM9UG9sYW5kLG89bWV0bGlmZSxkYz1tZXRsaWZlLGRjPWNvbSIsInVzZXJDaGVjayI6dHJ1ZX0sImlhdCI6MTYxMjMzNzA1NCwiZXhwIjoxNjEyMzgwMjU0fQ.DF3cfAMA1Z0BLYN_k5yrqtWDcq1ed9z1Vu5EkIgj_x0",
    userName: "OsamaAdmin"
  };
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        "myDocumentFilter": host + '/api/v1/documents/filters'
      }
    }
  };
  beforeEach(() => {
    window.sessionStorage.setItem('userToken', JSON.stringify(userToken));

    window['__env'].environmentConstURLs = environmentConstURL;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, DocumentsModule, HttpClientTestingModule],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TranslateService],
      declarations: [],
      // imports: [TranslateModule.forRoot()],
    })
      .compileComponents();
    fixture = TestBed.createComponent(DocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(DocumentsComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create', () => {
    component.dataSource = new MatTableDataSource<DocumentData>();
    expect(component).toBeTruthy();
  });
});
