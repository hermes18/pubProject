import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DocumentsService {

  constructor() { }
  clientId;
  getClientID(data, customerId, userrole) {
    let clientID;
    let multipleRole = encodeURIComponent(userrole);
    if (customerId && customerId.opeType == 'search') {
      clientID = customerId.clientID ? customerId.clientID : '';
    } else {
      clientID = data.clientId ? data.clientId : null;
    }
    // let role = data.roleInfo ? data.roleInfo[0] ? data.roleInfo[0].name : '' : '',

    this.clientId = clientID;
    //(this.clientId);


    return this.clientId;
  }
}
