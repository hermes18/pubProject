import { NgModule } from '@angular/core';
import { MatFormFieldModule, MatPaginatorModule } from '@angular/material';
import { Routes, RouterModule } from '@angular/router';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { DocumentsComponent } from './documents.component';


const routes: Routes = [
  {
    path: '', component: DocumentsComponent,
    canDeactivate: [NavigationGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes), MatFormFieldModule, MatPaginatorModule],
  exports: [RouterModule, MatFormFieldModule, MatPaginatorModule]
})
export class DocumentsRoutingModule { }
