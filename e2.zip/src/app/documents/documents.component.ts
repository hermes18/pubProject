
import { FormBuilder } from '@angular/forms';
import { AppConfig } from 'src/config/app.config';

import { environment } from 'src/environments/environment';
import { HttpCommonService } from '../shared/services/http-common.service';
import { Component, OnInit, HostListener, ViewChild, Output, EventEmitter } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { HttpHeaders } from '@angular/common/http';
import { DateAdapter, MatPaginator, MatTableDataSource } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { DocumentsService } from './documents.service';
import { DatePipe, formatDate } from '@angular/common';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { Router } from '@angular/router';
import { DeviceDetectorService } from 'ngx-device-detector';
import * as moment from 'moment';
import * as utils from 'lodash';
import { UtilityService } from '../shared/utilities/utility.service';

export class DocumentData {
  eventType: string;
  contractNo: string;
  aggrementDisplay: number;
  creationDate: Date;
  file;
}
export class Post {
  fromDate: Date;
  toDate: Date;
}
@Component({
  selector: 'documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss'],
  providers: [DatePipe]
})
export class DocumentsComponent implements OnInit {
  selectedOption1 = 1;
  selectedOption2 = 1;
  selectedOption3 = 1;

  @ViewChild('tooltip', { static: false }) tooltip;
  maxDate: Date;
  minDate: Date;
  @HostListener('window:scroll', ['$event'])
  scrollHandler(event) {
    this.tooltip ? this.tooltip.hide() : '';
  }
  displayedColumns: string[] = ['eventType', 'contractNo', 'aggrementDisplay', 'creationDate'];
  user: any;
  count: any;
  RecordsFound: boolean;
  zeroRecordFound: boolean;
  country: string;
  lang: any;
  displayPoland: boolean;
  clientId;
  userInfo: any = sessionStorage.getItem('loggedInUserInfo');
  userdetail: any = JSON.parse(this.userInfo);
  role: string = this.userdetail.roleInfo[0] ? this.userdetail.roleInfo[0].name : 'NoRole';
  dataSource: MatTableDataSource<DocumentData>;

  // post: Post = {
  //   fromDate: new Date(new Date().setFullYear(new Date().getFullYear() - 1)),
  //   toDate: new Date(Date.now())
  // }
  @Output('setCalenderLanguage') calenderLangugae = new EventEmitter<any>();
  setLocaleDatePicker: any;
  changeText: boolean;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  documentUrl = this.baseUrl.ecustomer.myDocument;
  // documentUrl = environment.mydocument.testUrl;
  // dropdownUrl = environment.mydocumentdropdown.dropdownUrl;mock 
  dropdownUrl = this.baseUrl.ecustomer.myDocumentFilter;
  documentRequestDTO: any;
  filterRequestDTO: any;
  showTable: boolean = false;
  eventTypeDropDown;
  policyNumberDropdown;
  docTypeDropdown;
  documentInput: any;
  eventTypeRefernceList: any;
  documentTypeReferenceList: any;
  contractList: any;
  constructor(public fb: FormBuilder, public documentService: DocumentsService, public sharedService: SharedServiceService,
    private sanitizer: DomSanitizer, public menuItemService: MenuItemsService, public deviceDetector: DeviceDetectorService,
    private readonly router: Router, public commonService: HttpCommonService, private dateAdapter: DateAdapter<Date>,
    public datepipe: DatePipe) {
    this.minDate = new Date(1900, 0, 1);
    this.maxDate = new Date(2050, 0, 1);
    this.changeText = false;
    // this.pdfByteArrays.push(this.pdfTest1);
  }
  private paginator: MatPaginator;
  private sort: MatSort;


  @ViewChild(MatPaginator, { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (this.dataSource)
      this.dataSource.paginator = this.paginator;
  }
  @ViewChild(MatSort, { static: false }) set matSort(mp: MatSort) {
    this.sort = mp;
    if (this.dataSource)
      this.dataSource.sort = this.sort;
  }
  ngAfterViewInit() {
    this.sharedService.getLangChange().subscribe((data) => {
      const lang = sessionStorage.getItem("defaultLanguage");
      let dateTranslate = {
        'pl_en': 'en',
        'pl_pl': 'pl',
        'ro_ro': 'ro',
        'ro_en': 'en',
        'gr_gr': 'el',
        'gr_en': 'en',
        'gr': 'el'
      }
      //("after lang change", data);
      const language = data ? data === 'gr' ? dateTranslate[lang] : data : dateTranslate[lang];
      this.dateAdapter.setLocale(language);
    })
    this.calenderLangugae.emit(this.setLocaleDatePicker);

    if (this.dataSource) {
      this.dataSource.sort = this.sort;
      //console.log(this.sort)
      this.dataSource.paginator = this.paginator;
      //console.log(this.dataSource.paginator)
    }


  }

  defaultLanguage: string;

  isMobile = this.deviceDetector.isMobile();
  responseData: any;
  ngOnInit() {
    const userInfo = sessionStorage.getItem('loggedInUserInfo');
    let userdetail = JSON.parse(userInfo);
    let role = userdetail.roleInfo[0] ? userdetail.roleInfo[0].name : 'NoRole';
    this.sharedService.getLangChange().subscribe((data) => {

      this.defaultLanguage = sessionStorage.getItem("defaultLanguage");
    });
    this.country = sessionStorage.getItem('countryCode');
    //("country", this.country)

    this.lang = sessionStorage.getItem('defaultLanguage');
    //("lang", this.lang)
    let loggedInCountryCheck = UtilityService.getCountry();
    if (loggedInCountryCheck) {
      // if (this.country == 'pl') {
      this.displayPoland = true;
    }
    else {
      this.displayPoland = false;
    }
    this.documentInput = this.fb.group({
      eventType: null,
      contractNo: null,
      documentType: null,
      fromDate: '',
      toDate: new Date(),
      // fromDate: [formatDate(this.post.fromDate, 'yyyy-MM-dd', 'en')],
      // toDate: [formatDate(this.post.toDate, 'yyyy-MM-dd', 'en')]

    });
    this.setDateValue();
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID')),
      loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo')),
      userrole = this.menuItemService.getAllRoles();
    //(userrole);
    this.clientId = this.documentService.getClientID(loggedInUserDetail, customerId, userrole);
    const fromDateValue = moment(this.documentInput.value.fromDate);
    const toDateValue = moment(this.documentInput.value.toDate);

    if (fromDateValue.isValid() && toDateValue.isValid()) {
      this.documentSearchRequestDetails();
    }
    this.filterRequestDTO = {
      roles: userrole,
      clientId: this.clientId
    }
    this.commonService['postData'](this.dropdownUrl, this.documentRequestDTO, this.headers).subscribe(data => {
      this.eventTypeDropDown = data.eventTypeList;
      this.policyNumberDropdown = data.policyNoList;
      this.docTypeDropdown = data.documentTypeList;
      this.eventTypeRefernceList = data.eventTypeRefernceList;
      this.documentTypeReferenceList = data.documentTypeReferenceList;

      if (data.documentPresentDtos != null) {
        //this.responseData = data.documentPresentDtos;
        this.documentSearchResponsedetails(data.documentPresentDtos);
      }
      // //("111", this.eventTypeDropDown);
      // //("222", this.policyNumberDropdown);
      // //("333", this.docTypeDropdown)
    })
    this.showTable = false;
    this.zeroRecordFound = false;

    // this.documentSearch();
  }

  setDateValue() {

    let toDate = new Date();
    const fromDateRange = new Date(toDate.setFullYear(toDate.getFullYear() - 1))
    this.documentInput.patchValue({
      fromDate: fromDateRange
    })
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  wardenRoleCheck: boolean = false;
  wardernContractArray: any = [];
  activeContractArray: any = [];
  documentSearch() {

    this.documentSearchRequestDetails();
    const fromDateValue = moment(this.documentInput.value.fromDate);
    const toDateValue = moment(this.documentInput.value.toDate);

    if (fromDateValue.isValid() && toDateValue.isValid()) {
      this.documentSearchList();
    }
  }
  documentSearchRequestDetails() {
    this.showTable = false;
    const userInfo = sessionStorage.getItem('loggedInUserInfo');
    let userdetail = JSON.parse(userInfo);
    let role = this.menuItemService.getAllRoles();

    if (this.documentInput.value.eventType || this.documentInput.value.contractNo ||
      this.documentInput.value.documentType || this.documentInput.value.fromDate ||
      this.documentInput.value.toDate) {
      //("valid");
      let fromdate = (this.documentInput.value.fromDate ? (this.documentInput.value.fromDate) : '');
      let toDate = (this.documentInput.value.toDate ? (this.documentInput.value.toDate) : '');
      let eventType = (this.documentInput.value.eventType ? (this.documentInput.value.eventType) : '')
      let contractNo = (this.documentInput.value.contractNo ? (this.documentInput.value.contractNo) : '')
      let documentType = (this.documentInput.value.documentType ? (this.documentInput.value.documentType) : '')

      const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
      const menuItemList2 = JSON.parse(sessionStorage.getItem('menuItemList'));

      if (menuItemList) {
        this.contractList = menuItemList.contractList ? menuItemList.contractList : null;
        this.activeContractArray = menuItemList.activeContractDetails ? menuItemList.activeContractDetails : null;
        this.wardenRoleCheck = menuItemList.wardenRoleCheck ? menuItemList.wardenRoleCheck : false;
      } else if (menuItemList2) {
        this.contractList = menuItemList2.contractList ? menuItemList2.contractList : null;
        this.wardenRoleCheck = menuItemList2.wardenRoleCheck ? menuItemList2.wardenRoleCheck : false;
        this.activeContractArray = menuItemList2.activeContractDetails ? menuItemList2.activeContractDetails : null;
      }

      if ((this.wardenRoleCheck == true) && this.activeContractArray != null && this.activeContractArray.length > 0) {
        /// this.wardernContractArray = this.contractList.concat(this.activeContractArray); 
        for (var i of this.activeContractArray) {
          this.contractList.push(i);
        }
      }

      this.documentRequestDTO = {
        eventType: eventType != 1 ? eventType.trim() : '',
        contractNo: contractNo != 1 ? contractNo.trim() : '',
        documentType: documentType != 1 ? documentType.trim() : '',
        fromDate: fromdate ? fromdate : '',
        toDate: toDate ? toDate : '',
        eventTypeRefernceList: this.eventTypeRefernceList,
        documentTypeReferenceList: this.documentTypeReferenceList,
        loggedInUserRole: role,
        roles: role,
        contractsDTOList: this.contractList,
        wardenRoleCheck: this.wardenRoleCheck,
        language: userdetail.preferredLanguage,
        clientId: this.clientId
      }
      for (const key in this.documentRequestDTO) {
        if (this.documentRequestDTO[key] == null) {
          delete this.documentRequestDTO[key];
        }
      }
    }
  }
  headers = new HttpHeaders();

  documentSearchList() {
    //(this.documentRequestDTO)
    //(this.documentUrl)
    // this.commonService['getData'](this.documentUrl).subscribe(data => {
    this.commonService['postData'](this.documentUrl, this.documentRequestDTO, this.headers).subscribe(data => {

      this.documentSearchResponsedetails(data);
      // setTimeout(() => {
      //   this.zeroRecordFound = false;
      // }, 3500);

    })
    // this.documentInput.reset()
  }
  documentSearchResponsedetails(data: any) {
    this.dataSource = new MatTableDataSource<DocumentData>();
    this.user = data;
    //(this.user)
    this.dataSource = new MatTableDataSource(this.user)
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    //console.log("sorttt", this.dataSource.sort)

    this.dataSource.sort.disableClear = true;
    this.dataSource.sortingDataAccessor = (data, header) => {
      switch (header) {
        case "creationDate":
          //  let sorted = new Date(data.date) ;
          //  let date=new Date();
          let latest_date = this.datepipe.transform(data.creationDate, "yyyy-MM-dd");
          // //console.log(latest_date);
          return latest_date;
        default:
          return data[header];
      }
    };
    //   this.dataSource.sort = this.sort;
    //this.dataSource.sort.disableClear = true;
    this.count = this.user.length;
    ////console.log(this.count)
    if (this.count > 0) {
      this.zeroRecordFound = false;
      this.showTable = true;
    } else {
      this.zeroRecordFound = true;
      this.showTable = false;
    }
  }

  generalData(data) {
    let contract = {
      "contractNumber": data.contractNo,
      "status": data.contractStatus
    }
    sessionStorage.setItem('contractDetails', JSON.stringify(contract));
    sessionStorage.setItem('contract', JSON.stringify(data.contractNo));
    //this.router.navigate(['/contract-details']);
    this.menuItemService.getSubmenuList(contract);
  }
  downloadPdf(row) {
    if (row.data)
      this.user = row.data;

    const byteCharacters = atob(this.user);

    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    let blob = new Blob([byteArray], { type: "application/pdf" });
    if (window.navigator.msSaveOrOpenBlob) {

      window.navigator.msSaveOrOpenBlob(blob);
    } else {
      let url = window.URL.createObjectURL(blob);
      window.open(url);
    }


  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }
  // formatDate(date) {
  //   if (date) {
  //     var d = new Date(date),
  //       month = '' + (d.getMonth() + 1),
  //       day = '' + d.getDate(),
  //       year = d.getFullYear();

  //     if (month.length < 2)
  //       month = '0' + month;
  //     if (day.length < 2)
  //       day = '0' + day;

  //     return [year, month, day].join('-');
  //   }
  // }
}

