import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { BehaviorSubject } from 'rxjs';
import { AppConfig } from 'src/config/app.config';
import { environment } from 'src/environments/environment';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { HttpCommonService } from '../shared/services/http-common.service';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MenuItemsService } from '../shared-service/menu-items.service';
import { TransformPipe } from '../shared/pipe/transform.pipe';
import { DeviceDetectorService } from 'ngx-device-detector';

@Component({
  selector: 'fund-pric-monitoring',
  templateUrl: './fund-pric-monitoring.component.html',
  styleUrls: ['./fund-pric-monitoring.component.scss']
})
export class FundPricMonitoringComponent implements OnInit {

  form: FormGroup;
  lang: string;
  country: string;
  displayRoOption: boolean = false
  accountDetail
  dataSource: MatTableDataSource<any>;
  fundDetails
  emailInValid: boolean = false
  displayedColumns = ['fundName', 'unitPrice', 'minimumFundAllocation', 'maximumFundAllocation']
  displayedColumns1 = ['accountvalue', "", 'minimumAccountValue', 'maximumAccountValue']
  accountMonitoring: FormGroup
  FundSwitchRequestDTO: any = [];
  personalInfo: any;
  clientId: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  reqFund: any;
  submitSuccess: boolean = false;
  FundAccountEmpty: boolean = false;
  maxAccountErr: boolean = false;
  minAccountErr: boolean = false;
  emailEmpty: boolean = false;
  maxFundErr: boolean = false;
  minFundErr: boolean = false;
  formSubmitted: boolean = false;
  accountMenuClicked: any;
  invalidEmail: boolean = false;
  maxFundEmpty: boolean = false;
  minFundEmpty: boolean = false;
  minAccountEmptyErr: boolean;
  maxAccountEmptyErr: boolean;
  checkString: any;
  userdetail: any;
  policyNumberList: any = '';

  constructor(public commonService: HttpCommonService, public fb: FormBuilder,
    public sharedService: SharedServiceService,
    public deviceDetector: DeviceDetectorService,
    private menuItemService: MenuItemsService,
    private transform: TransformPipe) {
  }
  isMobile = this.deviceDetector.isMobile();
  ngOnInit() {
    this.sharedService.getMenuClicked().subscribe((flag) => {
      this.accountMenuClicked = flag;
      if (this.accountMenuClicked) {
        this.submitSuccess = false;
        this.initValues();
      } else {
        this.initValues();
      }
    })
  }

  initValues() {
    this.accountMonitoring =
      this.fb.group({
        accountMaxValue: ["", [Validators.required, Validators.pattern('^[0-9]')]],
        accountMinValue: ["", [Validators.required, Validators.pattern('^[0-9]')]],
        email: ["", [Validators.email, Validators.required]],
        emailSelect: ["", [Validators.email, Validators.required]],
        fundPriceDTOs: this.fb.array([]),
      })
    this.country = sessionStorage.getItem('countryCode');
    this.lang = sessionStorage.getItem('defaultLanguage');
    //this.clientId = this.sharedService.getClientId() != null ? this.sharedService.getClientId() : "";
    if (this.country == 'ro') {
      this.displayRoOption = true;
    } else {
      this.displayRoOption = false;
    }
    const menuItemList = JSON.parse(sessionStorage.getItem('menuListFromClientSearch'));
    if (menuItemList != null && menuItemList.contractList != null && menuItemList.contractList.length > 0) {
      menuItemList.contractList.forEach(data => {
        this.policyNumberList = this.policyNumberList.concat(data.contractNumber != null && data.contractNumber != "" ? data.contractNumber + ',' : '')
      });
    } else {
      const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
      if (menuItemList != null && menuItemList.contractList != null && menuItemList.contractList.length > 0) {
        menuItemList.contractList.forEach(data => {
          this.policyNumberList = this.policyNumberList.concat(data.contractNumber != null && data.contractNumber != "" ? data.contractNumber + ',' : '')
        });
      }
    }
    this.userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    if (customerId) {
      this.clientId = customerId.clientID ? customerId.clientID : '';
    } else if (this.userdetail) {
      this.clientId = this.userdetail.clientId ? this.userdetail.clientId : '';
    }
    this.sharedService.getDetail('menuItemList').subscribe((data) => {
      //this.clientId = data.clientId;
      if (data != null && data.fundPriceDetails) {
        this.accountDetail = data.fundPriceDetails;
        this.fundDetails = this.accountDetail.fundSwitchDTOs;
        //(this.fundDetails.length);
        for (var i = 0; i < this.fundDetails.length; i++) {
          this.add(i);
        }
        //(this.accountMonitoring);
      } else {
        this.accountDetail = [];
      }
      if (data != null && data.personalInformationDTO) {
        this.personalInfo = data.personalInformationDTO;
      } else {
        this.personalInfo = null;
      }
    });
    this.dataSource = new MatTableDataSource((this.accountMonitoring['controls'].fundPriceDTOs['controls']));
    this.accountMonitoring.controls['email'].setValue("");
    // this.accountMonitoring.value.emailSelect = this.personalInfo.emailBasic;
    this.accountMonitoring.controls['emailSelect'].setValue("0");
    //(this.accountMonitoring.value)
  }

  // get account(): FormArray {
  //   return this.form.get('account') as FormArray;
  // }
  // onUserChange(event, account: FormGroup) {
  //   const minimumFundAllocation = account.get('minimumFundAllocation');
  //   minimumFundAllocation.setValue(null);
  //   minimumFundAllocation.markAsUntouched();
  // }
  fundPriceDTOs(): FormArray {
    return this.accountMonitoring.get('fundPriceDTOs') as FormArray;
  }
  add(index) {
    this.fundPriceDTOs().push(this.new(index));
  }
  new(index): FormGroup {
    return this.fb.group({
      fundCode: this.fundDetails[index].fundCode,
      fundName: this.fundDetails[index].fundName,
      unitPrice: this.fundDetails[index].unitPrice,
      unitPriceActual: this.fundDetails[index].unitPriceActual,
      sort: this.fundDetails[index].sort,
      minimumFundAllocation: [""],
      maximumFundAllocation: [""],
      minFiledErr: false,
      maxFieldErr: false
    })
  }

  onSubmit() {
    this.FundAccountEmpty = false;
    this.maxAccountErr = false;
    this.minAccountErr = false;
    this.emailEmpty = false;
    this.minFundErr = false;
    this.maxFundErr = false;
    if ((this.accountMonitoring.value.emailSelect == 'Other' || this.accountMonitoring.value.emailSelect == 'Alta') && this.accountMonitoring.get('email').value == "") {
      // setTimeout(() => {
      //   this.emailEmpty = false;
      //   window.scroll(0, 0);
      // }, 5000);
      this.emailEmpty = true;
      this.FundAccountEmpty = false;
      this.minAccountErr = false;
      this.maxAccountErr = false;
      this.maxAccountEmptyErr = false;
      this.minAccountEmptyErr = false;
      this.maxFundErr = false;
      this.maxFundEmpty = false;
      this.minFundEmpty = false;
      this.minFundErr = false;
      window.scroll(0, 0);
    } else if (this.accountMonitoring.value.emailSelect == "0" && this.personalInfo.emailBasic != null) {
      // setTimeout(() => {
      //   this.emailEmpty = false;
      // }, 5000);
      this.emailEmpty = true;
      this.FundAccountEmpty = false;
      this.minAccountErr = false;
      this.maxAccountErr = false;
      this.maxAccountEmptyErr = false;
      this.minAccountEmptyErr = false;
      this.maxFundErr = false;
      this.maxFundEmpty = false;
      this.minFundEmpty = false;
      this.minFundErr = false;
      window.scroll(0, 0);
      this.accountMonitoring.value.email = "";
    } else if (this.accountMonitoring.value.emailSelect == "0" && this.personalInfo.emailBasic == null &&
      this.accountMonitoring.value.email == "") {
      // setTimeout(() => {
      //   this.emailEmpty = false;
      // }, 5000);
      this.emailEmpty = true;
      this.FundAccountEmpty = false;
      this.minAccountErr = false;
      this.maxAccountErr = false;
      this.maxAccountEmptyErr = false;
      this.minAccountEmptyErr = false;
      this.maxFundErr = false;
      this.maxFundEmpty = false;
      this.minFundEmpty = false;
      this.minFundErr = false;
      window.scroll(0, 0);
      this.accountMonitoring.value.email = "";
    } else {
      if ((this.accountMonitoring.value.emailSelect == "Other" || this.accountMonitoring.value.emailSelect == "Alta") && this.accountMonitoring.get('email').invalid
        // && (this.accountMonitoring.get('email').dirty || this.accountMonitoring.get('email').touched)
      ) {
        // setTimeout(() => {
        //   this.invalidEmail = false;
        // }, 5000)
        this.invalidEmail = true;
        this.emailEmpty = false;
        this.FundAccountEmpty = false;
        this.minAccountErr = false;
        this.maxAccountErr = false;
        this.maxAccountEmptyErr = false;
        this.minAccountEmptyErr = false;
        this.maxFundErr = false;
        this.maxFundEmpty = false;
        this.minFundEmpty = false;
        this.minFundErr = false;
        window.scroll(0, 0);
      } else {
        this.emailEmpty = false;
        this.FundAccountEmpty = false;
        this.minAccountErr = false;
        this.maxAccountErr = false;
        this.maxAccountEmptyErr = false;
        this.minAccountEmptyErr = false;
        this.maxFundErr = false;
        this.maxFundEmpty = false;
        this.minFundEmpty = false;
        this.minFundErr = false;
        this.invalidEmail = false;
        this.accountMonitoring.value.email = this.personalInfo.emailBasic;
      }
    }
    this.getFundPriceDTOs();
    this.formSubmitted = true;
    let minFundErrCnt = 0;
    let maxFundErrCnt = 0;
    let req = {
      "clientId": this.clientId,//"11088615",
      "email": this.accountMonitoring['controls'].email.value != "" ? this.accountMonitoring['controls'].email.value : this.personalInfo.emailBasic,//"Shabana.Shaikh@Metlife.pl",
      "firstName": this.personalInfo.firstName,//"Shabana",
      "lastName": this.personalInfo.lastName,//"Shaikh",
      "policyNumber": this.policyNumberList != '' ? this.policyNumberList.substring(0, this.policyNumberList.length - 1) : '',//this.personalInfo.policyNumber,//"10293697",
      "language": this.lang,
      "accountValue": this.accountDetail.accountValue,//"100",
      "accountMaxValue": this.accountMonitoring.value.accountMaxValue,//"125",
      "accountMinValue": this.accountMonitoring.value.accountMinValue,//"75",
      "fundPriceDTOs": this.reqFund
    }
    let headers = new HttpHeaders();
    let url = this.baseUrl.ecustomer.fundPriceSubmit;
    if (((this.accountMonitoring.value.accountMaxValue == null || this.accountMonitoring.value.accountMaxValue == "") && (this.accountMonitoring.value.accountMinValue == "" || this.accountMonitoring.value.accountMinValue == null))
      && this.reqFund.length == 0) {
      //minimum one filed err
      // setTimeout(() => {
      //   this.FundAccountEmpty = false;
      // }, 5000);
      this.FundAccountEmpty = true;
      window.scroll(0, 0);
    } else if (this.reqFund.length == 0) {
      // this.maxFundErr = false;
      // this.maxFundEmpty = false;
      // this.minFundEmpty = false;
      // this.minFundErr = false;
      // this.minAccountEmptyErr = false;
      // this.maxAccountEmptyErr = false;
      // if (this.accountMonitoring.value.accountMaxValue != '' && this.accountMonitoring.value.accountMinValue == '') {
      //   // setTimeout(() => {
      //   //   this.maxAccountErr = false;
      //   // }, 5000);
      //   this.minAccountEmptyErr = true;
      //   // this.maxAccountEmptyErr = false;
      //   // this.maxAccountErr = false;
      //   // this.minAccountErr = false;
      //   // this.FundAccountEmpty = true;
      //   window.scroll(0, 0);
      // } 
      // if (this.accountMonitoring.value.accountMaxValue == '' && this.accountMonitoring.value.accountMinValue != '') {
      //   // setTimeout(() => {
      //   //   this.maxAccountErr = false;
      //   // }, 5000);
      //   this.maxAccountEmptyErr = true;
      //   // this.minAccountEmptyErr = false;
      //   // this.maxAccountErr = false;
      //   // this.minAccountErr = false;
      //   // this.FundAccountEmpty = true;
      //   window.scroll(0, 0);
      // } 
      // if (this.accountMonitoring.value.accountMaxValue!="" && this.accountMonitoring.value.accountMinValue!= "" &&
      //   (parseFloat(this.accountMonitoring.value.accountMaxValue) < parseFloat(this.accountDetail.accountValue)) && 
      //   (parseFloat(this.accountMonitoring.value.accountMinValue) > parseFloat(this.accountDetail.accountValue))) {
      //   //account max filed validation
      //   // setTimeout(() => {
      //   //   this.maxAccountErr = false;
      //   //   this.minAccountErr = false;
      //   //   window.scroll(0, 0);
      //   // }, 5000);
      //   this.maxAccountErr = true;
      //   this.minAccountErr = true;
      //   // this.maxAccountEmptyErr = false;
      //   // this.minAccountEmptyErr = false;
      //   // this.FundAccountEmpty = false;
      //   window.scroll(0, 0);
      // } 
      // if (this.accountMonitoring.value.accountMaxValue!="" && 
      // (parseFloat(this.accountMonitoring.value.accountMaxValue) < parseFloat(this.accountDetail.accountValue))) {
      //   // setTimeout(() => {
      //   //   this.maxAccountErr = false;
      //   // }, 5000);
      //   this.maxAccountErr = true;
      //   // this.minAccountErr = false;
      //   // this.maxAccountEmptyErr = false;
      //   // this.minAccountEmptyErr = false;
      //   // this.FundAccountEmpty = false;
      //   window.scroll(0, 0);
      // } 
      // if (this.accountMonitoring.value.accountMinValue!= "" && (parseFloat(this.accountMonitoring.value.accountMinValue) > parseFloat(this.accountDetail.accountValue))) {
      //   //account min field validation
      //   // setTimeout(() => {
      //   //   this.minAccountErr = false;
      //   // }, 5000);
      //   this.minAccountErr = true;
      //   // this.maxAccountErr = false;
      //   // this.maxAccountEmptyErr = false;
      //   // this.minAccountEmptyErr = false;
      //   // this.FundAccountEmpty = false;
      //   window.scroll(0, 0);
      // } else {
      //   // this.FundAccountEmpty = false;
      //   // this.minAccountErr = false;
      //   // this.maxAccountErr = false;
      //   // this.maxAccountEmptyErr = false;
      //   // this.minAccountEmptyErr = false;
      //   //this.callApi(url, req, headers);
      // }
      //total value validation
      this.callTotalAccountValueValidation(url, req, headers);

      if (!this.minAccountErr && !this.maxAccountErr && !this.maxAccountEmptyErr && !this.minAccountEmptyErr && !this.FundAccountEmpty) {
        this.callApi(url, req, headers);
      } else { }
    } else if (this.reqFund.length != 0) {
      // let minFundErrCnt = 0;
      // let maxFundErrCnt = 0;
      this.maxFundEmpty = false;
      this.minFundEmpty = false;
      this.maxFundErr = false;
      this.minFundErr = false;
      //check formarray fund rows validation
      for (let i = 0; i < this.accountMonitoring.controls.fundPriceDTOs.value.length; i++) {
        if ((this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation == "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation != "")) {
          // setTimeout(() => {
          //   this.FundAccountEmpty = false;
          // }, 5000);
          this.maxFundEmpty = true;
          // this.minFundEmpty = false;
          // this.maxFundErr = false;
          // this.minFundErr = false;
          this.FundAccountEmpty = true;
          window.scroll(0, 0);
        }
        if ((this.accountMonitoring.controls.fundPriceDTOs.value[0].maximumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[0].minimumFundAllocation == "")) {
          // setTimeout(() => {
          //   this.FundAccountEmpty = false;
          // }, 5000);
          this.minFundEmpty = true;
          // this.maxFundEmpty = false;
          // this.maxFundErr = false;
          // this.minFundErr = false;
          this.FundAccountEmpty = true;
          window.scroll(0, 0);
        }
        if ((this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation < this.accountMonitoring.controls.fundPriceDTOs.value[i].unitPriceActual)) {
          // setTimeout(() => {
          this.accountMonitoring.controls.fundPriceDTOs.value[i].maxFieldErr = true;
          this.maxFundErr = true;
          // this.maxFundEmpty = false;
          // this.minFundEmpty = false;
          // this.minFundErr = false;
          // this.FundAccountEmpty = false;
          maxFundErrCnt = maxFundErrCnt++;
          window.scroll(0, 0);
          // setTimeout(() => {
          //   this.maxFundErr = false;
          // }, 5000);
        }
        if ((this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation > this.accountMonitoring.controls.fundPriceDTOs.value[i].unitPriceActual)) {
          //setTimeout(() => {
          this.accountMonitoring.controls.fundPriceDTOs.value[i].minFiledErr = true;
          this.minFundErr = true;
          // this.maxFundErr = false;
          // this.maxFundEmpty = false;
          // this.minFundEmpty = false;
          // this.FundAccountEmpty = false;
          minFundErrCnt = minFundErrCnt++;
          window.scroll(0, 0);
          // }, 300);
          // setTimeout(() => {
          //   this.minFundErr = false;
          // }, 5000)
        }
        if ((this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation < this.accountMonitoring.controls.fundPriceDTOs.value[i].unitPriceActual)
          && (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation > this.accountMonitoring.controls.fundPriceDTOs.value[i].unitPriceActual)) {
          // setTimeout(() => {
          this.accountMonitoring.controls.fundPriceDTOs.value[i].maxFieldErr = true;
          this.maxFundErr = true;
          this.accountMonitoring.controls.fundPriceDTOs.value[i].minFiledErr = true;
          this.minFundErr = true;
          // this.maxFundEmpty = false;
          // this.minFundEmpty = false;
          // this.FundAccountEmpty = false;
          maxFundErrCnt = maxFundErrCnt++;
          minFundErrCnt = minFundErrCnt++;
          window.scroll(0, 0);
          // setTimeout(() => {
          //   this.maxFundErr = false;
          // }, 5000);
        }
      }
      //total value validation
      this.callTotalAccountValueValidation(url, req, headers);
      if (!this.minFundErr && !this.maxFundErr && !this.FundAccountEmpty && minFundErrCnt == 0 && maxFundErrCnt == 0) {
        this.callApi(url, req, headers);
      }
      //(this.accountMonitoring.controls.fundPriceDTOs.value);
    } else {

    }
  }
  callApi(url, req, headers) {
    if ((((this.accountMonitoring.value.accountMaxValue != null || this.accountMonitoring.value.accountMaxValue != "") && (this.accountMonitoring.value.accountMinValue != "" || this.accountMonitoring.value.accountMinValue != null))
      || (this.reqFund.length != 0 && !this.minFundErr && !this.maxFundErr))
      && ((this.personalInfo.emailBasic != null && (this.accountMonitoring.value.emailSelect != "0") && (this.accountMonitoring.value.email != "")
        && (!this.FundAccountEmpty) && (!this.invalidEmail)) || (this.personalInfo.emailBasic == null && (this.accountMonitoring.value.email != "")
          && (!this.FundAccountEmpty) && (!this.invalidEmail)))) {
      this.commonService['postData'](url, req, headers).subscribe(data => {
        //response goes here
        this.submitSuccess = true;
        this.formSubmitted = false;
        this.accountMonitoring.reset();
        this.FundAccountEmpty = false;
        this.maxAccountErr = false;
        this.minAccountErr = false;
        this.emailEmpty = false;
        this.maxFundErr = false;
        this.minFundErr = false;
        this.invalidEmail = false;
      });
    }

  }

  callTotalAccountValueValidation(url, req, headers) {
    // this.maxFundErr = false;
    //this.maxFundEmpty = false;
    // this.minFundEmpty = false;
    // this.minFundErr = false;
    this.minAccountEmptyErr = false;
    this.maxAccountEmptyErr = false;
    if (this.accountMonitoring.value.accountMaxValue != '' && this.accountMonitoring.value.accountMinValue == '') {
      // setTimeout(() => {
      //   this.maxAccountErr = false;
      // }, 5000);
      this.minAccountEmptyErr = true;
      // this.maxAccountEmptyErr = false;
      // this.maxAccountErr = false;
      // this.minAccountErr = false;
      // this.FundAccountEmpty = true;
      window.scroll(0, 0);
    }
    if (this.accountMonitoring.value.accountMaxValue == '' && this.accountMonitoring.value.accountMinValue != '') {
      // setTimeout(() => {
      //   this.maxAccountErr = false;
      // }, 5000);
      this.maxAccountEmptyErr = true;
      // this.minAccountEmptyErr = false;
      // this.maxAccountErr = false;
      // this.minAccountErr = false;
      // this.FundAccountEmpty = true;
      window.scroll(0, 0);
    }
    if (this.accountMonitoring.value.accountMaxValue != "" && this.accountMonitoring.value.accountMinValue != "" &&
      (parseFloat(this.accountMonitoring.value.accountMaxValue) < parseFloat(this.accountDetail.accountValue)) &&
      (parseFloat(this.accountMonitoring.value.accountMinValue) > parseFloat(this.accountDetail.accountValue))) {
      //account max filed validation
      // setTimeout(() => {
      //   this.maxAccountErr = false;
      //   this.minAccountErr = false;
      //   window.scroll(0, 0);
      // }, 5000);
      this.maxAccountErr = true;
      this.minAccountErr = true;
      // this.maxAccountEmptyErr = false;
      // this.minAccountEmptyErr = false;
      // this.FundAccountEmpty = false;
      window.scroll(0, 0);
    }
    if (this.accountMonitoring.value.accountMaxValue != "" &&
      (parseFloat(this.accountMonitoring.value.accountMaxValue) < parseFloat(this.accountDetail.accountValue))) {
      // setTimeout(() => {
      //   this.maxAccountErr = false;
      // }, 5000);
      this.maxAccountErr = true;
      // this.minAccountErr = false;
      // this.maxAccountEmptyErr = false;
      // this.minAccountEmptyErr = false;
      // this.FundAccountEmpty = false;
      window.scroll(0, 0);
    }
    if (this.accountMonitoring.value.accountMinValue != "" && (parseFloat(this.accountMonitoring.value.accountMinValue) > parseFloat(this.accountDetail.accountValue))) {
      //account min field validation
      // setTimeout(() => {
      //   this.minAccountErr = false;
      // }, 5000);
      this.minAccountErr = true;
      // this.maxAccountErr = false;
      // this.maxAccountEmptyErr = false;
      // this.minAccountEmptyErr = false;
      // this.FundAccountEmpty = false;
      window.scroll(0, 0);
    } else {
      // this.FundAccountEmpty = false;
      // this.minAccountErr = false;
      // this.maxAccountErr = false;
      // this.maxAccountEmptyErr = false;
      // this.minAccountEmptyErr = false;
      //this.callApi(url, req, headers);
    }
    if (!this.minAccountErr && !this.maxAccountErr && !this.maxAccountEmptyErr && !this.minAccountEmptyErr && !this.FundAccountEmpty) {
      this.callApi(url, req, headers);
    } else { }
  }

  callUnitValuesValidation(minFundErrCnt, maxFundErrCnt) {
    // let minFundErrCnt = 0;
    //   let maxFundErrCnt = 0;
    this.maxFundEmpty = false;
    this.minFundEmpty = false;
    this.maxFundErr = false;
    this.minFundErr = false;
    //check formarray fund rows validation
    for (let i = 0; i < this.accountMonitoring.controls.fundPriceDTOs.value.length; i++) {
      if ((this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation == "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation != "")) {
        // setTimeout(() => {
        //   this.FundAccountEmpty = false;
        // }, 5000);
        this.maxFundEmpty = true;
        // this.minFundEmpty = false;
        // this.maxFundErr = false;
        // this.minFundErr = false;
        this.FundAccountEmpty = true;
        window.scroll(0, 0);
      }
      if ((this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation == "")) {
        // setTimeout(() => {
        //   this.FundAccountEmpty = false;
        // }, 5000);
        this.minFundEmpty = true;
        // this.maxFundEmpty = false;
        // this.maxFundErr = false;
        // this.minFundErr = false;
        this.FundAccountEmpty = true;
        window.scroll(0, 0);
      }
      if ((this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation < this.accountMonitoring.controls.fundPriceDTOs.value[i].unitPriceActual)) {
        // setTimeout(() => {
        this.accountMonitoring.controls.fundPriceDTOs.value[i].maxFieldErr = true;
        this.maxFundErr = true;
        // this.maxFundEmpty = false;
        // this.minFundEmpty = false;
        // this.minFundErr = false;
        // this.FundAccountEmpty = false;
        maxFundErrCnt = maxFundErrCnt++;
        window.scroll(0, 0);
        // setTimeout(() => {
        //   this.maxFundErr = false;
        // }, 5000);
      }
      if ((this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation > this.accountMonitoring.controls.fundPriceDTOs.value[i].unitPriceActual)) {
        //setTimeout(() => {
        this.accountMonitoring.controls.fundPriceDTOs.value[i].minFiledErr = true;
        this.minFundErr = true;
        // this.maxFundErr = false;
        // this.maxFundEmpty = false;
        // this.minFundEmpty = false;
        // this.FundAccountEmpty = false;
        minFundErrCnt = minFundErrCnt++;
        window.scroll(0, 0);
        // }, 300);
        // setTimeout(() => {
        //   this.minFundErr = false;
        // }, 5000)
      }
      if ((this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation < this.accountMonitoring.controls.fundPriceDTOs.value[i].unitPriceActual)
        && (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation != "") && (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation > this.accountMonitoring.controls.fundPriceDTOs.value[i].unitPriceActual)) {
        // setTimeout(() => {
        this.accountMonitoring.controls.fundPriceDTOs.value[i].maxFieldErr = true;
        this.maxFundErr = true;
        this.accountMonitoring.controls.fundPriceDTOs.value[i].minFiledErr = true;
        this.minFundErr = true;
        // this.maxFundEmpty = false;
        // this.minFundEmpty = false;
        // this.FundAccountEmpty = false;
        maxFundErrCnt = maxFundErrCnt++;
        minFundErrCnt = minFundErrCnt++;
        window.scroll(0, 0);
        // setTimeout(() => {
        //   this.maxFundErr = false;
        // }, 5000);
      }
    }
  }

  getFundPriceDTOs() {
    let arr = [];
    for (let i = 0; i < this.accountMonitoring.controls.fundPriceDTOs.value.length; i++) {
      if (this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation || this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation) {
        const Object =
        {
          "fundCode": "",//"36",
          "fundName": "",//"Leu confortabil",
          "minimumFundAllocation": "",//"200.0000 RON",
          "maximumFundAllocation": "",//200,
        };
        Object.fundCode = this.accountMonitoring.controls.fundPriceDTOs.value[i].fundCode,
          Object.fundName = this.accountMonitoring.controls.fundPriceDTOs.value[i].fundName,
          Object.minimumFundAllocation = this.accountMonitoring.controls.fundPriceDTOs.value[i].minimumFundAllocation,
          Object.maximumFundAllocation = this.accountMonitoring.controls.fundPriceDTOs.value[i].maximumFundAllocation
        arr.push(Object);
      }
    }
    this.reqFund = arr;
  }

  gotoHome() {
    const menuItemList = JSON.parse(sessionStorage.getItem('menuItemList'));
    this.menuItemService.navigationBasedOnRole(menuItemList);
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;

    if (charCode != 46 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  numberValue1(event, itemrow, action) {
    // let clipboardData = event.clipboardData;
    // let pastedText = clipboardData.getData('text');
    let pastedText;
    if (action == 'paste') {
      let clipboardData = event.clipboardData;
      pastedText = clipboardData.getData('text');
    } else {
      pastedText = event.target.value;
      // let pastedText = clipboardData.getData('text');
    }
    event.preventDefault();
    let ctrl = itemrow.get('minimumFundAllocation') as FormControl;
    ctrl.setValue(this.transform.transform(pastedText, this.country), { emitEvent: false, emitViewToModelChange: false });
    // ctrl.setValue(ctrl.value.substr(0,));
    this.numberValueFormat(ctrl);
  }

  numberValue2(event, itemrow, action) {
    // let clipboardData = event.clipboardData;
    // let pastedText = clipboardData.getData('text');
    let pastedText;
    if (action == 'paste') {
      let clipboardData = event.clipboardData;
      pastedText = clipboardData.getData('text');
    } else {
      pastedText = event.target.value;
      // let pastedText = clipboardData.getData('text');
    }
    let ctrl2 = itemrow.get('maximumFundAllocation') as FormControl;
    event.preventDefault();
    ctrl2.setValue(this.transform.transform(pastedText, this.country), { emitEvent: false, emitViewToModelChange: false });
    // ctrl2.setValue(ctrl2.value.substr(0, 8));
    this.numberValueFormat(ctrl2);
  }

  minValueTranform(event, action) {
    // let clipboardData = event.clipboardData;
    // let pastedText = clipboardData.getData('text');
    let pastedText;
    if (action == 'paste') {
      let clipboardData = event.clipboardData;
      pastedText = clipboardData.getData('text');
    } else {
      pastedText = event.target.value;
      // let pastedText = clipboardData.getData('text');
    }
    let ctrl2 = this.accountMonitoring.get('accountMinValue') as FormControl;
    event.preventDefault();
    ctrl2.setValue(this.transform.transform(pastedText, this.country), { emitEvent: false, emitViewToModelChange: false });
    //ctrl2.setValue(ctrl2.value.substr(0, 8));
    this.numberValueFormat(ctrl2)
  }
  maxValueTranform(event, action) {
    // let clipboardData = event.clipboardData;
    // let pastedText = clipboardData.getData('text');
    let pastedText;
    if (action == 'paste') {
      let clipboardData = event.clipboardData;
      pastedText = clipboardData.getData('text');
    } else {
      pastedText = event.target.value;
      // let pastedText = clipboardData.getData('text');
    }
    let ctrl2 = this.accountMonitoring.get('accountMaxValue') as FormControl;
    event.preventDefault();
    ctrl2.setValue(this.transform.transform(pastedText, this.country), { emitEvent: false, emitViewToModelChange: false });
    //ctrl2.setValue(ctrl2.value.substr(0, 8));
    this.numberValueFormat(ctrl2);
  }

  numberValueFormat(contrl) {
    if (contrl.value != null) {
      let numeric = (contrl.value).toString();
      // if (this.langChange == 'pl' || this.langChange == 'ro') {
      //   if (numeric.includes(',')) {
      //     let checkNumeric = numeric.split(',');
      //     if (checkNumeric.length > 2) {
      //       ctrl.setValue(checkNumeric[0].substr(0,8) + ',' + checkNumeric[1].substr(0,2));
      //       return false;
      //     }
      //     this.checkString = checkNumeric[1].split('');
      //     if (this.checkString.length <= 2) {
      //       ctrl.setValue(checkNumeric[0].substr(0,8) + ',' + checkNumeric[1].substr(0,2));
      //       // this.toastrService.warning("Invalid value", "Warning");
      //       // return false;
      //     } else {
      //       let afterDot = checkNumeric[1].substr(0, 2);
      //       ctrl.setValue(checkNumeric[0].substr(0,8) + ',' + afterDot);
      //       // return true;
      //     }
      //   }else{
      //     ctrl.setValue(numeric.substr(0,8));
      //   }
      // } else {
      if (numeric.includes('.')) {
        let checkNumeric = numeric.split('.');
        if (checkNumeric.length > 2) {
          contrl.setValue(checkNumeric[0].substr(0, 8) + '.' + checkNumeric[1].substr(0, 4));
          return false;
        }
        this.checkString = checkNumeric[1].split('');
        if (this.checkString.length <= 2) {
          contrl.setValue(checkNumeric[0].substr(0, 8) + '.' + checkNumeric[1].substr(0, 4));
          // this.toastrService.warning("Invalid value", "Warning");
          // return false;
        } else {
          let afterDot = checkNumeric[1].substr(0, 4);
          contrl.setValue(checkNumeric[0].substr(0, 8) + '.' + afterDot);
          //return true;
        }
      } else {
        contrl.setValue(numeric.substr(0, 8));
      }
      // }
      let reg1Str;
      let temp = contrl.value;//obj.value;
      let decimalValue;
      decimalValue = '.';
      // if (this.langChange == 'en') {
      //   decimalValue = '.';
      // }
      // else {
      //   decimalValue = ',';
      // }

      let decimalPlaces = 4;
      let reg0Str = '[0-9]*';
      if (decimalPlaces > 0) {
        reg0Str += '\\.?[0-9]{0.' + decimalPlaces + '}';
        // if (this.langChange == 'en') {
        //   reg0Str += '\\.?[0-9]{0.' + decimalPlaces + '}';
        // }
        // else {
        //   reg0Str += '\\,?[0-9]{0,' + decimalPlaces + '}';
        // }
      } else if (decimalPlaces < 0) {
        reg0Str += '\\.?[0-9]*';
        // if (this.langChange == 'en') {
        //   reg0Str += '\\.?[0-9]*';
        // }
        // else {
        //   reg0Str += '\\,?[0-9]*';
        // }
      }
      if (decimalPlaces != 0) {
        let reg3;
        reg3 = /\./g;
        // if (this.langChange == 'en') {
        //   reg3 = /\./g;
        // }
        // else {
        //   reg3 = /\,/g;
        // }
        let reg3Array = reg3.exec(temp);
        if (reg3Array != null) {
          // keep only first occurrence of .
          //  and the number of places specified by decimalPlaces or the entire string if 

          decimalPlaces < 0
          let reg3Right = temp.substring(reg3Array.index + reg3Array[0].length);
          reg3Right = reg3Right.replace(reg3, '');
          reg3Right = decimalPlaces > 0 && (temp.indexOf('.') < 8) ? reg3Right.substring(0, decimalPlaces) : reg3Right.substring(0, 2);
          temp = temp.substring(0, reg3Array.index) + decimalValue + reg3Right;
        }
      }

      // obj.value = temp;
      contrl.setValue(temp);
      return true;
    }
  }

  emailDropdownChange(event) {
    //console.log(event.target.value)
    if (event.target.value == 'Other' || event.target.value == 'Alta') {
      this.accountMonitoring.value.email = "";
      this.accountMonitoring.get('email').setValue("");
    }
  }
}
export class Account {
  fundName: string;
  unitPrice: number;
  minimumFundAllocation: number;
  maximumFundAllocation: number;

  static asFormGroup(account: Account): FormGroup {
    const fg = new FormGroup({
      fundName: new FormControl(account.fundName, Validators.required),
      unitPrice: new FormControl(account.unitPrice, Validators.required),
      minimumFundAllocation: new FormControl(account.minimumFundAllocation, Validators.required),
      maximumFundAllocation: new FormControl(account.maximumFundAllocation, Validators.required)
    });
    return fg;
  }
}
export class AccountValue {
  accountValue: number;
  accountThresholdValue: number;
}

