import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FundPriceMonitoringRoutingModule } from './fund-price-monitoring-routing.module';
import { FundPricMonitoringComponent } from './fund-pric-monitoring.component';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule, MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule,
  MatProgressSpinnerModule, MatExpansionModule, MatTabsModule, MatTooltipModule,
  MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatInputModule,
  MatSortModule, MatTableModule, MatPaginatorModule
} from '@angular/material';
import { SharedModule } from '../shared/shared.module';

const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule,];

@NgModule({
  declarations: [
    FundPricMonitoringComponent
  ],
  imports: [
    CommonModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    ...materialModule,
    FundPriceMonitoringRoutingModule,
    SharedModule
  ]

})
export class FundPriceMonitoringModule { }
