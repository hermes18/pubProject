import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { AppModule } from '../app.module';

import { FundPricMonitoringComponent } from './fund-pric-monitoring.component';
import { FundPriceMonitoringModule } from './fund-price-monitoring.module';

describe('FundPricMonitoringComponent', () => {
  let component: FundPricMonitoringComponent;
  let fixture: ComponentFixture<FundPricMonitoringComponent>;
  const host = 'http://10.65.153.19:9080/emea';
  window['__env'] = window['__env'] || {};
  const environmentConstURL =
  {
    api: {
      'ecustomer': {
        'fundPriceSubmit': host + '/api/v1/order/target-fund'
      }
    }
  };


  beforeEach(() => {
    window['__env'].environmentConstURLs = environmentConstURL;

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, FundPriceMonitoringModule, HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: []
    })
      .compileComponents();
    const userdetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    const customerId = JSON.parse(sessionStorage.getItem('searcClientID'));
    fixture = TestBed.createComponent(FundPricMonitoringComponent);
    component = fixture.componentInstance;
    component.accountDetail = null;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call init value method', () => {
    component.initValues();
  });

  it('should call form array value method', () => {
    component.fundPriceDTOs();
  });

  it('should call fund price list method', () => {
    component.getFundPriceDTOs();
  });

  xit('should call email dropdown change method', () => {
    component.emailDropdownChange('Other');
  });

  xit('should call home navigation method', () => {
    component.gotoHome();
  });

  xit('should call number only method', () => {
    component.numberOnly(null);
  });





});


