import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { AppModule } from '../app.module';
import { SharedServiceService } from '../shared-service/shared-service.service';

import { MyCompanyComponent } from './my-company.component';
import { MyCompanyModule } from './my-company.module';
import { of } from 'rxjs';
import { HttpClient } from '@angular/common/http';

describe('MyCompanyComponent', () => {
  let component: MyCompanyComponent;
  let fixture: ComponentFixture<MyCompanyComponent>;
  const menuList = {
    activeContractDetails: null,
    billingRecipent: null,
    callRetrievePolicies: false,
    callRetriveClientData: false,
    callRetriveClientOffers: false,
    ccDBAddressDTO: {
      ccdbFullAddress: "https://10.112.202.48/ccdb-web/",
      ccdbAddressPart2: ""
    },
    claimList: null,
    clientAdministration: true,
    clientId: "",
    clientIdList: [],
    clientIdbillControlList: [],
    clientLoginId: null,
    clientRoleIds: "3033|3034",
    clientRoleNames: "rSuperUser|rAdmnistrator",
    contractList: null,
    documentsList: null,
    eClaimsURL: "https://qa.eclaim.metlife.pl?countryCode=pl&sourcekey=2de4f0048fbe84b96a9ae77801b5c9db5cbc0b01056e7f539f9c61c57820e9f2d97a66b1701d9b29a80596a211ca3460e22ab4a70a2b886995e3826482fec79fa890f1f92293e6961ccd91c419c3efe9642d615c7d69b2a7",
    fundPriceDetails: null,
    menuItems: [{ menuId: "2", accessSpec: "RW", menuName: "Clients Administration", parentMenu: "Administration" }],
    offerResponse: null,
    orderHistory: null,
    personalInformationDTO: null,
    renderClaims: false,
    renderDocuments: false,
    renderFundPriceMonitoring: false,
    renderMyCompany: false,
    renderMyContract: false,
    renderMyData: false,
    renderOffers: false,
    renderOrderReview: false,
    renderUserAcctAdministration: true,
    route: "DisplayClientSearch",
    searchFlag: false,
    wardenRoleCheck: false
  };
  // beforeEach(async(() => {

  // }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, MyCompanyModule, HttpClientTestingModule, TranslateModule.forRoot()],
      providers: [HttpClient, { provide: 'Window', useFactory: () => window }],
      declarations: []
    })
      .compileComponents();
    fixture = TestBed.createComponent(MyCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    let commonService = TestBed.get(SharedServiceService);
    spyOn(commonService, 'getDetail').and.returnValue(of(menuList));
    //  commonService.getDetail('menuItemList');
    // spyOn(SharedServiceService.prototype, 'getDetail').and.returnValue(of(menuList));
    expect(component).toBeTruthy();
  });
  it('gotoHome  should call', () => {
    spyOn(component.router, 'navigate').and.callThrough();
    component.gotoHome();
    expect(component.router.navigate ).toHaveBeenCalled();
  });
});
