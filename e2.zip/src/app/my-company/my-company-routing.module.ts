import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavigationGuard } from '../core/gaurds/navigation-guard';
import { MyCompanyComponent } from './my-company.component';


const routes: Routes = [
  { path: '', component: MyCompanyComponent, canDeactivate: [NavigationGuard] }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MyCompanyRoutingModule { }
