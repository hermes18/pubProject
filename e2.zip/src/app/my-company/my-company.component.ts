import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConfig } from 'src/config/app.config';
import { SharedServiceService } from '../shared-service/shared-service.service';
import { HttpCommonService } from '../shared/services/http-common.service';

@Component({
  selector: 'my-company',
  templateUrl: './my-company.component.html',
  styleUrls: ['./my-company.component.scss']
})
export class MyCompanyComponent implements OnInit {
  myCompanyRequest;
  user: any;
  appConfig: AppConfig = AppConfig.getConfig();
  baseUrl = this.appConfig['api'];
  contractListDataActive: any = [];
  myCompanyPersonalDetails;
  myCompanyPolicyDetails;
  billControlDetails;
  constructor(public commonhttpService: HttpCommonService, public router: Router, public sharedService: SharedServiceService) { }

  ngOnInit() {
    // let searchedClientDetails = JSON.parse(sessionStorage.getItem('searchedClientDetails'));
    // let loggedInUserDetail = JSON.parse(sessionStorage.getItem('loggedInUserInfo'));
    // this.myCompanyRequest = {
    //  clientId: searchedClientDetails ? searchedClientDetails.customerId : '',
    //   requesterId: loggedInUserDetail ? loggedInUserDetail.requesterId : '',
    //   requesterRole: loggedInUserDetail ? loggedInUserDetail.requesterRole : '',
    //   userId: loggedInUserDetail ? loggedInUserDetail.userName : '',

    // }
    // this.commonhttpService.postData(this.baseUrl.ecustomer.wardenSearch, this.myCompanyRequest, '').subscribe(data => {
    //   //("warden retrival data3", data)

    //   if (data && (data.activeContractDetails != null && data.activeContractDetails != '')) {
    //     this.contractListDataActive = [];
    //     this.user = this.contractListDataActive;
    //   }
    // })
    this.sharedService.getDetail('menuItemList').subscribe((data) => {
      if (data) {
        this.myCompanyPolicyDetails = data ? data.activeContractDetails[0].contractDetailsDTO : '';
        this.myCompanyPersonalDetails = data.personalInformationDTO;
        this.billControlDetails = data.billingRecipent[0]
        //(data)
        //("activee",this.myCompanyPolicyDetails);
        //("active",this.myCompanyPersonalDetails);
      }
    })

  }
  // editCompanyDetails() {

  // }
  gotoHome() {
    this.router.navigate(['/homepage'])

  }
}
