import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MyCompanyRoutingModule } from './my-company-routing.module';
import { MyCompanyComponent } from './my-company.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule, MatSidenavModule, MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule, MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatInputModule, MatPaginatorModule, MatSortModule, MatTableModule } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { NgxPaginationModule } from 'ngx-pagination';
import { SharedModule } from '../shared/shared.module';



const materialModule = [MatIconModule, MatDialogModule, MatToolbarModule, MatButtonModule,
  MatSidenavModule,
  MatListModule, MatCardModule, MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule,
  MatExpansionModule, MatTabsModule, MatTooltipModule, MatDatepickerModule, MatNativeDateModule,
  MatSnackBarModule, MatInputModule, MatPaginatorModule,
  MatSortModule, MatTableModule,];
@NgModule({
  declarations: [MyCompanyComponent],
  imports: [
    CommonModule,
    MyCompanyRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    ...materialModule,
    NgxPaginationModule,
    SharedModule
  ]
})
export class MyCompanyModule { }
